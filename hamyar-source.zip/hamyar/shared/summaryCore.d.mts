export interface PageText {
  n: number;
  text: string;
}
export interface ModelSummary {
  overview: string;
  highlights: { text: string; pageNumbers: number[] }[];
  actionItems: { text: string; pageNumbers: number[] }[];
  caveats: string[];
}
export interface FinalSummary extends ModelSummary {
  coveredPages: number[];
  totalPages: number;
  language: 'fa' | 'en';
}
export interface Chunk {
  pages: number[];
  parts: PageText[];
  size: number;
}
export interface Prompt {
  system: string;
  user: string;
}
export type CompleteFn = (p: Prompt & { schema: object; signal?: AbortSignal }) => Promise<string | object>;

export const PROMPT_VERSION: string;
export const MODEL_SUMMARY_SCHEMA: object;
export function buildChunks(pages: PageText[], maxChars: number): Chunk[];
export function buildMapPrompt(o: { chunk: Chunk; language: 'fa' | 'en'; length: 'short' | 'medium'; totalPages: number; partial: boolean }): Prompt;
export function buildReducePrompt(o: { partials: ModelSummary[]; language: 'fa' | 'en'; length: 'short' | 'medium'; totalPages: number }): Prompt;
export function parseModelJson(text: unknown): unknown;
export function validateModelSummary(
  raw: unknown,
  ctx: { allowedPages: number[] },
): { ok: true; value: ModelSummary; dropped: number } | { ok: false; errors: string[] };
export function finalizeSummary(model: ModelSummary, meta: { coveredPages: number[]; totalPages: number; language: 'fa' | 'en'; dropped?: number }): FinalSummary;
export function summarizeDocument(o: {
  pages: PageText[];
  totalPages: number;
  language: 'fa' | 'en';
  length: 'short' | 'medium';
  maxChars: number;
  complete: CompleteFn;
  signal?: AbortSignal;
  onProgress?: (done: number, total: number) => void;
}): Promise<FinalSummary>;
