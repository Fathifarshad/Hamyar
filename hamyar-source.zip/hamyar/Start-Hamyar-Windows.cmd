@echo off
title Hamyar
rem Double-click this file to start Hamyar. Keep the window open while you use it.
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js is not installed.
  echo   Install the LTS version from https://nodejs.org and then double-click this file again.
  echo.
  pause
  exit /b 1
)
if not exist "server\index.mjs" (
  echo.
  echo   This file must stay inside the hamyar folder, next to README.md and the server folder.
  echo.
  pause
  exit /b 1
)
node server\index.mjs --open
echo.
pause
