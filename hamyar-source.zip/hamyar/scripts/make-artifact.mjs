// Turns the `vite build --mode artifact` output into one self-contained page for the
// claude.ai Artifact viewer: JS and CSS are inlined, and the document skeleton
// (doctype/html/head/body) is removed because the viewer adds its own.
//
// Output: dist-artifact/hamyar.html (+ dist-artifact/samples/ for the example PDF).
import { copyFileSync, existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const outDir = join(root, 'dist-artifact');
const html = readFileSync(join(outDir, 'index.html'), 'utf8');

const scripts = [...html.matchAll(/<script[^>]*\bsrc="([^"]+)"[^>]*><\/script>/g)].map((m) => m[1]);
const styles = [...html.matchAll(/<link[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g)].map((m) => m[1]);
if (scripts.length !== 1) throw new Error(`expected one script in the artifact build, found ${scripts.length}`);

const read = (rel) => readFileSync(join(outDir, rel.replace(/^\.\//, '')), 'utf8');

// Inline code must not close its own element early or open an HTML comment state.
const js = read(scripts[0]).replace(/<\/(script)/gi, '<\\/$1').replace(/<!--/g, '<\\!--');
const css = styles.map(read).join('\n').replace(/<\/(style)/gi, '<\\/$1');

const title = html.match(/<title>[\s\S]*?<\/title>/)?.[0] ?? '<title>همیار</title>';
const description = html.match(/<meta name="description"[^>]*>/)?.[0] ?? '';

const page = [
  title,
  description,
  `<style>${css}</style>`,
  '<div id="root"></div>',
  '<noscript>همیار برای اجرا به JavaScript نیاز دارد.</noscript>',
  `<script type="module">${js}</script>`,
  '',
].join('\n');

const outFile = join(outDir, 'hamyar.html');
writeFileSync(outFile, page);

const sample = join(root, 'public', 'samples', 'hamyar-sample-fa.pdf');
if (existsSync(sample)) {
  mkdirSync(join(outDir, 'samples'), { recursive: true });
  copyFileSync(sample, join(outDir, 'samples', 'hamyar-sample-fa.pdf'));
}

const mb = (statSync(outFile).size / 1024 / 1024).toFixed(2);
console.log(`artifact page: ${outFile} (${mb} MiB)`);
if (Number(mb) > 15.5) throw new Error('artifact page is too close to the 16 MiB limit');
