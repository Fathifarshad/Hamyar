#!/usr/bin/env python3
"""Applies Hamyar's look and settings to the generated Capacitor Android project.

Run once after `npx cap add android` (needs Python 3 + Pillow). The result is kept in
android/, so the GitHub build does not need Python. Re-running is safe.
"""
from pathlib import Path
import re

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / 'android' / 'app' / 'src' / 'main' / 'res'
MANIFEST = ROOT / 'android' / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
GRADLE = ROOT / 'android' / 'app' / 'build.gradle'

TEAL = (15, 118, 110, 255)
WHITE = (255, 255, 255, 255)
SOFT = (255, 255, 255, 97)  # white at 38%
MINT = (94, 234, 212, 255)
SS = 4  # supersampling for smooth edges

DENSITIES = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}


def glyph(draw: ImageDraw.ImageDraw, x0: float, y0: float, size: float) -> None:
    """The four-tile mark: size is the side of the whole glyph."""
    tile = size * 100 / 220
    gap = size - 2 * tile
    r = tile * 0.3
    tiles = [
        (x0, y0, WHITE, r),
        (x0 + tile + gap, y0, SOFT, r),
        (x0, y0 + tile + gap, SOFT, r),
        (x0 + tile + gap, y0 + tile + gap, MINT, tile / 2),
    ]
    for x, y, color, radius in tiles:
        draw.rounded_rectangle([x, y, x + tile, y + tile], radius=radius, fill=color)


def glyph_layer(w: int, h: int, size: float) -> Image.Image:
    """The mark on its own transparent layer, so translucent tiles blend when composited."""
    layer = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    glyph(ImageDraw.Draw(layer), (w - size) / 2, (h - size) / 2, size)
    return layer


def render(px: int, kind: str) -> Image.Image:
    """kind: 'square' (rounded app icon), 'round', 'foreground' (adaptive, transparent)."""
    n = px * SS
    img = Image.new('RGBA', (n, n), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if kind == 'square':
        d.rounded_rectangle([0, 0, n - 1, n - 1], radius=n * 0.22, fill=TEAL)
        size = n * 0.56
    elif kind == 'round':
        d.ellipse([0, 0, n - 1, n - 1], fill=TEAL)
        size = n * 0.5
    else:  # adaptive foreground on a 108dp canvas; keep inside the 66dp safe zone
        size = n * 46 / 108
    img.alpha_composite(glyph_layer(n, n, size))
    return img.resize((px, px), Image.LANCZOS)


def splash(width: int, height: int) -> Image.Image:
    n_w, n_h = width * SS, height * SS
    img = Image.new('RGBA', (n_w, n_h), TEAL)
    img.alpha_composite(glyph_layer(n_w, n_h, min(n_w, n_h) * 0.22))
    return img.resize((width, height), Image.LANCZOS).convert('RGB')


def icons() -> None:
    for name, scale in DENSITIES.items():
        folder = RES / f'mipmap-{name}'
        folder.mkdir(parents=True, exist_ok=True)
        render(round(48 * scale), 'square').save(folder / 'ic_launcher.png', optimize=True)
        render(round(48 * scale), 'round').save(folder / 'ic_launcher_round.png', optimize=True)
        render(round(108 * scale), 'foreground').save(folder / 'ic_launcher_foreground.png', optimize=True)
    (RES / 'values' / 'ic_launcher_background.xml').write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0F766E</color>\n</resources>\n',
        encoding='utf-8',
    )
    # The template's vector Capacitor logo is not referenced by the adaptive icon; drop it.
    for stale in [RES / 'drawable-v24' / 'ic_launcher_foreground.xml', RES / 'drawable' / 'ic_launcher_background.xml']:
        if stale.exists():
            stale.unlink()


def splashes() -> None:
    for path in RES.glob('drawable*/splash.png'):
        with Image.open(path) as old:
            w, h = old.size
        splash(w, h).save(path, optimize=True)


def notification_icon() -> None:
    """Status-bar icon: Android shows it as a white silhouette."""
    (RES / 'drawable').mkdir(exist_ok=True)
    (RES / 'drawable' / 'ic_stat_hamyar.xml').write_text(
        '''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M5.5,3.5h4a2,2 0 0 1 2,2v4a2,2 0 0 1 -2,2h-4a2,2 0 0 1 -2,-2v-4a2,2 0 0 1 2,-2z" />
    <path
        android:fillColor="#FFFFFFFF"
        android:fillAlpha="0.55"
        android:pathData="M14.5,3.5h4a2,2 0 0 1 2,2v4a2,2 0 0 1 -2,2h-4a2,2 0 0 1 -2,-2v-4a2,2 0 0 1 2,-2z" />
    <path
        android:fillColor="#FFFFFFFF"
        android:fillAlpha="0.55"
        android:pathData="M5.5,12.5h4a2,2 0 0 1 2,2v4a2,2 0 0 1 -2,2h-4a2,2 0 0 1 -2,-2v-4a2,2 0 0 1 2,-2z" />
    <path
        android:fillColor="#FFFFFFFF"
        android:pathData="M16.5,12.5a4,4 0 1 1 0,8a4,4 0 1 1 0,-8z" />
</vector>
''',
        encoding='utf-8',
    )


def styles() -> None:
    path = RES / 'values' / 'styles.xml'
    s = path.read_text(encoding='utf-8')
    if 'windowSplashScreenBackground' not in s:
        s = s.replace(
            '<item name="android:background">@drawable/splash</item>',
            '<item name="android:background">@drawable/splash</item>\n'
            '        <item name="windowSplashScreenBackground">#0F766E</item>\n'
            '        <item name="postSplashScreenTheme">@style/AppTheme.NoActionBar</item>',
        )
    path.write_text(s, encoding='utf-8')


def manifest() -> None:
    s = MANIFEST.read_text(encoding='utf-8')
    # Personal health data stays on the phone: no automatic cloud backup.
    s = s.replace('android:allowBackup="true"', 'android:allowBackup="false"')
    extra = [
        # exact reminder times on Android 13+ (granted at install for sideloaded apps)
        '<uses-permission android:name="android.permission.USE_EXACT_ALARM" />',
        # microphone recording inside the web view (voice notes / recorder)
        '<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />',
        '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
    ]
    for line in extra:
        if line not in s:
            s = s.replace('<uses-permission android:name="android.permission.INTERNET" />', f'<uses-permission android:name="android.permission.INTERNET" />\n    {line}')
    MANIFEST.write_text(s, encoding='utf-8')


def gradle() -> None:
    s = GRADLE.read_text(encoding='utf-8')
    if 'HAMYAR_VERSION_CODE' not in s:
        s = s.replace('versionCode 1', "versionCode((System.getenv('HAMYAR_VERSION_CODE') ?: '1') as Integer)")
        s = s.replace('versionName "1.0"', "versionName(System.getenv('HAMYAR_VERSION_NAME') ?: '0.1.0')")
    if 'signingConfigs' not in s:
        s = s.replace(
            '    buildTypes {\n        release {\n            minifyEnabled false',
            '''    // Release signing comes from the build machine (GitHub Actions secrets); see .github/workflows.
    def hamyarKeystore = System.getenv('HAMYAR_KEYSTORE_FILE')
    signingConfigs {
        release {
            if (hamyarKeystore) {
                storeFile file(hamyarKeystore)
                storePassword System.getenv('HAMYAR_KEYSTORE_PASSWORD')
                keyAlias(System.getenv('HAMYAR_KEY_ALIAS') ?: 'hamyar')
                keyPassword(System.getenv('HAMYAR_KEY_PASSWORD') ?: System.getenv('HAMYAR_KEYSTORE_PASSWORD'))
            }
        }
    }
    buildTypes {
        release {
            if (hamyarKeystore) {
                signingConfig signingConfigs.release
            }
            minifyEnabled false''',
        )
    if 'checkReleaseBuilds' not in s:
        # Store-policy lint checks (e.g. exact alarms) do not apply to a personal, sideloaded app.
        s = s.replace(
            '    namespace = "app.hamyar.personal"\n',
            '    namespace = "app.hamyar.personal"\n    lint {\n        checkReleaseBuilds false\n        abortOnError false\n    }\n',
        )
    GRADLE.write_text(s, encoding='utf-8')


if __name__ == '__main__':
    icons()
    splashes()
    notification_icon()
    styles()
    manifest()
    gradle()
    print('android project customized')
