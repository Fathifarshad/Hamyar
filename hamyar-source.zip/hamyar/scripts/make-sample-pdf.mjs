/* global document -- used inside a page.evaluate callback, which runs in the browser */
// Builds public/samples/hamyar-sample-fa.pdf — an original 3-page Persian guide used as
// example content. Rendered by headless Chromium so Persian shaping and text extraction work.
import { chromium } from 'playwright-core';
import { mkdirSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { chromiumPath } from './chromium.mjs';

const font = pathToFileURL(resolve('node_modules/@fontsource-variable/vazirmatn/files/vazirmatn-arabic-wght-normal.woff2')).toString();
const fontLatin = pathToFileURL(resolve('node_modules/@fontsource-variable/vazirmatn/files/vazirmatn-latin-wght-normal.woff2')).toString();

const html = `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><style>
@font-face{font-family:V;src:url(${font}) format('woff2');font-weight:100 900;unicode-range:U+0600-06FF,U+200C-200F,U+FB50-FDFF,U+FE70-FEFF}
@font-face{font-family:V;src:url(${fontLatin}) format('woff2');font-weight:100 900}
@page{size:A5;margin:18mm 16mm}
body{font-family:V,sans-serif;font-size:11pt;line-height:2;color:#182230}
h1{font-size:19pt;margin:0 0 4mm;color:#0f766e}
h2{font-size:13pt;margin:6mm 0 2mm;color:#0f766e}
.lead{color:#475467}
.page{page-break-after:always}
.page:last-child{page-break-after:auto}
li{margin-bottom:1.5mm}
.note{border-right:3px solid #0f766e;padding-right:4mm;color:#344054}
</style></head><body>
<section class="page">
<h1>مدیریت زمان با گام‌های کوچک</h1>
<p class="lead">راهنمای نمونه همیار — این متن برای آزمایش نمایش، جست‌وجو و خلاصه‌سازی PDF نوشته شده است.</p>
<h2>چرا برنامه روزانه کمک می‌کند؟</h2>
<p>بیشتر ما روز را با فهرستی طولانی از کارها شروع می‌کنیم و در پایان روز احساس می‌کنیم کار مهمی انجام نشده است. دلیل اصلی معمولاً کمبود وقت نیست؛ بلکه نبودن اولویت روشن است. وقتی همه کارها هم‌وزن به نظر برسند، ذهن سراغ کارهای کوچک و آسان می‌رود و کار اصلی عقب می‌افتد.</p>
<p>برنامه روزانه کوتاه، این مشکل را کم می‌کند. کافی است هر صبح سه کار مهم روز را بنویسید و یکی از آن‌ها را «کار اصلی» بنامید. کار اصلی کاری است که اگر فقط همان انجام شود، روز موفق حساب می‌شود.</p>
<p class="note">پیشنهاد: کار اصلی را در اولین ساعت پرانرژی روز انجام دهید؛ برای بیشتر افراد این زمان پیش از ظهر است.</p>
</section>
<section class="page">
<h2>روش پومودورو</h2>
<p>در روش پومودورو، کار در بازه‌های ۲۵ دقیقه‌ای و بدون وقفه انجام می‌شود و پس از هر بازه پنج دقیقه استراحت می‌کنید. پس از چهار بازه، استراحت طولانی‌تری بین پانزده تا سی دقیقه در نظر بگیرید. این روش دو فایده دارد: شروع کار را آسان می‌کند و خستگی ذهنی را پیش از آنکه زیاد شود، کنترل می‌کند.</p>
<ul>
<li>پیش از شروع، فقط یک کار مشخص را انتخاب کنید.</li>
<li>اعلان‌های تلفن را در طول بازه خاموش کنید.</li>
<li>اگر فکری مزاحم شد، آن را در یادداشت بنویسید و ادامه دهید.</li>
<li>در پایان روز، تعداد بازه‌های کامل‌شده را ثبت کنید تا روند خود را ببینید.</li>
</ul>
<h2>یادآوری‌ها را ساده نگه دارید</h2>
<p>یادآوری زیاد، اثر یادآوری را از بین می‌برد. برای کارهای زمان‌دار یک یادآوری کافی است؛ پانزده دقیقه پیش از قرار برای بیشتر کارها مناسب است. برای کارهای بدون ساعت، به‌جای یادآوری، آن‌ها را در فهرست «امروز» نگه دارید.</p>
</section>
<section class="page">
<h2>بازبینی هفتگی</h2>
<p>یک بار در هفته، مثلاً جمعه عصر، بیست دقیقه برای مرور هفته کنار بگذارید. کارهای انجام‌نشده را بررسی کنید: یا آن‌ها را به هفته بعد منتقل کنید، یا اگر دیگر مهم نیستند حذفشان کنید. همچنین یک هدف کوچک برای هفته آینده بنویسید.</p>
<h2>خلاصه اقدامات پیشنهادی</h2>
<ol>
<li>هر صبح سه کار مهم را بنویسید و یکی را کار اصلی کنید.</li>
<li>برای کارهای سخت از بازه‌های ۲۵ دقیقه‌ای تمرکز استفاده کنید.</li>
<li>برای هر قرار فقط یک یادآوری تنظیم کنید.</li>
<li>جمعه‌ها بیست دقیقه بازبینی هفتگی انجام دهید.</li>
</ol>
<p class="lead">این سند فقط برای نمایش امکانات همیار است و توصیه تخصصی محسوب نمی‌شود.</p>
</section>
</body></html>`;

const browser = await chromium.launch({ executablePath: chromiumPath() });
const page = await browser.newPage();
await page.setContent(html, { waitUntil: 'networkidle' });
await page.evaluate(() => document.fonts.ready);
const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
mkdirSync('public/samples', { recursive: true });
writeFileSync('public/samples/hamyar-sample-fa.pdf', pdf);
console.log('wrote public/samples/hamyar-sample-fa.pdf', pdf.length, 'bytes');
await browser.close();
