// Renders the SVG app icons to PNG (192, 512, maskable) with headless Chromium.
import { chromium } from 'playwright-core';
import { readFileSync, writeFileSync } from 'node:fs';
import { chromiumPath } from './chromium.mjs';

const browser = await chromium.launch({ executablePath: chromiumPath() });
const page = await browser.newPage();
const jobs = [
  ['public/icons/icon.svg', 192, 'public/icons/icon-192.png'],
  ['public/icons/icon.svg', 512, 'public/icons/icon-512.png'],
  ['public/icons/icon-maskable.svg', 512, 'public/icons/icon-maskable-512.png'],
];
for (const [src, size, out] of jobs) {
  const svg = readFileSync(src, 'utf8');
  await page.setViewportSize({ width: size, height: size });
  await page.setContent(`<html><body style="margin:0;background:transparent">${svg.replace('<svg ', `<svg width="${size}" height="${size}" `)}</body></html>`);
  writeFileSync(out, await page.screenshot({ omitBackground: true, clip: { x: 0, y: 0, width: size, height: size } }));
  console.log('wrote', out);
}
await browser.close();
