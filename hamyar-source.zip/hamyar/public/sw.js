/* Hamyar service worker — app files only.
   Precaches every file the app needs (HTML, hashed JS/CSS, fonts, icons, the sample PDF)
   so the installed app opens without internet; pdf.js extras are cached on first use.
   It never caches /api responses or anything personal: personal data lives in IndexedDB.
   BUILD and PRECACHE are filled in at build time (see vite.config.ts). */
const BUILD = 'dev';
const PRECACHE = ['./', './index.html', './manifest.webmanifest', './icons/icon.svg', './icons/icon-192.png', './icons/icon-512.png'];
const VERSION = `hamyar-shell-${BUILD}`;

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(VERSION)
      .then((c) => c.addAll(PRECACHE))
      // First install starts at once; an update waits until the page asks (see main.tsx).
      .then(() => (self.registration.active ? undefined : self.skipWaiting())),
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('hamyar-shell-') && k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.includes('/api/')) return;

  if (req.mode === 'navigate') {
    // Network first so updates arrive; the cached page keeps the app working offline.
    event.respondWith(
      fetch(req)
        .then((res) => {
          if (res.ok) {
            const copy = res.clone();
            caches.open(VERSION).then((c) => c.put('./index.html', copy));
          }
          return res;
        })
        .catch(() => caches.match('./index.html', { ignoreSearch: true }).then((hit) => hit || caches.match('./'))),
    );
    return;
  }

  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then(
      (hit) =>
        hit ||
        fetch(req).then((res) => {
          const cacheable = /\/(assets|pdfjs|icons|samples)\//.test(url.pathname) || url.pathname.endsWith('.webmanifest');
          if (res.ok && cacheable) {
            const copy = res.clone();
            caches.open(VERSION).then((c) => c.put(req, copy));
          }
          return res;
        }),
    ),
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || '#/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if ('focus' in client) {
          client.navigate(new URL(target, client.url).toString()).catch(() => undefined);
          return client.focus();
        }
      }
      return self.clients.openWindow(new URL(target, self.registration.scope).toString());
    }),
  );
});
