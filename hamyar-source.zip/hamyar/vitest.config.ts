import { defineConfig } from 'vitest/config';

export default defineConfig({
  define: {
    __HAMYAR_TARGET__: JSON.stringify('app'),
    __HAMYAR_VERSION__: JSON.stringify('test'),
  },
  test: {
    environment: 'node',
    include: ['tests/unit/**/*.test.ts'],
    setupFiles: ['tests/unit/setup.ts'],
  },
});
