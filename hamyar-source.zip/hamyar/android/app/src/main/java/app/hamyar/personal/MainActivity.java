package app.hamyar.personal;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
