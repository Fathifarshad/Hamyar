import { defineConfig, loadEnv, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { createHash } from 'node:crypto';
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';

/**
 * Copies pdf.js CMaps, standard fonts and wasm decoders into public/pdfjs so the
 * viewer can render and extract text from PDFs that need them. Skipped for the
 * single-file preview build (those files are optional there).
 */
function pdfjsAssets(): Plugin {
  return {
    name: 'hamyar-pdfjs-assets',
    buildStart() {
      const src = resolve(import.meta.dirname, 'node_modules/pdfjs-dist');
      const dest = resolve(import.meta.dirname, 'public/pdfjs');
      for (const dir of ['cmaps', 'standard_fonts', 'wasm']) {
        const target = resolve(dest, dir);
        if (!existsSync(target)) {
          mkdirSync(target, { recursive: true });
          cpSync(resolve(src, dir), target, { recursive: true });
        }
      }
    },
  };
}

function listFiles(dir: string, base = dir): string[] {
  return readdirSync(dir).flatMap((name) => {
    const full = join(dir, name);
    return statSync(full).isDirectory() ? listFiles(full, base) : [relative(base, full).split('\\').join('/')];
  });
}

/**
 * Writes the precache list and a build id into the service worker, so an installed
 * app opens offline with every screen available and updates when a new build ships.
 */
function serviceWorkerManifest(outDir: string): Plugin {
  return {
    name: 'hamyar-sw-manifest',
    apply: 'build',
    closeBundle() {
      const dir = resolve(import.meta.dirname, outDir);
      const swPath = join(dir, 'sw.js');
      if (!existsSync(swPath)) return;
      const files = listFiles(dir)
        .filter((f) => f === 'index.html' || f === 'manifest.webmanifest' || /^(assets|icons|samples)\//.test(f))
        .sort()
        .map((f) => `./${f}`);
      const precache = ['./', ...files];
      const build = createHash('sha256').update(precache.join('\n')).update(readFileSync(join(dir, 'index.html'))).digest('hex').slice(0, 12);
      const sw = readFileSync(swPath, 'utf8')
        .replace(/const BUILD = '[^']*';/, `const BUILD = '${build}';`)
        .replace(/const PRECACHE = \[[^\]]*\];/, `const PRECACHE = ${JSON.stringify(precache)};`);
      writeFileSync(swPath, sw);
    },
  };
}

/** Mounts the same /api handler that `npm start` uses, so `npm run dev` has AI routes too. */
function localApi(env: Record<string, string>): Plugin {
  return {
    name: 'hamyar-local-api',
    async configureServer(server) {
      const { createApiHandler } = await import('./server/api.mjs');
      const handler = createApiHandler({ env: { ...process.env, ...env } });
      server.middlewares.use((req, res, next) => {
        if (req.url && req.url.startsWith('/api/')) return handler(req, res);
        next();
      });
    },
  };
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const isArtifact = mode === 'artifact';
  const isMobile = mode === 'mobile';
  const outDir = isArtifact ? 'dist-artifact' : isMobile ? 'dist-mobile' : 'dist';
  return {
    base: './',
    plugins: [react(), ...(isArtifact ? [] : [pdfjsAssets(), serviceWorkerManifest(outDir), ...(isMobile ? [] : [localApi(env)])])],
    define: {
      __HAMYAR_TARGET__: JSON.stringify(isArtifact ? 'artifact' : isMobile ? 'mobile' : 'app'),
      __HAMYAR_VERSION__: JSON.stringify(process.env.npm_package_version ?? '0.1.0'),
    },
    publicDir: isArtifact ? false : 'public',
    build: isArtifact
      ? {
          outDir,
          assetsInlineLimit: 100_000_000,
          cssCodeSplit: false,
          modulePreload: false,
          rolldownOptions: { output: { codeSplitting: false } },
        }
      : {
          outDir,
          sourcemap: false,
          chunkSizeWarningLimit: 1800,
        },
    server: { port: 5173, host: '127.0.0.1' },
    preview: { port: 4173 },
  };
});
