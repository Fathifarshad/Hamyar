#!/bin/sh
# Double-click this file (macOS) to start Hamyar. Keep the window open while you use it.
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  Node.js is not installed."
  echo "  Install the LTS version from https://nodejs.org and then open this file again."
  echo ""
  read -r _
  exit 1
fi
node server/index.mjs --open
