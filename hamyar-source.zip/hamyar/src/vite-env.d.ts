/// <reference types="vite/client" />

declare const __HAMYAR_TARGET__: 'app' | 'artifact' | 'mobile';
declare const __HAMYAR_VERSION__: string;

declare module '*?raw' {
  const content: string;
  export default content;
}
