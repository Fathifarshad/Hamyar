export const ACCENTS = [
  'teal',
  'blue',
  'indigo',
  'violet',
  'pink',
  'red',
  'orange',
  'amber',
  'green',
  'slate',
] as const;
export type Accent = (typeof ACCENTS)[number];

export const SCHEMES = ['teal', 'indigo', 'blue', 'pink', 'amber', 'slate'] as const;
export type Scheme = (typeof SCHEMES)[number];

export const CARD_PRESETS = ['default', 'minimal', 'list'] as const;
export type CardPreset = (typeof CARD_PRESETS)[number];

export const ICON_KEYS = [
  'check-square',
  'calendar-clock',
  'music',
  'file-text',
  'clapperboard',
  'audio-lines',
  'pill',
  'notebook-pen',
  'bookmark',
  'timer',
  'list-checks',
  'droplets',
  'wallet',
  'cloud-sun',
  'calendar-days',
  'layout-grid',
  'heart',
  'star',
  'book-open',
  'briefcase',
  'dumbbell',
  'graduation-cap',
  'home',
  'car',
  'plane',
  'coffee',
  'sparkles',
  'leaf',
  'sun',
  'moon',
  'headphones',
  'users',
] as const;
export type IconKey = (typeof ICON_KEYS)[number];

export function isAccent(v: unknown): v is Accent {
  return typeof v === 'string' && (ACCENTS as readonly string[]).includes(v);
}
export function isIconKey(v: unknown): v is IconKey {
  return typeof v === 'string' && (ICON_KEYS as readonly string[]).includes(v);
}
