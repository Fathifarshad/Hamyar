/** Product limits from PRD §11 — one place, used by UI and data rules. */
const MiB = 1024 * 1024;

export const LIMITS = {
  maxActiveModules: 10,
  maxTotalModules: 50,
  accountStorageBytes: 500 * MiB,
  pdfBytes: 20 * MiB,
  pdfSummaryMaxPages: 100,
  musicBytes: 30 * MiB,
  videoBytes: 100 * MiB,
  transcriptionBytes: 20 * MiB,
  transcriptionSeconds: 10 * 60,
  commandSeconds: 60,
  concurrentAiJobs: 2,
  dailySummaries: 10,
  dailyTranscriptionMinutes: 30,
  /** a reminder that is later than this is kept in the inbox but not pushed as a system notification */
  staleReminderMinutes: 60,
  reminderTickMs: 15_000,
  /** text characters per summary chunk (pages are never split unless one page is larger) */
  summaryChunkChars: 24_000,
  maxCustomFields: 8,
} as const;

export const MiB_ = MiB;
