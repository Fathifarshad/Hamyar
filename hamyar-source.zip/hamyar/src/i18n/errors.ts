import { DomainError } from '../domain/types';
import { AiError } from '../lib/ai';

type T = (fa: string, en: string, params?: Record<string, string | number>) => string;

/** Turns any error into a short, plain message. Technical details never reach the UI. */
export function errorText(e: unknown, t: T): string {
  const code = e instanceof DomainError || e instanceof AiError ? e.code : (e as { code?: string })?.code;
  switch (code) {
    case 'MODULE_LIMIT_REACHED':
      return t('۱۰ بخش فعال دارید. اول یک بخش را پنهان کنید، یا این بخش را غیرفعال بسازید.', 'You already have 10 active sections. Hide one first, or create this one hidden.');
    case 'MODULE_TOTAL_LIMIT':
      return t('به سقف ۵۰ بخش رسیده‌اید. یک بخش را حذف کنید.', 'You have reached 50 sections. Delete one first.');
    case 'MODULE_ARCHIVED':
      return t('این بخش بایگانی است؛ اول آن را از بایگانی خارج کنید.', 'This section is archived. Restore it first.');
    case 'NOT_FOUND':
      return t('این مورد دیگر وجود ندارد.', 'This item no longer exists.');
    case 'VERSION_CONFLICT':
      return t('این بخش در تب دیگری تغییر کرده است. پنجره را ببندید و دوباره باز کنید.', 'This section changed in another tab. Close and reopen this window.');
    case 'EMPTY_FILE':
      return t('فایل خالی است.', 'The file is empty.');
    case 'FILE_TOO_LARGE':
      return t('حجم فایل از سقف مجاز این بخش بیشتر است.', 'The file is larger than this section allows.');
    case 'QUOTA_EXCEEDED':
      return t('به سقف مجاز رسیده‌اید (فضا یا استفاده روزانه). بعداً دوباره امتحان کنید یا فایل‌های قدیمی را حذف کنید.', 'You reached a limit (storage or daily use). Try later or remove old files.');
    case 'BROWSER_STORAGE_FULL':
      return t('فضای ذخیره مرورگر پر است. چند فایل را حذف کنید؛ داده‌های قبلی سالم مانده‌اند.', 'Browser storage is full. Remove some files; existing data is safe.');
    case 'UNSUPPORTED_MEDIA':
      return t('این نوع فایل در این بخش پشتیبانی نمی‌شود.', 'This file type is not supported here.');
    case 'CAPABILITY_UNAVAILABLE':
    case 'NOT_CONFIGURED':
      return t('این قابلیت هنوز برای این نسخه راه‌اندازی نشده است.', 'This feature has not been set up for this copy yet.');
    case 'NOT_GRANTED':
      return t('اجازه استفاده از Claude داده نشد؛ این قابلیت در این صفحه غیرفعال شد.', 'Claude access was not allowed, so this feature is off on this page.');
    case 'NETWORK':
      return t('اتصال برقرار نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.', 'Could not connect. Check the connection and try again.');
    case 'RATE_LIMITED':
      return t('درخواست‌ها زیاد بوده است. چند دقیقه بعد دوباره تلاش کنید.', 'Too many requests. Try again in a few minutes.');
    case 'TIMEOUT':
      return t('پاسخ سرویس طول کشید. دوباره تلاش کنید.', 'The service took too long. Try again.');
    case 'PROVIDER_AUTH':
      return t('کلید سرویس هوش مصنوعی پذیرفته نشد. تنظیمات سرور را بررسی کنید.', 'The AI service key was rejected. Check the server settings.');
    case 'PROVIDER_ERROR':
    case 'FAILED':
      return t('سرویس پردازش خطا داد. فایل و متن شما سالم است؛ دوباره تلاش کنید.', 'The processing service failed. Your file is safe; try again.');
    case 'INVALID_OUTPUT':
      return t('خروجی سرویس معتبر نبود و نمایش داده نشد. دوباره تلاش کنید.', 'The service returned invalid output, so nothing was shown. Try again.');
    case 'TOO_LARGE':
      return t('این محتوا برای پردازش بیش از حد بزرگ است.', 'This content is too large to process.');
    case 'REFUSED':
      return t('سرویس این متن را پردازش نکرد. بخش کوتاه‌تری از سند را امتحان کنید.', 'The service declined this text. Try a shorter part of the document.');
    case 'SESSION_EXPIRED':
      return t('نشست Claude شما منقضی شده است. دوباره وارد شوید و صفحه را تازه کنید.', 'Your Claude session expired. Sign in again and reload the page.');
    case 'NO_TEXT':
      return t('متنی برای پردازش پیدا نشد.', 'No text was found to process.');
    case 'JOB_EXPIRED':
      return t('وضعیت پردازش از دست رفت (سرور دوباره راه‌اندازی شده). دوباره تلاش کنید.', 'The job was lost (server restarted). Try again.');
    case 'UNSUPPORTED_AUDIO':
      return t('این قالب صوتی برای تبدیل پشتیبانی نمی‌شود. فایل را به MP3، M4A یا WAV تبدیل کنید.', 'This audio format is not supported. Convert it to MP3, M4A or WAV.');
    case 'CANCELLED':
      return t('لغو شد.', 'Cancelled.');
    default:
      return t('کار انجام نشد. دوباره تلاش کنید.', 'That did not work. Please try again.');
  }
}
