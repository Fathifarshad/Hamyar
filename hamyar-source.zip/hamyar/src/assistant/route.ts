import type { ModuleType } from '../domain/types';
import { Scanner, normalizeKeepLength, WB_END as E } from '../domain/commands/scanner';
import { extractDateTime } from '../domain/commands/datetime';
import { CURRENCY_RE, NUMBER_RE } from '../domain/commands/numbers';
import { matchesQuery } from '../domain/normalize';

/**
 * The voice assistant: the first word says which section a sentence is for («دارو …»,
 * «ماشین …», «آهنگ‌های …»), the rest goes to that section, which reads it with its own
 * parser and shows its own "check before saving" screen.
 */

export interface RouteModule {
  id: string;
  type: ModuleType;
  title: string;
  active: 0 | 1;
  archivedAt: string | null;
  order: number;
}

export type Route =
  /** `moduleId` null: there is no section of that type yet */
  | { kind: 'module'; type: ModuleType; moduleId: string | null; text: string }
  | { kind: 'open'; moduleId: string }
  | { kind: 'unknown'; text: string };

interface Keyword {
  type: ModuleType;
  re: string;
  /** remove the word before handing the sentence over (it only chose the section) */
  strip: boolean;
}

/** Normalized forms (the Scanner writes «ا» for «آ» and a space for a ZWNJ). Longest first wins. */
export const KEYWORDS: Keyword[] = [
  // medications
  { type: 'medications', re: 'داروی?\\s*جدید|دارو(?:ی|ها|هام|م)?|medicines?|medications?|meds', strip: true },
  { type: 'medications', re: 'قرص|کپسول|شربت|امپول|قطره|اسپری|پماد|pills?|tablets?', strip: false },
  // cars
  { type: 'vehicles', re: 'ماشین(?:م|مون)?|خودرو(?:م|ها)?|اتومبیل|my\\s*car|car|vehicle', strip: true },
  {
    type: 'vehicles',
    re: 'بیمه(?:\\s*(?:ی\\s*)?(?:ثالث|بدنه))?|معاینه\\s*(?:ی\\s*)?فنی|تعویض\\s*روغن|روغن\\s*موتور|لاستیک|لنت|کیلومتر|کارکرد|عوارض|تعمیر(?:ات|گاه)?|oil\\s*change|insurance|inspection|odometer',
    strip: false,
  },
  // tasks
  { type: 'tasks', re: 'کار\\s*جدید|قرار\\s*جدید|قرار|کار|task|appointment|todo', strip: true },
  { type: 'tasks', re: 'یادم\\s*(?:ب)?نداز|یادم\\s*بینداز|یاداوری\\s*کن|یاداوری|جلسه|remind\\s*me|reminder|meeting', strip: false },
  // notes
  { type: 'notes', re: 'یادداشت\\s*کن|یادداشت|بنویس|note|write\\s*down', strip: true },
  // checklists
  { type: 'checklists', re: 'لیست\\s*خرید|فهرست\\s*خرید|چک\\s*لیست|لیست|فهرست|خرید|shopping\\s*list|shopping|checklist|list', strip: true },
  // expenses
  { type: 'expenses', re: 'هزینه|خرج(?:\\s*کردم)?|پرداخت(?:\\s*کردم)?|expense|spent|paid', strip: true },
  // weather («آب و هوا» before «آب»), habits and water
  { type: 'weather', re: 'اب\\s*و\\s*هوا|هوا|weather', strip: true },
  { type: 'habits', re: '(?:(?:یک|یه|دو|سه|چهار|\\d+)\\s*)?لیوان(?:\\s*اب)?|اب\\s*خوردم|اب|water|(?:a|one|two)\\s*glass(?:es)?\\s*of\\s*water', strip: false },
  { type: 'habits', re: 'عادت|habit', strip: true },
  // calendar and countdowns
  { type: 'calendar', re: 'رویداد|مناسبت|شمارش\\s*معکوس|countdown|event', strip: true },
  { type: 'calendar', re: 'تولد|سالگرد|birthday|anniversary', strip: false },
  // music and video
  { type: 'music', re: 'اهنگ|ترانه|موزیک|موسیقی|خواننده|بخون|song|songs|music|play', strip: false },
  { type: 'music', re: 'پخش\\s*کن|پخش|بزن|بذار', strip: false },
  { type: 'video', re: '(?:پخش\\s*(?:کن\\s*)?)?(?:ویدئو|ویدیو|فیلم)(?:\\s*ی)?|(?:play\\s*)?(?:the\\s*)?(?:video|movie)', strip: true },
  // focus timer
  { type: 'focus', re: 'تمرکز|پومودورو|تایمر|focus|pomodoro|timer', strip: true },
  // saved links, PDFs
  { type: 'bookmarks', re: 'لینک|سایت|link|website', strip: true },
  { type: 'pdf', re: 'پی\\s*دی\\s*اف|pdf', strip: true },
];

/** Names people use for each section, for «باز کن …». */
const OPEN_NAMES: Partial<Record<ModuleType, string>> = {
  tasks: 'کارها|کار|قرارها|tasks',
  medications: 'داروها|دارو|medications|medicines',
  vehicles: 'خودروها|خودرو|ماشین|ماشینها|cars?|vehicles?',
  music: 'موسیقی|اهنگ|اهنگها|music',
  video: 'ویدئو|ویدیو|فیلم|video',
  notes: 'یادداشتها|یادداشت|notes',
  checklists: 'چک\\s*لیست|لیست|فهرست|checklists?',
  expenses: 'هزینهها|هزینه|expenses',
  habits: 'عادتها|اب|habits|water',
  calendar: 'تقویم|calendar',
  focus: 'تمرکز|focus',
  weather: 'اب\\s*و\\s*هوا|هوا|weather',
  pdf: 'pdf|پی\\s*دی\\s*اف',
  bookmarks: 'لینکها|لینک|links',
  transcription: 'صوت\\s*به\\s*متن|transcription',
  custom: 'دلخواه|custom',
};

function pick(modules: RouteModule[], type: ModuleType): RouteModule | null {
  const live = modules.filter((m) => m.type === type && !m.archivedAt).sort((a, b) => b.active - a.active || a.order - b.order);
  return live[0] ?? null;
}

const LEAD = '^\\s*(?:لطفا|please|hey|سلام)?\\s*';

export function routeUtterance(text: string, ctx: { modules: RouteModule[]; now: number; timezone: string }): Route {
  const raw = text.trim();
  if (!raw) return { kind: 'unknown', text: raw };
  const norm = normalizeKeepLength(raw);

  // «باز کن داروها», «برو به ماشین»
  const open = new RegExp(`${LEAD}(?:باز\\s*کن|بازکن|برو\\s*(?:به|تو)?|open|go\\s*to|show)\\s+(?:بخش\\s+|section\\s+)?(.+)$`, 'u').exec(norm);
  if (open) {
    const what = raw.slice(open.index + open[0].length - open[1]!.length).trim();
    const byTitle = ctx.modules.filter((m) => !m.archivedAt).find((m) => matchesQuery(m.title, what) || matchesQuery(what, m.title));
    if (byTitle) return { kind: 'open', moduleId: byTitle.id };
    for (const [type, names] of Object.entries(OPEN_NAMES) as [ModuleType, string][]) {
      if (new RegExp(`^\\s*(?:${names})\\s*$`, 'u').test(normalizeKeepLength(what).replace(/\s+(?=ها)/g, ''))) {
        const m = pick(ctx.modules, type);
        if (m) return { kind: 'open', moduleId: m.id };
      }
    }
  }

  // the first word (or two) chooses the section
  let best: { kw: Keyword; len: number } | null = null;
  for (const kw of KEYWORDS) {
    const m = new RegExp(`${LEAD}(?:${kw.re})${E}`, 'u').exec(norm);
    if (m && (!best || m[0].length > best.len)) best = { kw, len: m[0].length };
  }
  if (best) {
    const rest = best.kw.strip ? raw.slice(best.len).replace(/^[\s:،,.-]+/u, '').trim() : raw.replace(new RegExp(`^\\s*(?:لطفا|please|hey|سلام)\\s*`, 'u'), '').trim();
    let handed = rest || raw;
    // «تمرکز» or «تمرکز ۴۰ دقیقه» means: start it
    if (best.kw.type === 'focus' && !/(?:شروع|start|توقف|مکث|pause|stop|ادامه|resume|ریست|reset|رد|skip)/u.test(normalizeKeepLength(handed))) handed = `شروع ${rest}`.trim();
    const m = pick(ctx.modules, best.kw.type);
    return { kind: 'module', type: best.kw.type, moduleId: m?.id ?? null, text: handed };
  }

  // no section word: an amount with a currency is an expense; a date or time is a task
  const sc = new Scanner(raw);
  if (sc.has(new RegExp(`(?:${NUMBER_RE})\\s*(?:${CURRENCY_RE})${E}|\\$\\s*\\d`, 'u'))) {
    const m = pick(ctx.modules, 'expenses');
    return { kind: 'module', type: 'expenses', moduleId: m?.id ?? null, text: raw };
  }
  const dt = extractDateTime(new Scanner(raw), { now: ctx.now, timezone: ctx.timezone });
  if (dt.found) {
    const m = pick(ctx.modules, 'tasks');
    return { kind: 'module', type: 'tasks', moduleId: m?.id ?? null, text: raw };
  }
  return { kind: 'unknown', text: raw };
}
