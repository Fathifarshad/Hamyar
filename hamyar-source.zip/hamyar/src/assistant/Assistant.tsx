import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../data/db';
import { useApp } from '../shell/AppContext';
import { moduleHref, navigate } from '../shell/router';
import { Button, Modal, Notice } from '../ui/primitives';
import { VoiceInput } from '../ui/VoiceInput';
import { Info, Mic, Plus } from '../ui/icons';
import { ModuleIcon } from '../ui/Icon';
import { createModule } from '../data/modules';
import { MODULE_TEXT } from '../modules/registry';
import { CATALOG } from '../domain/catalog';
import { DomainError, type ModuleType } from '../domain/types';
import { handOff } from '../lib/handoff';
import { player } from '../lib/media';
import { toast } from '../lib/ui-store';
import { errorText } from '../i18n/errors';
import { routeUtterance } from './route';

const EXAMPLES_FA = [
  'دارو استامینوفن ۵۰۰ هر ۸ ساعت بعد از غذا به مدت ۵ روز',
  'ماشین تعویض روغن امروز کیلومتر ۸۵ هزار',
  'بیمه ثالث تا ۲۰ اسفند',
  'آهنگ‌های گوگوش',
  'یادم بنداز فردا ساعت ۹ صبح جلسه',
  'خرید نان، شیر و تخم‌مرغ',
  'هزینه ۵۰ هزار تومان نان',
  'یادداشت کتاب جدید برای کلاس بخرم',
];
const EXAMPLES_EN = ['medicine ibuprofen 400 mg twice a day after meals', 'car oil change today at 85000 km', 'songs by Adele', 'remind me tomorrow at 9am meeting', 'shopping bread, milk and eggs'];

/**
 * One microphone for the whole app. The first word chooses the section («دارو …»، «ماشین …»،
 * «آهنگ‌های …»); the section opens and receives the rest of the sentence, then shows its own
 * filled-in form or preview. Nothing is saved without the person confirming it there.
 */
export function Assistant() {
  const { t, locale, tz, profile } = useApp();
  const modules = useLiveQuery(() => db.modules.toArray(), []);
  const [open, setOpen] = useState(false);
  const [text, setText] = useState('');
  const [missing, setMissing] = useState<{ type: ModuleType; text: string } | null>(null);
  const [unknown, setUnknown] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const lang = locale === 'fa' ? 'fa-IR' : 'en-US';
  const live = (modules ?? []).filter((m) => !m.archivedAt).sort((a, b) => b.active - a.active || a.order - b.order);
  const name = (type: ModuleType) => MODULE_TEXT[type].name[locale === 'fa' ? 0 : 1];

  const close = () => {
    setOpen(false);
    setText('');
    setMissing(null);
    setUnknown(null);
  };

  const deliver = (moduleId: string, said: string) => {
    close();
    navigate(moduleHref(moduleId));
    handOff(moduleId, said);
  };

  const handle = (said: string) => {
    const value = said.trim();
    if (!value) return;
    setMissing(null);
    setUnknown(null);
    const route = routeUtterance(value, { modules: modules ?? [], now: Date.now(), timezone: tz });
    if (route.kind === 'open') {
      close();
      navigate(moduleHref(route.moduleId));
    } else if (route.kind === 'module') {
      if (route.moduleId) deliver(route.moduleId, route.text);
      else setMissing({ type: route.type, text: route.text });
    } else setUnknown(route.text);
  };

  const createAndGo = async () => {
    if (!missing) return;
    setBusy(true);
    try {
      const input = { type: missing.type, title: name(missing.type), inputLanguage: lang, locale } as const;
      let mod;
      try {
        mod = await createModule({ ...input, active: true });
      } catch (e) {
        if (!(e instanceof DomainError && e.code === 'MODULE_LIMIT_REACHED')) throw e;
        // ten sections are already on the dashboard: make it hidden, it still works
        mod = await createModule({ ...input, active: false });
        toast({ kind: 'warning', text: t('بخش «{x}» ساخته شد ولی چون ۱۰ بخش فعال دارید، در داشبورد نیست؛ از «بخش‌ها» پیدایش کنید.', 'The “{x}” section was created but hidden, because ten sections are already shown. Find it under “Sections”.', { x: mod.title }), timeout: 9000 });
      }
      deliver(mod.id, missing.text);
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  const start = () => {
    // a tap is the moment browsers allow sound: unlock music so «آهنگ‌های …» can start by itself
    player.unlock();
    setOpen(true);
  };

  return (
    <>
      <button type="button" className="assistant-fab" onClick={start} aria-label={t('دستیار صوتی: بگویید چه کاری انجام شود', 'Voice assistant: say what to do')} title={t('دستیار صوتی', 'Voice assistant')}>
        <Mic size={24} aria-hidden="true" />
      </button>
      <Modal open={open} onClose={close} title={t('دستیار صوتی', 'Voice assistant')} closeLabel={t('بستن', 'Close')}>
        <div className="stack assistant">
          <p className="muted small">
            {t(
              'اول بگویید برای کدام بخش است، بعد بقیه را: «دارو …»، «ماشین …»، «آهنگ‌های …»، «یادم بنداز …». همان بخش باز می‌شود و فرمش پر می‌شود؛ ثبت فقط با تأیید شما.',
              'Start with the section, then the rest: “medicine …”, “car …”, “songs by …”, “remind me …”. That section opens with its form filled in; nothing is saved until you confirm.',
            )}
          </p>
          {open && (
            <VoiceInput
              value={text}
              onChange={setText}
              lang={lang}
              ownerId="assistant"
              inputLabel={t('فرمان یا پیام', 'Command or message')}
              placeholder={t('بگویید یا بنویسید…', 'Say or type…')}
              mode="command"
              onCommand={handle}
              onSubmit={(s) => {
                player.unlock();
                handle(s);
              }}
              submitLabel={t('انجام', 'Go')}
              maxLength={400}
              autoStart
            />
          )}
          {missing && (
            <Notice
              tone="info"
              icon={<Info size={16} />}
              title={t('بخش «{x}» هنوز ساخته نشده', 'There is no “{x}” section yet', { x: name(missing.type) })}
              action={
                <Button size="sm" variant="accent" busy={busy} icon={<Plus size={14} />} onClick={() => void createAndGo()}>
                  {t('بساز و ادامه بده', 'Create it and continue')}
                </Button>
              }
            >
              <span className="auto-dir">«{missing.text}»</span>
            </Notice>
          )}
          {unknown && (
            <Notice tone="warn" icon={<Info size={16} />} title={t('معلوم نشد برای کدام بخش است', 'Which section is this for?')}>
              <div className="stack-sm">
                <span className="auto-dir">«{unknown}»</span>
                <span className="small">{t('یک بخش را انتخاب کنید، یا دفعه‌ی بعد اول نام بخش را بگویید (مثلاً «دارو»).', 'Pick a section, or next time start with its name (e.g. “medicine”).')}</span>
                <div className="chip-row">
                  {live
                    .filter((m) => CATALOG[m.type].commands || m.type === 'medications')
                    .map((m) => (
                      <button key={m.id} type="button" className="day-chip assistant-chip" data-accent={m.appearance.accent} onClick={() => deliver(m.id, unknown)}>
                        <ModuleIcon icon={m.appearance.icon} size={14} /> {m.title}
                      </button>
                    ))}
                </div>
              </div>
            </Notice>
          )}
          {!missing && !unknown && (
            <div className="stack-sm">
              <span className="subtle xsmall">{t('نمونه‌ها (برای امتحان بزنید):', 'Examples (tap to try):')}</span>
              <div className="chip-row">
                {(locale === 'fa' ? EXAMPLES_FA : EXAMPLES_EN).map((ex) => (
                  <button key={ex} type="button" className="day-chip assistant-chip" onClick={() => setText(ex)}>
                    {ex}
                  </button>
                ))}
              </div>
            </div>
          )}
          {profile.locale === 'fa' && (
            <p className="subtle xsmall">{t('اگر میکروفن این گوشی کار نکرد، از دکمه‌ی میکروفن صفحه‌کلید استفاده کنید و «انجام» را بزنید.', 'If this phone’s microphone does not work here, use the keyboard’s microphone and press “Go”.')}</p>
          )}
        </div>
      </Modal>
    </>
  );
}
