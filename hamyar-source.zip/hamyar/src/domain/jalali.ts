import { toGregorian, toJalaali, isValidJalaaliDate, jalaaliMonthLength } from 'jalaali-js';
import { isoFromParts, parseISODate } from './time';

export const JALALI_MONTHS_FA = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
];
export const JALALI_MONTHS_EN = [
  'Farvardin',
  'Ordibehesht',
  'Khordad',
  'Tir',
  'Mordad',
  'Shahrivar',
  'Mehr',
  'Aban',
  'Azar',
  'Dey',
  'Bahman',
  'Esfand',
];
export const GREGORIAN_MONTHS_FA = [
  'ژانویه',
  'فوریه',
  'مارس',
  'آوریل',
  'مه',
  'ژوئن',
  'ژوئیه',
  'اوت',
  'سپتامبر',
  'اکتبر',
  'نوامبر',
  'دسامبر',
];
export const GREGORIAN_MONTHS_EN = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];
/** index = JS weekday (0 = Sunday) */
export const WEEKDAYS_FA = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
export const WEEKDAYS_EN = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const WEEKDAYS_SHORT_FA = ['ی', 'د', 'س', 'چ', 'پ', 'ج', 'ش'];
export const WEEKDAYS_SHORT_EN = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

export interface JalaliDate {
  jy: number;
  jm: number;
  jd: number;
}

export function isoToJalali(iso: string): JalaliDate {
  const { y, m, d } = parseISODate(iso);
  return toJalaali(y, m, d);
}

export function jalaliToISO(jy: number, jm: number, jd: number): string {
  const g = toGregorian(jy, jm, jd);
  return isoFromParts(g.gy, g.gm, g.gd);
}

export function isValidJalali(jy: number, jm: number, jd: number): boolean {
  try {
    return isValidJalaaliDate(jy, jm, jd);
  } catch {
    return false;
  }
}

export function jalaliMonthDays(jy: number, jm: number): number {
  return jalaaliMonthLength(jy, jm);
}

/**
 * Parses «1405/07/12», «1405-7-12» or a Gregorian «2026-10-04».
 * Years below 1700 are treated as Jalali. Returns an ISO Gregorian date or null.
 */
export function parseFlexibleDate(input: string): string | null {
  const m = input.trim().match(/^(\d{3,4})[/\-.](\d{1,2})[/\-.](\d{1,2})$/);
  if (!m) return null;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  if (y < 1700) {
    if (!isValidJalali(y, mo, d)) return null;
    return jalaliToISO(y, mo, d);
  }
  const dt = new Date(Date.UTC(y, mo - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) return null;
  return isoFromParts(y, mo, d);
}

/** Next ISO date (today included) whose Jalali month/day equal the given ones. */
export function nextJalaliMonthDay(jm: number, jd: number, todayIso: string): string | null {
  const t = isoToJalali(todayIso);
  for (const jy of [t.jy, t.jy + 1, t.jy + 2]) {
    if (!isValidJalali(jy, jm, jd)) continue;
    const iso = jalaliToISO(jy, jm, jd);
    if (iso >= todayIso) return iso;
  }
  return null;
}

/** Next ISO date (today included) for a Gregorian month/day. */
export function nextGregorianMonthDay(month: number, day: number, todayIso: string): string | null {
  const y0 = parseISODate(todayIso).y;
  for (const y of [y0, y0 + 1, y0 + 4]) {
    const dt = new Date(Date.UTC(y, month - 1, day));
    if (dt.getUTCMonth() !== month - 1) continue;
    const iso = isoFromParts(y, month, day);
    if (iso >= todayIso) return iso;
  }
  return null;
}
