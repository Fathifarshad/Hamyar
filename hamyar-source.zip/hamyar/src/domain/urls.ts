/**
 * URL rules (PRD §13): only http(s) links are stored; javascript:, data:, file:, blob:
 * and raw HTML are rejected. Media URLs must be HTTPS. Embeds are built by the app from
 * a validated id — user-supplied iframe/HTML is never rendered.
 */

export type UrlCheck = { ok: true; url: string } | { ok: false; reason: 'empty' | 'invalid' | 'scheme' | 'insecure' | 'html' };

export function checkLinkUrl(raw: string, opts: { requireHttps?: boolean } = {}): UrlCheck {
  const value = raw.trim();
  if (!value) return { ok: false, reason: 'empty' };
  if (/[<>]/.test(value)) return { ok: false, reason: 'html' };
  const withScheme = /^[a-z][a-z0-9+.-]*:/i.test(value) ? value : `https://${value}`;
  let u: URL;
  try {
    u = new URL(withScheme);
  } catch {
    return { ok: false, reason: 'invalid' };
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return { ok: false, reason: 'scheme' };
  if (opts.requireHttps && u.protocol !== 'https:') return { ok: false, reason: 'insecure' };
  if (!u.hostname || !u.hostname.includes('.')) {
    if (u.hostname !== 'localhost') return { ok: false, reason: 'invalid' };
  }
  if (u.username || u.password) return { ok: false, reason: 'invalid' };
  return { ok: true, url: u.toString() };
}

const YT_ID = /^[A-Za-z0-9_-]{11}$/;

/** Extracts a YouTube video id from common URL shapes. */
export function extractYouTubeId(raw: string): string | null {
  let u: URL;
  try {
    u = new URL(raw.trim());
  } catch {
    return null;
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
  const host = u.hostname.replace(/^www\.|^m\.|^music\./, '');
  let id: string | null = null;
  if (host === 'youtu.be') id = u.pathname.split('/')[1] ?? null;
  else if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
    if (u.pathname === '/watch') id = u.searchParams.get('v');
    else {
      const m = u.pathname.match(/^\/(?:embed|shorts|live|v)\/([^/?#]+)/);
      id = m?.[1] ?? null;
    }
  }
  return id && YT_ID.test(id) ? id : null;
}

const APARAT_HASH = /^[A-Za-z0-9]{3,16}$/;

/** Extracts an Aparat video hash from https://www.aparat.com/v/<hash>. */
export function extractAparatHash(raw: string): string | null {
  let u: URL;
  try {
    u = new URL(raw.trim());
  } catch {
    return null;
  }
  const host = u.hostname.replace(/^www\./, '');
  if (host !== 'aparat.com') return null;
  const m = u.pathname.match(/^\/v\/([^/?#]+)/) ?? u.pathname.match(/\/videohash\/([^/?#]+)/);
  const hash = m?.[1] ?? null;
  return hash && APARAT_HASH.test(hash) ? hash : null;
}

export function youTubeEmbedUrl(id: string, origin?: string): string {
  const params = new URLSearchParams({ enablejsapi: '1', rel: '0', playsinline: '1' });
  if (origin) params.set('origin', origin);
  return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?${params.toString()}`;
}

export function youTubeWatchUrl(id: string): string {
  return `https://www.youtube.com/watch?v=${encodeURIComponent(id)}`;
}

export function aparatEmbedUrl(hash: string): string {
  return `https://www.aparat.com/video/video/embed/videohash/${encodeURIComponent(hash)}/vt/frame`;
}

export function aparatWatchUrl(hash: string): string {
  return `https://www.aparat.com/v/${encodeURIComponent(hash)}`;
}

/** Streaming services that have no official playback integration in the MVP. */
const EXTERNAL_MUSIC_HOSTS = [
  'open.spotify.com',
  'spotify.com',
  'music.apple.com',
  'soundcloud.com',
  'deezer.com',
  'tidal.com',
  'music.youtube.com',
  'radiojavan.com',
  'play.radiojavan.com',
  'navaak.com',
  'bia2.com',
];

export function isExternalMusicPage(raw: string): boolean {
  try {
    const host = new URL(raw).hostname.replace(/^www\./, '');
    return EXTERNAL_MUSIC_HOSTS.some((h) => host === h || host.endsWith(`.${h}`));
  } catch {
    return false;
  }
}

export function hostOf(raw: string): string {
  try {
    return new URL(raw).hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

const AUDIO_EXT = /\.(mp3|m4a|aac|wav|ogg|oga|opus|flac|webm)(\?|#|$)/i;
const VIDEO_EXT = /\.(mp4|m4v|webm|mov|ogv)(\?|#|$)/i;

export function looksLikeAudioUrl(raw: string): boolean {
  return AUDIO_EXT.test(raw);
}
export function looksLikeVideoUrl(raw: string): boolean {
  return VIDEO_EXT.test(raw);
}
