import type { Accent, IconKey } from '../config/appearance';
import { isAccent } from '../config/appearance';
import type { CustomField, CustomFieldType, ModuleType } from './types';
import { LIMITS } from '../config/limits';

export type Capability = 'speech' | 'microphone' | 'ai-summary' | 'ai-transcription' | 'network' | 'notifications';

export interface ModuleTypeMeta {
  type: ModuleType;
  icon: IconKey;
  accent: Accent;
  width: 'normal' | 'wide';
  group: 'daily' | 'media' | 'health' | 'tools';
  commands: boolean;
  needs: Capability[];
}

export const CATALOG: Record<ModuleType, ModuleTypeMeta> = {
  tasks: { type: 'tasks', icon: 'calendar-clock', accent: 'teal', width: 'normal', group: 'daily', commands: true, needs: ['notifications'] },
  music: { type: 'music', icon: 'music', accent: 'violet', width: 'normal', group: 'media', commands: true, needs: [] },
  pdf: { type: 'pdf', icon: 'file-text', accent: 'blue', width: 'normal', group: 'tools', commands: true, needs: ['ai-summary'] },
  video: { type: 'video', icon: 'clapperboard', accent: 'red', width: 'wide', group: 'media', commands: true, needs: ['network'] },
  transcription: { type: 'transcription', icon: 'audio-lines', accent: 'indigo', width: 'normal', group: 'tools', commands: false, needs: ['microphone', 'ai-transcription'] },
  medications: { type: 'medications', icon: 'pill', accent: 'pink', width: 'normal', group: 'health', commands: false, needs: ['notifications'] },
  notes: { type: 'notes', icon: 'notebook-pen', accent: 'amber', width: 'normal', group: 'daily', commands: true, needs: [] },
  bookmarks: { type: 'bookmarks', icon: 'bookmark', accent: 'slate', width: 'normal', group: 'tools', commands: true, needs: [] },
  focus: { type: 'focus', icon: 'timer', accent: 'orange', width: 'normal', group: 'daily', commands: true, needs: [] },
  checklists: { type: 'checklists', icon: 'list-checks', accent: 'green', width: 'normal', group: 'daily', commands: true, needs: [] },
  habits: { type: 'habits', icon: 'droplets', accent: 'blue', width: 'normal', group: 'health', commands: true, needs: [] },
  expenses: { type: 'expenses', icon: 'wallet', accent: 'green', width: 'normal', group: 'daily', commands: true, needs: [] },
  weather: { type: 'weather', icon: 'cloud-sun', accent: 'blue', width: 'normal', group: 'daily', commands: false, needs: ['network'] },
  calendar: { type: 'calendar', icon: 'calendar-days', accent: 'teal', width: 'normal', group: 'daily', commands: true, needs: [] },
  custom: { type: 'custom', icon: 'layout-grid', accent: 'violet', width: 'normal', group: 'tools', commands: false, needs: [] },
};

export const GROUP_ORDER: ModuleTypeMeta['group'][] = ['daily', 'health', 'media', 'tools'];

export interface PresetDef {
  id: 'daily' | 'study' | 'health' | 'starter';
  types: ModuleType[];
}

/** Ready-made dashboards built only from existing module types (PRD §6). */
export const PRESETS: PresetDef[] = [
  { id: 'starter', types: ['tasks', 'notes', 'music', 'pdf', 'focus'] },
  { id: 'daily', types: ['tasks', 'calendar', 'checklists', 'notes', 'weather', 'expenses', 'music'] },
  { id: 'study', types: ['pdf', 'notes', 'focus', 'transcription', 'bookmarks', 'tasks'] },
  { id: 'health', types: ['medications', 'habits', 'tasks', 'focus', 'notes'] },
];

export interface CityRef {
  id: string;
  name: string;
  nameFa?: string;
  lat: number;
  lon: number;
  tz: string;
}

/** Built-in cities so clocks and weather work without a search service. */
export const CITY_LIBRARY: CityRef[] = [
  { id: 'tehran', name: 'Tehran', nameFa: 'تهران', lat: 35.6892, lon: 51.389, tz: 'Asia/Tehran' },
  { id: 'mashhad', name: 'Mashhad', nameFa: 'مشهد', lat: 36.2605, lon: 59.6168, tz: 'Asia/Tehran' },
  { id: 'isfahan', name: 'Isfahan', nameFa: 'اصفهان', lat: 32.6539, lon: 51.666, tz: 'Asia/Tehran' },
  { id: 'shiraz', name: 'Shiraz', nameFa: 'شیراز', lat: 29.5918, lon: 52.5837, tz: 'Asia/Tehran' },
  { id: 'tabriz', name: 'Tabriz', nameFa: 'تبریز', lat: 38.08, lon: 46.2919, tz: 'Asia/Tehran' },
  { id: 'rasht', name: 'Rasht', nameFa: 'رشت', lat: 37.2808, lon: 49.5832, tz: 'Asia/Tehran' },
  { id: 'kerman', name: 'Kerman', nameFa: 'کرمان', lat: 30.2839, lon: 57.0834, tz: 'Asia/Tehran' },
  { id: 'santiago', name: 'Santiago', nameFa: 'سانتیاگو', lat: -33.4489, lon: -70.6693, tz: 'America/Santiago' },
  { id: 'dubai', name: 'Dubai', nameFa: 'دبی', lat: 25.2048, lon: 55.2708, tz: 'Asia/Dubai' },
  { id: 'istanbul', name: 'Istanbul', nameFa: 'استانبول', lat: 41.0082, lon: 28.9784, tz: 'Europe/Istanbul' },
  { id: 'london', name: 'London', nameFa: 'لندن', lat: 51.5072, lon: -0.1276, tz: 'Europe/London' },
  { id: 'berlin', name: 'Berlin', nameFa: 'برلین', lat: 52.52, lon: 13.405, tz: 'Europe/Berlin' },
  { id: 'paris', name: 'Paris', nameFa: 'پاریس', lat: 48.8566, lon: 2.3522, tz: 'Europe/Paris' },
  { id: 'stockholm', name: 'Stockholm', nameFa: 'استکهلم', lat: 59.3293, lon: 18.0686, tz: 'Europe/Stockholm' },
  { id: 'toronto', name: 'Toronto', nameFa: 'تورنتو', lat: 43.6532, lon: -79.3832, tz: 'America/Toronto' },
  { id: 'vancouver', name: 'Vancouver', nameFa: 'ونکوور', lat: 49.2827, lon: -123.1207, tz: 'America/Vancouver' },
  { id: 'newyork', name: 'New York', nameFa: 'نیویورک', lat: 40.7128, lon: -74.006, tz: 'America/New_York' },
  { id: 'losangeles', name: 'Los Angeles', nameFa: 'لس‌آنجلس', lat: 34.0522, lon: -118.2437, tz: 'America/Los_Angeles' },
  { id: 'sydney', name: 'Sydney', nameFa: 'سیدنی', lat: -33.8688, lon: 151.2093, tz: 'Australia/Sydney' },
  { id: 'kabul', name: 'Kabul', nameFa: 'کابل', lat: 34.5553, lon: 69.2075, tz: 'Asia/Kabul' },
  { id: 'dushanbe', name: 'Dushanbe', nameFa: 'دوشنبه', lat: 38.5598, lon: 68.787, tz: 'Asia/Dushanbe' },
];

export const DEFAULT_EXPENSE_CATEGORIES_FA = ['خوراک', 'رفت‌وآمد', 'خرید', 'قبوض', 'سلامت', 'تفریح', 'سایر'];
export const DEFAULT_EXPENSE_CATEGORIES_EN = ['Food', 'Transport', 'Shopping', 'Bills', 'Health', 'Fun', 'Other'];

export const CURRENCY_CODES = ['IRT', 'IRR', 'USD', 'EUR', 'GBP', 'CAD', 'AUD', 'TRY', 'AED', 'CLP', 'AFN'] as const;

export const CUSTOM_FIELD_TYPES: CustomFieldType[] = ['text', 'longtext', 'number', 'date', 'checkbox', 'link', 'rating'];

export interface CustomTemplate {
  id: 'blank' | 'books' | 'contacts' | 'car' | 'ideas';
  fields: { label: [string, string]; type: CustomFieldType }[];
}

export const CUSTOM_TEMPLATES: CustomTemplate[] = [
  { id: 'blank', fields: [{ label: ['عنوان', 'Title'], type: 'text' }, { label: ['توضیح', 'Details'], type: 'longtext' }] },
  {
    id: 'books',
    fields: [
      { label: ['نام کتاب', 'Book'], type: 'text' },
      { label: ['نویسنده', 'Author'], type: 'text' },
      { label: ['امتیاز', 'Rating'], type: 'rating' },
      { label: ['تمام شد', 'Finished'], type: 'checkbox' },
    ],
  },
  {
    id: 'contacts',
    fields: [
      { label: ['نام', 'Name'], type: 'text' },
      { label: ['تلفن', 'Phone'], type: 'text' },
      { label: ['یادداشت', 'Note'], type: 'longtext' },
    ],
  },
  {
    id: 'car',
    fields: [
      { label: ['کار انجام‌شده', 'Service'], type: 'text' },
      { label: ['تاریخ', 'Date'], type: 'date' },
      { label: ['کیلومتر', 'Odometer (km)'], type: 'number' },
      { label: ['هزینه', 'Cost'], type: 'number' },
    ],
  },
  {
    id: 'ideas',
    fields: [
      { label: ['ایده', 'Idea'], type: 'text' },
      { label: ['شرح', 'Description'], type: 'longtext' },
      { label: ['انجام‌شده', 'Done'], type: 'checkbox' },
    ],
  },
];

function num(v: unknown, def: number, min: number, max: number): number {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : def;
}

function oneOf<T extends string>(v: unknown, allowed: readonly T[], def: T): T {
  return typeof v === 'string' && (allowed as readonly string[]).includes(v) ? (v as T) : def;
}

function sanitizeFields(v: unknown): CustomField[] {
  if (!Array.isArray(v)) return [];
  const out: CustomField[] = [];
  for (const f of v.slice(0, LIMITS.maxCustomFields)) {
    if (!f || typeof f !== 'object') continue;
    const o = f as Record<string, unknown>;
    const label = String(o.label ?? '').trim().slice(0, 40);
    if (!label) continue;
    out.push({
      id: typeof o.id === 'string' && o.id ? o.id.slice(0, 40) : `f${out.length + 1}`,
      label,
      type: oneOf(o.type, CUSTOM_FIELD_TYPES, 'text'),
    });
  }
  return out;
}

function sanitizeCities(v: unknown): CityRef[] {
  if (!Array.isArray(v)) return [];
  const out: CityRef[] = [];
  for (const c of v.slice(0, 8)) {
    if (!c || typeof c !== 'object') continue;
    const o = c as Record<string, unknown>;
    const lat = Number(o.lat);
    const lon = Number(o.lon);
    const tz = String(o.tz ?? '');
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180 || !tz) continue;
    out.push({
      id: String(o.id ?? `${lat},${lon}`).slice(0, 60),
      name: String(o.name ?? '').slice(0, 60),
      nameFa: o.nameFa ? String(o.nameFa).slice(0, 60) : undefined,
      lat,
      lon,
      tz,
    });
  }
  return out;
}

/** Type-specific config: unknown keys dropped, values coerced to allowed ranges. */
export function sanitizeConfig(type: ModuleType, raw: Record<string, unknown> | undefined, locale: 'fa' | 'en' = 'fa'): Record<string, unknown> {
  const c = raw ?? {};
  switch (type) {
    case 'tasks':
      return {
        view: oneOf(c.view, ['today', 'upcoming', 'week', 'done'] as const, 'today'),
        defaultReminder: c.defaultReminder === null ? null : num(c.defaultReminder, 0, 0, 1440),
      };
    case 'music':
      return { repeat: oneOf(c.repeat, ['off', 'one', 'all'] as const, 'all'), volume: num(c.volume, 80, 0, 100) };
    case 'pdf':
      return { summaryLanguage: oneOf(c.summaryLanguage, ['fa', 'en'] as const, locale), summaryLength: oneOf(c.summaryLength, ['short', 'medium'] as const, 'short') };
    case 'transcription':
      return { keepAudio: c.keepAudio === true };
    case 'focus':
      return { focusMin: num(c.focusMin, 25, 1, 180), breakMin: num(c.breakMin, 5, 1, 60), sound: c.sound !== false };
    case 'habits':
      return { waterGoal: num(c.waterGoal, 8, 1, 30), showWater: c.showWater !== false };
    case 'expenses': {
      const cats = Array.isArray(c.categories)
        ? (c.categories as unknown[]).map((x) => String(x).trim().slice(0, 30)).filter(Boolean).slice(0, 16)
        : [];
      return {
        currency: oneOf(c.currency, CURRENCY_CODES, locale === 'fa' ? 'IRT' : 'USD'),
        categories: cats.length ? cats : locale === 'fa' ? DEFAULT_EXPENSE_CATEGORIES_FA : DEFAULT_EXPENSE_CATEGORIES_EN,
      };
    }
    case 'weather': {
      const cities = sanitizeCities(c.cities);
      return {
        cities: cities.length ? cities : [CITY_LIBRARY[0]!, CITY_LIBRARY.find((x) => x.id === 'santiago')!],
        unit: oneOf(c.unit, ['c', 'f'] as const, 'c'),
      };
    }
    case 'calendar':
      return { showHijri: c.showHijri === true, weekStart: oneOf(c.weekStart, ['sat', 'sun', 'mon'] as const, locale === 'fa' ? 'sat' : 'mon') };
    case 'custom': {
      const fields = sanitizeFields(c.fields);
      return {
        fields: fields.length ? fields : sanitizeFields([{ id: 'f1', label: locale === 'fa' ? 'عنوان' : 'Title', type: 'text' }]),
        layout: oneOf(c.layout, ['cards', 'table'] as const, 'cards'),
      };
    }
    default:
      return {};
  }
}

export function defaultAppearanceFor(type: ModuleType) {
  const meta = CATALOG[type];
  return {
    preset: 'default' as const,
    accent: isAccent(meta.accent) ? meta.accent : ('teal' as Accent),
    icon: meta.icon,
    width: meta.width,
    density: 'comfortable' as const,
  };
}
