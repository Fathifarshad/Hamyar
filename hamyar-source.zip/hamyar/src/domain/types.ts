import type { Accent, CardPreset, IconKey, Scheme } from '../config/appearance';

export const MODULE_TYPES = [
  'tasks',
  'music',
  'pdf',
  'video',
  'transcription',
  'medications',
  'notes',
  'bookmarks',
  'focus',
  'checklists',
  'habits',
  'expenses',
  'weather',
  'calendar',
  'custom',
  'vehicles',
] as const;
export type ModuleType = (typeof MODULE_TYPES)[number];

export type InputLanguage = 'fa-IR' | 'en-US';
export type VoiceMode = 'dictation' | 'command';
export type Locale = 'fa' | 'en';

export interface ModuleAppearance {
  preset: CardPreset;
  accent: Accent;
  icon: IconKey;
  width: 'normal' | 'wide';
  density: 'comfortable' | 'compact';
}

export interface ModuleInstance {
  id: string;
  type: ModuleType;
  title: string;
  /** 1 = shown on the dashboard. Stored as a number so it can be indexed. */
  active: 0 | 1;
  archivedAt: string | null;
  order: number;
  inputLanguage: InputLanguage;
  voiceMode: VoiceMode;
  /** pauses this module's reminders without hiding or archiving it */
  remindersPaused: boolean;
  appearance: ModuleAppearance;
  config: Record<string, unknown>;
  configVersion: number;
  version: number;
  createdAt: string;
  updatedAt: string;
}

export type ThemeSetting = 'system' | 'light' | 'dark';
export type LayoutMode = 'grid' | 'list' | 'focus';
export type CalendarSystem = 'jalali' | 'gregorian';

export interface Profile {
  id: 'profile';
  locale: Locale;
  theme: ThemeSetting;
  scheme: Scheme;
  fontScale: 'normal' | 'large';
  calendar: CalendarSystem;
  timezone: string;
  layoutMode: LayoutMode;
  focusModuleId: string | null;
  onboarded: boolean;
  reminderSound: boolean;
  systemNotifications: boolean;
  sampleData: boolean;
  version: number;
  updatedAt: string;
}

/** A recurring or one-off schedule, interpreted in its own IANA time zone. */
export interface ScheduleRule {
  freq: 'once' | 'daily' | 'weekly';
  /** local date YYYY-MM-DD (Gregorian ISO) */
  startDate: string;
  /** inclusive local end date, or null for open-ended */
  endDate: string | null;
  /** 0 = Sunday … 6 = Saturday; used when freq = weekly */
  weekdays: number[];
  /** local wall times HH:mm; empty for an all-day (untimed) task */
  times: string[];
  timezone: string;
}

/** Schedule revision: a rule that applies from `validFrom` (UTC ms) until the next revision. */
export interface ScheduleRevision {
  validFrom: number;
  rule: ScheduleRule;
}

export const DST_POLICY = 'gap-forward_fold-first' as const;

export interface Task {
  id: string;
  moduleId: string;
  kind: 'task' | 'event';
  title: string;
  notes: string;
  priority: 'low' | 'normal' | 'high';
  /** null = no date yet (inbox task) */
  revisions: ScheduleRevision[] | null;
  /** minutes before the due time; null = no reminder */
  reminderOffset: number | null;
  dstPolicy: typeof DST_POLICY;
  revision: number;
  createdAt: string;
  updatedAt: string;
}

export interface TaskCompletion {
  /** `${taskId}|${occurrenceKey}` */
  id: string;
  taskId: string;
  moduleId: string;
  occurrence: string;
  completedAt: string;
}

export interface MedicationSnapshot {
  name: string;
  dosageText: string;
  unitText: string;
  localDate: string;
  localTime: string;
  timezone: string;
}

export interface Medication {
  id: string;
  moduleId: string;
  name: string;
  dosageText: string;
  unitText: string;
  notes: string;
  revisions: ScheduleRevision[];
  active: boolean;
  reminderEnabled: boolean;
  showNameInNotification: boolean;
  dstPolicy: typeof DST_POLICY;
  revision: number;
  createdAt: string;
  updatedAt: string;
}

export type MedAction = 'taken' | 'skipped' | 'cleared';

export interface MedEvent {
  id: string;
  medId: string;
  moduleId: string;
  /** `${medId}|${localDate}|${localTime}` */
  occurrenceKey: string;
  scheduledAt: number;
  action: MedAction;
  actualTakenAt: string | null;
  recordedAt: string;
  snapshot: MedicationSnapshot;
  supersedesId: string | null;
  idempotencyKey: string;
}

export interface ReminderRecord {
  /** deterministic per occurrence (and per snooze), so a second claim fails */
  id: string;
  kind: 'task' | 'medication' | 'focus' | 'vehicle';
  sourceId: string;
  moduleId: string;
  occurrenceKey: string;
  dueAt: number;
  firedAt: string;
  late: boolean;
  title: string;
  body: string;
  readAt: string | null;
  snoozedUntil: number | null;
  followUpOf: string | null;
  delivery: 'in_app' | 'system' | 'none';
}

export interface Asset {
  id: string;
  moduleId: string;
  kind: 'audio' | 'video' | 'pdf' | 'recording';
  name: string;
  mime: string;
  size: number;
  hash: string;
  blob: Blob;
  createdAt: string;
}

export type MediaSourceType = 'file' | 'url' | 'youtube' | 'aparat' | 'external';

export interface MediaItem {
  id: string;
  moduleId: string;
  kind: 'audio' | 'video';
  sourceType: MediaSourceType;
  assetId: string | null;
  url: string | null;
  embedId: string | null;
  title: string;
  artist: string;
  favorite: boolean;
  order: number;
  position: number;
  duration: number | null;
  missingFile: boolean;
  createdAt: string;
}

export interface PdfDocument {
  id: string;
  moduleId: string;
  assetId: string | null;
  name: string;
  size: number;
  tags: string[];
  pageCount: number;
  textPageCount: number;
  extraction: 'pending' | 'running' | 'done' | 'failed' | 'encrypted';
  extractionError: string | null;
  contentHash: string | null;
  lastPage: number;
  createdAt: string;
}

export interface PdfPage {
  /** `${docId}|${pageNumber}` */
  id: string;
  docId: string;
  pageNumber: number;
  text: string;
  hasText: boolean;
}

export interface PdfSummary {
  overview: string;
  highlights: { text: string; pageNumbers: number[] }[];
  actionItems: { text: string; pageNumbers: number[] }[];
  caveats: string[];
  coveredPages: number[];
  totalPages: number;
  language: 'fa' | 'en';
}

export interface SummaryRecord {
  id: string;
  docId: string;
  cacheKey: string;
  language: 'fa' | 'en';
  length: 'short' | 'medium';
  promptVersion: string;
  provider: string;
  result: PdfSummary;
  createdAt: string;
}

export interface Transcript {
  id: string;
  moduleId: string;
  title: string;
  text: string;
  language: InputLanguage;
  source: 'recording' | 'file' | 'live' | 'manual';
  assetId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Note {
  id: string;
  moduleId: string;
  title: string;
  body: string;
  tags: string[];
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Bookmark {
  id: string;
  moduleId: string;
  title: string;
  url: string;
  tags: string[];
  order: number;
  createdAt: string;
}

export interface FocusState {
  /** = moduleId */
  id: string;
  phase: 'focus' | 'break';
  status: 'idle' | 'running' | 'paused';
  /** epoch ms when the running phase ends */
  endAt: number | null;
  pausedRemainingMs: number | null;
  sessionsDate: string;
  sessionsCount: number;
  updatedAt: string;
}

export interface FocusSession {
  id: string;
  moduleId: string;
  startedAt: string;
  endedAt: string;
  minutes: number;
}

export interface Checklist {
  id: string;
  moduleId: string;
  name: string;
  archived: boolean;
  order: number;
  createdAt: string;
}

export interface ChecklistItem {
  id: string;
  listId: string;
  moduleId: string;
  text: string;
  done: boolean;
  order: number;
  createdAt: string;
}

export interface Habit {
  id: string;
  moduleId: string;
  name: string;
  order: number;
  archived: boolean;
  createdAt: string;
}

export interface HabitLog {
  /** `${habitId}|${date}` */
  id: string;
  habitId: string;
  moduleId: string;
  date: string;
}

export interface WaterLog {
  /** `${moduleId}|${date}` */
  id: string;
  moduleId: string;
  date: string;
  count: number;
}

export interface Expense {
  id: string;
  moduleId: string;
  amount: number;
  currency: string;
  category: string;
  note: string;
  date: string;
  createdAt: string;
}

export interface CountdownEvent {
  id: string;
  moduleId: string;
  title: string;
  /** Gregorian ISO date of the (next) occurrence the user picked */
  date: string;
  repeatYearly: boolean;
  /** which calendar the yearly repeat follows */
  calendar: CalendarSystem;
  createdAt: string;
}

/** What a car record is about. Insurance, inspection and road tax are valid until a date; the rest are work done. */
export const VEHICLE_RECORD_KINDS = ['insurance_third', 'insurance_body', 'inspection', 'toll', 'oil', 'service', 'tires', 'brakes', 'battery', 'repair', 'other'] as const;
export type VehicleRecordKind = (typeof VEHICLE_RECORD_KINDS)[number];

export interface Vehicle {
  id: string;
  moduleId: string;
  /** what the owner calls it, e.g. «پژو سفید» */
  name: string;
  make: string;
  model: string;
  /** model year as written (Jalali or Gregorian) */
  year: string;
  color: string;
  plate: string;
  /** stored upper-case without spaces */
  vin: string;
  engineNo: string;
  /** last known odometer reading, in the section's distance unit */
  odometer: number | null;
  odometerDate: string | null;
  notes: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface VehicleRecord {
  id: string;
  vehicleId: string;
  moduleId: string;
  kind: VehicleRecordKind;
  title: string;
  /** ISO date the work was done or the policy starts */
  date: string;
  /** ISO date an insurance policy, inspection or road tax runs out */
  validUntil: string | null;
  odometer: number | null;
  /** when the same work is next due */
  nextDueKm: number | null;
  nextDueDate: string | null;
  cost: number | null;
  currency: string;
  /** insurer, garage or shop */
  provider: string;
  /** policy, invoice or receipt number */
  reference: string;
  /** parts or extras done with it, e.g. filters changed */
  items: string[];
  notes: string;
  /** remind before validUntil / nextDueDate */
  remind: boolean;
  createdAt: string;
  updatedAt: string;
}

export type CustomFieldType = 'text' | 'longtext' | 'number' | 'date' | 'checkbox' | 'link' | 'rating';

export interface CustomField {
  id: string;
  label: string;
  type: CustomFieldType;
}

export interface CustomEntry {
  id: string;
  moduleId: string;
  values: Record<string, string | number | boolean | null>;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface KvRecord {
  key: string;
  value: unknown;
}

export interface Consent {
  /** `${feature}:${provider}` */
  id: string;
  feature: 'summary' | 'transcription' | 'speech';
  provider: string;
  grantedAt: string;
  version: number;
}

export class DomainError extends Error {
  readonly code: string;
  readonly details?: Record<string, unknown>;
  constructor(code: string, message?: string, details?: Record<string, unknown>) {
    super(message ?? code);
    this.code = code;
    this.details = details;
  }
}
