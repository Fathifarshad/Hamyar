/**
 * Time-zone helpers built on Intl only (no dependency on the device zone).
 * Instants are UTC epoch milliseconds; local dates are ISO 'YYYY-MM-DD' strings and
 * local times are 'HH:mm' strings interpreted in an explicit IANA zone.
 *
 * DST policy (PRD §9): a wall time that does not exist (spring-forward gap) maps to the
 * first valid instant after the gap; a wall time that happens twice (fall-back fold)
 * maps to its first occurrence.
 */

export interface LocalParts {
  y: number;
  m: number;
  d: number;
  h: number;
  min: number;
  s: number;
}

const dtfCache = new Map<string, Intl.DateTimeFormat>();

function dtf(tz: string): Intl.DateTimeFormat {
  let f = dtfCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone: tz,
      hourCycle: 'h23',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    dtfCache.set(tz, f);
  }
  return f;
}

export function isValidTimeZone(tz: string): boolean {
  if (!tz) return false;
  try {
    dtf(tz);
    return true;
  } catch {
    return false;
  }
}

export function deviceTimeZone(): string {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    return tz && isValidTimeZone(tz) ? tz : 'UTC';
  } catch {
    return 'UTC';
  }
}

export function listTimeZones(): string[] {
  const intl = Intl as unknown as { supportedValuesOf?: (k: string) => string[] };
  try {
    const list = intl.supportedValuesOf?.('timeZone');
    if (list && list.length) return list.includes('UTC') ? list : ['UTC', ...list];
  } catch {
    /* fall through */
  }
  return [
    'UTC',
    'Asia/Tehran',
    'Asia/Dubai',
    'Asia/Kabul',
    'Asia/Dushanbe',
    'Europe/Istanbul',
    'Europe/London',
    'Europe/Berlin',
    'Europe/Paris',
    'Europe/Stockholm',
    'America/New_York',
    'America/Toronto',
    'America/Chicago',
    'America/Denver',
    'America/Los_Angeles',
    'America/Vancouver',
    'America/Santiago',
    'America/Sao_Paulo',
    'Australia/Sydney',
  ];
}

export function utcToLocal(utcMs: number, tz: string): LocalParts {
  const parts = dtf(tz).formatToParts(new Date(utcMs));
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? '0');
  return { y: get('year'), m: get('month'), d: get('day'), h: get('hour'), min: get('minute'), s: get('second') };
}

/** Offset of `tz` from UTC at the given instant, in minutes (e.g. +210 for Tehran). */
export function getOffsetMinutes(utcMs: number, tz: string): number {
  const p = utcToLocal(utcMs, tz);
  const asUtc = Date.UTC(p.y, p.m - 1, p.d, p.h, p.min, p.s);
  const truncated = Math.floor(utcMs / 1000) * 1000;
  return Math.round((asUtc - truncated) / 60000);
}

export function pad2(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

export function isoFromParts(y: number, m: number, d: number): string {
  return `${String(y).padStart(4, '0')}-${pad2(m)}-${pad2(d)}`;
}

export function parseISODate(iso: string): { y: number; m: number; d: number } {
  const [y, m, d] = iso.split('-').map(Number);
  return { y: y!, m: m!, d: d! };
}

export function isValidISODate(iso: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return false;
  const { y, m, d } = parseISODate(iso);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

export function isValidTime(hhmm: string): boolean {
  if (!/^\d{2}:\d{2}$/.test(hhmm)) return false;
  const [h, m] = hhmm.split(':').map(Number);
  return h! >= 0 && h! <= 23 && m! >= 0 && m! <= 59;
}

export function addDaysISO(iso: string, days: number): string {
  const { y, m, d } = parseISODate(iso);
  const dt = new Date(Date.UTC(y, m - 1, d + days));
  return isoFromParts(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate());
}

/** 0 = Sunday … 6 = Saturday */
export function weekdayOfISO(iso: string): number {
  const { y, m, d } = parseISODate(iso);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

export function diffDaysISO(later: string, earlier: string): number {
  const a = parseISODate(later);
  const b = parseISODate(earlier);
  return Math.round((Date.UTC(a.y, a.m - 1, a.d) - Date.UTC(b.y, b.m - 1, b.d)) / 86_400_000);
}

export function todayISO(tz: string, now: number = Date.now()): string {
  const p = utcToLocal(now, tz);
  return isoFromParts(p.y, p.m, p.d);
}

export function localTimeHHMM(utcMs: number, tz: string): string {
  const p = utcToLocal(utcMs, tz);
  return `${pad2(p.h)}:${pad2(p.min)}`;
}

export interface ZonedResolution {
  utc: number;
  /** the wall time did not exist and was moved to the end of the gap */
  shifted: boolean;
  /** the wall time happened twice; the first occurrence was chosen */
  ambiguous: boolean;
}

/** Converts a local wall date+time in `tz` to a UTC instant, applying the DST policy. */
export function resolveZoned(dateISO: string, timeHHMM: string, tz: string): ZonedResolution {
  const { y, m, d } = parseISODate(dateISO);
  const [hh, mm] = timeHHMM.split(':').map(Number);
  const wall = Date.UTC(y, m - 1, d, hh!, mm!);
  const DAY = 86_400_000;
  const offsets = Array.from(new Set([getOffsetMinutes(wall - DAY, tz), getOffsetMinutes(wall + DAY, tz), getOffsetMinutes(wall, tz)]));
  const valid: number[] = [];
  for (const o of offsets) {
    const t = wall - o * 60_000;
    if (getOffsetMinutes(t, tz) === o && !valid.includes(t)) valid.push(t);
  }
  if (valid.length) {
    valid.sort((a, b) => a - b);
    return { utc: valid[0]!, shifted: false, ambiguous: valid.length > 1 };
  }
  // Gap: find the first instant after the transition (minute precision).
  const candidates = offsets.map((o) => wall - o * 60_000);
  let lo = Math.min(...candidates);
  let hi = Math.max(...candidates);
  const offLo = getOffsetMinutes(lo, tz);
  while (hi - lo > 60_000) {
    const mid = Math.floor((lo + hi) / 2 / 60_000) * 60_000;
    if (mid <= lo || mid >= hi) break;
    if (getOffsetMinutes(mid, tz) === offLo) lo = mid;
    else hi = mid;
  }
  return { utc: hi, shifted: true, ambiguous: false };
}

export function zonedToUtc(dateISO: string, timeHHMM: string, tz: string): number {
  return resolveZoned(dateISO, timeHHMM, tz).utc;
}

/** Start of a local day as a UTC instant (midnight may not exist; policy applies). */
export function startOfLocalDay(dateISO: string, tz: string): number {
  return zonedToUtc(dateISO, '00:00', tz);
}
