import { Scanner, WB_END as E, WB_START as S } from './scanner';
import { addDaysISO, localTimeHHMM, pad2, resolveZoned, todayISO, weekdayOfISO } from '../time';
import { isValidJalali, jalaliToISO, nextJalaliMonthDay, nextGregorianMonthDay, parseFlexibleDate } from '../jalali';

export interface DateTimeContext {
  now: number;
  timezone: string;
}

export interface AmbiguousTime {
  kind: 'ampm' | 'night' | 'midnight';
  /** candidate HH:mm values the user must choose from */
  options: string[];
}

export interface DateTimeResult {
  date: string | null;
  /** no date was spoken; today was filled in and must be confirmed */
  dateAssumed: boolean;
  time: string | null;
  ambiguity: AmbiguousTime | null;
  isPast: boolean;
  at: number | null;
  /** the time fell into a DST gap and was moved forward */
  shifted: boolean;
  found: boolean;
}

type Period = 'am' | 'noon' | 'pm' | 'night' | 'early' | null;

const FA_HOUR_WORDS: Record<string, number> = {
  یک: 1,
  یه: 1,
  دو: 2,
  سه: 3,
  چهار: 4,
  پنج: 5,
  شش: 6,
  شیش: 6,
  هفت: 7,
  هشت: 8,
  نه: 9,
  ده: 10,
  یازده: 11,
  دوازده: 12,
};
const FA_HOUR_ALT = Object.keys(FA_HOUR_WORDS)
  .sort((a, b) => b.length - a.length)
  .join('|');

const FA_SMALL_NUMBERS: Record<string, number> = {
  ...FA_HOUR_WORDS,
  پونزده: 15,
  پانزده: 15,
  بیست: 20,
  سی: 30,
  چهل: 40,
  پنجاه: 50,
};
const FA_SMALL_ALT = Object.keys(FA_SMALL_NUMBERS)
  .sort((a, b) => b.length - a.length)
  .join('|');

const EN_NUMBERS: Record<string, number> = {
  a: 1,
  an: 1,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  fifteen: 15,
  twenty: 20,
  thirty: 30,
  forty: 40,
  'forty-five': 45,
  fifty: 50,
};

const FA_MONTHS: Record<string, number> = {
  فروردین: 1,
  اردیبهشت: 2,
  خرداد: 3,
  تیر: 4,
  مرداد: 5,
  شهریور: 6,
  مهر: 7,
  ابان: 8,
  اذر: 9,
  دی: 10,
  بهمن: 11,
  اسفند: 12,
};
const FA_MONTH_ALT = Object.keys(FA_MONTHS)
  .sort((a, b) => b.length - a.length)
  .join('|');

const EN_MONTHS: [RegExp, number][] = [
  [/^jan/, 1],
  [/^feb/, 2],
  [/^mar/, 3],
  [/^apr/, 4],
  [/^may/, 5],
  [/^jun/, 6],
  [/^jul/, 7],
  [/^aug/, 8],
  [/^sep/, 9],
  [/^oct/, 10],
  [/^nov/, 11],
  [/^dec/, 12],
];
const EN_MONTH_RE =
  '(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)';

const FA_WEEKDAYS: [string, number][] = [
  ['یک\\s*شنبه', 0],
  ['دو\\s*شنبه', 1],
  ['سه\\s*شنبه', 2],
  ['چهار\\s*شنبه', 3],
  ['پنج\\s*شنبه', 4],
  ['جمعه', 5],
  ['شنبه', 6],
];
const EN_WEEKDAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

function enMonth(word: string): number {
  for (const [re, n] of EN_MONTHS) if (re.test(word)) return n;
  return 0;
}

function num(token: string | undefined, dict: Record<string, number>): number | null {
  if (!token) return null;
  const t = token.trim();
  if (/^\d+$/.test(t)) return Number(t);
  return t in dict ? dict[t]! : null;
}

function nextWeekday(todayIso: string, weekday: number): string {
  const cur = weekdayOfISO(todayIso);
  let delta = (weekday - cur + 7) % 7;
  if (delta === 0) delta = 7;
  return addDaysISO(todayIso, delta);
}

function hhmm(h: number, m: number): string {
  return `${pad2(h)}:${pad2(m)}`;
}

/** Applies a spoken period (morning/evening…) to a 0–24 hour. Never guesses AM/PM silently. */
export function applyPeriod(h: number, m: number, period: Period, lang: 'fa' | 'en'): { time: string | null; ambiguity: AmbiguousTime | null } {
  if (h > 24 || m > 59) return { time: null, ambiguity: null };
  if (h === 24) h = 0;
  if (h >= 13) return { time: hhmm(h, m), ambiguity: null };
  if (h === 0) return { time: hhmm(0, m), ambiguity: null };
  switch (period) {
    case 'am':
      if (h === 12) return lang === 'en' ? { time: hhmm(0, m), ambiguity: null } : { time: null, ambiguity: { kind: 'ampm', options: [hhmm(0, m), hhmm(12, m)] } };
      return { time: hhmm(h, m), ambiguity: null };
    case 'early':
      return h <= 6 ? { time: hhmm(h, m), ambiguity: null } : { time: null, ambiguity: { kind: 'ampm', options: [hhmm(h, m), hhmm(h + 12, m)] } };
    case 'noon':
      if (h === 12 || h === 11) return { time: hhmm(h, m), ambiguity: null };
      if (h >= 1 && h <= 4) return { time: hhmm(h + 12, m), ambiguity: null };
      return { time: null, ambiguity: { kind: 'ampm', options: [hhmm(h, m), hhmm(h + 12, m)] } };
    case 'pm':
      return { time: hhmm(h === 12 ? 12 : h + 12, m), ambiguity: null };
    case 'night':
      if (h >= 5 && h <= 11) return { time: hhmm(h + 12, m), ambiguity: null };
      if (h === 12) return { time: null, ambiguity: { kind: 'midnight', options: [hhmm(0, m), hhmm(12, m)] } };
      return { time: null, ambiguity: { kind: 'night', options: [hhmm(h, m), hhmm(h + 12, m)] } };
    default:
      return { time: null, ambiguity: { kind: 'ampm', options: [hhmm(h, m), hhmm(h === 12 ? 0 : h + 12, m)] } };
  }
}

/**
 * Extracts one date and one time from free text (Persian or English).
 * Consumes the matched words from the scanner so the caller can use the rest as a title.
 */
export function extractDateTime(sc: Scanner, ctx: DateTimeContext): DateTimeResult {
  const today = todayISO(ctx.timezone, ctx.now);
  let date: string | null = null;
  let period: Period = null;
  let relativeMs: number | null = null;
  let found = false;

  // ── relative times: «۲ ساعت دیگر», «نیم ساعت بعد», «in 30 minutes»
  let m = sc.take(new RegExp(`${S}(\\d+|${FA_SMALL_ALT})\\s*ساعت\\s*و\\s*نیم\\s*(?:دیگه|دیگر|بعد)${E}`));
  if (m) relativeMs = ((num(m[1], FA_SMALL_NUMBERS) ?? 0) * 60 + 30) * 60_000;
  if (relativeMs === null) {
    m = sc.take(new RegExp(`${S}(\\d+|${FA_SMALL_ALT}|نیم)\\s*(ساعت|دقیقه)\\s*(?:دیگه|دیگر|بعد)${E}`));
    if (m) {
      const n = m[1] === 'نیم' ? 0.5 : num(m[1], FA_SMALL_NUMBERS);
      if (n !== null) relativeMs = n * (m[2] === 'ساعت' ? 3_600_000 : 60_000);
    }
  }
  if (relativeMs === null) {
    m = sc.take(new RegExp(`${S}(?:یه|یک)?\\s*ربع\\s*(?:ساعت\\s*)?(?:دیگه|دیگر|بعد)${E}`));
    if (m) relativeMs = 15 * 60_000;
  }
  if (relativeMs === null) {
    m = sc.take(/\bin\s+(\d+|an?|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty-five|forty|fifty|half an?)\s*(hours?|hrs?|minutes?|mins?)\b/);
    if (m) {
      const n = m[1]!.startsWith('half') ? 0.5 : num(m[1], EN_NUMBERS);
      if (n !== null) relativeMs = n * (m[2]!.startsWith('h') ? 3_600_000 : 60_000);
    }
  }
  if (relativeMs !== null && relativeMs > 0) {
    const at = ctx.now + relativeMs;
    return {
      date: todayISO(ctx.timezone, at),
      dateAssumed: false,
      time: localTimeHHMM(at, ctx.timezone),
      ambiguity: null,
      isPast: false,
      at,
      shifted: false,
      found: true,
    };
  }

  // ── dates
  if ((m = sc.take(new RegExp(`${S}پس\\s*فردا${E}`))) || (m = sc.take(/\bday after tomorrow\b/))) date = addDaysISO(today, 2);
  else if ((m = sc.take(new RegExp(`${S}فردا${E}`))) || (m = sc.take(/\btomorrow\b/))) date = addDaysISO(today, 1);
  else if ((m = sc.take(new RegExp(`${S}امشب${E}`))) || (m = sc.take(/\btonight\b/))) {
    date = today;
    period = 'night';
  } else if ((m = sc.take(new RegExp(`${S}امروز${E}`))) || (m = sc.take(/\btoday\b/))) date = today;
  else if ((m = sc.take(new RegExp(`${S}دیروز${E}`))) || (m = sc.take(/\byesterday\b/))) date = addDaysISO(today, -1);
  if (m) found = true;

  if (!date) {
    m = sc.take(new RegExp(`${S}(\\d+|${FA_SMALL_ALT})\\s*روز\\s*(?:دیگه|دیگر|بعد)${E}`)) ?? sc.take(/\bin\s+(\d+|two|three|four|five|six|seven|ten)\s+days?\b/);
    if (m) {
      const n = num(m[1], { ...FA_SMALL_NUMBERS, ...EN_NUMBERS });
      if (n !== null) {
        date = addDaysISO(today, n);
        found = true;
      }
    }
  }
  if (!date) {
    m = sc.take(/\b(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})\b/);
    if (m) {
      const iso = parseFlexibleDate(`${m[1]}/${m[2]}/${m[3]}`);
      if (iso) {
        date = iso;
        found = true;
      }
    }
  }
  if (!date) {
    m = sc.take(new RegExp(`${S}(\\d{1,2})\\s*(?:ام|م)?\\s*(${FA_MONTH_ALT})(?:\\s*ماه)?(?:\\s*(?:سال\\s*)?(\\d{4}))?${E}`));
    if (m) {
      const jd = Number(m[1]);
      const jm = FA_MONTHS[m[2]!]!;
      if (m[3]) {
        const jy = Number(m[3]);
        if (isValidJalali(jy, jm, jd)) date = jalaliToISO(jy, jm, jd);
      } else date = nextJalaliMonthDay(jm, jd, today);
      if (date) found = true;
    }
  }
  if (!date) {
    m =
      sc.take(new RegExp(`\\b${EN_MONTH_RE}\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s+(\\d{4}))?\\b`)) ??
      null;
    if (m) {
      const mo = enMonth(m[1]!);
      const d = Number(m[2]);
      date = m[3] ? parseFlexibleDate(`${m[3]}-${mo}-${d}`) : nextGregorianMonthDay(mo, d, today);
      if (date) found = true;
    } else {
      m = sc.take(new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?${EN_MONTH_RE}(?:,?\\s+(\\d{4}))?\\b`));
      if (m) {
        const mo = enMonth(m[2]!);
        const d = Number(m[1]);
        date = m[3] ? parseFlexibleDate(`${m[3]}-${mo}-${d}`) : nextGregorianMonthDay(mo, d, today);
        if (date) found = true;
      }
    }
  }
  if (!date) {
    for (const [word, wd] of FA_WEEKDAYS) {
      m = sc.take(new RegExp(`${S}${word}(?:\\s+(?:بعد|اینده|آینده|دیگه|دیگر))?${E}`));
      if (m) {
        date = nextWeekday(today, wd);
        found = true;
        break;
      }
    }
  }
  if (!date) {
    m = sc.take(/\b(?:next\s+|this\s+|on\s+)?(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/);
    if (m) {
      date = nextWeekday(today, EN_WEEKDAYS.indexOf(m[1]!));
      found = true;
    }
  }
  if (date) sc.take(new RegExp(`${S}هفته\\s*(?:بعد|اینده|دیگه|دیگر)${E}`));

  // ── time
  let hour: number | null = null;
  let minute = 0;
  let lang: 'fa' | 'en' = 'fa';

  m = sc.take(new RegExp(`${S}(?:یه|یک)?\\s*ربع\\s*به\\s*(?:ساعت\\s*)?(\\d{1,2}|${FA_HOUR_ALT})${E}`));
  if (m) {
    const h = num(m[1], FA_HOUR_WORDS);
    if (h !== null) {
      hour = h === 0 ? 23 : h - 1;
      minute = 45;
      if (hour === 0) hour = 12;
    }
  }
  if (hour === null) {
    m = sc.take(
      new RegExp(`${S}ساعت\\s*(\\d{1,2}|${FA_HOUR_ALT})(?:\\s*[:.]\\s*(\\d{2}))?(?:\\s*و\\s*(نیم|ربع|(\\d{1,2})\\s*دقیقه))?${E}`),
    );
    if (m) {
      hour = num(m[1], FA_HOUR_WORDS);
      if (m[2]) minute = Number(m[2]);
      else if (m[3] === 'نیم') minute = 30;
      else if (m[3] === 'ربع') minute = 15;
      else if (m[4]) minute = Number(m[4]);
    }
  }
  if (hour === null) {
    m = sc.take(/\b(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)(?![a-z])/);
    if (m) {
      lang = 'en';
      hour = Number(m[1]);
      minute = m[2] ? Number(m[2]) : 0;
      period = m[3]!.startsWith('a') ? 'am' : 'pm';
    }
  }
  if (hour === null) {
    m = sc.take(/\bat\s+(\d{1,2})(?::(\d{2}))?(?:\s*o'?clock)?\b(?!\s*(?:days?|hours?|minutes?|mins?|%))/);
    if (m) {
      lang = 'en';
      hour = Number(m[1]);
      minute = m[2] ? Number(m[2]) : 0;
    }
  }
  if (hour === null) {
    m = sc.take(/(?<![\d/.\-:])(\d{1,2})[:.](\d{2})(?![\d/.\-:])/);
    if (m) {
      hour = Number(m[1]);
      minute = Number(m[2]);
    }
  }
  if (hour === null) {
    m = sc.take(
      new RegExp(`${S}(\\d{1,2}|${FA_HOUR_ALT})(?:\\s*و\\s*(نیم|ربع))?(?=\\s*(?:صبح|ظهر|عصر|شب|بعد\\s*از\\s*ظهر|بعدازظهر|بامداد))`),
    );
    if (m) {
      hour = num(m[1], FA_HOUR_WORDS);
      minute = m[2] === 'نیم' ? 30 : m[2] === 'ربع' ? 15 : 0;
    }
  }
  if (hour === null && (sc.take(/\bnoon\b/) || sc.take(new RegExp(`${S}ظهر${E}`)))) {
    hour = 12;
    minute = 0;
    period = 'noon';
  }
  let midnightOnly = false;
  if (hour === null && (sc.take(/\bmidnight\b/) || sc.take(new RegExp(`${S}نیمه\\s*شب${E}`)))) {
    midnightOnly = true;
  }

  // periods (only meaningful with an hour)
  if (period === null || period === 'night') {
    const pm = sc.take(
      new RegExp(`${S}(صبح|قبل\\s*از\\s*ظهر|بعد\\s*از\\s*ظهر|بعدازظهر|ظهر|عصر|شب|بامداد|سحر)${E}`),
    );
    if (pm) {
      const w = pm[1]!.replace(/\s+/g, '');
      period = w === 'صبح' || w === 'قبلازظهر' ? 'am' : w === 'ظهر' ? 'noon' : w === 'شب' ? 'night' : w === 'بامداد' || w === 'سحر' ? 'early' : 'pm';
    } else {
      const en = sc.take(/\b(?:in the\s+)?(morning|afternoon|evening|night)\b|\bat night\b/);
      if (en) {
        lang = 'en';
        const w = en[1] ?? 'night';
        period = w === 'morning' ? 'am' : w === 'afternoon' || w === 'evening' ? 'pm' : 'night';
      }
    }
  }

  let time: string | null = null;
  let ambiguity: AmbiguousTime | null = null;
  if (hour !== null) {
    found = true;
    const r = applyPeriod(hour, minute, period, lang);
    time = r.time;
    ambiguity = r.ambiguity;
  } else if (midnightOnly) {
    found = true;
    ambiguity = { kind: 'midnight', options: ['00:00'] };
  }

  let dateAssumed = false;
  if (!date && (time || ambiguity)) {
    date = today;
    dateAssumed = true;
  }

  let at: number | null = null;
  let shifted = false;
  let isPast = false;
  if (date && time) {
    const r = resolveZoned(date, time, ctx.timezone);
    at = r.utc;
    shifted = r.shifted;
    isPast = at < ctx.now;
  } else if (date && !time && !ambiguity) {
    isPast = date < today;
  }

  return { date, dateAssumed, time, ambiguity, isPast, at, shifted, found };
}
