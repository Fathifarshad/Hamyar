import type { ModuleType } from '../types';
import { Scanner, WB_END as E, WB_START as S, stripFillers } from './scanner';
import { extractDateTime, type AmbiguousTime, type DateTimeContext } from './datetime';
import { parsePersianNumberWords } from '../normalize';

/**
 * Deterministic, limited grammar for voice/typed commands (PRD §8–9).
 * The parser only produces a draft; nothing runs from here. Each draft kind maps to a
 * handler registered by the module, and drafts that create or change data always go
 * through a preview the person confirms.
 */
export type CommandDraft =
  | {
      kind: 'create_task';
      title: string;
      date: string | null;
      time: string | null;
      dateAssumed: boolean;
      ambiguity: AmbiguousTime | null;
      isPast: boolean;
      shifted: boolean;
      timezone: string;
      missing: ('title' | 'date' | 'time')[];
      requiresConfirmation: true;
    }
  | { kind: 'media'; action: 'play' | 'pause' | 'next' | 'previous'; requiresConfirmation: false }
  | { kind: 'media_search'; query: string; target: 'artist' | 'track' | 'any'; requiresConfirmation: false }
  | { kind: 'media_favorites'; requiresConfirmation: false }
  | { kind: 'focus'; action: 'start' | 'pause' | 'resume' | 'reset' | 'skip'; minutes: number | null; requiresConfirmation: false }
  | { kind: 'create_note'; text: string; requiresConfirmation: true }
  | { kind: 'add_item'; text: string; items: string[]; requiresConfirmation: true }
  | { kind: 'check_item'; query: string; requiresConfirmation: true }
  | { kind: 'pdf_goto'; page: number; requiresConfirmation: false }
  | { kind: 'pdf_summarize'; requiresConfirmation: true }
  | { kind: 'water_add'; count: number; requiresConfirmation: false }
  | { kind: 'habit_check'; query: string; requiresConfirmation: true }
  | { kind: 'create_expense'; amount: number | null; currency: string | null; note: string; missing: 'amount'[]; requiresConfirmation: true }
  | { kind: 'create_countdown'; title: string; date: string | null; missing: ('title' | 'date')[]; requiresConfirmation: true }
  | { kind: 'open_bookmark'; query: string; requiresConfirmation: false }
  | { kind: 'open_module'; query: string; requiresConfirmation: false }
  | { kind: 'unsupported'; transcript: string; reason: 'empty' | 'not_understood' | 'not_allowed_here' };

export interface ParseContext extends DateTimeContext {
  moduleType: ModuleType;
}

/** Module types that accept command mode at all. Others are dictation-only. */
export const COMMAND_MODULES: ModuleType[] = [
  'tasks',
  'music',
  'video',
  'focus',
  'notes',
  'checklists',
  'pdf',
  'habits',
  'expenses',
  'calendar',
  'bookmarks',
];

const TASK_LEADING = [
  'یادم\\s*بنداز(?:\\s*که)?',
  'یادم\\s*بینداز(?:\\s*که)?',
  'به\\s*من\\s*یاداوری\\s*کن(?:\\s*که)?',
  'یاداوری\\s*کن(?:\\s*که)?',
  'لطفا',
  'یه\\s*کار\\s*اضافه\\s*کن',
  'اضافه\\s*کن',
  'ثبت\\s*کن',
  'قرار\\s*بذار',
  'قرار\\s*جدید',
  'کار\\s*جدید',
  'که',
  'remind me to',
  'remind me',
  'please',
  'add a task to',
  'add a task',
  'add task',
  'create a task',
  'create task',
  'schedule',
  'set a reminder to',
  'i have',
  "i've got",
  'i need to',
  'to',
];
const TASK_TRAILING = [
  'دارم',
  'داریم',
  'هست',
  'است',
  'رو\\s*یادم\\s*بنداز',
  'را\\s*یاداوری\\s*کن',
  'یادم\\s*بنداز',
  'یاداوری\\s*کن',
  'اضافه\\s*کن',
  'ثبت\\s*کن',
  'در',
  'برای',
  'ساعت',
  'روز',
  'please',
  'at',
  'on',
  'for',
];

function text(sc: Scanner): string {
  return sc.rest();
}

function isEmpty(s: string): boolean {
  return !s.replace(/[\s.،,]/g, '');
}

function parseTask(raw: string, ctx: ParseContext): CommandDraft {
  const sc = new Scanner(raw);
  const dt = extractDateTime(sc, ctx);
  const title = stripFillers(text(sc), TASK_LEADING, TASK_TRAILING);
  const missing: ('title' | 'date' | 'time')[] = [];
  if (!title) missing.push('title');
  if (!dt.date) missing.push('date');
  return {
    kind: 'create_task',
    title,
    date: dt.date,
    time: dt.time,
    dateAssumed: dt.dateAssumed,
    ambiguity: dt.ambiguity,
    isPast: dt.isPast,
    shifted: dt.shifted,
    timezone: ctx.timezone,
    missing,
    requiresConfirmation: true,
  };
}

const PLAY_VERB = '(?:پخش\\s*کن|پخش|بزن|بذار|بزار|بخون|play|put\\s*on)';
const MUSIC_NOUN = '(?:اهنگ|ترانه|موزیک|موسیقی|song|track|music)';

/** «آهنگ‌های X», «یه آهنگ از X», «songs by X» ask for an artist; «آهنگ X» for one track. */
function mediaQuery(text: string): { query: string; target: 'artist' | 'track' | 'any' } {
  let q = stripFillers(text, [PLAY_VERB, 'لطفا', 'please', 'برام', 'برامون', 'یه\\s*کم', 'the'], [`(?:رو|را)\\s*${PLAY_VERB}`, PLAY_VERB, 'رو', 'را', 'برام', 'لطفا', 'please']);
  const n = () => new Scanner(q).norm;
  let target: 'artist' | 'track' | 'any' = 'any';
  const cut = (re: RegExp) => {
    const m = re.exec(n());
    if (!m) return false;
    q = q.slice(m[0].length).trim();
    return true;
  };
  if (
    cut(new RegExp(`^\\s*(?:همه\\s*(?:ی|ء)?\\s*)?${MUSIC_NOUN}\\s*(?:ها|های|هایی|ای|هاش)\\s*(?:ی\\s*)?(?:از\\s+|مال\\s+)?`, 'u')) ||
    cut(new RegExp(`^\\s*(?:یه|یک|چند\\s*تا|چندتا)?\\s*${MUSIC_NOUN}?\\s*(?:از|مال)\\s+`, 'u')) ||
    cut(/^\s*(?:(?:all\s*)?(?:songs?|tracks?|music)\s+(?:by|from|of)|something\s+by|anything\s+by)\s+/u)
  )
    target = 'artist';
  else if (cut(new RegExp(`^\\s*${MUSIC_NOUN}\\s+`, 'u'))) target = 'track';
  else {
    const tail = new RegExp(`\\s+(?:${MUSIC_NOUN}\\s*(?:ها|های|اش)|songs?|tracks?)\\s*$`, 'u').exec(n());
    if (tail) {
      q = q.slice(0, tail.index).trim();
      target = 'artist';
    }
  }
  q = stripFillers(q, [PLAY_VERB, 'رو', 'را'], [`(?:رو|را)\\s*${PLAY_VERB}`, PLAY_VERB, 'رو', 'را']);
  return { query: q, target };
}

function matchMedia(raw: string): CommandDraft | null {
  const sc = new Scanner(raw);
  const n = sc.norm.trim();
  if (/^(?:اهنگ\s*)?(?:بعدی|next(?: track| song)?|skip)$/.test(n)) return { kind: 'media', action: 'next', requiresConfirmation: false };
  if (/^(?:اهنگ\s*)?(?:قبلی|previous(?: track| song)?|prev|back)$/.test(n)) return { kind: 'media', action: 'previous', requiresConfirmation: false };
  if (/^(?:توقف|مکث|وایسا|قطع\s*کن|stop|pause|stop music|pause music|بس\s*کن)(?:\s*کن)?$/.test(n))
    return { kind: 'media', action: 'pause', requiresConfirmation: false };
  if (/^(?:پخش|پخش\s*کن|بزن|play|resume|play music|ادامه(?:\s*بده)?|(?:اهنگ|موسیقی|موزیک)(?:\s*(?:پخش\s*کن|بزن|بذار))?)$/.test(n)) return { kind: 'media', action: 'play', requiresConfirmation: false };
  const { query, target } = mediaQuery(raw);
  if (/^(?:علاقه\s*مندی\s*ها(?:م)?|مورد\s*علاقه\s*ها|favou?rites?)$/u.test(new Scanner(query).norm.trim())) return { kind: 'media_favorites', requiresConfirmation: false };
  if (query && /[\p{L}\p{N}]/u.test(query)) return { kind: 'media_search', query, target, requiresConfirmation: false };
  return null;
}

function matchFocus(raw: string): CommandDraft | null {
  const sc = new Scanner(raw);
  const n = sc.norm.trim();
  const minutesMatch = n.match(/(\d{1,3})\s*(?:دقیقه|دقیقه ای|min(?:ute)?s?)/);
  const minutes = minutesMatch ? Math.min(180, Math.max(1, Number(minutesMatch[1]))) : null;
  if (/(?:شروع|start|begin|بزن\s*بریم|تایمر\s*رو\s*روشن)/.test(n)) return { kind: 'focus', action: 'start', minutes, requiresConfirmation: false };
  if (/(?:ادامه|resume|continue)/.test(n)) return { kind: 'focus', action: 'resume', minutes: null, requiresConfirmation: false };
  if (/(?:توقف|مکث|نگه\s*دار|pause|stop)/.test(n)) return { kind: 'focus', action: 'pause', minutes: null, requiresConfirmation: false };
  if (/(?:ریست|بازنشانی|از\s*اول|reset|restart)/.test(n)) return { kind: 'focus', action: 'reset', minutes: null, requiresConfirmation: false };
  if (/(?:رد\s*کن|بعدی|skip|next)/.test(n)) return { kind: 'focus', action: 'skip', minutes: null, requiresConfirmation: false };
  return null;
}

function matchPdf(raw: string): CommandDraft | null {
  const sc = new Scanner(raw);
  const n = sc.norm.trim();
  const page = n.match(/(?:صفحه|page|برو\s*به\s*صفحه|go to page)\s*(\d{1,4})/) ?? n.match(/^(\d{1,4})$/);
  if (page) return { kind: 'pdf_goto', page: Number(page[1]), requiresConfirmation: false };
  if (/(?:خلاصه|summar)/.test(n)) return { kind: 'pdf_summarize', requiresConfirmation: true };
  return null;
}

const CURRENCIES: { re: string; code: string; word: boolean }[] = [
  { re: 'دلار\\s*کانادا|cad', code: 'CAD', word: true },
  { re: 'تومن|تومان|toman', code: 'IRT', word: true },
  { re: 'ریال|rials?', code: 'IRR', word: true },
  { re: 'دلار|dollars?|usd', code: 'USD', word: true },
  { re: 'یورو|euros?|eur', code: 'EUR', word: true },
  { re: 'پوند|pounds?|gbp', code: 'GBP', word: true },
  { re: 'لیر|liras?', code: 'TRY', word: true },
  { re: 'درهم|dirhams?|aed', code: 'AED', word: true },
  { re: 'پزو|pesos?|clp', code: 'CLP', word: true },
  { re: '\\$', code: 'USD', word: false },
  { re: '€', code: 'EUR', word: false },
  { re: '£', code: 'GBP', word: false },
];

function parseExpense(raw: string): CommandDraft {
  const sc = new Scanner(raw);
  let amount: number | null = null;
  let currency: string | null = null;
  // «۵۰ هزار», «2.5 میلیون», «پنجاه هزار», «$12», «12.50»
  const m =
    sc.take(new RegExp(`${S}(\\d+(?:[.,]\\d+)?)\\s*(هزار|میلیون|میلیارد|k)?${E}`)) ??
    sc.take(
      new RegExp(
        `${S}((?:(?:یک|یه|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|سیزده|چهارده|پانزده|شانزده|هفده|هجده|نوزده|بیست|سی|چهل|پنجاه|شصت|هفتاد|هشتاد|نود|صد|یکصد|دویست|سیصد|چهارصد|پانصد|ششصد|هفتصد|هشتصد|نهصد|هزار|میلیون|میلیارد)\\s*(?:و\\s*)?)+)${E}`,
      ),
    );
  if (m) {
    if (/^\d/.test(m[1]!)) {
      const base = Number(m[1]!.replace(',', '.'));
      const scale = m[2] === 'هزار' || m[2] === 'k' ? 1_000 : m[2] === 'میلیون' ? 1_000_000 : m[2] === 'میلیارد' ? 1_000_000_000 : 1;
      amount = base * scale;
    } else amount = parsePersianNumberWords(m[1]!);
  }
  for (const c of CURRENCIES) {
    const hit = sc.take(new RegExp(c.word ? `${S}(?:${c.re})${E}` : c.re));
    if (hit) {
      currency = c.code;
      break;
    }
  }
  const note = stripFillers(text(sc), ['خرید', 'هزینه', 'برای', 'بابت', 'spent', 'for', 'on', 'paid'], ['خریدم', 'دادم', 'پرداخت\\s*کردم', 'خرج\\s*کردم', 'شد', 'بابت', 'برای']);
  return { kind: 'create_expense', amount, currency, note, missing: amount === null ? ['amount'] : [], requiresConfirmation: true };
}

function parseCountdown(raw: string, ctx: ParseContext): CommandDraft {
  const sc = new Scanner(raw);
  const dt = extractDateTime(sc, ctx);
  const title = stripFillers(text(sc), ['شمارش\\s*معکوس\\s*(?:برای|تا)?', 'رویداد', 'countdown to', 'countdown', 'event'], ['است', 'هست', 'داریم', 'دارم']);
  const missing: ('title' | 'date')[] = [];
  if (!title) missing.push('title');
  if (!dt.date || dt.dateAssumed) missing.push('date');
  return { kind: 'create_countdown', title, date: dt.dateAssumed ? null : dt.date, missing, requiresConfirmation: true };
}

/**
 * «نان، شیر و تخم‌مرغ» is three items. Commas always separate; «و» separates only short
 * parts, so «نان و پنیر» or a longer phrase stays one item.
 */
export function splitItems(text: string): string[] {
  const byComma = text
    .split(/\s*[،,]\s*/u)
    .map((x) => x.trim())
    .filter(Boolean);
  const out: string[] = [];
  for (const part of byComma) {
    const pieces = part.split(/\s+(?:و|and)\s+/u).map((x) => x.trim()).filter(Boolean);
    const short = pieces.length > 1 && pieces.every((p) => p.split(/\s+/).length <= 2) && (byComma.length > 1 || pieces.length > 2);
    out.push(...(short ? pieces : [part]));
  }
  return out.slice(0, 20);
}

export function parseCommand(transcript: string, ctx: ParseContext): CommandDraft {
  const raw = transcript.trim();
  if (isEmpty(raw)) return { kind: 'unsupported', transcript, reason: 'empty' };
  if (!COMMAND_MODULES.includes(ctx.moduleType)) return { kind: 'unsupported', transcript, reason: 'not_allowed_here' };

  const sc = new Scanner(raw);
  const open = sc.take(new RegExp(`^\\s*(?:باز\\s*کن|بازکن|open|برو\\s*به|go to)\\s+(?:بخش\\s+|section\\s+)?(.+)$`));
  if (open && ctx.moduleType !== 'pdf') {
    const query = raw.slice(open.index).replace(/^\s*\S+(?:\s+کن)?\s+(?:بخش\s+|section\s+)?/u, '').trim();
    if (ctx.moduleType === 'bookmarks') return { kind: 'open_bookmark', query, requiresConfirmation: false };
    if (query) return { kind: 'open_module', query, requiresConfirmation: false };
  }

  switch (ctx.moduleType) {
    case 'tasks':
      return parseTask(raw, ctx);
    case 'music':
    case 'video':
      return matchMedia(raw) ?? { kind: 'unsupported', transcript, reason: 'not_understood' };
    case 'focus':
      return matchFocus(raw) ?? { kind: 'unsupported', transcript, reason: 'not_understood' };
    case 'pdf':
      return matchPdf(raw) ?? { kind: 'unsupported', transcript, reason: 'not_understood' };
    case 'notes':
      return { kind: 'create_note', text: stripFillers(raw, ['یادداشت\\s*کن', 'بنویس', 'یادداشت', 'note', 'write down', 'take a note'], []), requiresConfirmation: true };
    case 'checklists': {
      const chk = new Scanner(raw).take(new RegExp(`^\\s*(?:تیک\\s*بزن|علامت\\s*بزن|check(?:\\s*off)?|done)\\s+(.+)$`));
      if (chk) return { kind: 'check_item', query: stripFillers(raw, ['تیک\\s*بزن', 'علامت\\s*بزن', 'check\\s*off', 'check', 'done'], ['رو', 'را']), requiresConfirmation: true };
      const item = stripFillers(raw, ['اضافه\\s*کن', 'بنویس', 'add', 'put'], ['رو\\s*اضافه\\s*کن', 'را\\s*اضافه\\s*کن', 'اضافه\\s*کن', 'to the list', 'to list', 'رو', 'را']);
      return { kind: 'add_item', text: item, items: splitItems(item), requiresConfirmation: true };
    }
    case 'habits': {
      const n = new Scanner(raw).norm;
      if (/(?:اب|لیوان|water|glass)/.test(n)) {
        const c = n.match(/(\d+)/);
        const words = parsePersianNumberWords(n.replace(/[^\p{L}\s]/gu, ' ').split(/\s+/).find((w) => parsePersianNumberWords(w) !== null) ?? '');
        const count = c ? Number(c[1]) : words ?? 1;
        return { kind: 'water_add', count: Math.max(1, Math.min(12, count)), requiresConfirmation: false };
      }
      const query = stripFillers(raw, ['تیک\\s*بزن', 'انجام\\s*شد', 'done', 'check'], ['انجام\\s*شد', 'انجام\\s*دادم', 'رو\\s*انجام\\s*دادم', 'کردم', 'done', 'رو', 'را']);
      return query ? { kind: 'habit_check', query, requiresConfirmation: true } : { kind: 'unsupported', transcript, reason: 'not_understood' };
    }
    case 'expenses':
      return parseExpense(raw);
    case 'calendar':
      return parseCountdown(raw, ctx);
    case 'bookmarks':
      return { kind: 'open_bookmark', query: stripFillers(raw, ['باز\\s*کن', 'open', 'برو\\s*به'], []), requiresConfirmation: false };
    default:
      return { kind: 'unsupported', transcript, reason: 'not_allowed_here' };
  }
}
