const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';

/**
 * Length-preserving normalization: every UTF-16 unit maps to exactly one unit, so
 * indexes found in the normalized text are valid in the original text too.
 */
export function normalizeKeepLength(s: string): string {
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const c = s[i]!;
    const fa = FA_DIGITS.indexOf(c);
    if (fa >= 0) {
      out += String(fa);
      continue;
    }
    const ar = AR_DIGITS.indexOf(c);
    if (ar >= 0) {
      out += String(ar);
      continue;
    }
    switch (c) {
      case 'ي':
      case 'ى':
        out += 'ی';
        continue;
      case 'ك':
        out += 'ک';
        continue;
      case 'ۀ':
      case 'ة':
        out += 'ه';
        continue;
      case 'أ':
      case 'إ':
      case 'آ':
        out += 'ا';
        continue;
      case 'ؤ':
        out += 'و';
        continue;
      case '٫':
        out += '.';
        continue;
      case '‌':
      case '‍':
      case '‎':
      case '‏':
      case 'ـ':
      case '،':
      case '؛':
      case '؟':
      case '!':
      case '?':
      case ',':
      case ';':
      case '"':
      case '«':
      case '»':
      case '\n':
      case '\t':
        out += ' ';
        continue;
    }
    const code = c.charCodeAt(0);
    if ((code >= 0x064b && code <= 0x065f) || code === 0x0670) {
      out += ' ';
      continue;
    }
    if (code >= 65 && code <= 90) {
      out += c.toLowerCase();
      continue;
    }
    out += c;
  }
  return out;
}

/** Letters on either side make a match part of a larger word. */
export const WB_START = '(?<![\\p{L}\\p{N}])';
export const WB_END = '(?![\\p{L}\\p{N}])';

export class Scanner {
  readonly orig: string;
  readonly norm: string;
  private used: boolean[];

  constructor(text: string) {
    this.orig = text;
    this.norm = normalizeKeepLength(text);
    this.used = new Array(text.length).fill(false);
  }

  /** Finds the first match not overlapping consumed text, marks it consumed and returns it. */
  take(re: RegExp): RegExpExecArray | null {
    const flags = re.flags.includes('g') ? re.flags : `${re.flags}g`;
    const g = new RegExp(re.source, flags.includes('u') ? flags : `${flags}u`);
    let m: RegExpExecArray | null;
    while ((m = g.exec(this.norm))) {
      const start = m.index;
      const end = start + m[0].length;
      if (m[0].length === 0) {
        g.lastIndex++;
        continue;
      }
      let free = true;
      for (let i = start; i < end; i++) {
        if (this.used[i]) {
          free = false;
          break;
        }
      }
      if (!free) continue;
      for (let i = start; i < end; i++) this.used[i] = true;
      return m;
    }
    return null;
  }

  /** Tests without consuming. */
  has(re: RegExp): boolean {
    const g = new RegExp(re.source, re.flags.includes('u') ? re.flags : `${re.flags}u`);
    const m = g.exec(this.norm);
    if (!m) return false;
    for (let i = m.index; i < m.index + m[0].length; i++) if (this.used[i]) return false;
    return true;
  }

  /** Original text with consumed spans removed and whitespace collapsed. */
  rest(): string {
    let out = '';
    for (let i = 0; i < this.orig.length; i++) out += this.used[i] ? ' ' : this.orig[i];
    return out.replace(/\s+/g, ' ').trim();
  }
}

/** Removes leading/trailing filler phrases (matched on normalized text) from `text`. */
export function stripFillers(text: string, leading: string[], trailing: string[]): string {
  let t = text.trim();
  let changed = true;
  let guard = 0;
  while (changed && guard < 12) {
    changed = false;
    guard++;
    const n = normalizeKeepLength(t);
    for (const f of leading) {
      const re = new RegExp(`^\\s*${f}${WB_END}\\s*`, 'u');
      const m = re.exec(n);
      if (m) {
        t = t.slice(m[0].length).trim();
        changed = true;
        break;
      }
    }
    if (changed) continue;
    for (const f of trailing) {
      const re = new RegExp(`\\s*${WB_START}${f}\\s*[.。]*\\s*$`, 'u');
      const m = re.exec(n);
      if (m) {
        t = t.slice(0, m.index).trim();
        changed = true;
        break;
      }
    }
  }
  return t.replace(/^[\s:،,.\-–]+|[\s:،,\-–]+$/g, '').trim();
}
