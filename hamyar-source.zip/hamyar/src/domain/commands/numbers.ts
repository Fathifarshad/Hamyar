import { parsePersianNumberWords } from '../normalize';

/**
 * Numbers as people say or type them, on text normalized by the Scanner (ASCII digits):
 * «۸۵٬۰۰۰», «85,000», «85.000» (a thousands dot, as written in Chile), «۸۵ هزار»,
 * «2.5 میلیون», «هشتاد و پنج هزار».
 */

export const FA_NUMBER_WORD =
  '(?:یکصد|یک|یه|دویست|دوازده|دو|سیصد|سیزده|سه|چهارصد|چهارده|چهار|پانصد|پونصد|پانزده|پونزده|پنجاه|پنج|ششصد|شصت|شانزده|شونزده|شش|شیش|هفتصد|هفتاد|هفده|هیفده|هفت|هشتصد|هشتاد|هجده|هیجده|هشت|نهصد|نوزده|نود|نه|یازده|ده|بیست|سی|چهل|صد|هزار|میلیون|میلیارد)';

const SCALE = '(?:هزار|میلیون|میلیارد|k)';

/** A regex fragment (no capture groups) that matches one spoken or written number. */
export const NUMBER_RE = `(?:(?:\\d{1,3}(?:[,٬]\\d{3})+|\\d{1,3}(?: \\d{3})+(?!\\d)|\\d{1,3}(?:\\.\\d{3})+(?![\\d.])|\\d+(?:\\.\\d+)?)(?:\\s*${SCALE})?|${FA_NUMBER_WORD}(?:\\s*(?:و\\s*)?${FA_NUMBER_WORD})*)`;

/** Reads a phrase matched by NUMBER_RE. */
export function readNumber(phrase: string): number | null {
  const s = phrase.trim();
  const m = s.match(/^(\d{1,3}(?:[,٬ ]\d{3})+|\d{1,3}(?:\.\d{3})+|\d+(?:\.\d+)?)\s*(هزار|میلیون|میلیارد|k)?$/);
  if (m) {
    const raw = m[1]!;
    const base = /^\d{1,3}(?:[,٬ ]\d{3})+$/.test(raw) ? Number(raw.replace(/[,٬ ]/g, '')) : /^\d{1,3}(?:\.\d{3})+$/.test(raw) ? Number(raw.replace(/\./g, '')) : Number(raw);
    const scale = m[2] === 'هزار' || m[2] === 'k' ? 1_000 : m[2] === 'میلیون' ? 1_000_000 : m[2] === 'میلیارد' ? 1_000_000_000 : 1;
    const n = base * scale;
    return Number.isFinite(n) ? n : null;
  }
  return parsePersianNumberWords(s);
}

export interface CurrencyWord {
  re: string;
  code: string;
  word: boolean;
}

export const CURRENCY_WORDS: CurrencyWord[] = [
  { re: 'دلار\\s*کانادا|cad', code: 'CAD', word: true },
  { re: 'تومن|تومان|toman', code: 'IRT', word: true },
  { re: 'ریال|rials?', code: 'IRR', word: true },
  { re: 'دلار|dollars?|usd', code: 'USD', word: true },
  { re: 'یورو|euros?|eur', code: 'EUR', word: true },
  { re: 'پوند|pounds?|gbp', code: 'GBP', word: true },
  { re: 'لیر|liras?', code: 'TRY', word: true },
  { re: 'درهم|dirhams?|aed', code: 'AED', word: true },
  { re: 'پزو|pesos?|clp', code: 'CLP', word: true },
  { re: '\\$', code: 'USD', word: false },
  { re: '€', code: 'EUR', word: false },
  { re: '£', code: 'GBP', word: false },
];

/** One alternation of every currency word, longest first. */
export const CURRENCY_RE = `(?:${CURRENCY_WORDS.filter((c) => c.word)
  .map((c) => c.re)
  .join('|')})`;

export function currencyCode(word: string): string | null {
  for (const c of CURRENCY_WORDS) if (new RegExp(`^(?:${c.re})$`, 'u').test(word.trim())) return c.code;
  return null;
}
