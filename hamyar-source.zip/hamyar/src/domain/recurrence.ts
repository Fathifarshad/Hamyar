import type { ScheduleRevision, ScheduleRule } from './types';
import { addDaysISO, isValidISODate, isValidTime, isValidTimeZone, resolveZoned, todayISO, weekdayOfISO } from './time';

export interface Occurrence {
  /** `${date}|${time}` or `${date}|allday` — stable for a given rule */
  key: string;
  date: string;
  time: string | null;
  /** UTC instant; null for all-day items */
  at: number | null;
  timezone: string;
  /** the wall time fell into a DST gap and was moved forward */
  shifted: boolean;
  revisionIndex: number;
}

export function validateRule(rule: ScheduleRule): string[] {
  const errors: string[] = [];
  if (!isValidISODate(rule.startDate)) errors.push('startDate');
  if (rule.endDate !== null && (!isValidISODate(rule.endDate) || rule.endDate < rule.startDate)) errors.push('endDate');
  if (rule.freq === 'weekly' && (!rule.weekdays.length || rule.weekdays.some((d) => d < 0 || d > 6))) errors.push('weekdays');
  if (rule.times.some((t) => !isValidTime(t))) errors.push('times');
  if (!isValidTimeZone(rule.timezone)) errors.push('timezone');
  return errors;
}

export function ruleMatchesDate(rule: ScheduleRule, iso: string): boolean {
  if (iso < rule.startDate) return false;
  if (rule.endDate && iso > rule.endDate) return false;
  switch (rule.freq) {
    case 'once':
      return iso === rule.startDate;
    case 'daily':
      return true;
    case 'weekly':
      return rule.weekdays.includes(weekdayOfISO(iso));
  }
}

function revisionWindow(revisions: ScheduleRevision[], i: number): [number, number] {
  const from = revisions[i]!.validFrom;
  const to = i + 1 < revisions.length ? revisions[i + 1]!.validFrom : Number.POSITIVE_INFINITY;
  return [from, to];
}

function* datesBetween(fromIso: string, toIso: string): Generator<string> {
  let d = fromIso;
  let guard = 0;
  while (d <= toIso && guard < 4000) {
    yield d;
    d = addDaysISO(d, 1);
    guard++;
  }
}

/**
 * Occurrences whose local date (in each rule's zone) is within [fromDate, toDate],
 * each attributed to the revision that was in force at its instant.
 */
export function expandByDates(revisions: ScheduleRevision[] | null, fromDate: string, toDate: string): Occurrence[] {
  if (!revisions || !revisions.length || toDate < fromDate) return [];
  const out: Occurrence[] = [];
  revisions.forEach((rev, i) => {
    const { rule } = rev;
    const [validFrom, validTo] = revisionWindow(revisions, i);
    const tz = rule.timezone;
    const validFromDate = validFrom > 0 ? todayISO(tz, validFrom) : '0000-01-01';
    const validToDate = Number.isFinite(validTo) ? todayISO(tz, validTo) : '9999-12-31';
    const start = rule.startDate > fromDate ? rule.startDate : fromDate;
    const end = rule.endDate && rule.endDate < toDate ? rule.endDate : toDate;
    if (end < start) return;
    const seen = new Set<number>();
    for (const date of datesBetween(start, end)) {
      if (!ruleMatchesDate(rule, date)) continue;
      if (!rule.times.length) {
        // all-day: the revision in force on that local date owns it
        if (date < validFromDate || date >= validToDate) continue;
        out.push({ key: `${date}|allday`, date, time: null, at: null, timezone: tz, shifted: false, revisionIndex: i });
        continue;
      }
      for (const time of rule.times) {
        const r = resolveZoned(date, time, tz);
        if (r.utc < validFrom || r.utc >= validTo) continue;
        if (seen.has(r.utc)) continue;
        seen.add(r.utc);
        out.push({ key: `${date}|${time}`, date, time, at: r.utc, timezone: tz, shifted: r.shifted, revisionIndex: i });
      }
    }
  });
  return out.sort(compareOccurrences);
}

/** Timed occurrences with an instant in [fromUtc, toUtc). */
export function expandByInstants(revisions: ScheduleRevision[] | null, fromUtc: number, toUtc: number): Occurrence[] {
  if (!revisions || !revisions.length || toUtc <= fromUtc) return [];
  const zones = Array.from(new Set(revisions.map((r) => r.rule.timezone)));
  let fromDate = '9999-12-31';
  let toDate = '0000-01-01';
  for (const tz of zones) {
    const a = addDaysISO(todayISO(tz, fromUtc), -1);
    const b = addDaysISO(todayISO(tz, toUtc), 1);
    if (a < fromDate) fromDate = a;
    if (b > toDate) toDate = b;
  }
  return expandByDates(revisions, fromDate, toDate).filter((o) => o.at !== null && o.at >= fromUtc && o.at < toUtc);
}

export function nextOccurrence(revisions: ScheduleRevision[] | null, afterUtc: number, horizonDays = 120): Occurrence | null {
  const list = expandByInstants(revisions, afterUtc, afterUtc + horizonDays * 86_400_000);
  return list[0] ?? null;
}

export function compareOccurrences(a: Occurrence, b: Occurrence): number {
  if (a.date !== b.date) return a.date < b.date ? -1 : 1;
  if (a.at === null && b.at === null) return 0;
  if (a.at === null) return -1;
  if (b.at === null) return 1;
  return a.at - b.at;
}

export function currentRule(revisions: ScheduleRevision[] | null): ScheduleRule | null {
  if (!revisions || !revisions.length) return null;
  return revisions[revisions.length - 1]!.rule;
}

/**
 * Applies an edited rule.
 * - one-off rules replace the schedule (nothing to preserve);
 * - recurring rules keep history: the new rule applies from `now` onwards.
 */
export function reviseSchedule(
  revisions: ScheduleRevision[] | null,
  next: ScheduleRule,
  now: number,
  opts: { keepHistory: boolean },
): ScheduleRevision[] {
  const prev = currentRule(revisions);
  if (!revisions || !revisions.length || !prev || !opts.keepHistory || (next.freq === 'once' && prev.freq === 'once')) {
    return [{ validFrom: 0, rule: next }];
  }
  const kept = revisions.filter((r) => r.validFrom < now);
  if (!kept.length) return [{ validFrom: 0, rule: next }];
  return [...kept, { validFrom: now, rule: next }];
}
