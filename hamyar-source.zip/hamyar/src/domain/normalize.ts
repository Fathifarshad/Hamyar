const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';

/** Converts Persian and Arabic-Indic digits to ASCII digits. */
export function toAsciiDigits(input: string): string {
  let out = '';
  for (const ch of input) {
    const fa = FA_DIGITS.indexOf(ch);
    if (fa >= 0) {
      out += String(fa);
      continue;
    }
    const ar = AR_DIGITS.indexOf(ch);
    if (ar >= 0) {
      out += String(ar);
      continue;
    }
    out += ch;
  }
  return out;
}

/** Converts ASCII digits to Persian digits (display only). */
export function toPersianDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]!);
}

/**
 * Normalization for matching and parsing (never for storage):
 * digits → ASCII, Arabic yeh/kaf → Persian, ZWNJ/tatweel/diacritics removed,
 * punctuation collapsed, lower-case for Latin text.
 */
export function normalizeForMatch(input: string): string {
  return toAsciiDigits(input)
    .replace(/[يى]/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[ۀة]/g, 'ه')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ؤ/g, 'و')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/ـ/g, '')
    .replace(/\u200C|\u200D|\u200E|\u200F/g, ' ') // ZWNJ, ZWJ, LRM, RLM
    .replace(/٫/g, '.')
    .replace(/[،؛؟!?,;"«»()[\]{}]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

/** Parses a user-typed number that may contain Persian digits and thousands separators. */
export function parseLocaleNumber(input: string): number | null {
  const cleaned = toAsciiDigits(input)
    .replace(/[٬,\s_]/g, '')
    .replace(/٫/g, '.')
    .trim();
  if (!cleaned || !/^-?\d*(\.\d+)?$/.test(cleaned)) return null;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
}

const UNITS: Record<string, number> = {
  صفر: 0,
  یک: 1,
  یه: 1,
  دو: 2,
  سه: 3,
  چهار: 4,
  پنج: 5,
  شش: 6,
  شیش: 6,
  هفت: 7,
  هشت: 8,
  نه: 9,
  ده: 10,
  یازده: 11,
  دوازده: 12,
  سیزده: 13,
  چهارده: 14,
  پانزده: 15,
  پونزده: 15,
  شانزده: 16,
  شونزده: 16,
  هفده: 17,
  هیفده: 17,
  هجده: 18,
  هیجده: 18,
  نوزده: 19,
  بیست: 20,
  سی: 30,
  چهل: 40,
  پنجاه: 50,
  شصت: 60,
  هفتاد: 70,
  هشتاد: 80,
  نود: 90,
  صد: 100,
  یکصد: 100,
  دویست: 200,
  سیصد: 300,
  چهارصد: 400,
  پانصد: 500,
  پونصد: 500,
  ششصد: 600,
  هفتصد: 700,
  هشتصد: 800,
  نهصد: 900,
};
const SCALES: Record<string, number> = { هزار: 1_000, میلیون: 1_000_000, میلیارد: 1_000_000_000 };

/**
 * Parses Persian number words such as «پنجاه هزار» or «دو میلیون و پانصد هزار».
 * Returns null when any token is not a number word.
 */
export function parsePersianNumberWords(input: string): number | null {
  const tokens = normalizeForMatch(input)
    .split(/\s+/)
    .filter((t) => t && t !== 'و');
  if (!tokens.length) return null;
  let total = 0;
  let current = 0;
  for (const tok of tokens) {
    if (/^\d+(\.\d+)?$/.test(tok)) {
      current += Number(tok);
      continue;
    }
    if (tok in UNITS) {
      current += UNITS[tok]!;
      continue;
    }
    if (tok in SCALES) {
      total += (current || 1) * SCALES[tok]!;
      current = 0;
      continue;
    }
    return null;
  }
  return total + current;
}

/**
 * Case/diacritic-insensitive "contains" match for search fields. Spaces and ZWNJ are
 * ignored, because Persian text writes «می‌کنم», «می کنم» and «میکنم» interchangeably.
 */
export function matchesQuery(haystack: string, query: string): boolean {
  const q = normalizeForMatch(query).replace(/\s+/g, '');
  if (!q) return true;
  return normalizeForMatch(haystack).replace(/\s+/g, '').includes(q);
}
