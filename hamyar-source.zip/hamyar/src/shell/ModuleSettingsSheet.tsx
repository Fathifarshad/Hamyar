import { Suspense, useEffect, useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../data/db';
import { useApp } from './AppContext';
import { useStore } from '../lib/store';
import { moduleSettingsStore } from './settingsStore';
import type { InputLanguage, ModuleAppearance, ModuleInstance, VoiceMode } from '../domain/types';
import { CATALOG, defaultAppearanceFor } from '../domain/catalog';
import { ICON_KEYS, type IconKey } from '../config/appearance';
import { MODULE_SETTINGS, MODULE_TEXT } from '../modules/registry';
import { updateModule } from '../data/modules';
import { Button, Field, Input, Modal, Notice, Segmented, Spinner, Switch } from '../ui/primitives';
import { ModuleIcon } from '../ui/Icon';
import { AccentPicker } from './AddModuleDialog';
import { ModuleBody } from './ModuleCard';
import { askConfirm, toast } from '../lib/ui-store';
import { errorText } from '../i18n/errors';
import { Info, RotateCcw, Star } from '../ui/icons';

interface Draft {
  title: string;
  appearance: ModuleAppearance;
  inputLanguage: InputLanguage;
  voiceMode: VoiceMode;
  remindersPaused: boolean;
  config: Record<string, unknown>;
}

function fromModule(m: ModuleInstance): Draft {
  return { title: m.title, appearance: { ...m.appearance }, inputLanguage: m.inputLanguage, voiceMode: m.voiceMode, remindersPaused: m.remindersPaused, config: { ...m.config } };
}

const ICON_NAMES: Record<IconKey, [string, string]> = {
  'check-square': ['تیک', 'Check'],
  'calendar-clock': ['تقویم و ساعت', 'Calendar clock'],
  music: ['موسیقی', 'Music'],
  'file-text': ['سند', 'Document'],
  clapperboard: ['ویدئو', 'Video'],
  'audio-lines': ['صدا', 'Audio'],
  pill: ['دارو', 'Pill'],
  'notebook-pen': ['دفترچه', 'Notebook'],
  bookmark: ['نشانک', 'Bookmark'],
  timer: ['زمان‌سنج', 'Timer'],
  'list-checks': ['فهرست', 'Checklist'],
  droplets: ['آب', 'Water'],
  wallet: ['کیف پول', 'Wallet'],
  'cloud-sun': ['آب‌وهوا', 'Weather'],
  'calendar-days': ['تقویم', 'Calendar'],
  'layout-grid': ['شبکه', 'Grid'],
  heart: ['قلب', 'Heart'],
  star: ['ستاره', 'Star'],
  'book-open': ['کتاب', 'Book'],
  briefcase: ['کیف کار', 'Briefcase'],
  dumbbell: ['ورزش', 'Exercise'],
  'graduation-cap': ['تحصیل', 'Study'],
  home: ['خانه', 'Home'],
  car: ['خودرو', 'Car'],
  plane: ['سفر', 'Travel'],
  coffee: ['قهوه', 'Coffee'],
  sparkles: ['درخشش', 'Sparkles'],
  leaf: ['برگ', 'Leaf'],
  sun: ['خورشید', 'Sun'],
  moon: ['ماه', 'Moon'],
  headphones: ['هدفون', 'Headphones'],
  users: ['افراد', 'People'],
};

function IconPicker({ value, onChange, label }: { value: IconKey; onChange: (i: IconKey) => void; label: string }) {
  const { t } = useApp();
  return (
    <div className="icon-grid" role="radiogroup" aria-label={label}>
      {ICON_KEYS.map((k) => (
        <button
          key={k}
          type="button"
          role="radio"
          aria-checked={value === k}
          aria-label={t(...(ICON_NAMES[k] ?? [k, k]))}
          title={t(...(ICON_NAMES[k] ?? [k, k]))}
          className={`icon-choice${value === k ? ' is-on' : ''}`}
          onClick={() => onChange(k)}
        >
          <ModuleIcon icon={k} size={18} />
        </button>
      ))}
    </div>
  );
}

export function ModuleSettingsSheet() {
  const id = useStore(moduleSettingsStore);
  const { t, locale, profile, updateProfile, bidi } = useApp();
  const mod = useLiveQuery(() => (id ? db.modules.get(id) : undefined), [id]);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [baseVersion, setBaseVersion] = useState(0);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (mod && (!draft || baseVersion === 0)) {
      setDraft(fromModule(mod));
      setBaseVersion(mod.version);
    }
  }, [mod]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!id) {
      setDraft(null);
      setBaseVersion(0);
    }
  }, [id]);

  const previewMod = useMemo<ModuleInstance | null>(() => (mod && draft ? { ...mod, ...draft, appearance: draft.appearance, config: draft.config } : null), [mod, draft]);

  if (!id) return null;
  const close = async () => {
    if (mod && draft && JSON.stringify(fromModule(mod)) !== JSON.stringify(draft)) {
      const ok = await askConfirm({
        title: t('تغییرات ذخیره نشده‌اند', 'Unsaved changes'),
        body: t('اگر ببندید، تغییرات ظاهر و تنظیمات این بخش از بین می‌رود.', 'If you close, the changes to this section are lost.'),
        confirmText: t('بستن بدون ذخیره', 'Discard'),
        cancelText: t('ادامه ویرایش', 'Keep editing'),
      });
      if (!ok) return;
    }
    moduleSettingsStore.set(null);
  };
  if (!mod || !draft || !previewMod) {
    return (
      <Modal open onClose={() => moduleSettingsStore.set(null)} title={t('تنظیمات بخش', 'Section settings')} closeLabel={t('بستن', 'Close')}>
        {mod === undefined ? <Spinner /> : <p>{t('این بخش پیدا نشد.', 'Section not found.')}</p>}
      </Modal>
    );
  }
  const set = (p: Partial<Draft>) => setDraft((d) => (d ? { ...d, ...p } : d));
  const setA = (p: Partial<ModuleAppearance>) => setDraft((d) => (d ? { ...d, appearance: { ...d.appearance, ...p } } : d));
  const Settings = MODULE_SETTINGS[mod.type];
  const supportsCommands = CATALOG[mod.type].commands;
  const hasReminders = mod.type === 'tasks' || mod.type === 'medications';

  const save = async () => {
    setBusy(true);
    try {
      await updateModule(mod.id, { title: draft.title, appearance: draft.appearance, inputLanguage: draft.inputLanguage, voiceMode: draft.voiceMode, remindersPaused: draft.remindersPaused, config: draft.config }, baseVersion, locale);
      toast({ kind: 'success', text: t('تنظیمات «{n}» ذخیره شد.', 'Settings for “{n}” saved.', { n: draft.title }) });
      moduleSettingsStore.set(null);
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open
      onClose={() => void close()}
      size="lg"
      title={t('تنظیمات و ظاهر «{n}»', 'Settings & look — “{n}”', { n: mod.title })}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          <Button variant="ghost" icon={<RotateCcw size={15} />} onClick={() => setA(defaultAppearanceFor(mod.type))} className="me-auto">
            {t('ظاهر پیش‌فرض', 'Default look')}
          </Button>
          <Button variant="ghost" onClick={() => void close()}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="primary" busy={busy} onClick={() => void save()}>
            {t('ذخیره', 'Save')}
          </Button>
        </>
      }
    >
      <div className="settings-split">
        <div className="form-grid" data-accent={draft.appearance.accent}>
          <Field label={t('عنوان', 'Title')}>
            <Input value={draft.title} onChange={(e) => set({ title: e.target.value })} maxLength={60} />
          </Field>
          <Field label={t('رنگ', 'Colour')}>
            <AccentPicker value={draft.appearance.accent} onChange={(accent) => setA({ accent })} label={t('رنگ', 'Colour')} />
          </Field>
          <Field label={t('آیکن', 'Icon')}>
            <IconPicker value={draft.appearance.icon} onChange={(icon) => setA({ icon })} label={t('آیکن', 'Icon')} />
          </Field>
          <Field label={t('قالب کارت', 'Card style')}>
            <Segmented
              label={t('قالب کارت', 'Card style')}
              value={draft.appearance.preset}
              onChange={(preset) => setA({ preset })}
              options={[
                { value: 'default', label: t('پیش‌فرض', 'Default') },
                { value: 'minimal', label: t('مینیمال', 'Minimal') },
                { value: 'list', label: t('فهرستی', 'List') },
              ]}
            />
          </Field>
          <div className="form-row">
            <Field label={t('اندازه', 'Size')}>
              <Segmented
                label={t('اندازه', 'Size')}
                value={draft.appearance.width}
                onChange={(width) => setA({ width })}
                size="sm"
                options={[
                  { value: 'normal', label: t('عادی', 'Normal') },
                  { value: 'wide', label: t('عریض', 'Wide') },
                ]}
              />
            </Field>
            <Field label={t('تراکم', 'Density')}>
              <Segmented
                label={t('تراکم', 'Density')}
                value={draft.appearance.density}
                onChange={(density) => setA({ density })}
                size="sm"
                options={[
                  { value: 'comfortable', label: t('راحت', 'Comfortable') },
                  { value: 'compact', label: t('فشرده', 'Compact') },
                ]}
              />
            </Field>
          </div>
          <div className="form-row">
            <Field label={t('زبان ورودی صوتی', 'Voice input language')} hint={t('مستقل از زبان برنامه', 'Independent of the app language')}>
              <Segmented label={t('زبان صوت', 'Voice language')} value={draft.inputLanguage} onChange={(inputLanguage) => set({ inputLanguage })} size="sm" options={[{ value: 'fa-IR', label: 'فارسی' }, { value: 'en-US', label: 'English' }]} />
            </Field>
            {supportsCommands && (
              <Field label={t('حالت پیش‌فرض میکروفن', 'Default microphone mode')}>
                <Segmented
                  label={t('حالت میکروفن', 'Microphone mode')}
                  value={draft.voiceMode}
                  onChange={(voiceMode) => set({ voiceMode })}
                  size="sm"
                  options={[
                    { value: 'dictation', label: t('دیکته', 'Dictation') },
                    { value: 'command', label: t('فرمان', 'Command') },
                  ]}
                />
              </Field>
            )}
          </div>
          {hasReminders && (
            <Switch
              checked={draft.remindersPaused}
              onChange={(remindersPaused) => set({ remindersPaused })}
              label={t('توقف یادآوری‌های این بخش', 'Pause this section’s reminders')}
              description={t('پنهان کردن بخش یادآوری‌ها را متوقف نمی‌کند؛ این کلید متوقف می‌کند.', 'Hiding a section does not stop reminders; this switch does.')}
            />
          )}
          {profile.layoutMode === 'focus' && (
            <Button
              size="sm"
              variant={profile.focusModuleId === mod.id ? 'soft' : 'outline'}
              icon={<Star size={14} />}
              onClick={() => void updateProfile({ focusModuleId: mod.id })}
              disabled={profile.focusModuleId === mod.id}
            >
              {profile.focusModuleId === mod.id ? t('بخش برجسته چیدمان تمرکز', 'Featured in focus layout') : t('برجسته در چیدمان تمرکز', 'Feature in focus layout')}
            </Button>
          )}
          {Settings && (
            <section className="type-settings">
              <h3>{t('تنظیمات {n}', '{n} settings', { n: MODULE_TEXT[mod.type].name[locale === 'fa' ? 0 : 1] })}</h3>
              <Suspense fallback={<Spinner />}>
                <Settings mod={mod} config={draft.config} onChange={(patch) => set({ config: { ...draft.config, ...patch } })} />
              </Suspense>
            </section>
          )}
          <Notice tone="neutral" icon={<Info size={16} />}>
            {t('تغییر ظاهر روی داده‌های این بخش اثری ندارد. ظاهر فقط از گزینه‌های آماده ساخته می‌شود.', 'Changing the look never touches this section’s data. Looks are built only from the provided options.')}
          </Notice>
        </div>
        <div className="settings-preview" aria-hidden="true">
          <div className="preview-label">{t('پیش‌نمایش', 'Preview')}</div>
          <section className="mod is-preview" data-accent={draft.appearance.accent} data-preset={draft.appearance.preset} data-density={draft.appearance.density} inert>
            <header className="mod-head">
              <span className="mod-icon">
                <ModuleIcon icon={draft.appearance.icon} size={19} />
              </span>
              <h2 className="mod-title">
                <span className="auto-dir" dir={bidi(draft.title || mod.title)}>
                  {draft.title || mod.title}
                </span>
              </h2>
            </header>
            <div className="mod-body">
              <ModuleBody mod={previewMod} variant="card" />
            </div>
          </section>
        </div>
      </div>
    </Modal>
  );
}
