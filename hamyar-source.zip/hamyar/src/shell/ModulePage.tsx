import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../data/db';
import { useApp } from './AppContext';
import { ModuleBody, ModuleMenu } from './ModuleCard';
import { ModuleIcon } from '../ui/Icon';
import { Button, Chip, EmptyState, IconButton, Spinner } from '../ui/primitives';
import { ArrowLeft, ArrowRight, BellOff, EyeOff, Settings2, Archive, SearchX } from '../ui/icons';
import { navigate } from './router';
import { openModuleSettings } from './settingsStore';
import { MODULE_TEXT } from '../modules/registry';
import { setActive, unarchiveModule } from '../data/modules';
import { toast } from '../lib/ui-store';
import { errorText } from '../i18n/errors';

export function ModulePage({ id, focus }: { id: string; focus?: string }) {
  const { t, locale, bidi } = useApp();
  const mod = useLiveQuery(() => db.modules.get(id), [id], null);
  const Back = locale === 'fa' ? ArrowRight : ArrowLeft;
  if (mod === null)
    return (
      <div className="page-loading">
        <Spinner />
      </div>
    );
  if (!mod)
    return (
      <EmptyState
        icon={<SearchX size={24} />}
        title={t('این بخش پیدا نشد', 'Section not found')}
        text={t('ممکن است حذف شده باشد.', 'It may have been deleted.')}
        action={
          <Button variant="primary" onClick={() => navigate('/')}>
            {t('بازگشت به داشبورد', 'Back to dashboard')}
          </Button>
        }
      />
    );
  const typeName = MODULE_TEXT[mod.type].name[locale === 'fa' ? 0 : 1];
  return (
    <div className="module-page" data-accent={mod.appearance.accent} data-preset={mod.appearance.preset} data-density={mod.appearance.density}>
      <header className="page-head">
        <IconButton label={t('بازگشت', 'Back')} onClick={() => (window.history.length > 1 ? window.history.back() : navigate('/'))}>
          <Back size={20} />
        </IconButton>
        <span className="mod-icon is-lg">
          <ModuleIcon icon={mod.appearance.icon} size={22} />
        </span>
        <div className="page-title-wrap">
          <h1 className="page-title auto-dir" dir={bidi(mod.title)}>
            {mod.title}
          </h1>
          <div className="page-sub">
            {mod.title !== typeName && <span>{typeName}</span>}
            {mod.archivedAt && <Chip tone="warn" icon={<Archive size={11} />}>{t('بایگانی', 'Archived')}</Chip>}
            {!mod.archivedAt && mod.active === 0 && <Chip icon={<EyeOff size={11} />}>{t('پنهان از داشبورد', 'Hidden from dashboard')}</Chip>}
            {mod.remindersPaused && <Chip tone="warn" icon={<BellOff size={11} />}>{t('یادآوری متوقف', 'Reminders paused')}</Chip>}
          </div>
        </div>
        <div className="page-actions">
          {!mod.archivedAt && mod.active === 0 && (
            <Button
              size="sm"
              variant="soft"
              onClick={async () => {
                try {
                  await setActive(mod.id, true);
                } catch (e) {
                  toast({ kind: 'error', text: errorText(e, t) });
                }
              }}
            >
              {t('نمایش در داشبورد', 'Show on dashboard')}
            </Button>
          )}
          {mod.archivedAt && (
            <Button size="sm" variant="soft" onClick={() => void unarchiveModule(mod.id, false)}>
              {t('خروج از بایگانی', 'Restore')}
            </Button>
          )}
          <IconButton label={t('تنظیمات و ظاهر', 'Settings & look')} variant="soft" onClick={() => openModuleSettings(mod.id)}>
            <Settings2 size={18} />
          </IconButton>
          <ModuleMenu mod={mod} inFull />
        </div>
      </header>
      <div className="page-body">
        <ModuleBody mod={mod} variant="full" focus={focus} />
      </div>
    </div>
  );
}
