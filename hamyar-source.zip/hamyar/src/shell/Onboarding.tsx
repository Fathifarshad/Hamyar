import { useMemo, useState } from 'react';
import { useApp } from './AppContext';
import { Button, Field, Notice, Segmented, Select, Switch } from '../ui/primitives';
import { Logo } from './Layout';
import { ArrowLeft, ArrowRight, Check, HardDrive, Info, Sparkles } from '../ui/icons';
import { deviceTimeZone, listTimeZones } from '../domain/time';
import { CATALOG, GROUP_ORDER, PRESETS, type PresetDef } from '../domain/catalog';
import { MODULE_TYPES, type ModuleType } from '../domain/types';
import { MODULE_TEXT } from '../modules/registry';
import { ModuleIcon } from '../ui/Icon';
import { presetDesc, presetName } from './PresetDialog';
import { applyPreset, createModule, planPreset } from '../data/modules';
import { loadSampleData } from '../data/sample';
import { LIMITS } from '../config/limits';
import { toast } from '../lib/ui-store';
import { errorText } from '../i18n/errors';
import { IS_ARTIFACT, IS_NATIVE } from '../lib/platform';

type Choice = PresetDef['id'] | 'manual' | 'empty';

export function Onboarding() {
  const { t, profile, updateProfile, locale, dig } = useApp();
  const [step, setStep] = useState(0);
  const [choice, setChoice] = useState<Choice>('starter');
  const [manual, setManual] = useState<ModuleType[]>(['tasks', 'notes', 'music', 'pdf', 'focus']);
  const [sample, setSample] = useState(false);
  const [busy, setBusy] = useState(false);
  const zones = useMemo(() => listTimeZones(), []);
  const device = deviceTimeZone();
  const Next = locale === 'fa' ? ArrowLeft : ArrowRight;
  const Back = locale === 'fa' ? ArrowRight : ArrowLeft;

  const finish = async () => {
    setBusy(true);
    try {
      const lang = locale === 'fa' ? 'fa-IR' : 'en-US';
      const name = (type: ModuleType) => MODULE_TEXT[type].name[locale === 'fa' ? 0 : 1];
      if (choice === 'manual') {
        for (const type of manual.slice(0, LIMITS.maxActiveModules)) await createModule({ type, title: name(type), active: true, inputLanguage: lang, locale });
      } else if (choice !== 'empty') {
        await applyPreset(await planPreset(choice, 'add'), name, lang, locale);
      }
      if (sample) await loadSampleData(locale, profile.timezone);
      await updateProfile({ onboarded: true, sampleData: sample });
      // Android app: reminders only work when closed if notifications are allowed (asked from this tap).
      if (IS_NATIVE) void import('../lib/native').then((m) => m.enablePhoneReminders());
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="onboarding">
      <div className="ob-card">
        <div className="ob-brand">
          <Logo size={40} />
          <div>
            <div className="ob-name">{t('همیار', 'Hamyar')}</div>
            <div className="ob-tag">{t('میزکار شخصی شما؛ هر بخش همان‌طور که می‌خواهید.', 'Your personal desk, every section the way you want it.')}</div>
          </div>
        </div>
        <ol className="ob-steps" aria-label={t('مراحل', 'Steps')}>
          {[t('زبان و زمان', 'Language & time'), t('چیدمان', 'Layout'), t('شروع', 'Start')].map((s, i) => (
            <li key={i} className={i === step ? 'is-on' : i < step ? 'is-done' : ''} aria-current={i === step ? 'step' : undefined}>
              <span className="ob-step-dot">{i < step ? <Check size={12} /> : dig(i + 1)}</span>
              <span>{s}</span>
            </li>
          ))}
        </ol>

        {step === 0 && (
          <div className="form-grid">
            <Field label={t('زبان برنامه', 'App language')}>
              <Segmented
                label={t('زبان', 'Language')}
                value={profile.locale}
                onChange={(v) => void updateProfile({ locale: v, calendar: v === 'fa' ? 'jalali' : 'gregorian' })}
                options={[
                  { value: 'fa', label: 'فارسی' },
                  { value: 'en', label: 'English' },
                ]}
              />
            </Field>
            <Field label={t('تقویم', 'Calendar')}>
              <Segmented
                label={t('تقویم', 'Calendar')}
                value={profile.calendar}
                onChange={(v) => void updateProfile({ calendar: v })}
                options={[
                  { value: 'jalali', label: t('شمسی', 'Jalali (Persian)') },
                  { value: 'gregorian', label: t('میلادی', 'Gregorian') },
                ]}
              />
            </Field>
            <Field label={t('منطقه زمانی', 'Time zone')} hint={t('پیشنهاد دستگاه شما: {z}. یادآوری‌ها بر اساس این منطقه محاسبه می‌شوند.', 'Your device suggests {z}. Reminders are calculated in this zone.', { z: device })}>
              <Select value={profile.timezone} onChange={(e) => void updateProfile({ timezone: e.target.value })} className="ltr">
                {zones.map((z) => (
                  <option key={z} value={z}>
                    {z}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label={t('ظاهر', 'Appearance')}>
              <Segmented
                label={t('ظاهر', 'Appearance')}
                value={profile.theme}
                onChange={(v) => void updateProfile({ theme: v })}
                options={[
                  { value: 'system', label: t('مثل دستگاه', 'System') },
                  { value: 'light', label: t('روشن', 'Light') },
                  { value: 'dark', label: t('تیره', 'Dark') },
                ]}
              />
            </Field>
          </div>
        )}

        {step === 1 && (
          <div className="stack">
            <div className="preset-grid" role="radiogroup" aria-label={t('چیدمان شروع', 'Starting layout')}>
              {PRESETS.map((p) => (
                <button key={p.id} type="button" role="radio" aria-checked={choice === p.id} className={`preset-card${choice === p.id ? ' is-on' : ''}`} onClick={() => setChoice(p.id)}>
                  <span className="preset-name">
                    {presetName(p.id, t)}
                    {p.id === 'starter' && <span className="chip chip-accent">{t('پیشنهادی', 'Suggested')}</span>}
                  </span>
                  <span className="preset-desc">{presetDesc(p.id, t)}</span>
                  <span className="preset-icons" aria-hidden="true">
                    {p.types.map((ty) => (
                      <span key={ty} className="mod-icon is-sm" data-accent={CATALOG[ty].accent}>
                        <ModuleIcon icon={CATALOG[ty].icon} size={13} />
                      </span>
                    ))}
                  </span>
                </button>
              ))}
              <button type="button" role="radio" aria-checked={choice === 'manual'} className={`preset-card${choice === 'manual' ? ' is-on' : ''}`} onClick={() => setChoice('manual')}>
                <span className="preset-name">{t('انتخاب دستی', 'Pick myself')}</span>
                <span className="preset-desc">{t('از ۱۵ نوع بخش، تا ۱۰ مورد', 'Up to 10 from 15 section types')}</span>
              </button>
              <button type="button" role="radio" aria-checked={choice === 'empty'} className={`preset-card${choice === 'empty' ? ' is-on' : ''}`} onClick={() => setChoice('empty')}>
                <span className="preset-name">{t('داشبورد خالی', 'Empty dashboard')}</span>
                <span className="preset-desc">{t('بعداً خودم اضافه می‌کنم', 'I’ll add sections later')}</span>
              </button>
            </div>
            {choice === 'manual' && (
              <div className="manual-pick">
                <div className="row-flex spread">
                  <span className="small muted">{t('انتخاب‌شده: {n} از {max}', 'Selected: {n} of {max}', { n: manual.length, max: LIMITS.maxActiveModules })}</span>
                </div>
                {GROUP_ORDER.map((g) => (
                  <div key={g} className="type-grid is-compact">
                    {MODULE_TYPES.filter((ty) => CATALOG[ty].group === g).map((ty) => {
                      const on = manual.includes(ty);
                      const disabled = !on && manual.length >= LIMITS.maxActiveModules;
                      return (
                        <button
                          key={ty}
                          type="button"
                          className={`type-card is-check${on ? ' is-on' : ''}`}
                          data-accent={CATALOG[ty].accent}
                          aria-pressed={on}
                          disabled={disabled}
                          onClick={() => setManual(on ? manual.filter((x) => x !== ty) : [...manual, ty])}
                        >
                          <span className="mod-icon">
                            <ModuleIcon icon={CATALOG[ty].icon} size={17} />
                          </span>
                          <span className="type-text">
                            <span className="type-name">{MODULE_TEXT[ty].name[locale === 'fa' ? 0 : 1]}</span>
                          </span>
                          {on && <Check size={16} className="type-go" aria-hidden="true" />}
                        </button>
                      );
                    })}
                  </div>
                ))}
                {manual.length >= LIMITS.maxActiveModules && <p className="subtle small">{t('به سقف ۱۰ بخش فعال رسیدید. بعداً می‌توانید بخش‌های بیشتری به‌صورت پنهان بسازید.', 'You reached 10 active sections. You can add more hidden ones later.')}</p>}
              </div>
            )}
          </div>
        )}

        {step === 2 && (
          <div className="stack">
            <Notice tone="info" icon={<HardDrive size={16} />} title={IS_ARTIFACT ? t('پیش‌نمایش آزمایشی', 'Trial preview') : t('حالت محلی', 'Local mode')}>
              {t(
                'همه داده‌ها و فایل‌ها فقط در همین مرورگر ذخیره می‌شوند و با پاک کردن داده‌های مرورگر از بین می‌روند. از «تنظیمات» می‌توانید خروجی JSON بگیرید. حساب کاربری و همگام‌سازی در نسخه اصلی می‌آید.',
                'All data and files stay in this browser and are lost if you clear browser data. You can export JSON from Settings. Accounts and sync come in the full version.',
              )}
            </Notice>
            <Switch
              checked={sample}
              onChange={setSample}
              label={t('با داده نمونه شروع کن', 'Start with example data')}
              description={t('چند کار، یادداشت، چک‌لیست، یک ملودی و یک PDF نمونه با برچسب «نمونه» ساخته می‌شود؛ بعداً قابل پاک کردن است.', 'Adds a few example tasks, notes, a checklist, a melody and a PDF, all labelled “example”; you can clear them later.')}
            />
            <Notice tone="neutral" icon={<Info size={16} />}>
              {t('اجازه میکروفن و اعلان فقط وقتی پرسیده می‌شود که خودتان دکمه آن را بزنید.', 'Microphone and notification permissions are only asked when you press their buttons.')}
            </Notice>
          </div>
        )}

        <div className="ob-actions">
          {step > 0 ? (
            <Button variant="ghost" icon={<Back size={16} />} onClick={() => setStep(step - 1)}>
              {t('قبلی', 'Back')}
            </Button>
          ) : (
            <span />
          )}
          {step < 2 ? (
            <Button variant="primary" onClick={() => setStep(step + 1)} disabled={step === 1 && choice === 'manual' && manual.length === 0}>
              {t('ادامه', 'Continue')} <Next size={16} />
            </Button>
          ) : (
            <Button variant="primary" busy={busy} icon={<Sparkles size={16} />} onClick={() => void finish()}>
              {t('ساخت داشبورد من', 'Build my dashboard')}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
