import { useEffect, useState } from 'react';
import { useApp } from './AppContext';
import { Button, IconButton } from '../ui/primitives';
import { Download, X } from '../ui/icons';
import { IS_MOBILE, IS_NATIVE, isIos, isStandalone } from '../lib/platform';
import { canPromptInstall, onInstallPromptChange, promptInstall } from '../lib/pwa';

const KEY = 'hamyar:install-hint-dismissed';

function dismissed(): boolean {
  try {
    return localStorage.getItem(KEY) === '1';
  } catch {
    return false;
  }
}

/** Phone web app opened in the browser: explains how to put Hamyar on the home screen. */
export function InstallHint() {
  const { t } = useApp();
  const [hidden, setHidden] = useState(() => !IS_MOBILE || IS_NATIVE || isStandalone() || dismissed());
  const [canPrompt, setCanPrompt] = useState(canPromptInstall());
  useEffect(() => onInstallPromptChange(() => setCanPrompt(canPromptInstall())), []);
  if (hidden || (!isIos() && !canPrompt)) return null;
  const close = () => {
    try {
      localStorage.setItem(KEY, '1');
    } catch {
      /* per-device convenience only */
    }
    setHidden(true);
  };
  return (
    <div className="install-hint" role="note">
      <Download size={18} aria-hidden="true" />
      <div className="grow stack-sm">
        <strong>{t('همیار را روی صفحه اصلی گوشی بگذارید', 'Put Hamyar on your home screen')}</strong>
        {isIos() ? (
          <span className="small">
            {t('در Safari دکمه اشتراک‌گذاری (مربع با فلش رو به بالا) را بزنید و «Add to Home Screen» را انتخاب کنید. بعد از آن، همیار مثل یک برنامه و بدون اینترنت باز می‌شود.', 'In Safari tap Share (the square with an arrow) and choose “Add to Home Screen”. Hamyar then opens like an app, even offline.')}
          </span>
        ) : (
          <span className="small">{t('با نصب، همیار مثل یک برنامه و بدون اینترنت باز می‌شود.', 'Once installed, Hamyar opens like an app, even offline.')}</span>
        )}
        {canPrompt && (
          <div>
            <Button size="sm" variant="primary" onClick={() => void promptInstall()}>
              {t('نصب همیار', 'Install Hamyar')}
            </Button>
          </div>
        )}
      </div>
      <IconButton label={t('بستن', 'Close')} size="sm" onClick={close}>
        <X size={16} />
      </IconButton>
    </div>
  );
}
