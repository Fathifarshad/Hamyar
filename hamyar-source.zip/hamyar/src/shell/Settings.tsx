import { useEffect, useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../data/db';
import { useApp } from './AppContext';
import { Button, Chip, Field, Modal, Notice, Segmented, Select, Switch } from '../ui/primitives';
import { FileDrop } from '../ui/FileDrop';
import { Bell, CircleCheck, CircleX, Database, Download, Info, Languages, Mic, Palette, RefreshCw, ShieldCheck, Sparkles, TrashIcon } from '../ui/icons';
import { SCHEMES, type Scheme } from '../config/appearance';
import { deviceTimeZone, listTimeZones } from '../domain/time';
import { notificationPermission, requestNotificationPermission, showSystemNotification, playChime, type NotifyPermission } from '../lib/notify';
import { aiStatusStore, refreshAiStatus, getUsage } from '../lib/ai';
import { useStore } from '../lib/store';
import { detectCaps, IS_ARTIFACT, IS_MOBILE, IS_NATIVE, isIos, APP_VERSION, pickRecorderMime } from '../lib/platform';
import { NativeReminderSettings } from './NativeReminderSettings';
import { storageEstimate, storageUsed } from '../data/assets';
import { LIMITS } from '../config/limits';
import { buildExport, commitImport, deleteAllData, markSkipSeed, validateImport, type ImportPlan } from '../data/transfer';
import { relabelDefaultTitles } from '../data/modules';
import { saveFile } from '../lib/download';
import { askConfirm, toast } from '../lib/ui-store';
import { errorText } from '../i18n/errors';
import { MODULE_TEXT } from '../modules/registry';

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <section className="set-section">
      <h2 className="set-title">
        {icon}
        {title}
      </h2>
      <div className="set-body">{children}</div>
    </section>
  );
}

function Status({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={`status-line${ok ? ' is-ok' : ' is-off'}`}>
      {ok ? <CircleCheck size={15} aria-hidden="true" /> : <CircleX size={15} aria-hidden="true" />}
      {label}
    </span>
  );
}

function ImportDialog({ plan, onClose }: { plan: ImportPlan | null; onClose: () => void }) {
  const { t, locale } = useApp();
  const [busy, setBusy] = useState(false);
  if (!plan) return null;
  const reasons: Record<string, string> = {
    not_hamyar: t('این فایل خروجی همیار نیست.', 'This is not a Hamyar export.'),
    version: t('این فایل از نسخه جدیدتری است.', 'This file is from a newer version.'),
    total_limit: t('بعد از ورود، تعداد بخش‌ها از ۵۰ بیشتر می‌شود. اول چند بخش را حذف کنید.', 'Importing would exceed 50 sections. Delete some first.'),
    module_shape: t('ساختار بخش‌ها در فایل معتبر نیست.', 'Sections in the file are not valid.'),
  };
  return (
    <Modal
      open
      onClose={onClose}
      title={t('پیش‌نمایش ورود داده', 'Import preview')}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button
            variant="primary"
            busy={busy}
            disabled={!plan.ok}
            onClick={async () => {
              setBusy(true);
              try {
                await commitImport(plan, locale);
                toast({ kind: 'success', text: t('داده‌ها وارد شد.', 'Data imported.') });
                onClose();
              } catch (e) {
                toast({ kind: 'error', text: errorText(e, t) });
              } finally {
                setBusy(false);
              }
            }}
          >
            {t('ورود داده', 'Import')}
          </Button>
        </>
      }
    >
      {plan.ok ? (
        <div className="stack-sm">
          <p>{t('{n} بخش اضافه می‌شود (داده فعلی شما دست نمی‌خورد):', '{n} section(s) will be added (your current data is untouched):', { n: plan.modules.length })}</p>
          <ul className="plan-list">
            {plan.modules.map((m, i) => (
              <li key={i}>
                <span className={`plan-tag${m.active ? ' is-show' : ''}`}>{m.active ? t('نمایش', 'Shown') : t('پنهان', 'Hidden')}</span> {m.title} <span className="subtle">({MODULE_TEXT[m.type as keyof typeof MODULE_TEXT]?.name[locale === 'fa' ? 0 : 1] ?? m.type})</span>
              </li>
            ))}
          </ul>
          <p className="subtle small">{t('بعد از ورود: {a} از ۱۰ بخش فعال، {b} از ۵۰ بخش.', 'After import: {a} of 10 active, {b} of 50 sections.', { a: plan.activeAfter, b: plan.totalAfter })}</p>
          {plan.missingFiles > 0 && (
            <Notice tone="warn" icon={<Info size={16} />}>
              {t('{n} مورد فایل دارند که در خروجی JSON نیست؛ آن‌ها با برچسب «فایل موجود نیست» وارد می‌شوند و باید دوباره بارگذاری شوند.', '{n} item(s) have files that JSON exports do not include; they arrive marked “file missing” and need re-uploading.', { n: plan.missingFiles })}
            </Notice>
          )}
        </div>
      ) : (
        <Notice tone="danger" icon={<CircleX size={16} />} title={t('این فایل وارد نمی‌شود', 'This file cannot be imported')}>
          {plan.errors.map((e) => reasons[e] ?? t('ساختار فایل معتبر نیست ({e}).', 'The file structure is invalid ({e}).', { e })).join(' ')}
        </Notice>
      )}
    </Modal>
  );
}

export function Settings() {
  const { t, profile, updateProfile, bytes, num } = useApp();
  const zones = useMemo(() => listTimeZones(), []);
  const [perm, setPerm] = useState<NotifyPermission>(notificationPermission());
  const ai = useStore(aiStatusStore);
  const caps = useMemo(() => detectCaps(), []);
  const [usage, setUsage] = useState<{ ours: number; est: { usage: number; quota: number } | null }>({ ours: 0, est: null });
  const [persisted, setPersisted] = useState<boolean | null>(null);
  const [aiUse, setAiUse] = useState({ summaries: 0, transcriptionSec: 0 });
  const [plan, setPlan] = useState<ImportPlan | null>(null);
  const consents = useLiveQuery(() => db.consents.toArray(), []);

  useEffect(() => {
    void refreshAiStatus(true);
    void Promise.all([storageUsed(), storageEstimate()]).then(([ours, est]) => setUsage({ ours, est }));
    void navigator.storage?.persisted?.().then(setPersisted).catch(() => setPersisted(null));
    void getUsage().then(setAiUse);
  }, []);

  const askPermission = async () => {
    const p = await requestNotificationPermission();
    setPerm(p);
    if (p === 'granted') await updateProfile({ systemNotifications: true });
  };

  const exportJson = async () => {
    const data = await buildExport();
    const r = await saveFile(`hamyar-export-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(data, null, 2), 'application/json');
    if (r === 'saved') toast({ kind: 'success', text: t('خروجی آماده شد. فایل‌های صوتی، ویدئو و PDF داخل آن نیستند.', 'Export ready. Audio, video and PDF files are not included.') });
    else if (r === 'unavailable') toast({ kind: 'warning', text: t('دریافت فایل در این نمایش ممکن نیست.', 'Downloads are not available here.') });
  };

  const importFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    try {
      const json = JSON.parse(await f.text());
      setPlan(await validateImport(json));
    } catch {
      setPlan({ ok: false, errors: ['not_hamyar'], counts: {}, modules: [], activeAfter: 0, totalAfter: 0, missingFiles: 0, data: null });
    }
  };

  const wipe = async () => {
    const ok = await askConfirm({
      title: t('پاک کردن همه داده‌های همیار در این مرورگر؟', 'Erase all Hamyar data in this browser?'),
      body: t('همه بخش‌ها، کارها، داروها، یادداشت‌ها و فایل‌ها پاک می‌شود و بازگرداندن ممکن نیست. اگر لازم دارید، اول خروجی بگیرید.', 'All sections, tasks, medications, notes and files are erased and cannot be recovered. Export first if you need a copy.'),
      confirmText: t('پاک کردن همه', 'Erase everything'),
      cancelText: t('انصراف', 'Cancel'),
      danger: true,
      typeToConfirm: t('حذف', 'delete'),
    });
    if (!ok) return;
    markSkipSeed();
    await deleteAllData();
    window.location.hash = '#/';
    window.location.reload();
  };

  const providerReason = (r: string) =>
    r === 'ok' || r === 'preview_claude'
      ? t('آماده', 'Ready')
      : r === 'not_configured'
        ? t('تنظیم نشده (کلید و مدل در ‎.env سرور)', 'Not set up (key and model in the server’s .env)')
        : r === 'server_missing'
          ? t('سرور محلی در دسترس نیست', 'Local server unreachable')
          : r === 'offline'
            ? t('بدون اینترنت', 'Offline')
            : r === 'checking'
              ? t('در حال بررسی…', 'Checking…')
              : r === 'mobile_unavailable'
                ? t('در نسخه گوشی نیست (به سرور نیاز دارد)', 'Not in the phone app (needs a server)')
              : r === 'not_granted'
                ? t('اجازه داده نشد', 'Not allowed')
                : t('در این نمایش در دسترس نیست', 'Not available in this view');

  return (
    <div className="settings-page">
      <header className="page-head is-plain">
        <div className="page-title-wrap">
          <h1 className="page-title">{t('تنظیمات', 'Settings')}</h1>
          <div className="page-sub">{t('ظاهر، زبان، اعلان‌ها، هوش مصنوعی و داده‌ها', 'Look, language, notifications, AI and data')}</div>
        </div>
      </header>

      <Section icon={<Palette size={18} />} title={t('ظاهر', 'Appearance')}>
        <Field label={t('حالت رنگ', 'Colour mode')}>
          <Segmented
            label={t('حالت رنگ', 'Colour mode')}
            value={profile.theme}
            onChange={(theme) => void updateProfile({ theme })}
            options={[
              { value: 'system', label: t('مثل دستگاه', 'System') },
              { value: 'light', label: t('روشن', 'Light') },
              { value: 'dark', label: t('تیره', 'Dark') },
            ]}
          />
        </Field>
        <Field label={t('پوسته رنگی برنامه', 'App colour scheme')} hint={t('رنگ هر بخش جداگانه از تنظیمات همان بخش انتخاب می‌شود.', 'Each section’s own colour is set in that section’s settings.')}>
          <div className="swatches" role="radiogroup" aria-label={t('پوسته', 'Scheme')}>
            {SCHEMES.map((s: Scheme) => (
              <button key={s} type="button" role="radio" aria-checked={profile.scheme === s} aria-label={s} className={`swatch${profile.scheme === s ? ' is-on' : ''}`} data-accent={s} onClick={() => void updateProfile({ scheme: s })}>
                <span />
              </button>
            ))}
          </div>
        </Field>
        <div className="form-row">
          <Field label={t('اندازه متن', 'Text size')}>
            <Segmented
              label={t('اندازه متن', 'Text size')}
              value={profile.fontScale}
              onChange={(fontScale) => void updateProfile({ fontScale })}
              options={[
                { value: 'normal', label: t('معمولی', 'Normal') },
                { value: 'large', label: t('درشت', 'Large') },
              ]}
            />
          </Field>
          <Field label={t('چیدمان داشبورد', 'Dashboard layout')}>
            <Segmented
              label={t('چیدمان', 'Layout')}
              value={profile.layoutMode}
              onChange={(layoutMode) => void updateProfile({ layoutMode })}
              options={[
                { value: 'grid', label: t('شبکه‌ای', 'Grid') },
                { value: 'list', label: t('فهرستی', 'List') },
                { value: 'focus', label: t('تمرکز', 'Focus') },
              ]}
            />
          </Field>
        </div>
      </Section>

      <Section icon={<Languages size={18} />} title={t('زبان و زمان', 'Language & time')}>
        <div className="form-row">
          <Field label={t('زبان برنامه', 'App language')}>
            <Segmented
              label={t('زبان', 'Language')}
              value={profile.locale}
              onChange={(l) => {
                void updateProfile({ locale: l }).then(() => relabelDefaultTitles((type) => MODULE_TEXT[type]?.name, l));
              }}
              options={[
                { value: 'fa', label: 'فارسی' },
                { value: 'en', label: 'English' },
              ]}
            />
          </Field>
          <Field label={t('تقویم نمایش', 'Display calendar')}>
            <Segmented
              label={t('تقویم', 'Calendar')}
              value={profile.calendar}
              onChange={(calendar) => void updateProfile({ calendar })}
              options={[
                { value: 'jalali', label: t('شمسی', 'Jalali') },
                { value: 'gregorian', label: t('میلادی', 'Gregorian') },
              ]}
            />
          </Field>
        </div>
        <Field
          label={t('منطقه زمانی', 'Time zone')}
          hint={t('دستگاه: {d}. تغییر این گزینه زمان کارها و داروهای قبلی را جابه‌جا نمی‌کند؛ هر برنامه منطقه زمانی خودش را دارد.', 'Device: {d}. Changing this does not move existing tasks or medications; each schedule keeps its own zone.', { d: deviceTimeZone() })}
        >
          <Select value={profile.timezone} onChange={(e) => void updateProfile({ timezone: e.target.value })} className="ltr">
            {zones.map((z) => (
              <option key={z} value={z}>
                {z}
              </option>
            ))}
          </Select>
        </Field>
      </Section>

      <Section icon={<Bell size={18} />} title={t('یادآوری و اعلان', 'Reminders & notifications')}>
        <Switch
          checked={profile.reminderSound}
          onChange={(reminderSound) => void updateProfile({ reminderSound })}
          label={t('صدای یادآوری', 'Reminder sound')}
          description={t('مرورگر فقط بعد از اولین کلیک شما اجازه پخش صدا می‌دهد.', 'Browsers allow sound only after your first click.')}
        />
        {IS_NATIVE ? (
          <NativeReminderSettings />
        ) : (
          <>
          {perm === 'unsupported' ? (
            <Notice tone="neutral" icon={<Info size={16} />}>
              {IS_ARTIFACT
                ? t('در پیش‌نمایش claude.ai اعلان سیستم در دسترس نیست؛ یادآوری‌ها داخل برنامه نمایش داده می‌شوند.', 'System notifications are not available in the claude.ai preview; reminders appear inside the app.')
                : t('این مرورگر اعلان سیستم را پشتیبانی نمی‌کند؛ یادآوری‌ها داخل برنامه و در صندوق یادآوری نمایش داده می‌شوند.', 'This browser does not support system notifications; reminders appear in the app and the inbox.')}
            </Notice>
          ) : (
            <>
              <div className="row-flex wrap">
                <Status ok={perm === 'granted'} label={perm === 'granted' ? t('اجازه اعلان داده شده', 'Notifications allowed') : perm === 'denied' ? t('اعلان مسدود است (از تنظیمات مرورگر باز کنید)', 'Notifications blocked (unblock in browser settings)') : t('هنوز اجازه داده نشده', 'Not allowed yet')} />
                {perm === 'default' && (
                  <Button size="sm" variant="primary" onClick={() => void askPermission()}>
                    {t('اجازه اعلان', 'Allow notifications')}
                  </Button>
                )}
                {perm === 'granted' && (
                  <Button
                    size="sm"
                    variant="soft"
                    onClick={async () => {
                      playChime();
                      const ok = await showSystemNotification(t('اعلان آزمایشی همیار', 'Hamyar test notification'), t('اگر این را می‌بینید، اعلان سیستم کار می‌کند.', 'If you see this, system notifications work.'), { tag: 'test', url: '#/settings' });
                      toast({ kind: ok ? 'success' : 'warning', text: ok ? t('اعلان به سیستم تحویل شد (دیده‌شدن آن تضمین نیست).', 'Handed to the OS (being seen is not guaranteed).') : t('اعلان نمایش داده نشد.', 'The notification was not shown.') });
                    }}
                  >
                    {t('ارسال اعلان آزمایشی', 'Send a test')}
                  </Button>
                )}
              </div>
              <Switch
                checked={profile.systemNotifications && perm === 'granted'}
                onChange={(v) => (perm === 'granted' ? void updateProfile({ systemNotifications: v }) : void askPermission())}
                label={t('نمایش اعلان سیستم برای یادآوری‌ها', 'Show system notifications for reminders')}
                disabled={perm === 'denied'}
              />
            </>
          )}
          </>
        )}
        {!IS_NATIVE && (
          <Notice tone="warn" icon={<Info size={16} />}>
            {IS_MOBILE && isIos()
              ? t(
                  'محدودیت آیفون: یادآوری فقط وقتی همیار باز است اجرا می‌شود. برای یادآوری مطمئن داروها و قرارها، در بخش مربوط «افزودن به تقویم گوشی» را بزنید تا تقویم آیفون سر وقت هشدار بدهد.',
                  'iPhone limitation: reminders run only while Hamyar is open. For dependable medication and appointment alerts, use “Add to phone calendar” in that section so the iPhone Calendar alerts you on time.',
                )
              : t(
                  'محدودیت این نسخه: یادآوری فقط وقتی همیار در مرورگر باز است اجرا می‌شود و جای زنگ هشدار گوشی را نمی‌گیرد. اعلان با مرورگر بسته (Web Push) به سرور نیاز دارد و در نسخه اصلی همراه حساب کاربری اضافه می‌شود. برای یادآوری مطمئن، از «افزودن به تقویم گوشی» در بخش کارها و داروها استفاده کنید.',
                  'Limitation of this version: reminders run only while Hamyar is open and do not replace a phone alarm. Notifications with the browser closed (Web Push) need a server and come in the full version with accounts. For dependable alerts, use “Add to phone calendar” in tasks and medications.',
                )}
          </Notice>
        )}
      </Section>

      <Section icon={<Mic size={18} />} title={t('صدا و هوش مصنوعی', 'Voice & AI')}>
        <div className="status-grid">
          <Status ok={caps.speechRecognition && !IS_ARTIFACT} label={IS_NATIVE ? t('تشخیص گفتار گوشی (دیکته و فرمان)', 'Phone speech recognition (dictation & commands)') : t('تبدیل گفتار مرورگر (دیکته و فرمان)', 'Browser speech recognition (dictation & commands)')} />
          <Status ok={!!pickRecorderMime() && caps.getUserMedia && !IS_ARTIFACT} label={t('ضبط صدا (MediaRecorder)', 'Audio recording (MediaRecorder)')} />
          <Status ok={ai.summary.available} label={`${t('خلاصه PDF', 'PDF summaries')}: ${ai.summary.provider ?? ''} ${providerReason(ai.summary.reason)}`} />
          <Status ok={ai.transcription.available} label={`${t('تبدیل فایل صوتی', 'Audio transcription')}: ${ai.transcription.provider ?? ''} ${providerReason(ai.transcription.reason)}`} />
        </div>
        <p className="subtle small">
          {t('استفاده امروز: {a} از {b} خلاصه، {c} از {d} دقیقه رونویسی.', 'Used today: {a} of {b} summaries, {c} of {d} transcription minutes.', {
            a: aiUse.summaries,
            b: LIMITS.dailySummaries,
            c: Math.round(aiUse.transcriptionSec / 60),
            d: LIMITS.dailyTranscriptionMinutes,
          })}
        </p>
        <div className="row-flex wrap">
          <Button size="sm" variant="soft" icon={<RefreshCw size={14} />} onClick={() => void refreshAiStatus(true)}>
            {t('بررسی دوباره سرویس‌ها', 'Re-check services')}
          </Button>
        </div>
        <Field label={t('رضایت‌های ارسال داده', 'Data-sending consents')}>
          {consents && consents.length ? (
            <ul className="rows">
              {consents.map((c) => (
                <li key={c.id} className="row">
                  <ShieldCheck size={16} aria-hidden="true" />
                  <span className="grow">
                    {c.feature === 'summary' ? t('خلاصه PDF', 'PDF summaries') : c.feature === 'transcription' ? t('تبدیل صوت', 'Transcription') : t('گفتار مرورگر', 'Browser speech')} · {c.provider}
                  </span>
                  <Button size="sm" variant="ghost" onClick={() => void db.consents.delete(c.id)}>
                    {t('لغو رضایت', 'Withdraw')}
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="subtle small">{t('هنوز رضایتی ثبت نشده.', 'No consents recorded yet.')}</p>
          )}
        </Field>
      </Section>

      <Section icon={<Database size={18} />} title={t('داده‌ها و حریم خصوصی', 'Data & privacy')}>
        <p className="small">
          {t('فایل‌های ذخیره‌شده: {a} از {b}.', 'Stored files: {a} of {b}.', { a: bytes(usage.ours), b: bytes(LIMITS.accountStorageBytes) })}{' '}
          {usage.est && t('فضای مرورگر: {a} از {b}.', 'Browser storage: {a} of {b}.', { a: bytes(usage.est.usage), b: bytes(usage.est.quota) })}
        </p>
        {caps.persistStorage && !IS_ARTIFACT && (
          <div className="row-flex wrap">
            <Status ok={!!persisted} label={persisted ? t('ذخیره ماندگار فعال است', 'Persistent storage is on') : t('مرورگر ممکن است در کمبود فضا داده‌ها را پاک کند', 'The browser may evict data when space runs low')} />
            {!persisted && (
              <Button size="sm" variant="soft" onClick={() => void navigator.storage.persist().then(setPersisted)}>
                {t('درخواست ذخیره ماندگار', 'Request persistent storage')}
              </Button>
            )}
          </div>
        )}
        <div className="row-flex wrap">
          <Button variant="soft" icon={<Download size={16} />} onClick={() => void exportJson()}>
            {t('خروجی JSON', 'Export JSON')}
          </Button>
        </div>
        <p className="subtle xsmall">{t('خروجی شامل تنظیمات، بخش‌ها، متن‌ها، برنامه‌ها و سوابق است؛ فایل‌های صوتی/تصویری/PDF و هیچ کلیدی داخل آن نیست. این «پشتیبان کامل فایل‌ها» نیست.', 'The export holds settings, sections, text, schedules and history; no audio/video/PDF files and no keys. It is not a full file backup.')}</p>
        <FileDrop accept="application/json,.json" onFiles={(f) => void importFile(f)} title={t('ورود از فایل JSON', 'Import from JSON')} hint={t('اول پیش‌نمایش نشان داده می‌شود؛ داده فعلی پاک نمی‌شود.', 'You see a preview first; current data is not erased.')} />
        <div className="danger-zone">
          <div>
            <div className="strong">{t('پاک کردن همه داده‌ها', 'Erase all data')}</div>
            <div className="subtle small">{t('همه چیز در این مرورگر پاک می‌شود.', 'Everything in this browser is erased.')}</div>
          </div>
          <Button variant="danger" icon={<TrashIcon size={15} />} onClick={() => void wipe()}>
            {t('پاک کردن همه', 'Erase all')}
          </Button>
        </div>
      </Section>

      <Section icon={<Sparkles size={18} />} title={t('درباره این نسخه', 'About this version')}>
        <p className="small">
          {t('همیار نسخه {v} — MVP محلی. ', 'Hamyar {v} — local MVP. ', { v: APP_VERSION })}
          {IS_ARTIFACT ? <Chip tone="info">{t('پیش‌نمایش claude.ai', 'claude.ai preview')}</Chip> : <Chip tone="ok">{t('نسخه قابل اجرا', 'Runnable app')}</Chip>}
        </p>
        <ul className="bullets small muted">
          <li>{t('حساب کاربری، همگام‌سازی بین دستگاه‌ها و Push با مرورگر بسته در نسخه اصلی می‌آیند.', 'Accounts, cross-device sync and Push with the browser closed come in the full version.')}</li>
          <li>{t('PDF اسکن‌شده به OCR نیاز دارد که در این نسخه نیست.', 'Scanned PDFs need OCR, which this version does not have.')}</li>
          <li>{t('همیار توصیه پزشکی نمی‌دهد و فقط برنامه دارویی واردشده توسط شما را نگه می‌دارد.', 'Hamyar gives no medical advice; it only keeps the medication schedule you enter.')}</li>
          <li>{t('{n} نوع بخش در این نسخه موجود است.', '{n} section types are available in this version.', { n: num(Object.keys(MODULE_TEXT).length) })}</li>
        </ul>
      </Section>
      <ImportDialog plan={plan} onClose={() => setPlan(null)} />
    </div>
  );
}
