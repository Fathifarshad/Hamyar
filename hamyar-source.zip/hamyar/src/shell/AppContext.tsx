import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso } from '../data/db';
import type { Locale, Profile } from '../domain/types';
import { deviceTimeZone, isValidTimeZone, todayISO } from '../domain/time';
import { setScheme, setThemeSetting } from '../lib/theme';
import { digits, fmtDate, fmtNum, fmtRelDay, fmtTime, fmtMoney, fmtBytes, fmtDuration, fmtInstantTime, type DateStyle } from '../lib/format';
import { dirOf, type Dir } from '../lib/bidi';

export function defaultProfile(locale: Locale = 'fa'): Profile {
  return {
    id: 'profile',
    locale,
    theme: 'system',
    scheme: 'teal',
    fontScale: 'normal',
    calendar: locale === 'fa' ? 'jalali' : 'gregorian',
    timezone: deviceTimeZone(),
    layoutMode: 'grid',
    focusModuleId: null,
    onboarded: false,
    reminderSound: true,
    systemNotifications: false,
    sampleData: false,
    version: 1,
    updatedAt: nowIso(),
  };
}

export async function saveProfile(patch: Partial<Profile>, fallback?: Profile): Promise<void> {
  await db.transaction('rw', db.profile, async () => {
    const cur = (await db.profile.get('profile')) ?? fallback ?? defaultProfile();
    const next: Profile = { ...cur, ...patch, id: 'profile', version: cur.version + 1, updatedAt: nowIso() };
    if (!isValidTimeZone(next.timezone)) next.timezone = cur.timezone;
    await db.profile.put(next);
  });
}

type Params = Record<string, string | number>;

export interface AppCtx {
  profile: Profile;
  loaded: boolean;
  locale: Locale;
  dir: Dir;
  /** base direction for a piece of user text (use as the element's `dir`) */
  bidi: (text: string | null | undefined) => Dir;
  tz: string;
  today: string;
  now: number;
  /** picks the Persian or English string and fills {placeholders} */
  t: (fa: string, en: string, params?: Params) => string;
  num: (n: number, frac?: number) => string;
  dig: (v: string | number) => string;
  date: (iso: string, style?: DateStyle) => string;
  relDay: (iso: string) => string;
  time: (hhmm: string) => string;
  instantTime: (utc: number) => string;
  money: (amount: number, currency: string) => string;
  bytes: (n: number) => string;
  duration: (sec: number) => string;
  updateProfile: (patch: Partial<Profile>) => Promise<void>;
}

const Ctx = createContext<AppCtx | null>(null);

function useClock(tz: string) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 30_000);
    const onVis = () => document.visibilityState === 'visible' && setNow(Date.now());
    document.addEventListener('visibilitychange', onVis);
    return () => {
      window.clearInterval(id);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, []);
  return { now, today: todayISO(tz, now) };
}

export function AppProvider({ children }: { children: ReactNode }) {
  const stored = useLiveQuery(() => db.profile.get('profile'), [], null as Profile | null | undefined);
  const loaded = stored !== null;
  const profile = useMemo(() => stored ?? defaultProfile(navigator.language?.startsWith('fa') || !navigator.language?.startsWith('en') ? 'fa' : 'en'), [stored]);
  const locale = profile.locale;
  const tz = profile.timezone;
  const { now, today } = useClock(tz);

  useEffect(() => {
    const root = document.documentElement;
    root.lang = locale;
    root.dir = locale === 'fa' ? 'rtl' : 'ltr';
    if (profile.fontScale === 'large') root.setAttribute('data-font-scale', 'large');
    else root.removeAttribute('data-font-scale');
    setThemeSetting(profile.theme);
    setScheme(profile.scheme);
  }, [locale, profile.theme, profile.scheme, profile.fontScale]);

  const t = useCallback(
    (fa: string, en: string, params?: Params) => {
      let s = locale === 'fa' ? fa : en;
      if (params) {
        for (const [k, v] of Object.entries(params)) {
          const val = typeof v === 'number' ? fmtNum(v, locale) : v;
          s = s.split(`{${k}}`).join(val);
        }
      }
      return s;
    },
    [locale],
  );

  const value = useMemo<AppCtx>(() => {
    const fctx = { locale, calendar: profile.calendar };
    const dir: Dir = locale === 'fa' ? 'rtl' : 'ltr';
    return {
      profile,
      loaded,
      locale,
      dir,
      bidi: (text) => dirOf(text, dir),
      tz,
      today,
      now,
      t,
      num: (n, frac = 0) => fmtNum(n, locale, frac),
      dig: (v) => digits(v, locale),
      date: (iso, style) => fmtDate(iso, fctx, style),
      relDay: (iso) => fmtRelDay(iso, today, fctx),
      time: (hhmm) => fmtTime(hhmm, locale),
      instantTime: (utc) => fmtInstantTime(utc, tz, locale),
      money: (a, c) => fmtMoney(a, c, locale),
      bytes: (n) => fmtBytes(n, locale),
      duration: (s) => fmtDuration(s, locale),
      updateProfile: (patch) => saveProfile(patch, profile),
    };
  }, [profile, loaded, locale, tz, today, now, t]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp outside AppProvider');
  return v;
}
