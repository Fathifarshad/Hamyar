import { useEffect, useState } from 'react';
import { useApp } from './AppContext';
import { Button, Notice, Switch } from '../ui/primitives';
import { BellRing, CircleCheck, CircleX, Info } from '../ui/icons';
import { toast } from '../lib/ui-store';
import type { NativePermission } from '../lib/native';

/** Android app: reminders through the phone's own alarm service. */
export function NativeReminderSettings() {
  const { t, locale, profile, updateProfile } = useApp();
  const [perm, setPerm] = useState<NativePermission | null>(null);
  const [exact, setExact] = useState<'granted' | 'denied' | null>(null);

  const refresh = async () => {
    const m = await import('../lib/native');
    setPerm(await m.notificationPermission());
    setExact(await m.exactAlarmStatus());
  };
  useEffect(() => {
    void refresh();
    const onVisible = () => document.visibilityState === 'visible' && void refresh();
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, []);

  const enable = async () => {
    const m = await import('../lib/native');
    const ok = await m.enablePhoneReminders();
    await refresh();
    if (!ok) toast({ kind: 'warning', text: t('اجازه اعلان داده نشد. از تنظیمات گوشی ← برنامه‌ها ← همیار ← اعلان‌ها روشنش کنید.', 'Notifications were not allowed. Turn them on in phone Settings → Apps → Hamyar → Notifications.') });
  };

  const on = profile.systemNotifications && perm === 'granted';
  return (
    <>
      <div className="row-flex wrap">
        <span className={`status-line${perm === 'granted' ? ' is-ok' : ' is-off'}`}>
          {perm === 'granted' ? <CircleCheck size={15} aria-hidden="true" /> : <CircleX size={15} aria-hidden="true" />}
          {perm === null ? t('در حال بررسی…', 'Checking…') : perm === 'granted' ? t('اجازه اعلان داده شده', 'Notifications allowed') : t('اعلان اجازه ندارد', 'Notifications not allowed')}
        </span>
        {perm !== null && perm !== 'granted' && (
          <Button size="sm" variant="primary" onClick={() => void enable()}>
            {t('اجازه اعلان', 'Allow notifications')}
          </Button>
        )}
        {perm === 'granted' && (
          <Button
            size="sm"
            variant="soft"
            icon={<BellRing size={15} />}
            onClick={async () => {
              const m = await import('../lib/native');
              const ok = await m.sendTestNotification(locale === 'fa');
              toast({ kind: ok ? 'success' : 'warning', text: ok ? t('۵ ثانیه دیگر اعلان می‌آید؛ می‌توانید برنامه را ببندید.', 'A notification arrives in 5 seconds; you can close the app.') : t('اعلان تنظیم نشد.', 'Could not schedule the notification.') });
            }}
          >
            {t('اعلان آزمایشی', 'Test notification')}
          </Button>
        )}
      </div>
      <Switch
        checked={on}
        onChange={(v) => (v ? void enable() : void updateProfile({ systemNotifications: false }))}
        label={t('یادآوری روی گوشی، حتی وقتی برنامه بسته است', 'Phone reminders, even when the app is closed')}
        description={t('کارها، نوبت داروها و پایان تایمر تمرکز تا ۳ هفته آینده در گوشی تنظیم می‌شوند و هر بار که همیار را باز کنید تمدید می‌شوند.', 'Tasks, medication doses and focus timer ends are set on the phone for the next 3 weeks and renewed every time you open Hamyar.')}
      />
      {on && exact === 'denied' && (
        <Notice tone="warn" icon={<Info size={16} />}>
          <div className="stack-sm">
            <span>{t('برای اینکه یادآوری دقیقاً سر وقت بیاید، اجازه «هشدارها و یادآوری‌ها» را بدهید.', 'To get reminders exactly on time, allow “Alarms & reminders”.')}</span>
            <Button
              size="sm"
              variant="soft"
              onClick={async () => {
                const m = await import('../lib/native');
                await m.openExactAlarmSettings();
                await refresh();
              }}
            >
              {t('باز کردن تنظیمات', 'Open settings')}
            </Button>
          </div>
        </Notice>
      )}
      <Notice tone="neutral" icon={<Info size={16} />}>
        {t(
          'اگر یادآوری‌ها دیر می‌رسند، در تنظیمات گوشی برای همیار «بهینه‌سازی باتری» را خاموش کنید (در گوشی‌های شیائومی و سامسونگ «اجرای خودکار» را هم روشن کنید). همیار توصیه پزشکی نمی‌دهد و جای زنگ هشدار حیاتی را نمی‌گیرد.',
          'If reminders arrive late, turn off “battery optimisation” for Hamyar in phone settings (on Xiaomi and Samsung also allow “autostart”). Hamyar gives no medical advice and does not replace a critical alarm.',
        )}
      </Notice>
    </>
  );
}
