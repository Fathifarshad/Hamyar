import { createStore } from '../lib/store';

/** Which section's settings sheet is open (null = closed). */
export const moduleSettingsStore = createStore<string | null>(null);
export function openModuleSettings(id: string) {
  moduleSettingsStore.set(id);
}

/** Add-section dialog; `presetType` pre-selects a type. */
export const addModuleStore = createStore<{ open: boolean; presetType?: string }>({ open: false });
export function openAddModule(presetType?: string) {
  addModuleStore.set({ open: true, presetType });
}

export const presetDialogStore = createStore(false);
export function openPresets() {
  presetDialogStore.set(true);
}

/** Dashboard edit mode (drag handles, move buttons). */
export const editModeStore = createStore(false);
