import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../data/db';
import { useApp } from './AppContext';
import type { ModuleInstance } from '../domain/types';
import { DomainError } from '../domain/types';
import { replaceActive, setActive, unarchiveModule } from '../data/modules';
import { ModuleIcon } from '../ui/Icon';
import { Button, EmptyState, IconButton, Modal, Spinner, Switch } from '../ui/primitives';
import { ArchiveRestore, Info, LayoutGrid, Plus, Settings2, Sparkles } from '../ui/icons';
import { MODULE_TEXT } from '../modules/registry';
import { ModuleMenu } from './ModuleCard';
import { openAddModule, openModuleSettings, openPresets } from './settingsStore';
import { LIMITS } from '../config/limits';
import { toast } from '../lib/ui-store';
import { errorText } from '../i18n/errors';
import { moduleHref } from './router';
import { ActiveCounter } from './Dashboard';

/** Shown when a section should be shown but 10 are already active: pick one to swap. */
export function ReplaceDialog({ target, live, onClose }: { target: ModuleInstance | null; live: ModuleInstance[]; onClose: () => void }) {
  const { t, bidi } = useApp();
  const [pick, setPick] = useState<string>('');
  if (!target) return null;
  return (
    <Modal
      open
      onClose={onClose}
      title={t('۱۰ بخش فعال دارید', 'You have 10 active sections')}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button
            variant="primary"
            disabled={!pick}
            onClick={async () => {
              try {
                await replaceActive(target.id, pick);
                toast({ kind: 'success', text: t('«{a}» نمایش داده شد.', '“{a}” is now shown.', { a: target.title }) });
                onClose();
              } catch (e) {
                toast({ kind: 'error', text: errorText(e, t) });
              }
            }}
          >
            {t('جایگزین کن', 'Swap')}
          </Button>
        </>
      }
    >
      <div className="stack-sm">
        <p>{t('برای نمایش «{a}»، یکی از بخش‌های فعال را پنهان کنید. داده آن حذف نمی‌شود.', 'To show “{a}”, hide one active section. Its data is kept.', { a: target.title })}</p>
        <div className="pick-list" role="radiogroup">
          {live.map((m) => (
            <label key={m.id} className={`pick${pick === m.id ? ' is-on' : ''}`} data-accent={m.appearance.accent}>
              <input type="radio" name="replace" value={m.id} checked={pick === m.id} onChange={() => setPick(m.id)} />
              <span className="mod-icon">
                <ModuleIcon icon={m.appearance.icon} size={16} />
              </span>
              <span className="auto-dir" dir={bidi(m.title)}>
                {m.title}
              </span>
            </label>
          ))}
        </div>
      </div>
    </Modal>
  );
}

function Row({ mod, onToggle }: { mod: ModuleInstance; onToggle: (m: ModuleInstance, on: boolean) => void }) {
  const { t, locale, bidi } = useApp();
  return (
    <li className="lib-row" data-accent={mod.appearance.accent}>
      <span className="mod-icon">
        <ModuleIcon icon={mod.appearance.icon} size={17} />
      </span>
      <a className="lib-main" href={moduleHref(mod.id)}>
        <span className="row-title auto-dir" dir={bidi(mod.title)}>
          {mod.title}
        </span>
        {mod.title !== MODULE_TEXT[mod.type].name[locale === 'fa' ? 0 : 1] && <span className="row-meta">{MODULE_TEXT[mod.type].name[locale === 'fa' ? 0 : 1]}</span>}
      </a>
      {mod.archivedAt ? (
        <Button size="sm" variant="soft" icon={<ArchiveRestore size={14} />} onClick={() => void unarchiveModule(mod.id, false)}>
          {t('بازگردانی', 'Restore')}
        </Button>
      ) : (
        <Switch checked={mod.active === 1} onChange={(on) => onToggle(mod, on)} label={<span className="visually-hidden">{t('نمایش در داشبورد', 'Show on dashboard')}</span>} />
      )}
      <IconButton label={t('تنظیمات و ظاهر', 'Settings & look')} size="sm" onClick={() => openModuleSettings(mod.id)}>
        <Settings2 size={16} />
      </IconButton>
      <ModuleMenu mod={mod} />
    </li>
  );
}

export function Library() {
  const { t, num } = useApp();
  const modules = useLiveQuery(() => db.modules.toArray(), []);
  const [replaceTarget, setReplaceTarget] = useState<ModuleInstance | null>(null);
  if (!modules)
    return (
      <div className="page-loading">
        <Spinner />
      </div>
    );
  const sorted = [...modules].sort((a, b) => a.order - b.order);
  const live = sorted.filter((m) => m.active === 1 && !m.archivedAt);
  const hidden = sorted.filter((m) => m.active === 0 && !m.archivedAt);
  const archived = sorted.filter((m) => !!m.archivedAt);

  const toggle = async (m: ModuleInstance, on: boolean) => {
    try {
      await setActive(m.id, on);
      if (!on && (m.type === 'tasks' || m.type === 'medications') && !m.remindersPaused) toast({ kind: 'info', text: t('پنهان شد؛ یادآوری‌هایش همچنان فعال است.', 'Hidden; its reminders keep running.') });
    } catch (e) {
      if (e instanceof DomainError && e.code === 'MODULE_LIMIT_REACHED') setReplaceTarget(m);
      else toast({ kind: 'error', text: errorText(e, t) });
    }
  };

  return (
    <div className="library">
      <header className="page-head is-plain">
        <div className="page-title-wrap">
          <h1 className="page-title">{t('بخش‌ها', 'Sections')}</h1>
          <div className="page-sub">{t('{a} بخش از سقف {b}', '{a} of {b} sections', { a: modules.length, b: LIMITS.maxTotalModules })}</div>
        </div>
        <div className="page-actions">
          <ActiveCounter count={live.length} compact />
          <Button variant="outline" icon={<Sparkles size={16} />} onClick={() => openPresets()}>
            {t('قالب‌های آماده', 'Ready-made layouts')}
          </Button>
          <Button variant="primary" icon={<Plus size={16} />} onClick={() => openAddModule()}>
            {t('افزودن بخش', 'Add section')}
          </Button>
        </div>
      </header>
      <p className="lib-note">
        <Info size={15} aria-hidden="true" />
        {t(
          'تا {n} بخش می‌توانند هم‌زمان در داشبورد فعال باشند. پنهان کردن، داده و یادآوری را حذف نمی‌کند؛ بایگانی یادآوری‌های آینده را متوقف می‌کند.',
          'Up to {n} sections can be active on the dashboard. Hiding keeps data and reminders; archiving stops future reminders.',
          { n: LIMITS.maxActiveModules },
        )}
      </p>
      {modules.length === 0 ? (
        <EmptyState icon={<LayoutGrid size={24} />} title={t('هنوز بخشی ندارید', 'No sections yet')} />
      ) : (
        <>
          <section className="lib-group">
            <h2>
              {t('فعال در داشبورد', 'On the dashboard')} <span className="sec-count">{num(live.length)}</span>
            </h2>
            {live.length ? (
              <ul className="lib-list">
                {live.map((m) => (
                  <Row key={m.id} mod={m} onToggle={toggle} />
                ))}
              </ul>
            ) : (
              <p className="subtle small">{t('هیچ بخشی فعال نیست.', 'No active sections.')}</p>
            )}
          </section>
          {hidden.length > 0 && (
            <section className="lib-group">
              <h2>
                {t('پنهان', 'Hidden')} <span className="sec-count">{num(hidden.length)}</span>
              </h2>
              <ul className="lib-list">
                {hidden.map((m) => (
                  <Row key={m.id} mod={m} onToggle={toggle} />
                ))}
              </ul>
            </section>
          )}
          {archived.length > 0 && (
            <section className="lib-group">
              <h2>
                {t('بایگانی', 'Archived')} <span className="sec-count">{num(archived.length)}</span>
              </h2>
              <ul className="lib-list">
                {archived.map((m) => (
                  <Row key={m.id} mod={m} onToggle={toggle} />
                ))}
              </ul>
            </section>
          )}
        </>
      )}
      <ReplaceDialog target={replaceTarget} live={live} onClose={() => setReplaceTarget(null)} />
    </div>
  );
}
