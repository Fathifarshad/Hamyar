import { Component, Suspense, type ReactNode } from 'react';
import { useApp } from './AppContext';
import { MODULE_VIEWS } from '../modules/registry';
import type { ModuleInstance } from '../domain/types';
import { ModuleIcon } from '../ui/Icon';
import { IconButton, Menu, MenuItem, MenuSeparator, Spinner } from '../ui/primitives';
import {
  Archive,
  ArrowDown,
  ArrowUp,
  BellOff,
  BellRing,
  CircleAlert,
  EyeOff,
  GripVertical,
  Maximize2,
  MoreIcon,
  RotateCcw,
  Settings2,
  TrashIcon,
} from '../ui/icons';
import { moduleHref, navigate } from './router';
import { archiveModule, deleteModule, setActive, updateModule } from '../data/modules';
import { askConfirm, toast } from '../lib/ui-store';
import { errorText } from '../i18n/errors';
import { openModuleSettings } from './settingsStore';
import { player, playerStore } from '../lib/media';

class CardBoundary extends Component<{ children: ReactNode; fallback: (reset: () => void) => ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  override componentDidCatch(err: unknown) {
    console.error('[hamyar] section crashed', err);
  }
  override render() {
    if (this.state.failed) return this.props.fallback(() => this.setState({ failed: false }));
    return this.props.children;
  }
}

export function SectionFallback({ reset }: { reset: () => void }) {
  const { t } = useApp();
  return (
    <div className="empty">
      <div className="empty-icon">
        <CircleAlert size={22} />
      </div>
      <div className="empty-title">{t('این بخش با خطا روبه‌رو شد', 'This section hit an error')}</div>
      <p className="empty-text">{t('داده‌ها سالم‌اند و بقیه داشبورد کار می‌کند.', 'Your data is safe and the rest of the dashboard works.')}</p>
      <button type="button" className="btn btn-soft btn-sm" onClick={reset}>
        <RotateCcw size={14} /> {t('تلاش دوباره', 'Try again')}
      </button>
    </div>
  );
}

export function ModuleBody({ mod, variant, focus }: { mod: ModuleInstance; variant: 'card' | 'full'; focus?: string }) {
  const { t } = useApp();
  const View = MODULE_VIEWS[mod.type];
  return (
    <CardBoundary fallback={(reset) => <SectionFallback reset={reset} />}>
      <Suspense
        fallback={
          <div className="mod-loading">
            <Spinner label={t('در حال بارگذاری…', 'Loading…')} />
          </div>
        }
      >
        <View mod={mod} variant={variant} focus={focus} />
      </Suspense>
    </CardBoundary>
  );
}

const REMINDER_TYPES = new Set(['tasks', 'medications']);

/** Shared actions for a section (used by the card menu and the full view). */
export function useModuleActions(mod: ModuleInstance) {
  const { t } = useApp();
  const hasReminders = REMINDER_TYPES.has(mod.type);
  return {
    hasReminders,
    async hide() {
      const ok = await askConfirm({
        title: t('پنهان کردن «{title}» از داشبورد؟', 'Hide “{title}” from the dashboard?', { title: mod.title }),
        body: hasReminders
          ? t('این بخش در داشبورد پنهان می‌شود؛ یادآوری‌هایش همچنان فعال می‌مانند. برای توقف یادآوری‌ها از «توقف یادآوری‌ها» یا «بایگانی» استفاده کنید.', 'The section is hidden, but its reminders keep running. Use “Pause reminders” or “Archive” to stop them.')
          : t('داده‌های این بخش حذف نمی‌شود و هر وقت بخواهید از «بخش‌ها» دوباره نمایشش می‌دهید.', 'Nothing is deleted. You can show it again from “Sections”.'),
        confirmText: t('پنهان کن', 'Hide'),
        cancelText: t('انصراف', 'Cancel'),
      });
      if (!ok) return;
      try {
        await setActive(mod.id, false);
        toast({ kind: 'success', text: t('«{title}» پنهان شد.', '“{title}” is hidden.', { title: mod.title }) });
      } catch (e) {
        toast({ kind: 'error', text: errorText(e, t) });
      }
    },
    async toggleReminders() {
      try {
        await updateModule(mod.id, { remindersPaused: !mod.remindersPaused });
        toast({
          kind: 'success',
          text: mod.remindersPaused ? t('یادآوری‌های این بخش دوباره فعال شد.', 'Reminders for this section are back on.') : t('یادآوری‌های این بخش متوقف شد.', 'Reminders for this section are paused.'),
        });
      } catch (e) {
        toast({ kind: 'error', text: errorText(e, t) });
      }
    },
    async archive() {
      const ok = await askConfirm({
        title: t('بایگانی «{title}»؟', 'Archive “{title}”?', { title: mod.title }),
        body: t('داده‌ها حفظ می‌شود، کارت از داشبورد برداشته می‌شود و یادآوری‌های آینده این بخش متوقف می‌شود. از «بخش‌ها» قابل بازگرداندن است.', 'Data is kept, the card leaves the dashboard and this section’s future reminders stop. You can restore it from “Sections”.'),
        confirmText: t('بایگانی', 'Archive'),
        cancelText: t('انصراف', 'Cancel'),
      });
      if (!ok) return;
      await archiveModule(mod.id);
      toast({ kind: 'success', text: t('بایگانی شد.', 'Archived.') });
    },
    async remove(after?: () => void) {
      const word = t('حذف', 'delete');
      const ok = await askConfirm({
        title: t('حذف دائمی «{title}»؟', 'Permanently delete “{title}”?', { title: mod.title }),
        body: t(
          'همه داده‌ها و فایل‌های این بخش از این مرورگر پاک می‌شود و یادآوری‌های آینده‌اش لغو می‌شود. بازگرداندن ممکن نیست.',
          'All of this section’s data and files are erased from this browser and its future reminders are cancelled. This cannot be undone.',
        ),
        confirmText: t('حذف دائمی', 'Delete permanently'),
        cancelText: t('انصراف', 'Cancel'),
        danger: true,
        typeToConfirm: word,
      });
      if (!ok) return;
      if (playerStore.get().moduleId === mod.id) player.stopAndClear();
      const res = await deleteModule(mod.id);
      toast({
        kind: 'success',
        text: res.assetsRemoved
          ? t('بخش و {n} فایل حذف شد.', 'Section and {n} file(s) deleted.', { n: res.assetsRemoved })
          : t('بخش حذف شد.', 'Section deleted.'),
      });
      after?.();
    },
  };
}

export function ModuleMenu({ mod, inFull }: { mod: ModuleInstance; inFull?: boolean }) {
  const { t } = useApp();
  const actions = useModuleActions(mod);
  return (
    <Menu
      label={t('گزینه‌های بخش', 'Section options')}
      trigger={(p) => (
        <IconButton label={t('گزینه‌های بخش', 'Section options')} size="sm" {...p}>
          <MoreIcon size={18} />
        </IconButton>
      )}
    >
      {(close) => (
        <>
          {!inFull && (
            <MenuItem
              icon={<Maximize2 size={16} />}
              onSelect={() => {
                close();
                navigate(moduleHref(mod.id));
              }}
            >
              {t('نمای کامل', 'Open full view')}
            </MenuItem>
          )}
          <MenuItem
            icon={<Settings2 size={16} />}
            onSelect={() => {
              close();
              openModuleSettings(mod.id);
            }}
          >
            {t('تنظیمات و ظاهر', 'Settings & look')}
          </MenuItem>
          {actions.hasReminders && (
            <MenuItem
              icon={mod.remindersPaused ? <BellRing size={16} /> : <BellOff size={16} />}
              onSelect={() => {
                close();
                void actions.toggleReminders();
              }}
            >
              {mod.remindersPaused ? t('ادامه یادآوری‌ها', 'Resume reminders') : t('توقف یادآوری‌ها', 'Pause reminders')}
            </MenuItem>
          )}
          <MenuSeparator />
          {mod.active === 1 && (
            <MenuItem
              icon={<EyeOff size={16} />}
              onSelect={() => {
                close();
                void actions.hide();
              }}
            >
              {t('پنهان کردن از داشبورد', 'Hide from dashboard')}
            </MenuItem>
          )}
          <MenuItem
            icon={<Archive size={16} />}
            onSelect={() => {
              close();
              void actions.archive();
            }}
          >
            {t('بایگانی', 'Archive')}
          </MenuItem>
          <MenuItem
            icon={<TrashIcon size={16} />}
            danger
            onSelect={() => {
              close();
              void actions.remove(inFull ? () => navigate('/') : undefined);
            }}
          >
            {t('حذف دائمی', 'Delete permanently')}
          </MenuItem>
        </>
      )}
    </Menu>
  );
}

export interface CardDragProps {
  index: number;
  count: number;
  onMove: (dir: -1 | 1) => void;
  onHandlePointerDown: (e: React.PointerEvent, index: number) => void;
  dragging: boolean;
}

export function ModuleCard({ mod, edit, featured, drag }: { mod: ModuleInstance; edit: boolean; featured?: boolean; drag: CardDragProps }) {
  const { t, bidi } = useApp();
  const a = mod.appearance;
  const titleId = `mod-title-${mod.id}`;
  return (
    <section
      className={`mod${featured ? ' is-featured' : ''}${edit ? ' is-editing' : ''}${drag.dragging ? ' is-dragging' : ''}`}
      data-accent={a.accent}
      data-preset={a.preset}
      data-density={a.density}
      data-width={a.width}
      data-mod-index={drag.index}
      aria-labelledby={titleId}
    >
      <header className="mod-head">
        {edit && (
          <button
            type="button"
            className="drag-handle"
            aria-label={t('جابه‌جایی «{title}» با کشیدن', 'Drag to move “{title}”', { title: mod.title })}
            onPointerDown={(e) => drag.onHandlePointerDown(e, drag.index)}
          >
            <GripVertical size={18} />
          </button>
        )}
        <span className="mod-icon">
          <ModuleIcon icon={a.icon} size={19} />
        </span>
        <h2 className="mod-title" id={titleId}>
          <a href={moduleHref(mod.id)} className="auto-dir" dir={bidi(mod.title)}>
            {mod.title}
          </a>
        </h2>
        {mod.remindersPaused && (
          <span className="mod-flag" title={t('یادآوری‌ها متوقف است', 'Reminders paused')}>
            <BellOff size={14} aria-label={t('یادآوری‌ها متوقف است', 'Reminders paused')} />
          </span>
        )}
        <div className="mod-tools">
          {edit ? (
            <>
              <IconButton label={t('بالاتر', 'Move up')} size="sm" onClick={() => drag.onMove(-1)} disabled={drag.index === 0}>
                <ArrowUp size={17} />
              </IconButton>
              <IconButton label={t('پایین‌تر', 'Move down')} size="sm" onClick={() => drag.onMove(1)} disabled={drag.index === drag.count - 1}>
                <ArrowDown size={17} />
              </IconButton>
              <IconButton label={t('تنظیمات و ظاهر', 'Settings & look')} size="sm" onClick={() => openModuleSettings(mod.id)}>
                <Settings2 size={17} />
              </IconButton>
            </>
          ) : (
            <>
              <IconButton label={t('نمای کامل', 'Open full view')} size="sm" onClick={() => navigate(moduleHref(mod.id))}>
                <Maximize2 size={16} />
              </IconButton>
              <ModuleMenu mod={mod} />
            </>
          )}
        </div>
      </header>
      <div className="mod-body" inert={edit ? true : undefined}>
        <ModuleBody mod={mod} variant="card" />
      </div>
    </section>
  );
}
