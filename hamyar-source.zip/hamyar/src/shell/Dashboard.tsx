import { useEffect, useMemo, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../data/db';
import { useApp } from './AppContext';
import { ModuleCard } from './ModuleCard';
import { moveModule, reorderModules } from '../data/modules';
import { LIMITS } from '../config/limits';
import { useStore } from '../lib/store';
import { editModeStore, openAddModule, openPresets } from './settingsStore';
import { Button, EmptyState, IconButton, Segmented, Spinner } from '../ui/primitives';
import { Check, LayoutGrid, LayoutList, Focus, Pencil, Plus, Sparkles, LayoutDashboard } from '../ui/icons';
import { TodayStrip } from './TodayStrip';
import { navigate } from './router';
import type { LayoutMode, ModuleInstance } from '../domain/types';
import { fmtDate } from '../lib/format';
import { utcToLocal } from '../domain/time';
import { SampleBanner } from './SampleBanner';
import { InstallHint } from './InstallHint';

function greeting(hour: number, t: (fa: string, en: string) => string): string {
  if (hour >= 5 && hour < 11) return t('صبح بخیر', 'Good morning');
  if (hour >= 11 && hour < 16) return t('روز بخیر', 'Good afternoon');
  if (hour >= 16 && hour < 20) return t('عصر بخیر', 'Good evening');
  return t('شب بخیر', 'Good night');
}

export function ActiveCounter({ count, compact }: { count: number; compact?: boolean }) {
  const { t } = useApp();
  const full = count >= LIMITS.maxActiveModules;
  return (
    <button
      type="button"
      className={`counter${full ? ' is-full' : ''}${compact ? ' is-compact' : ''}`}
      onClick={() => navigate('/library')}
      title={t('مدیریت بخش‌ها', 'Manage sections')}
    >
      <span className="counter-dots" aria-hidden="true">
        {Array.from({ length: LIMITS.maxActiveModules }, (_, i) => (
          <span key={i} className={i < count ? 'on' : ''} />
        ))}
      </span>
      <span className="counter-text">{t('{n} از {max} بخش فعال', '{n} of {max} active', { n: count, max: LIMITS.maxActiveModules })}</span>
    </button>
  );
}

function DashboardHeader({ live, edit }: { live: ModuleInstance[]; edit: boolean }) {
  const { t, profile, today, now, tz, date, updateProfile, locale } = useApp();
  const hour = utcToLocal(now, tz).h;
  const primary = date(today, 'long');
  const secondary = fmtDate(today, { locale, calendar: profile.calendar === 'jalali' ? 'gregorian' : 'jalali' }, 'medium');
  const layouts: { value: LayoutMode; label: string; icon: React.ReactNode }[] = [
    { value: 'grid', label: '', icon: <LayoutGrid size={17} aria-label={t('شبکه‌ای', 'Grid')} /> },
    { value: 'list', label: '', icon: <LayoutList size={17} aria-label={t('فهرستی', 'List')} /> },
    { value: 'focus', label: '', icon: <Focus size={17} aria-label={t('تمرکز', 'Focus')} /> },
  ];
  return (
    <header className="dash-head">
      <div className="dash-date">
        <div className="dash-greet">{greeting(hour, t)}</div>
        <h1 className="dash-day">{primary}</h1>
        <div className="dash-sub">
          <span>{secondary}</span>
          <span className="dot" aria-hidden="true" />
          <span className="ltr">{tz.replace(/_/g, ' ')}</span>
        </div>
      </div>
      <div className="dash-actions">
        <ActiveCounter count={live.length} />
        <div className="dash-tools">
          <Segmented
            label={t('چیدمان داشبورد', 'Dashboard layout')}
            value={profile.layoutMode}
            onChange={(v) => void updateProfile({ layoutMode: v })}
            options={layouts.map((l) => ({ ...l, title: l.value === 'grid' ? t('شبکه‌ای', 'Grid') : l.value === 'list' ? t('فهرستی', 'List') : t('تمرکز', 'Focus') }))}
            size="sm"
          />
          <IconButton
            label={edit ? t('پایان ویرایش چیدمان', 'Finish editing layout') : t('ویرایش چیدمان', 'Edit layout')}
            variant={edit ? 'primary' : 'soft'}
            pressed={edit}
            onClick={() => editModeStore.set(!edit)}
          >
            {edit ? <Check size={18} /> : <Pencil size={17} />}
          </IconButton>
          <Button variant="primary" icon={<Plus size={17} />} onClick={() => openAddModule()} className="dash-add">
            {t('افزودن بخش', 'Add section')}
          </Button>
        </div>
      </div>
    </header>
  );
}

export function Dashboard() {
  const { t, profile } = useApp();
  const modules = useLiveQuery(() => db.modules.toArray(), []);
  const edit = useStore(editModeStore);
  const live = useMemo(() => (modules ?? []).filter((m) => m.active === 1 && !m.archivedAt).sort((a, b) => a.order - b.order), [modules]);
  const [dragOrder, setDragOrder] = useState<string[] | null>(null);
  const [dragging, setDragging] = useState<string | null>(null);
  const orderRef = useRef<string[] | null>(null);

  useEffect(() => () => editModeStore.set(false), []);

  const ordered = useMemo(() => {
    if (!dragOrder) return live;
    const map = new Map(live.map((m) => [m.id, m]));
    return dragOrder.map((id) => map.get(id)).filter((m): m is ModuleInstance => !!m);
  }, [live, dragOrder]);

  const featuredId = profile.layoutMode === 'focus' ? (live.find((m) => m.id === profile.focusModuleId)?.id ?? live[0]?.id) : undefined;

  const onHandlePointerDown = (e: React.PointerEvent, index: number) => {
    e.preventDefault();
    const ids = ordered.map((m) => m.id);
    orderRef.current = ids;
    setDragOrder(ids);
    setDragging(ids[index] ?? null);
    let current = index;
    const onMove = (ev: PointerEvent) => {
      const el = document.elementFromPoint(ev.clientX, ev.clientY)?.closest<HTMLElement>('[data-mod-index]');
      if (ev.clientY < 70) window.scrollBy(0, -14);
      else if (ev.clientY > window.innerHeight - 70) window.scrollBy(0, 14);
      if (!el) return;
      const target = Number(el.dataset.modIndex);
      if (!Number.isFinite(target) || target === current || !orderRef.current) return;
      const next = [...orderRef.current];
      const [moved] = next.splice(current, 1);
      next.splice(target, 0, moved!);
      current = target;
      orderRef.current = next;
      setDragOrder(next);
    };
    const onUp = () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
      const final = orderRef.current;
      setDragging(null);
      if (final) void reorderModules(final).finally(() => setDragOrder(null));
      else setDragOrder(null);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
  };

  if (!modules) {
    return (
      <div className="page-loading">
        <Spinner label={t('در حال بارگذاری…', 'Loading…')} />
      </div>
    );
  }

  return (
    <div className="dashboard">
      <DashboardHeader live={live} edit={edit} />
      <InstallHint />
      {profile.sampleData && <SampleBanner />}
      <TodayStrip modules={live} />
      {edit && (
        <div className="edit-hint" role="status">
          {t('بخش‌ها را با دستگیره بکشید یا با دکمه‌های بالا و پایین جابه‌جا کنید. برای پنهان کردن، از تنظیمات هر بخش استفاده کنید.', 'Drag sections by the handle or use the up/down buttons. Use each section’s settings to hide it.')}
        </div>
      )}
      {live.length === 0 ? (
        <div className="dash-empty">
          <EmptyState
            icon={<LayoutDashboard size={24} />}
            title={t('داشبورد شما خالی است', 'Your dashboard is empty')}
            text={t('بخش‌هایی را که لازم دارید اضافه کنید یا از یک قالب آماده شروع کنید. تا ۱۰ بخش می‌توانند هم‌زمان فعال باشند.', 'Add the sections you need or start from a ready-made layout. Up to 10 can be active at once.')}
            action={
              <div className="row-flex wrap" style={{ justifyContent: 'center' }}>
                <Button variant="primary" icon={<Plus size={16} />} onClick={() => openAddModule()}>
                  {t('افزودن بخش', 'Add section')}
                </Button>
                <Button variant="outline" icon={<Sparkles size={16} />} onClick={() => openPresets()}>
                  {t('قالب‌های آماده', 'Ready-made layouts')}
                </Button>
              </div>
            }
          />
        </div>
      ) : (
        <div className={`dash-grid layout-${profile.layoutMode}`}>
          {ordered.map((m, i) => (
            <ModuleCard
              key={m.id}
              mod={m}
              edit={edit}
              featured={m.id === featuredId}
              drag={{
                index: i,
                count: ordered.length,
                dragging: dragging === m.id,
                onMove: (dir) => void moveModule(m.id, dir),
                onHandlePointerDown,
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
