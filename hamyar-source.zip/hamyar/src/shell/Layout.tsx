import { useEffect, type ReactNode } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../data/db';
import { useApp } from './AppContext';
import { useRoute, moduleHref } from './router';
import { ModuleIcon } from '../ui/Icon';
import { Inbox, LayoutDashboard, LayoutGrid, Settings, Pause, Play, SkipForward, X, Music, HardDrive, Monitor } from '../ui/icons';
import { useStore } from '../lib/store';
import { player, playerStore } from '../lib/media';
import { IconButton } from '../ui/primitives';
import { LIMITS } from '../config/limits';
import { IS_ARTIFACT, APP_VERSION } from '../lib/platform';

export function Logo({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true" className="logo-mark">
      <rect x="2" y="2" width="12.5" height="12.5" rx="4" className="lm-a" />
      <rect x="17.5" y="2" width="12.5" height="12.5" rx="4" className="lm-b" />
      <rect x="2" y="17.5" width="12.5" height="12.5" rx="4" className="lm-b" />
      <rect x="17.5" y="17.5" width="12.5" height="12.5" rx="6.25" className="lm-c" />
    </svg>
  );
}

function useUnread(): number {
  return useLiveQuery(async () => (await db.reminders.toArray()).filter((r) => !r.readAt).length, [], 0) ?? 0;
}

function NavLinks({ variant }: { variant: 'rail' | 'bottom' }) {
  const { t, num } = useApp();
  const route = useRoute();
  const unread = useUnread();
  const items = [
    { href: '#/', name: 'dashboard', label: t('داشبورد', 'Dashboard'), icon: LayoutDashboard },
    { href: '#/library', name: 'library', label: t('بخش‌ها', 'Sections'), icon: LayoutGrid },
    { href: '#/inbox', name: 'inbox', label: t('یادآوری‌ها', 'Reminders'), icon: Inbox, badge: unread },
    { href: '#/settings', name: 'settings', label: t('تنظیمات', 'Settings'), icon: Settings },
  ];
  return (
    <nav className={variant === 'rail' ? 'rail-nav' : 'bottom-nav'} aria-label={t('ناوبری اصلی', 'Main navigation')}>
      {items.map((it) => {
        const active = route.name === it.name;
        const Icon = it.icon;
        return (
          <a key={it.name} href={it.href} className={`nav-item${active ? ' is-active' : ''}`} aria-current={active ? 'page' : undefined}>
            <span className="nav-icon">
              <Icon size={variant === 'rail' ? 19 : 22} aria-hidden="true" />
              {!!it.badge && <span className="nav-badge">{num(Math.min(it.badge, 99))}</span>}
            </span>
            <span className="nav-label">{it.label}</span>
          </a>
        );
      })}
    </nav>
  );
}

function Rail() {
  const { t, num, bidi } = useApp();
  const route = useRoute();
  const modules = useLiveQuery(() => db.modules.toArray(), []);
  const live = (modules ?? []).filter((m) => m.active === 1 && !m.archivedAt).sort((a, b) => a.order - b.order);
  return (
    <aside className="rail">
      <a href="#/" className="brand">
        <Logo />
        <span className="brand-text">
          <span className="brand-name">{t('همیار', 'Hamyar')}</span>
          <span className="brand-sub">{t('میزکار شخصی', 'Personal desk')}</span>
        </span>
      </a>
      <NavLinks variant="rail" />
      <div className="rail-section">
        <div className="rail-title">
          <span>{t('بخش‌های فعال', 'Active sections')}</span>
          <span className="num">
            {num(live.length)}/{num(LIMITS.maxActiveModules)}
          </span>
        </div>
        <ul className="rail-mods">
          {live.map((m) => (
            <li key={m.id}>
              <a href={moduleHref(m.id)} className={`rail-mod${route.name === 'module' && route.id === m.id ? ' is-active' : ''}`} data-accent={m.appearance.accent}>
                <span className="rail-mod-icon">
                  <ModuleIcon icon={m.appearance.icon} size={15} />
                </span>
                <span className="ellipsis auto-dir" dir={bidi(m.title)}>
                  {m.title}
                </span>
              </a>
            </li>
          ))}
        </ul>
      </div>
      <div className="rail-foot">
        {IS_ARTIFACT ? <Monitor size={14} aria-hidden="true" /> : <HardDrive size={14} aria-hidden="true" />}
        <span>{IS_ARTIFACT ? t('پیش‌نمایش claude.ai · داده فقط در همین مرورگر', 'claude.ai preview · data stays in this browser') : t('حالت محلی · داده روی همین مرورگر', 'Local mode · data in this browser')}</span>
        <span className="rail-ver ltr">v{APP_VERSION}</span>
      </div>
    </aside>
  );
}

function MiniPlayer() {
  const { t, bidi } = useApp();
  const ps = useStore(playerStore);
  const route = useRoute();
  const visible = !!ps.current && !(route.name === 'module' && route.id === ps.moduleId);
  useEffect(() => {
    document.documentElement.style.setProperty('--player-h', visible ? '64px' : '0px');
  }, [visible]);
  if (!visible || !ps.current) return null;
  return (
    <div className="mini-player" role="region" aria-label={t('پخش‌کننده موسیقی', 'Music player')}>
      <a href={ps.moduleId ? moduleHref(ps.moduleId) : '#/'} className="mini-info">
        <span className="player-art" aria-hidden="true">
          <Music size={16} />
        </span>
        <span className="ellipsis auto-dir" dir={bidi(ps.current.title)}>
          {ps.current.title}
        </span>
      </a>
      <IconButton label={ps.playing ? t('توقف', 'Pause') : t('پخش', 'Play')} variant="primary" size="sm" onClick={() => void player.toggle()}>
        {ps.playing ? <Pause size={16} /> : <Play size={16} />}
      </IconButton>
      <IconButton label={t('بعدی', 'Next')} size="sm" onClick={() => void player.next()}>
        <SkipForward size={16} className="flip-rtl" />
      </IconButton>
      <IconButton label={t('بستن پخش‌کننده', 'Close player')} size="sm" onClick={() => player.stopAndClear()}>
        <X size={16} />
      </IconButton>
    </div>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { t } = useApp();
  return (
    <div className="app">
      <a href="#main" className="skip-link" onClick={(e) => (e.preventDefault(), document.getElementById('main')?.focus())}>
        {t('رفتن به محتوا', 'Skip to content')}
      </a>
      <Rail />
      <div className="main-col">
        <header className="topbar">
          <a href="#/" className="brand">
            <Logo size={26} />
            <span className="brand-name">{t('همیار', 'Hamyar')}</span>
          </a>
        </header>
        <main id="main" tabIndex={-1} className="main">
          {children}
        </main>
      </div>
      <MiniPlayer />
      <NavLinks variant="bottom" />
    </div>
  );
}
