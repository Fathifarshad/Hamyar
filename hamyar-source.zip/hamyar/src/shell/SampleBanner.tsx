import { useApp } from './AppContext';
import { Button } from '../ui/primitives';
import { Info } from '../ui/icons';
import { askConfirm } from '../lib/ui-store';
import { markSkipSeed, deleteAllData } from '../data/transfer';
import { IS_ARTIFACT } from '../lib/platform';

export function SampleBanner() {
  const { t, updateProfile } = useApp();
  return (
    <div className="sample-banner" role="note">
      <Info size={16} aria-hidden="true" />
      <span className="grow">
        {IS_ARTIFACT
          ? t('این پیش‌نمایش با داده نمونه پر شده است. هر چه اضافه کنید فقط در مرورگر خودتان می‌ماند.', 'This preview is filled with example data. Anything you add stays only in your browser.')
          : t('داده‌های نمونه بارگذاری شده‌اند و با برچسب «نمونه» مشخص‌اند.', 'Example data is loaded and labelled “example”.')}
      </span>
      <Button size="sm" variant="ghost" onClick={() => void updateProfile({ sampleData: false })}>
        {t('بستن پیام', 'Dismiss')}
      </Button>
      <Button
        size="sm"
        variant="outline"
        onClick={async () => {
          const ok = await askConfirm({
            title: t('شروع از صفر؟', 'Start from scratch?'),
            body: t('همه داده‌های این مرورگر (از جمله داده‌های نمونه) پاک می‌شود و دوباره به صفحه شروع می‌روید.', 'All data in this browser (including the examples) is erased and you return to the start screen.'),
            confirmText: t('پاک کن و شروع کن', 'Erase and start'),
            cancelText: t('انصراف', 'Cancel'),
            danger: true,
          });
          if (!ok) return;
          markSkipSeed();
          await deleteAllData();
          window.location.hash = '#/';
          window.location.reload();
        }}
      >
        {t('شروع از صفر', 'Start from scratch')}
      </Button>
    </div>
  );
}
