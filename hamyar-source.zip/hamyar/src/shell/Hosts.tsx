import { useEffect, useState } from 'react';
import { useStore } from '../lib/store';
import { confirmStore, dismissToast, textPromptStore, toastStore } from '../lib/ui-store';
import { useApp } from './AppContext';
import { Button, Input, Modal, IconButton } from '../ui/primitives';
import { BellRing, CircleAlert, CircleCheck, Info, TriangleAlert, X } from '../ui/icons';
import { normalizeForMatch } from '../domain/normalize';

export function ToastHost() {
  const list = useStore(toastStore);
  const { t, bidi } = useApp();
  return (
    <div className="toasts" aria-live="polite" aria-atomic="false">
      {list.map((x) => (
        <div key={x.id} className={`toast toast-${x.kind}`} role={x.kind === 'error' ? 'alert' : 'status'}>
          {x.kind === 'success' && <CircleCheck size={18} aria-hidden="true" />}
          {x.kind === 'error' && <CircleAlert size={18} aria-hidden="true" />}
          {x.kind === 'warning' && <TriangleAlert size={18} aria-hidden="true" />}
          {x.kind === 'info' && <Info size={18} aria-hidden="true" />}
          {x.kind === 'reminder' && <BellRing size={18} aria-hidden="true" />}
          <div className="toast-text">
            <div className="auto-dir" dir={bidi(x.text)}>
              {x.text}
            </div>
            {x.detail && (
              <div className="toast-detail auto-dir" dir={bidi(x.detail)}>
                {x.detail}
              </div>
            )}
          </div>
          {x.action && (
            <button
              type="button"
              className="toast-action"
              onClick={() => {
                x.action!.run();
                dismissToast(x.id);
              }}
            >
              {x.action.label}
            </button>
          )}
          <IconButton label={t('بستن', 'Dismiss')} size="sm" onClick={() => dismissToast(x.id)}>
            <X size={16} />
          </IconButton>
        </div>
      ))}
    </div>
  );
}

export function ConfirmHost() {
  const req = useStore(confirmStore);
  const { t, bidi } = useApp();
  const [typed, setTyped] = useState('');
  useEffect(() => setTyped(''), [req?.id]);
  if (!req) return null;
  const done = (ok: boolean) => {
    req.resolve(ok);
    confirmStore.set(null);
  };
  const needs = req.typeToConfirm;
  const matches = !needs || normalizeForMatch(typed) === normalizeForMatch(needs);
  return (
    <Modal
      open
      onClose={() => done(false)}
      title={req.title}
      size="sm"
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          <Button variant="ghost" onClick={() => done(false)}>
            {req.cancelText}
          </Button>
          <Button variant={req.danger ? 'danger' : 'primary'} onClick={() => done(true)} disabled={!matches} autoFocus={!needs}>
            {req.confirmText}
          </Button>
        </>
      }
    >
      <div className="stack-sm">
        {req.body && (
          <p className="auto-dir pre-wrap" dir={bidi(req.body)}>
            {req.body}
          </p>
        )}
        {needs && (
          <label className="field">
            <span className="field-label">{t('برای تأیید، کلمه «{w}» را بنویسید', 'Type “{w}” to confirm', { w: needs })}</span>
            <Input value={typed} onChange={(e) => setTyped(e.target.value)} autoFocus />
          </label>
        )}
      </div>
    </Modal>
  );
}

export function TextPromptHost() {
  const req = useStore(textPromptStore);
  const { t } = useApp();
  const [value, setValue] = useState('');
  useEffect(() => setValue(req?.initial ?? ''), [req?.id, req?.initial]);
  if (!req) return null;
  const done = (v: string | null) => {
    req.resolve(v);
    textPromptStore.set(null);
  };
  return (
    <Modal
      open
      onClose={() => done(null)}
      title={req.title}
      size="sm"
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          <Button variant="ghost" onClick={() => done(null)}>
            {req.cancelText}
          </Button>
          <Button variant="primary" onClick={() => done(value)} disabled={!value.trim()}>
            {req.confirmText}
          </Button>
        </>
      }
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (value.trim()) done(value);
        }}
      >
        <label className="field">
          <span className="field-label">{req.label}</span>
          <Input value={value} onChange={(e) => setValue(e.target.value)} maxLength={req.maxLength} autoFocus />
        </label>
      </form>
    </Modal>
  );
}
