import { useSyncExternalStore } from 'react';

export type Route =
  | { name: 'dashboard' }
  | { name: 'library' }
  | { name: 'inbox' }
  | { name: 'settings'; section?: string }
  | { name: 'module'; id: string; focus?: string };

function parse(hash: string): Route {
  const h = hash.replace(/^#/, '') || '/';
  const [path, query = ''] = h.split('?');
  const params = new URLSearchParams(query);
  const parts = (path ?? '/').split('/').filter(Boolean);
  if (parts[0] === 'library') return { name: 'library' };
  if (parts[0] === 'inbox') return { name: 'inbox' };
  if (parts[0] === 'settings') return { name: 'settings', section: parts[1] };
  if (parts[0] === 'm' && parts[1]) return { name: 'module', id: decodeURIComponent(parts[1]), focus: params.get('focus') ?? undefined };
  return { name: 'dashboard' };
}

function subscribe(cb: () => void) {
  window.addEventListener('hashchange', cb);
  return () => window.removeEventListener('hashchange', cb);
}

export function useRoute(): Route {
  const hash = useSyncExternalStore(subscribe, () => window.location.hash, () => '');
  return parse(hash);
}

export function navigate(to: string) {
  const target = to.startsWith('#') ? to : `#${to}`;
  if (window.location.hash !== target) window.location.hash = target;
  window.scrollTo({ top: 0 });
}

export function moduleHref(id: string, focus?: string): string {
  return `#/m/${encodeURIComponent(id)}${focus ? `?focus=${encodeURIComponent(focus)}` : ''}`;
}
