import { useEffect, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../data/db';
import { useApp } from './AppContext';
import { useStore } from '../lib/store';
import { addModuleStore } from './settingsStore';
import { CATALOG, CUSTOM_TEMPLATES, GROUP_ORDER, defaultAppearanceFor } from '../domain/catalog';
import { MODULE_TYPES, type InputLanguage, type ModuleType } from '../domain/types';
import { MODULE_TEXT } from '../modules/registry';
import { ModuleIcon } from '../ui/Icon';
import { Button, Field, Input, Modal, Notice, Segmented, Select } from '../ui/primitives';
import { ArrowLeft, ArrowRight, Info } from '../ui/icons';
import { ACCENTS, type Accent } from '../config/appearance';
import { createModule, replaceActive } from '../data/modules';
import { LIMITS } from '../config/limits';
import { toast } from '../lib/ui-store';
import { errorText } from '../i18n/errors';
import { moduleHref, navigate } from './router';
import { fieldTypeLabel } from '../modules/custom/labels';

const ACCENT_NAMES: Record<Accent, [string, string]> = {
  teal: ['سبزآبی', 'Teal'],
  blue: ['آبی', 'Blue'],
  indigo: ['نیلی', 'Indigo'],
  violet: ['بنفش', 'Violet'],
  pink: ['صورتی', 'Pink'],
  red: ['قرمز', 'Red'],
  orange: ['نارنجی', 'Orange'],
  amber: ['کهربایی', 'Amber'],
  green: ['سبز', 'Green'],
  slate: ['خاکستری', 'Slate'],
};

export function AccentPicker({ value, onChange, label }: { value: Accent; onChange: (a: Accent) => void; label: string }) {
  const { t } = useApp();
  return (
    <div className="swatches" role="radiogroup" aria-label={label}>
      {ACCENTS.map((a) => (
        <button
          key={a}
          type="button"
          role="radio"
          aria-checked={value === a}
          aria-label={t(...(ACCENT_NAMES[a] ?? [a, a]))}
          title={t(...(ACCENT_NAMES[a] ?? [a, a]))}
          className={`swatch${value === a ? ' is-on' : ''}`}
          data-accent={a}
          onClick={() => onChange(a)}
        >
          <span />
        </button>
      ))}
    </div>
  );
}

export function AddModuleDialog() {
  const state = useStore(addModuleStore);
  const { t, locale } = useApp();
  const modules = useLiveQuery(() => db.modules.toArray(), []);
  const [type, setType] = useState<ModuleType | null>(null);
  const [title, setTitle] = useState('');
  const [accent, setAccent] = useState<Accent>('teal');
  const [lang, setLang] = useState<InputLanguage>(locale === 'fa' ? 'fa-IR' : 'en-US');
  const [template, setTemplate] = useState<(typeof CUSTOM_TEMPLATES)[number]['id']>('blank');
  const [placement, setPlacement] = useState<'show' | 'hidden' | 'replace'>('show');
  const [replaceId, setReplaceId] = useState('');
  const [busy, setBusy] = useState(false);
  const live = (modules ?? []).filter((m) => m.active === 1 && !m.archivedAt);
  const full = live.length >= LIMITS.maxActiveModules;
  const totalFull = (modules ?? []).length >= LIMITS.maxTotalModules;

  useEffect(() => {
    if (!state.open) return;
    const preset = state.presetType && (MODULE_TYPES as readonly string[]).includes(state.presetType) ? (state.presetType as ModuleType) : null;
    setType(preset);
    setLang(locale === 'fa' ? 'fa-IR' : 'en-US');
    setReplaceId('');
  }, [state.open, state.presetType, locale]);

  useEffect(() => {
    if (!type) return;
    setTitle(MODULE_TEXT[type].name[locale === 'fa' ? 0 : 1]);
    setAccent(defaultAppearanceFor(type).accent);
    setTemplate('blank');
  }, [type, locale]);

  useEffect(() => {
    setPlacement(full ? 'hidden' : 'show');
  }, [full, state.open]);

  const close = () => addModuleStore.set({ open: false });
  const Next = locale === 'fa' ? ArrowLeft : ArrowRight;
  const Back = locale === 'fa' ? ArrowRight : ArrowLeft;

  const create = async () => {
    if (!type) return;
    setBusy(true);
    try {
      const tpl = CUSTOM_TEMPLATES.find((x) => x.id === template)!;
      const config =
        type === 'custom'
          ? { fields: tpl.fields.map((f, i) => ({ id: `f${i + 1}`, label: f.label[locale === 'fa' ? 0 : 1], type: f.type })), layout: 'cards' }
          : undefined;
      const active = placement === 'show';
      const mod = await createModule({ type, title: title.trim() || MODULE_TEXT[type].name[0], active, inputLanguage: lang, appearance: { accent }, config, locale });
      if (placement === 'replace' && replaceId) await replaceActive(mod.id, replaceId);
      toast({
        kind: 'success',
        text: placement === 'hidden' ? t('«{n}» ساخته شد و پنهان است؛ از «بخش‌ها» نمایشش دهید.', '“{n}” was created hidden; show it from “Sections”.', { n: mod.title }) : t('«{n}» به داشبورد اضافه شد.', '“{n}” was added to the dashboard.', { n: mod.title }),
        action: { label: t('باز کردن', 'Open'), run: () => navigate(moduleHref(mod.id)) },
      });
      close();
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  if (!state.open) return null;
  return (
    <Modal
      open
      onClose={close}
      size="lg"
      title={type ? t('بخش جدید: {n}', 'New section: {n}', { n: MODULE_TEXT[type].name[locale === 'fa' ? 0 : 1] }) : t('افزودن بخش', 'Add a section')}
      closeLabel={t('بستن', 'Close')}
      footer={
        type ? (
          <>
            <Button variant="ghost" icon={<Back size={15} />} onClick={() => setType(null)} className="me-auto">
              {t('انتخاب نوع دیگر', 'Pick another type')}
            </Button>
            <Button variant="ghost" onClick={close}>
              {t('انصراف', 'Cancel')}
            </Button>
            <Button variant="primary" busy={busy} disabled={totalFull || (placement === 'replace' && !replaceId)} onClick={() => void create()}>
              {t('ساخت بخش', 'Create section')}
            </Button>
          </>
        ) : undefined
      }
    >
      {!type ? (
        <div className="type-groups">
          {totalFull && (
            <Notice tone="warn" icon={<Info size={16} />}>
              {t('به سقف ۵۰ بخش رسیده‌اید؛ برای ساخت بخش جدید یکی را حذف کنید.', 'You have 50 sections; delete one to create another.')}
            </Notice>
          )}
          {GROUP_ORDER.map((g) => (
            <section key={g} className="type-group">
              <h3>{g === 'daily' ? t('روزمره', 'Everyday') : g === 'health' ? t('سلامت', 'Health') : g === 'media' ? t('رسانه', 'Media') : t('ابزار', 'Tools')}</h3>
              <div className="type-grid">
                {MODULE_TYPES.filter((ty) => CATALOG[ty].group === g).map((ty) => (
                  <button key={ty} type="button" className="type-card" data-accent={CATALOG[ty].accent} onClick={() => setType(ty)}>
                    <span className="mod-icon">
                      <ModuleIcon icon={CATALOG[ty].icon} size={19} />
                    </span>
                    <span className="type-text">
                      <span className="type-name">{MODULE_TEXT[ty].name[locale === 'fa' ? 0 : 1]}</span>
                      <span className="type-desc">{MODULE_TEXT[ty].desc[locale === 'fa' ? 0 : 1]}</span>
                    </span>
                    <Next size={16} className="type-go" aria-hidden="true" />
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>
      ) : (
        <div className="form-grid" data-accent={accent}>
          <Field label={t('عنوان بخش', 'Section title')} hint={t('می‌توانید چند نمونه از یک نوع بسازید؛ مثلاً «موسیقی کار» و «موسیقی ورزش».', 'You can make several of one type, e.g. “Work music” and “Workout music”.')}>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={60} autoFocus />
          </Field>
          {type === 'custom' && (
            <Field label={t('شروع از قالب', 'Start from a template')}>
              <Select value={template} onChange={(e) => setTemplate(e.target.value as typeof template)}>
                {CUSTOM_TEMPLATES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.id === 'blank' ? t('خالی', 'Blank') : c.id === 'books' ? t('کتاب‌ها', 'Books') : c.id === 'contacts' ? t('مخاطبان مهم', 'Key contacts') : c.id === 'car' ? t('سرویس خودرو', 'Car service') : t('ایده‌ها', 'Ideas')}
                  </option>
                ))}
              </Select>
              <div className="chips-row">
                {CUSTOM_TEMPLATES.find((c) => c.id === template)!.fields.map((f) => (
                  <span key={f.label[0]} className="chip">
                    {f.label[locale === 'fa' ? 0 : 1]} · {fieldTypeLabel(f.type, t)}
                  </span>
                ))}
              </div>
            </Field>
          )}
          <Field label={t('رنگ', 'Colour')}>
            <AccentPicker value={accent} onChange={setAccent} label={t('رنگ', 'Colour')} />
          </Field>
          <Field label={t('زبان ورودی صوتی این بخش', 'Voice input language for this section')}>
            <Segmented label={t('زبان صوت', 'Voice language')} value={lang} onChange={setLang} options={[{ value: 'fa-IR', label: 'فارسی' }, { value: 'en-US', label: 'English' }]} />
          </Field>
          {full ? (
            <Notice tone="warn" icon={<Info size={16} />} title={t('۱۰ بخش فعال دارید', 'You have 10 active sections')}>
              <div className="stack-sm">
                <Segmented
                  label={t('جایگاه', 'Placement')}
                  value={placement === 'show' ? 'hidden' : placement}
                  onChange={(v) => setPlacement(v)}
                  options={[
                    { value: 'hidden', label: t('ساخت به‌صورت پنهان', 'Create hidden') },
                    { value: 'replace', label: t('جایگزین یک بخش فعال', 'Replace an active one') },
                  ]}
                  size="sm"
                />
                {placement === 'replace' && (
                  <Select value={replaceId} onChange={(e) => setReplaceId(e.target.value)} aria-label={t('بخشی که پنهان شود', 'Section to hide')}>
                    <option value="">{t('انتخاب بخشی که پنهان شود…', 'Choose a section to hide…')}</option>
                    {live.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.title}
                      </option>
                    ))}
                  </Select>
                )}
              </div>
            </Notice>
          ) : (
            <Segmented
              label={t('جایگاه', 'Placement')}
              value={placement === 'replace' ? 'show' : placement}
              onChange={(v) => setPlacement(v)}
              options={[
                { value: 'show', label: t('نمایش در داشبورد', 'Show on dashboard') },
                { value: 'hidden', label: t('فعلاً پنهان', 'Keep hidden') },
              ]}
            />
          )}
          <p className="subtle xsmall">{t('ظاهر کامل (آیکن، قالب کارت، اندازه و تراکم) را بعداً از «تنظیمات و ظاهر» هر بخش تغییر دهید.', 'Change the full look (icon, card style, size, density) later from each section’s “Settings & look”.')}</p>
        </div>
      )}
    </Modal>
  );
}
