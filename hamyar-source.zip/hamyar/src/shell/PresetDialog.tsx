import { useEffect, useState } from 'react';
import { useApp } from './AppContext';
import { useStore } from '../lib/store';
import { presetDialogStore } from './settingsStore';
import { CATALOG, PRESETS, type PresetDef } from '../domain/catalog';
import { applyPreset, planPreset, type PresetPlan } from '../data/modules';
import { MODULE_TEXT } from '../modules/registry';
import { Button, Modal, Notice, Segmented, Spinner } from '../ui/primitives';
import { ModuleIcon } from '../ui/Icon';
import { Info } from '../ui/icons';
import { toast } from '../lib/ui-store';
import { errorText } from '../i18n/errors';
import { LIMITS } from '../config/limits';

export function presetName(id: PresetDef['id'], t: (fa: string, en: string) => string): string {
  return id === 'starter' ? t('شروع پیشنهادی', 'Suggested start') : id === 'daily' ? t('روزمره', 'Everyday') : id === 'study' ? t('مطالعه', 'Study') : t('سلامت شخصی', 'Personal health');
}

export function presetDesc(id: PresetDef['id'], t: (fa: string, en: string) => string): string {
  return id === 'starter'
    ? t('کارها، یادداشت، موسیقی، PDF و تمرکز', 'Tasks, notes, music, PDF and focus')
    : id === 'daily'
      ? t('برنامه روز، تقویم، خرید، هوا و هزینه‌ها', 'Your day, calendar, shopping, weather and spending')
      : id === 'study'
        ? t('PDF و خلاصه، یادداشت، تمرکز و صوت به متن', 'PDFs and summaries, notes, focus and transcription')
        : t('داروها، عادت‌ها و آب، کارها و تمرکز', 'Medications, habits and water, tasks and focus');
}

export function PresetDialog() {
  const open = useStore(presetDialogStore);
  const { t, locale } = useApp();
  const [preset, setPreset] = useState<PresetDef['id']>('starter');
  const [mode, setMode] = useState<'add' | 'switch'>('add');
  const [plan, setPlan] = useState<PresetPlan | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    let alive = true;
    setPlan(null);
    setErr(null);
    planPreset(preset, mode)
      .then((p) => alive && setPlan(p))
      .catch((e) => alive && setErr(errorText(e, t)));
    return () => {
      alive = false;
    };
  }, [open, preset, mode, t]);

  if (!open) return null;
  const close = () => presetDialogStore.set(false);
  const name = (type: keyof typeof MODULE_TEXT) => MODULE_TEXT[type].name[locale === 'fa' ? 0 : 1];

  return (
    <Modal
      open
      onClose={close}
      size="lg"
      title={t('قالب‌های آماده', 'Ready-made layouts')}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          <Button variant="ghost" onClick={close}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button
            variant="primary"
            busy={busy}
            disabled={!plan}
            onClick={async () => {
              if (!plan) return;
              setBusy(true);
              try {
                await applyPreset(plan, name, locale === 'fa' ? 'fa-IR' : 'en-US', locale);
                toast({ kind: 'success', text: t('قالب «{n}» اعمال شد. هیچ داده‌ای حذف نشد.', 'Applied “{n}”. No data was deleted.', { n: presetName(preset, t) }) });
                close();
              } catch (e) {
                toast({ kind: 'error', text: errorText(e, t) });
              } finally {
                setBusy(false);
              }
            }}
          >
            {t('اعمال قالب', 'Apply layout')}
          </Button>
        </>
      }
    >
      <div className="stack">
        <div className="preset-grid" role="radiogroup" aria-label={t('قالب', 'Layout')}>
          {PRESETS.map((p) => (
            <button key={p.id} type="button" role="radio" aria-checked={preset === p.id} className={`preset-card${preset === p.id ? ' is-on' : ''}`} onClick={() => setPreset(p.id)}>
              <span className="preset-name">{presetName(p.id, t)}</span>
              <span className="preset-desc">{presetDesc(p.id, t)}</span>
              <span className="preset-icons" aria-hidden="true">
                {p.types.map((ty) => (
                  <span key={ty} className="mod-icon is-sm" data-accent={CATALOG[ty].accent}>
                    <ModuleIcon icon={CATALOG[ty].icon} size={13} />
                  </span>
                ))}
              </span>
            </button>
          ))}
        </div>
        <Segmented
          label={t('روش اعمال', 'How to apply')}
          value={mode}
          onChange={setMode}
          options={[
            { value: 'add', label: t('افزودن به داشبورد فعلی', 'Add to current dashboard') },
            { value: 'switch', label: t('جایگزینی داشبورد', 'Switch dashboard') },
          ]}
        />
        {err && <Notice tone="danger">{err}</Notice>}
        {!plan && !err && <Spinner />}
        {plan && (
          <div className="plan">
            <h3>{t('پیش‌نمایش تغییرات', 'What will happen')}</h3>
            <ul className="plan-list">
              {plan.create.map((c, i) => (
                <li key={`c${i}`}>
                  <span className="plan-tag is-new">{t('جدید', 'New')}</span> {name(c.type)} {!c.active && <span className="subtle">({t('پنهان، به دلیل سقف ۱۰', 'hidden — 10 limit')})</span>}
                </li>
              ))}
              {plan.activate.map((m) => (
                <li key={m.id}>
                  <span className="plan-tag is-show">{t('نمایش', 'Show')}</span> {m.title}
                </li>
              ))}
              {plan.deactivate.map((m) => (
                <li key={m.id}>
                  <span className="plan-tag is-hide">{t('پنهان', 'Hide')}</span> {m.title} <span className="subtle">({t('داده حفظ می‌شود', 'data kept')})</span>
                </li>
              ))}
              {plan.skipped.map((m) => (
                <li key={m.id}>
                  <span className="plan-tag">{t('بدون تغییر', 'Unchanged')}</span> {m.title} <span className="subtle">({t('پنهان می‌ماند — سقف ۱۰', 'stays hidden — 10 limit')})</span>
                </li>
              ))}
              {!plan.create.length && !plan.activate.length && !plan.deactivate.length && <li className="subtle">{t('همه بخش‌های این قالب از قبل در داشبورد هستند.', 'All of this layout’s sections are already on the dashboard.')}</li>}
            </ul>
            <p className="subtle small">{t('بعد از اعمال: {n} از {max} بخش فعال.', 'After applying: {n} of {max} active.', { n: plan.activeAfter, max: LIMITS.maxActiveModules })}</p>
            <Notice tone="neutral" icon={<Info size={16} />}>
              {t('اعمال قالب هیچ داده‌ای را حذف نمی‌کند؛ بخش‌های کنار گذاشته‌شده فقط پنهان می‌شوند.', 'Applying a layout never deletes data; sections left out are only hidden.')}
            </Notice>
          </div>
        )}
      </div>
    </Modal>
  );
}
