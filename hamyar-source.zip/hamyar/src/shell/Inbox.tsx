import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso } from '../data/db';
import { useApp } from './AppContext';
import { Button, Chip, EmptyState, Notice, Spinner, Tabs } from '../ui/primitives';
import { AlarmClock, BellRing, Check, CheckCheck, Eraser, Inbox as InboxIcon, Info, Pill, CalendarClock } from '../ui/icons';
import { reminderUrl, snoozeReminder } from '../lib/reminders';
import { todayISO, localTimeHHMM } from '../domain/time';
import { toast } from '../lib/ui-store';
import type { ReminderRecord } from '../domain/types';

export function Inbox() {
  const { t, relDay, time, tz, bidi } = useApp();
  const items = useLiveQuery(async () => (await db.reminders.orderBy('dueAt').reverse().limit(300).toArray()) as ReminderRecord[], []);
  const [tab, setTab] = useState<'all' | 'unread' | 'late'>('all');
  if (!items)
    return (
      <div className="page-loading">
        <Spinner />
      </div>
    );
  const unread = items.filter((r) => !r.readAt);
  const late = items.filter((r) => r.late);
  const list = tab === 'unread' ? unread : tab === 'late' ? late : items;
  const markAll = async () => {
    const ts = nowIso();
    await db.transaction('rw', db.reminders, async () => {
      for (const r of unread) await db.reminders.update(r.id, { readAt: ts });
    });
  };
  const clearRead = async () => {
    const ids = items.filter((r) => r.readAt && !r.snoozedUntil).map((r) => r.id);
    await db.reminders.bulkDelete(ids);
    toast({ kind: 'success', text: t('یادآوری‌های خوانده‌شده پاک شد.', 'Read reminders cleared.') });
  };
  return (
    <div className="inbox">
      <header className="page-head is-plain">
        <div className="page-title-wrap">
          <h1 className="page-title">{t('یادآوری‌ها', 'Reminders')}</h1>
          <div className="page-sub">{t('{n} خوانده‌نشده', '{n} unread', { n: unread.length })}</div>
        </div>
        <div className="page-actions">
          <Button variant="soft" icon={<CheckCheck size={16} />} disabled={!unread.length} onClick={() => void markAll()}>
            {t('همه خوانده شد', 'Mark all read')}
          </Button>
          <Button variant="ghost" icon={<Eraser size={16} />} disabled={!items.some((r) => r.readAt)} onClick={() => void clearRead()}>
            {t('پاک کردن خوانده‌شده‌ها', 'Clear read')}
          </Button>
        </div>
      </header>
      <Notice tone="neutral" icon={<Info size={16} />}>
        {t(
          'در این نسخه یادآوری‌ها وقتی همیار در مرورگر باز است (حتی در تب پس‌زمینه) اجرا می‌شوند. یادآوری‌هایی که در زمان بسته بودن برنامه سررسید شده‌اند، هنگام بازگشت اینجا می‌آیند؛ اگر بیش از ۶۰ دقیقه گذشته باشد، اعلان سیستمی نمی‌گیرند. ارسال اعلان به سیستم به معنی دیده‌شدن آن نیست.',
          'In this version reminders run while Hamyar is open in the browser (a background tab is fine). Reminders that fell due while it was closed appear here when you return; if more than 60 minutes late, they get no system notification. Handing a notification to the OS does not mean it was seen.',
        )}
      </Notice>
      <Tabs
        label={t('فیلتر یادآوری‌ها', 'Reminder filter')}
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'all', label: t('همه', 'All'), count: items.length },
          { value: 'unread', label: t('خوانده‌نشده', 'Unread'), count: unread.length },
          { value: 'late', label: t('دیرهنگام', 'Late'), count: late.length },
        ]}
      />
      {list.length === 0 ? (
        <EmptyState icon={<InboxIcon size={24} />} title={t('یادآوری‌ای اینجا نیست', 'No reminders here')} text={t('یادآوری کارها و داروها پس از رسیدن زمانشان اینجا ثبت می‌شوند.', 'Task and medication reminders are listed here once they are due.')} />
      ) : (
        <ul className="inbox-list">
          {list.map((r) => {
            const day = todayISO(tz, r.dueAt);
            const Icon = r.kind === 'medication' ? Pill : r.kind === 'task' ? CalendarClock : BellRing;
            const open = () => {
              void db.reminders.update(r.id, { readAt: r.readAt ?? nowIso() });
              window.location.hash = reminderUrl(r);
            };
            return (
              <li key={r.id} className={`inbox-item${r.readAt ? ' is-read' : ''}`}>
                <span className="inbox-icon" aria-hidden="true">
                  <Icon size={18} />
                </span>
                <div className="inbox-main">
                  <button type="button" className="inbox-title auto-dir" dir={bidi(r.title)} onClick={open}>
                    {r.title}
                  </button>
                  <div className="row-meta">
                    <span>
                      {relDay(day)} · <span className="num">{time(localTimeHHMM(r.dueAt, tz))}</span>
                    </span>
                    <span className="auto-dir" dir={bidi(r.body)}>
                      {r.body}
                    </span>
                    {r.followUpOf && <Chip>{t('پیرو تعویق', 'Snoozed follow-up')}</Chip>}
                    {r.late ? (
                      <Chip tone="warn">{t('دیرتر از ۶۰ دقیقه — بدون اعلان', 'Over 60 min late — not pushed')}</Chip>
                    ) : r.delivery === 'system' ? (
                      <Chip tone="info">{t('اعلان سیستم ارسال شد', 'Handed to the OS')}</Chip>
                    ) : (
                      <Chip>{t('داخل برنامه', 'In app')}</Chip>
                    )}
                    {r.snoozedUntil && r.snoozedUntil > Date.now() && <Chip tone="accent">{t('تعویق تا {t}', 'Snoozed until {t}', { t: time(localTimeHHMM(r.snoozedUntil, tz)) })}</Chip>}
                  </div>
                </div>
                <div className="inbox-actions">
                  {!r.late && !r.followUpOf && (!r.snoozedUntil || r.snoozedUntil < Date.now()) && (
                    <>
                      <Button size="sm" variant="ghost" icon={<AlarmClock size={14} />} onClick={() => void snoozeReminder(r.id, 10).then(() => toast({ kind: 'success', text: t('۱۰ دقیقه دیگر دوباره یادآوری می‌شود.', 'You’ll be reminded again in 10 minutes.') }))}>
                        {t('۱۰ دقیقه', '10 min')}
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => void snoozeReminder(r.id, 30).then(() => toast({ kind: 'success', text: t('۳۰ دقیقه دیگر دوباره یادآوری می‌شود.', 'You’ll be reminded again in 30 minutes.') }))}>
                        {t('۳۰ دقیقه', '30 min')}
                      </Button>
                    </>
                  )}
                  {!r.readAt && (
                    <Button size="sm" variant="soft" icon={<Check size={14} />} onClick={() => void db.reminders.update(r.id, { readAt: nowIso() })}>
                      {t('خوانده شد', 'Read')}
                    </Button>
                  )}
                  <Button size="sm" variant="outline" onClick={open}>
                    {r.kind === 'medication' ? t('رفتن به نوبت', 'Go to dose') : t('باز کردن', 'Open')}
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <p className="subtle xsmall">{t('تعویق فقط اعلان را عقب می‌اندازد؛ ساعت کار یا نوبت دارو تغییر نمی‌کند و نوبت جدیدی ساخته نمی‌شود.', 'Snoozing only delays the notification; it never changes the task time or the dose and never creates a new dose.')}</p>
    </div>
  );
}
