import { useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../data/db';
import { useApp } from './AppContext';
import type { ModuleInstance } from '../domain/types';
import { buildTaskViews } from '../modules/tasks/data';
import { listDoses } from '../modules/medications/data';
import { remainingMs } from '../modules/focus/data';
import { CalendarClock, Inbox, Pill, Timer, Sparkles } from '../ui/icons';
import { moduleHref } from './router';

/** "Today" overview — infrastructure, not one of the 10 sections. */
export function TodayStrip({ modules }: { modules: ModuleInstance[] }) {
  const { t, today, now, time, relDay, duration, num, bidi } = useApp();
  const tasks = useLiveQuery(() => db.tasks.toArray(), []);
  const completions = useLiveQuery(() => db.taskCompletions.toArray(), []);
  const meds = useLiveQuery(() => db.medications.toArray(), []);
  const events = useLiveQuery(() => db.medEvents.toArray(), []);
  const unread = useLiveQuery(async () => (await db.reminders.toArray()).filter((r) => !r.readAt).length, [], 0);
  const focus = useLiveQuery(() => db.focus.toArray(), []);
  const allMods = useLiveQuery(() => db.modules.toArray(), []);

  const data = useMemo(() => {
    const archived = new Set((allMods ?? []).filter((m) => m.archivedAt).map((m) => m.id));
    const views = buildTaskViews((tasks ?? []).filter((x) => !archived.has(x.moduleId)), completions ?? [], { today, now }, 2);
    const openToday = views.today.filter((x) => !x.done);
    const next = [...views.today, ...views.upcoming].filter((x) => !x.done && x.occ?.at && x.occ.at >= now).sort((a, b) => a.occ!.at! - b.occ!.at!)[0] ?? null;
    const doses = listDoses((meds ?? []).filter((m) => !archived.has(m.moduleId)), events ?? [], today, today);
    const pending = doses.filter((d) => d.state === 'pending');
    const nextDose = pending.find((d) => d.occ.at! >= now) ?? null;
    const running = (focus ?? []).find((f) => f.status === 'running' && f.endAt);
    return { openToday, next, overdue: views.overdue.length, pending, nextDose, running };
  }, [tasks, completions, meds, events, focus, allMods, today, now]);

  const tiles: React.ReactNode[] = [];
  const taskMod = modules.find((m) => m.type === 'tasks');
  if (tasks && tasks.length) {
    tiles.push(
      <a key="task" className="today-tile" href={data.next ? moduleHref(data.next.task.moduleId) : taskMod ? moduleHref(taskMod.id) : '#/'} data-accent="teal">
        <span className="today-icon">
          <CalendarClock size={18} aria-hidden="true" />
        </span>
        <span className="today-text">
          <span className="today-label">{t('بعدی', 'Next up')}</span>
          <span className="today-value auto-dir" dir={bidi(data.next?.task.title)}>
            {data.next ? data.next.task.title : t('کار زمان‌داری نمانده', 'No timed tasks left')}
          </span>
          <span className="today-sub">
            {data.next?.occ?.time ? `${data.next.occ.date === today ? '' : `${relDay(data.next.occ.date)} · `}${time(data.next.occ.time)}` : ''}
            {data.openToday.length > 0 && ` · ${t('{n} کار امروز', '{n} today', { n: data.openToday.length })}`}
            {data.overdue > 0 && ` · ${t('{n} عقب‌افتاده', '{n} overdue', { n: data.overdue })}`}
          </span>
        </span>
      </a>,
    );
  }
  if (meds && meds.some((m) => m.active)) {
    const medMod = modules.find((m) => m.type === 'medications');
    tiles.push(
      <a key="med" className="today-tile" href={data.nextDose ? moduleHref(data.nextDose.med.moduleId) : medMod ? moduleHref(medMod.id) : '#/'} data-accent="pink">
        <span className="today-icon">
          <Pill size={18} aria-hidden="true" />
        </span>
        <span className="today-text">
          <span className="today-label">{t('داروها', 'Medications')}</span>
          <span className="today-value">{data.nextDose ? t('نوبت بعدی {t}', 'Next dose {t}', { t: time(data.nextDose.occ.time!) }) : data.pending.length ? t('نوبت ثبت‌نشده دارید', 'Unrecorded dose') : t('نوبت‌های امروز ثبت شده', 'Today’s doses recorded')}</span>
          <span className="today-sub">{t('{n} نوبت ثبت‌نشده امروز', '{n} unrecorded today', { n: data.pending.length })}</span>
        </span>
      </a>,
    );
  }
  if (data.running?.endAt) {
    tiles.push(
      <a key="focus" className="today-tile" href={moduleHref(data.running.id)} data-accent="orange">
        <span className="today-icon">
          <Timer size={18} aria-hidden="true" />
        </span>
        <span className="today-text">
          <span className="today-label">{data.running.phase === 'focus' ? t('تمرکز', 'Focus') : t('استراحت', 'Break')}</span>
          <span className="today-value num">{duration(Math.ceil(remainingMs(data.running, 25, now) / 1000))}</span>
          <span className="today-sub">{t('در حال اجرا', 'Running')}</span>
        </span>
      </a>,
    );
  }
  tiles.push(
    <a key="inbox" className="today-tile" href="#/inbox" data-accent="indigo">
      <span className="today-icon">
        <Inbox size={18} aria-hidden="true" />
      </span>
      <span className="today-text">
        <span className="today-label">{t('یادآوری‌ها', 'Reminders')}</span>
        <span className="today-value">{unread ? t('{n} خوانده‌نشده', '{n} unread', { n: num(unread) }) : t('همه خوانده شده', 'All caught up')}</span>
        <span className="today-sub">{t('صندوق یادآوری', 'Reminder inbox')}</span>
      </span>
    </a>,
  );
  if (tiles.length === 1) {
    tiles.unshift(
      <div key="tip" className="today-tile is-tip" data-accent="violet">
        <span className="today-icon">
          <Sparkles size={18} aria-hidden="true" />
        </span>
        <span className="today-text">
          <span className="today-label">{t('نکته', 'Tip')}</span>
          <span className="today-value">{t('میکروفن هر بخش، فرمان همان بخش را می‌فهمد.', 'Each section’s microphone understands that section’s commands.')}</span>
          <span className="today-sub">{t('مثلاً در کارها: «فردا ساعت ۹ صبح جلسه»', 'e.g. in Tasks: “tomorrow at 9am meeting”')}</span>
        </span>
      </div>,
    );
  }
  return (
    <div className="today-strip" role="region" aria-label={t('نمای امروز', 'Today overview')}>
      {tiles}
    </div>
  );
}
