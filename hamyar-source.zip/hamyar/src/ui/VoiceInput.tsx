import { useEffect, useId, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';
import { Mic, Square, X, SendHorizontal, Wand2Icon } from './icons';
import { useApp } from '../shell/AppContext';
import { abortMic, micEngineAvailable, micStore, startDictation, stopMic, type MicErrorCode } from '../lib/mic';
import { useStore } from '../lib/store';
import type { InputLanguage, VoiceMode } from '../domain/types';
import { db, nowIso } from '../data/db';
import { Button, IconButton, Modal } from './primitives';
import { IS_ARTIFACT, IS_NATIVE, isIos } from '../lib/platform';

export function micErrorText(code: MicErrorCode, t: (fa: string, en: string) => string): string {
  switch (code) {
    case 'unsupported':
      if (IS_NATIVE)
        return t(
          'این گوشی سرویس تشخیص گفتار ندارد. برنامه Google را نصب یا به‌روز کنید، یا از میکروفن صفحه‌کلید استفاده کنید.',
          'This phone has no speech recognition service. Install or update the Google app, or use the keyboard microphone.',
        );
      if (isIos())
        return t('در این حالت آیفون، از دکمه میکروفن صفحه‌کلید برای گفتن متن استفاده کنید.', 'On this iPhone view, use the keyboard’s microphone button to dictate.');
      return t(
        'این مرورگر تبدیل گفتار به متن ندارد. متن را تایپ کنید یا از Chrome یا Edge استفاده کنید.',
        'This browser has no speech recognition. Type instead, or use Chrome or Edge.',
      );
    case 'denied':
      if (IS_NATIVE)
        return t('اجازه میکروفن داده نشد. در تنظیمات گوشی ← برنامه‌ها ← همیار ← مجوزها، میکروفن را روشن کنید.', 'Microphone permission was denied. Turn it on in phone Settings → Apps → Hamyar → Permissions.');
      return IS_ARTIFACT
        ? t('در پیش‌نمایش claude.ai میکروفن در دسترس نیست. نسخه قابل اجرا را روی کامپیوتر خود باز کنید.', 'The microphone is not available in the claude.ai preview. Run the app on your computer.')
        : t('اجازه میکروفن داده نشده است. از نماد قفل کنار نشانی سایت، میکروفن را مجاز کنید.', 'Microphone permission was denied. Allow it from the lock icon next to the address.');
    case 'no-speech':
      return t('صدایی شنیده نشد. دوباره امتحان کنید.', 'No speech was heard. Try again.');
    case 'network':
      return IS_NATIVE
        ? t('سرویس گفتار گوگل در دسترس نیست. اینترنت را بررسی کنید یا بسته زبان فارسی آفلاین را در تنظیمات گفتار Google نصب کنید.', 'Google speech service is unreachable. Check the internet, or install the offline Persian pack in Google speech settings.')
        : t('سرویس تشخیص گفتار مرورگر در دسترس نیست (اینترنت لازم است).', 'The browser speech service is unreachable (internet required).');
    case 'language':
      return t('این زبان در موتور گفتار این مرورگر پشتیبانی نمی‌شود.', 'This language is not supported by this browser’s speech engine.');
    case 'audio':
      return t('میکروفنی پیدا نشد یا در دسترس نیست.', 'No microphone was found or it is in use.');
    case 'stt-unavailable':
      return t('تبدیل صوت به متن روی سرور تنظیم نشده است. متن را تایپ کنید.', 'Server speech-to-text is not set up. Type instead.');
    case 'stt-failed':
      return t('تبدیل صوت به متن انجام نشد. متن شما حفظ شده است؛ دوباره تلاش کنید.', 'Transcription failed. Your text is kept; try again.');
    case 'too-long':
      return t('زمان ضبط از سقف مجاز گذشت.', 'Recording exceeded the limit.');
    default:
      return t('ورودی صوتی کار نکرد. دوباره تلاش کنید.', 'Voice input failed. Try again.');
  }
}

/** Shows the one-time explanation before the first voice use, then calls `go`. */
export function useSpeechConsent() {
  const [pending, setPending] = useState<null | (() => void)>(null);
  const ensure = async (go: () => void) => {
    const c = await db.consents.get('speech:browser');
    if (c) go();
    else setPending(() => go);
  };
  const accept = async () => {
    await db.consents.put({ id: 'speech:browser', feature: 'speech', provider: 'browser', grantedAt: nowIso(), version: 1 });
    const go = pending;
    setPending(null);
    go?.();
  };
  return { pending: !!pending, ensure, accept, cancel: () => setPending(null) };
}

export function SpeechConsentModal({ open, onAccept, onCancel }: { open: boolean; onAccept: () => void; onCancel: () => void }) {
  const { t } = useApp();
  return (
    <Modal
      open={open}
      onClose={onCancel}
      title={t('پیش از اولین استفاده از میکروفن', 'Before you use the microphone')}
      closeLabel={t('بستن', 'Close')}
      size="sm"
      footer={
        <>
          <Button variant="ghost" onClick={onCancel}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="primary" onClick={onAccept} icon={<Mic size={16} />}>
            {t('متوجه شدم، شروع', 'Got it, start')}
          </Button>
        </>
      }
    >
      <div className="stack-sm">
        <p>{t('میکروفن فقط وقتی روشن می‌شود که دکمه آن را بزنید و با «توقف» یا «لغو» خاموش می‌شود.', 'The microphone turns on only when you press it, and stops on “Stop” or “Cancel”.')}</p>
        <p className="muted small">
          {IS_NATIVE
            ? t(
                'تبدیل گفتار به متن با سرویس گفتار خود گوشی (معمولاً Google) انجام می‌شود و ممکن است صدا برای پردازش به آن سرویس فرستاده شود. همیار صدای شما را ذخیره نمی‌کند. متن پیش از ثبت قابل ویرایش است.',
                'Speech is converted by the phone’s own speech service (usually Google), which may send audio to that service. Hamyar does not store your voice. You can edit the text before anything is saved.',
              )
            : t(
                'تبدیل گفتار به متن با موتور خود مرورگر انجام می‌شود و بعضی مرورگرها (مثل Chrome) صدا را برای پردازش به سرور سازنده‌شان می‌فرستند. همیار صدای شما را ذخیره نمی‌کند. متن پیش از ثبت قابل ویرایش است.',
                'Speech is converted by the browser’s own engine; some browsers (such as Chrome) send audio to their maker’s servers. Hamyar does not store your voice. You can edit the text before anything is saved.',
              )}
        </p>
      </div>
    </Modal>
  );
}

export interface VoiceInputProps {
  value: string;
  onChange: (v: string) => void;
  lang: InputLanguage;
  ownerId: string;
  placeholder?: string;
  multiline?: boolean;
  rows?: number;
  /** command mode support: show the dictation/command toggle */
  mode?: VoiceMode;
  onModeChange?: (m: VoiceMode) => void;
  /** called with the transcript when in command mode */
  onCommand?: (text: string) => void;
  /** Enter / send button */
  onSubmit?: (text: string) => void;
  submitLabel?: string;
  submitIcon?: ReactNode;
  disabled?: boolean;
  inputLabel: string;
  id?: string;
  maxLength?: number;
  continuous?: boolean;
  examples?: string[];
}

export function VoiceInput(props: VoiceInputProps) {
  const { t, dig, bidi } = useApp();
  const mic = useStore(micStore);
  const [error, setError] = useState<string | null>(null);
  const autoId = useId();
  const id = props.id ?? autoId;
  const inputRef = useRef<HTMLInputElement & HTMLTextAreaElement>(null);
  const listening = mic?.ownerId === props.ownerId;
  const consent = useSpeechConsent();
  const engine = micEngineAvailable();
  const [elapsed, setElapsed] = useState(0);
  const valueRef = useRef(props.value);
  valueRef.current = props.value;

  useEffect(() => {
    if (!listening) return;
    const timer = window.setInterval(() => setElapsed(Math.floor((Date.now() - (micStore.get()?.startedAt ?? Date.now())) / 1000)), 250);
    return () => window.clearInterval(timer);
  }, [listening]);

  // Leaving the section releases the microphone.
  useEffect(
    () => () => {
      if (micStore.get()?.ownerId === props.ownerId) abortMic();
    },
    [props.ownerId],
  );

  const begin = () => {
    setError(null);
    setElapsed(0);
    void startDictation({
      ownerId: props.ownerId,
      lang: props.lang,
      continuous: props.continuous ?? props.mode !== 'command',
      onResult: (text) => {
        if (props.mode === 'command' && props.onCommand) {
          props.onChange(text);
          props.onCommand(text);
        } else {
          const cur = valueRef.current;
          const next = cur && !/\s$/.test(cur) ? `${cur} ${text}` : `${cur}${text}`;
          props.onChange(props.maxLength ? next.slice(0, props.maxLength) : next);
          inputRef.current?.focus();
        }
      },
      onError: (code) => setError(micErrorText(code, t)),
    });
  };

  const toggle = () => {
    if (listening) {
      stopMic();
      return;
    }
    void consent.ensure(begin);
  };

  const onKey = (e: KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && !props.multiline && props.onSubmit) {
      e.preventDefault();
      if (props.value.trim()) props.onSubmit(props.value.trim());
    }
  };

  const langTag = props.lang === 'fa-IR' ? 'FA' : 'EN';
  const micLabel = listening
    ? t('توقف شنیدن', 'Stop listening')
    : props.mode === 'command'
      ? t('گفتن فرمان ({lang})', 'Speak a command ({lang})', { lang: langTag })
      : t('دیکته با صدا ({lang})', 'Dictate ({lang})', { lang: langTag });
  const Field = props.multiline ? 'textarea' : 'input';

  return (
    <div className={`vi${listening ? ' is-listening' : ''}${props.mode === 'command' ? ' is-command' : ''}`}>
      <div className="vi-row">
        <Field
          ref={inputRef}
          id={id}
          className={`input vi-input${props.multiline ? ' textarea' : ''}`}
          value={props.value}
          onChange={(e: React.ChangeEvent<HTMLInputElement & HTMLTextAreaElement>) => props.onChange(e.target.value)}
          onKeyDown={onKey}
          placeholder={props.placeholder}
          aria-label={props.inputLabel}
          dir={props.value ? bidi(props.value) : undefined}
          disabled={props.disabled}
          rows={props.multiline ? props.rows ?? 3 : undefined}
          maxLength={props.maxLength}
        />
        <div className="vi-actions">
          <IconButton
            label={micLabel}
            variant={listening ? 'danger' : 'soft'}
            onClick={toggle}
            disabled={props.disabled || (!engine && !listening)}
            className="mic-btn"
            pressed={listening}
            title={engine ? micLabel : micErrorText('unsupported', t)}
          >
            {listening ? <Square size={16} /> : <Mic size={18} />}
            <span className="mic-lang" aria-hidden="true">
              {langTag}
            </span>
          </IconButton>
          {props.onSubmit && (
            <IconButton
              label={props.submitLabel ?? t('افزودن', 'Add')}
              variant="accent"
              onClick={() => props.value.trim() && props.onSubmit?.(props.value.trim())}
              disabled={props.disabled || !props.value.trim()}
            >
              {props.submitIcon ?? <SendHorizontal size={17} className="flip-rtl" />}
            </IconButton>
          )}
        </div>
      </div>
      {props.onModeChange && (
        <div className="vi-mode" role="radiogroup" aria-label={t('حالت ورودی صوتی', 'Voice input mode')}>
          <button type="button" role="radio" aria-checked={props.mode !== 'command'} className={props.mode !== 'command' ? 'is-on' : ''} onClick={() => props.onModeChange?.('dictation')}>
            {t('دیکته', 'Dictation')}
          </button>
          <button type="button" role="radio" aria-checked={props.mode === 'command'} className={props.mode === 'command' ? 'is-on' : ''} onClick={() => props.onModeChange?.('command')}>
            <Wand2Icon size={13} /> {t('فرمان', 'Command')}
          </button>
          {props.mode === 'command' && props.examples?.length ? (
            <span className="vi-example" title={props.examples.join(' • ')}>
              {t('مثال:', 'e.g.')} «{props.examples[0]}»
            </span>
          ) : null}
        </div>
      )}
      {listening && mic && (
        <div className="listening" role="status" aria-live="polite">
          <div className="wave" aria-hidden="true" style={{ ['--lvl' as string]: String(mic.level || 0.35) }}>
            <span />
            <span />
            <span />
            <span />
            <span />
          </div>
          <div className="listening-text grow">
            <div className="listening-label">
              {mic.phase === 'processing' ? t('در حال تبدیل به متن…', 'Transcribing…') : t('در حال شنیدن', 'Listening')}{' '}
              <span className="num">{dig(`${Math.floor(elapsed / 60)}:${String(elapsed % 60).padStart(2, '0')}`)}</span>
            </div>
            <div className="listening-interim auto-dir" dir={bidi(mic.interim)}>
              {mic.interim || t('صحبت کنید…', 'Speak now…')}
            </div>
          </div>
          <Button size="sm" variant="accent" onClick={() => stopMic()} icon={<Square size={14} />}>
            {t('پایان', 'Done')}
          </Button>
          <IconButton label={t('لغو', 'Cancel')} size="sm" onClick={() => abortMic()}>
            <X size={16} />
          </IconButton>
        </div>
      )}
      {error && !listening && (
        <div className="vi-error" role="alert">
          {error}
        </div>
      )}
      <SpeechConsentModal open={consent.pending} onAccept={() => void consent.accept()} onCancel={consent.cancel} />
    </div>
  );
}
