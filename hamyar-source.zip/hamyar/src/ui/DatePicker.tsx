import { useMemo, useState } from 'react';
import { useApp } from '../shell/AppContext';
import { Button, IconButton, Modal } from './primitives';
import { CalendarDays, ChevronLeft, ChevronRight } from './icons';
import { GREGORIAN_MONTHS_EN, GREGORIAN_MONTHS_FA, JALALI_MONTHS_EN, JALALI_MONTHS_FA, WEEKDAYS_SHORT_EN, WEEKDAYS_SHORT_FA, isoToJalali, jalaliMonthDays, jalaliToISO } from '../domain/jalali';
import { addDaysISO, isoFromParts, parseISODate, weekdayOfISO } from '../domain/time';
import type { CalendarSystem } from '../domain/types';

export interface MonthCell {
  iso: string;
  day: number;
  inMonth: boolean;
}

export interface MonthModel {
  title: string;
  cells: MonthCell[];
  weekdayLabels: string[];
}

/** Builds a 6-row month grid for either calendar, starting the week on `weekStart` (0 = Sunday). */
export function buildMonth(cal: CalendarSystem, year: number, month: number, locale: 'fa' | 'en', weekStart: number, digits: (v: number) => string): MonthModel {
  let first: string;
  let days: number;
  let title: string;
  if (cal === 'jalali') {
    first = jalaliToISO(year, month, 1);
    days = jalaliMonthDays(year, month);
    title = `${(locale === 'fa' ? JALALI_MONTHS_FA : JALALI_MONTHS_EN)[month - 1]} ${digits(year)}`;
  } else {
    first = isoFromParts(year, month, 1);
    days = new Date(Date.UTC(year, month, 0)).getUTCDate();
    title = `${(locale === 'fa' ? GREGORIAN_MONTHS_FA : GREGORIAN_MONTHS_EN)[month - 1]} ${digits(year)}`;
  }
  const lead = (weekdayOfISO(first) - weekStart + 7) % 7;
  const start = addDaysISO(first, -lead);
  const cells: MonthCell[] = [];
  for (let i = 0; i < 42; i++) {
    const iso = addDaysISO(start, i);
    const inMonth = i >= lead && i < lead + days;
    const day = cal === 'jalali' ? isoToJalali(iso).jd : parseISODate(iso).d;
    cells.push({ iso, day, inMonth });
  }
  const short = locale === 'fa' ? WEEKDAYS_SHORT_FA : WEEKDAYS_SHORT_EN;
  const weekdayLabels = Array.from({ length: 7 }, (_, i) => short[(weekStart + i) % 7]!);
  return { title, cells: cells.slice(0, Math.ceil((lead + days) / 7) * 7), weekdayLabels };
}

export function monthOf(iso: string, cal: CalendarSystem): { y: number; m: number } {
  if (cal === 'jalali') {
    const j = isoToJalali(iso);
    return { y: j.jy, m: j.jm };
  }
  const p = parseISODate(iso);
  return { y: p.y, m: p.m };
}

export function shiftMonth(y: number, m: number, delta: number): { y: number; m: number } {
  const idx = y * 12 + (m - 1) + delta;
  return { y: Math.floor(idx / 12), m: (idx % 12) + 1 };
}

export function MonthGrid({
  value,
  onPick,
  cursor,
  setCursor,
  marks,
}: {
  value: string | null;
  onPick: (iso: string) => void;
  cursor: { y: number; m: number };
  setCursor: (c: { y: number; m: number }) => void;
  marks?: Set<string>;
}) {
  const { profile, locale, today, t, dig } = useApp();
  const weekStart = locale === 'fa' ? 6 : 0;
  const model = useMemo(() => buildMonth(profile.calendar, cursor.y, cursor.m, locale, weekStart, (v) => dig(v)), [profile.calendar, cursor, locale, weekStart, dig]);
  const Prev = locale === 'fa' ? ChevronRight : ChevronLeft;
  const Next = locale === 'fa' ? ChevronLeft : ChevronRight;
  return (
    <div className="month">
      <div className="month-head">
        <IconButton label={t('ماه قبل', 'Previous month')} size="sm" onClick={() => setCursor(shiftMonth(cursor.y, cursor.m, -1))}>
          <Prev size={18} />
        </IconButton>
        <div className="month-title">{model.title}</div>
        <IconButton label={t('ماه بعد', 'Next month')} size="sm" onClick={() => setCursor(shiftMonth(cursor.y, cursor.m, 1))}>
          <Next size={18} />
        </IconButton>
      </div>
      <div className="month-grid" role="grid">
        {model.weekdayLabels.map((w, i) => (
          <div key={`h${i}`} className="month-wd" role="columnheader">
            {w}
          </div>
        ))}
        {model.cells.map((c) => (
          <button
            key={c.iso}
            type="button"
            role="gridcell"
            className={`month-day${c.inMonth ? '' : ' is-out'}${c.iso === today ? ' is-today' : ''}${c.iso === value ? ' is-selected' : ''}${marks?.has(c.iso) ? ' has-mark' : ''}`}
            aria-selected={c.iso === value}
            aria-label={c.iso}
            onClick={() => onPick(c.iso)}
          >
            {dig(c.day)}
          </button>
        ))}
      </div>
    </div>
  );
}

export function DatePicker({
  value,
  onChange,
  label,
  allowClear,
  id,
  placeholder,
}: {
  value: string | null;
  onChange: (iso: string | null) => void;
  label: string;
  allowClear?: boolean;
  id?: string;
  placeholder?: string;
}) {
  const { t, date, today, profile } = useApp();
  const [open, setOpen] = useState(false);
  const [cursor, setCursor] = useState(() => monthOf(value ?? today, profile.calendar));
  const pick = (iso: string | null) => {
    onChange(iso);
    setOpen(false);
  };
  return (
    <>
      <button
        id={id}
        type="button"
        className="input date-btn"
        onClick={() => {
          setCursor(monthOf(value ?? today, profile.calendar));
          setOpen(true);
        }}
        aria-label={`${label}: ${value ? date(value, 'long') : placeholder ?? t('بدون تاریخ', 'No date')}`}
      >
        <CalendarDays size={16} aria-hidden="true" />
        <span className={value ? '' : 'subtle'}>{value ? date(value, 'long') : placeholder ?? t('بدون تاریخ', 'No date')}</span>
      </button>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={label}
        size="sm"
        closeLabel={t('بستن', 'Close')}
        footer={
          <>
            {allowClear && (
              <Button variant="ghost" onClick={() => pick(null)}>
                {t('بدون تاریخ', 'No date')}
              </Button>
            )}
            <Button variant="soft" onClick={() => pick(addDaysISO(today, 1))}>
              {t('فردا', 'Tomorrow')}
            </Button>
            <Button variant="primary" onClick={() => pick(today)}>
              {t('امروز', 'Today')}
            </Button>
          </>
        }
      >
        <MonthGrid value={value} onPick={(iso) => pick(iso)} cursor={cursor} setCursor={setCursor} />
      </Modal>
    </>
  );
}
