import { useRef, useState, type ReactNode } from 'react';
import { Upload } from './icons';

/** Drop zone plus a real file button (keyboard reachable). */
export function FileDrop({ accept, multiple, onFiles, title, hint, disabled }: { accept: string; multiple?: boolean; onFiles: (files: File[]) => void; title: ReactNode; hint?: ReactNode; disabled?: boolean }) {
  const input = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  return (
    <div
      className={`drop${over ? ' is-over' : ''}${disabled ? ' is-disabled' : ''}`}
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setOver(false);
        if (disabled) return;
        const files = Array.from(e.dataTransfer.files ?? []);
        if (files.length) onFiles(multiple ? files : files.slice(0, 1));
      }}
    >
      <button type="button" className="drop-btn" onClick={() => input.current?.click()} disabled={disabled}>
        <Upload size={20} aria-hidden="true" />
        <span className="drop-title">{title}</span>
        {hint && <span className="drop-hint">{hint}</span>}
      </button>
      <input
        ref={input}
        type="file"
        accept={accept}
        multiple={multiple}
        hidden
        onChange={(e) => {
          const files = Array.from(e.target.files ?? []);
          e.target.value = '';
          if (files.length) onFiles(files);
        }}
      />
    </div>
  );
}
