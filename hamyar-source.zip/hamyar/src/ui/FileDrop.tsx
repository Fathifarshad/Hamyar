import { useRef, useState, type ReactNode } from 'react';
import { Upload, Folder } from './icons';

export interface FileDropProps {
  accept: string;
  multiple?: boolean;
  allowFolder?: boolean;
  onFiles: (files: File[]) => void;
  title: ReactNode;
  hint?: ReactNode;
  disabled?: boolean;
  fileLabel?: string;
  folderLabel?: string;
}

/** Recursively extracts files from DataTransferItemList, traversing any dropped folders. */
async function extractFilesFromItems(items: DataTransferItemList): Promise<File[]> {
  const files: File[] = [];
  const entries: any[] = [];

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    if (item.kind === 'file') {
      const entry = (item as any).webkitGetAsEntry ? (item as any).webkitGetAsEntry() : null;
      if (entry) {
        entries.push(entry);
      } else {
        const f = item.getAsFile();
        if (f) files.push(f);
      }
    }
  }

  async function scanEntry(entry: any) {
    if (entry.isFile) {
      await new Promise<void>((resolve) => {
        entry.file(
          (file: File) => {
            files.push(file);
            resolve();
          },
          () => resolve(),
        );
      });
    } else if (entry.isDirectory) {
      const reader = entry.createReader();
      const readBatch = (): Promise<any[]> =>
        new Promise((resolve) => {
          reader.readEntries(
            (results: any[]) => resolve(results || []),
            () => resolve([]),
          );
        });

      let batch = await readBatch();
      while (batch.length > 0) {
        for (const child of batch) {
          await scanEntry(child);
        }
        batch = await readBatch();
      }
    }
  }

  for (const e of entries) {
    await scanEntry(e);
  }
  return files;
}

/** Drop zone plus file and folder selection buttons (keyboard reachable). */
export function FileDrop({
  accept,
  multiple,
  allowFolder,
  onFiles,
  title,
  hint,
  disabled,
  fileLabel,
  folderLabel,
}: FileDropProps) {
  const fileInput = useRef<HTMLInputElement>(null);
  const folderInput = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setOver(false);
    if (disabled) return;

    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      const extracted = await extractFilesFromItems(e.dataTransfer.items);
      if (extracted.length > 0) {
        onFiles(multiple ? extracted : extracted.slice(0, 1));
        return;
      }
    }

    const fallbackFiles = Array.from(e.dataTransfer.files ?? []);
    if (fallbackFiles.length) onFiles(multiple ? fallbackFiles : fallbackFiles.slice(0, 1));
  };

  return (
    <div
      className={`drop${over ? ' is-over' : ''}${disabled ? ' is-disabled' : ''}`}
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => void handleDrop(e)}
    >
      <div className="drop-btn" style={{ cursor: 'default' }}>
        <Upload size={20} aria-hidden="true" />
        <span className="drop-title">{title}</span>
        {hint && <span className="drop-hint">{hint}</span>}
      </div>

      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', justifyContent: 'center', marginTop: '10px' }}>
        <button
          type="button"
          className="btn btn-secondary btn-sm"
          onClick={() => fileInput.current?.click()}
          disabled={disabled}
        >
          <Upload size={15} aria-hidden="true" />
          <span>{fileLabel ?? (multiple ? 'انتخاب فایل‌ها' : 'انتخاب فایل')}</span>
        </button>

        {allowFolder && (
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={() => folderInput.current?.click()}
            disabled={disabled}
          >
            <Folder size={15} aria-hidden="true" />
            <span>{folderLabel ?? 'انتخاب کل یک پوشه'}</span>
          </button>
        )}
      </div>

      <input
        ref={fileInput}
        type="file"
        accept={accept}
        multiple={multiple}
        hidden
        onChange={(e) => {
          const files = Array.from(e.target.files ?? []);
          e.target.value = '';
          if (files.length) onFiles(files);
        }}
      />

      {allowFolder && (
        <input
          ref={folderInput}
          type="file"
          // @ts-expect-error webkitdirectory is standard across modern browsers
          webkitdirectory=""
          directory=""
          multiple
          hidden
          onChange={(e) => {
            const files = Array.from(e.target.files ?? []);
            e.target.value = '';
            if (files.length) onFiles(files);
          }}
        />
      )}
    </div>
  );
}
