import { db } from '../data/db';
import { buildExport, validateImport, type ExportFile } from '../data/transfer';
import { IS_NATIVE } from './platform';

const BACKUP_FILE = 'hamyar-autobackup.json';
let isBackingUp = false;
let backupPending = false;
let backupTimer: number | undefined;

/**
 * Saves a JSON snapshot of the local database to the device's native app storage
 * (Directory.Data) using @capacitor/filesystem. Native storage is immune to WebView
 * cache evictions, OS disk sweeps, and browser database resets.
 */
export async function flushAutoBackup(): Promise<boolean> {
  if (!IS_NATIVE) return false;
  if (isBackingUp) {
    backupPending = true;
    return false;
  }
  isBackingUp = true;
  try {
    const profile = await db.profile.get('profile');
    if (!profile || !profile.onboarded) return false;

    const data = await buildExport();
    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    await Filesystem.writeFile({
      path: BACKUP_FILE,
      data: JSON.stringify(data),
      directory: Directory.Data,
      encoding: Encoding.UTF8,
      recursive: true,
    });
    return true;
  } catch (e) {
    console.warn('[hamyar] auto-backup failed:', (e as Error)?.message);
    return false;
  } finally {
    isBackingUp = false;
    if (backupPending) {
      backupPending = false;
      setTimeout(() => void flushAutoBackup(), 1000);
    }
  }
}

/** Schedules an auto-backup debounced by 2 seconds. */
export function scheduleAutoBackup(delay = 2000): void {
  if (!IS_NATIVE) return;
  if (backupTimer) clearTimeout(backupTimer);
  backupTimer = window.setTimeout(() => {
    void flushAutoBackup();
  }, delay);
}

/**
 * Checks if IndexedDB is empty (e.g. after a WebView reset, crash or LevelDB corruption),
 * and if a native backup exists in Directory.Data, automatically restores all user data.
 */
export async function restoreFromNativeBackupIfEmpty(): Promise<boolean> {
  if (!IS_NATIVE) return false;
  try {
    const profile = await db.profile.get('profile');
    if (profile && profile.onboarded) {
      // Data exists in IndexedDB, no restore needed.
      return false;
    }

    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    const check = await Filesystem.stat({ path: BACKUP_FILE, directory: Directory.Data }).catch(() => null);
    if (!check) return false;

    const file = await Filesystem.readFile({ path: BACKUP_FILE, directory: Directory.Data, encoding: Encoding.UTF8 });
    const content = typeof file.data === 'string' ? file.data : '';
    if (!content) return false;

    const parsed = JSON.parse(content) as ExportFile;
    const plan = await validateImport(parsed);
    if (!plan.ok || !plan.data) return false;

    // Restore tables in a single transaction
    const tableNames = Object.keys(plan.data.tables);
    const tablesToLock = tableNames.map((n) => db.table(n)).filter(Boolean);
    tablesToLock.push(db.profile as any);

    await db.transaction('rw', tablesToLock, async () => {
      for (const [table, rows] of Object.entries(plan.data!.tables)) {
        if (db.table(table) && rows && rows.length) {
          await db.table(table).bulkPut(rows);
        }
      }
      if (plan.data!.profile) {
        await db.profile.put(plan.data!.profile as any);
      }
    });

    console.info('[hamyar] successfully restored data from native backup!');
    return true;
  } catch (e) {
    console.warn('[hamyar] restore from native storage failed:', (e as Error)?.message);
    return false;
  }
}
