import { createStore } from './store';
import type { InputLanguage } from '../domain/types';
import { speechSupported, startSpeech, type SpeechErrorCode } from './speech';
import { RecorderError, startRecording } from './recorder';
import { AiError, aiStatusStore, refreshAiStatus, transcribeAudio } from './ai';
import { LIMITS } from '../config/limits';
import { pickRecorderMime } from './platform';

/**
 * One microphone for the whole app (PRD §8): starting a new session ends the previous
 * one, leaving a section or cancelling releases the stream. Never always-on.
 */
export interface MicState {
  ownerId: string;
  lang: InputLanguage;
  engine: 'speech' | 'recorder';
  phase: 'listening' | 'processing';
  startedAt: number;
  interim: string;
  level: number;
  maxMs: number;
}

export type MicErrorCode = SpeechErrorCode | 'stt-unavailable' | 'stt-failed' | 'too-long';

export const micStore = createStore<MicState | null>(null);

let current: { ownerId: string; stop: () => void; abort: () => void } | null = null;

export function micEngineAvailable(): 'speech' | 'recorder' | null {
  if (speechSupported()) return 'speech';
  if (pickRecorderMime() && aiStatusStore.get().transcription.available) return 'recorder';
  return null;
}

export function abortMic() {
  const c = current;
  current = null;
  micStore.set(null);
  c?.abort();
}

export function stopMic() {
  current?.stop();
}

export function isMicOwner(ownerId: string): boolean {
  return micStore.get()?.ownerId === ownerId;
}

export interface DictationRequest {
  ownerId: string;
  lang: InputLanguage;
  continuous: boolean;
  maxMs?: number;
  onResult: (text: string) => void;
  onError: (code: MicErrorCode) => void;
}

export async function startDictation(req: DictationRequest): Promise<void> {
  abortMic();
  const maxMs = req.maxMs ?? LIMITS.commandSeconds * 1000;
  if (speechSupported()) {
    let timer = 0;
    const handle = startSpeech({
      lang: req.lang,
      continuous: req.continuous,
      onInterim: (text) => micStore.set((s) => (s && s.ownerId === req.ownerId ? { ...s, interim: text } : s)),
      onFinal: (text) => req.onResult(text),
      onError: (code) => req.onError(code),
      onEnd: () => {
        window.clearTimeout(timer);
        if (current?.ownerId === req.ownerId) {
          current = null;
          micStore.set(null);
        }
      },
    });
    current = { ownerId: req.ownerId, stop: handle.stop, abort: handle.abort };
    micStore.set({ ownerId: req.ownerId, lang: req.lang, engine: 'speech', phase: 'listening', startedAt: Date.now(), interim: '', level: 0, maxMs });
    timer = window.setTimeout(() => handle.stop(), maxMs);
    return;
  }

  await refreshAiStatus();
  if (!pickRecorderMime() || !aiStatusStore.get().transcription.available) {
    req.onError(pickRecorderMime() ? 'stt-unavailable' : 'unsupported');
    return;
  }
  let cancelled = false;
  const owner = req.ownerId;
  const process = async (blob: Blob) => {
    if (cancelled) return;
    micStore.set((s) => (s && s.ownerId === owner ? { ...s, phase: 'processing' } : s));
    const ctl = new AbortController();
    current = { ownerId: owner, stop: () => undefined, abort: () => ctl.abort() };
    try {
      const durationSec = Math.max(1, (Date.now() - (micStore.get()?.startedAt ?? Date.now())) / 1000);
      const { text } = await transcribeAudio(blob, { language: req.lang === 'fa-IR' ? 'fa' : 'en', durationSec, filename: 'voice-command', signal: ctl.signal });
      if (text.trim()) req.onResult(text.trim());
      else req.onError('no-speech');
    } catch (e) {
      if (!(e instanceof AiError && e.code === 'CANCELLED')) req.onError('stt-failed');
    } finally {
      if (current?.ownerId === owner) {
        current = null;
        micStore.set(null);
      }
    }
  };
  try {
    const rec = await startRecording({
      maxMs,
      maxBytes: LIMITS.transcriptionBytes,
      onLevel: (level) => micStore.set((s) => (s && s.ownerId === owner ? { ...s, level } : s)),
      onAutoStop: (_reason, blob) => void process(blob),
    });
    current = {
      ownerId: owner,
      stop: () => {
        void rec.stop().then(process);
      },
      abort: () => {
        cancelled = true;
        rec.cancel();
      },
    };
    micStore.set({ ownerId: owner, lang: req.lang, engine: 'recorder', phase: 'listening', startedAt: Date.now(), interim: '', level: 0, maxMs });
  } catch (e) {
    req.onError(e instanceof RecorderError && e.code === 'denied' ? 'denied' : e instanceof RecorderError && e.code === 'unsupported' ? 'unsupported' : 'audio');
  }
}
