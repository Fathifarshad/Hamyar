import type { FocusState, MedEvent, Medication, ModuleInstance, Profile, ReminderRecord, Task, TaskCompletion } from '../domain/types';
import { expandByInstants } from '../domain/recurrence';
import { localTimeHHMM } from '../domain/time';
import { toPersianDigits } from '../domain/normalize';
import { currentEvents, occurrenceKey } from '../modules/medications/data';

/**
 * Looks ahead and lists every reminder the phone should raise by itself, so the Android
 * app can hand them to the system alarm service and they arrive even when Hamyar is closed.
 * Same rules as the in-app engine: hidden sections still remind; archived or paused ones
 * do not; done tasks and recorded doses are skipped; snoozes re-notify only.
 */

export interface PlannedNotification {
  /** positive 31-bit id (Android notification ids are Java ints) */
  id: number;
  key: string;
  at: number;
  title: string;
  body: string;
  url: string;
  kind: 'task' | 'medication' | 'focus' | 'notice';
}

export interface PlanInput {
  profile: Pick<Profile, 'locale'>;
  modules: ModuleInstance[];
  tasks: Task[];
  completions: TaskCompletion[];
  medications: Medication[];
  medEvents: MedEvent[];
  reminders: ReminderRecord[];
  focus: FocusState[];
}

export interface PlanOptions {
  horizonDays?: number;
  max?: number;
}

export const PLAN_HORIZON_DAYS = 21;
export const PLAN_MAX = 300;

function eligible(mod: ModuleInstance | undefined): boolean {
  return !!mod && !mod.archivedAt && !mod.remindersPaused;
}

/** Stable positive int from a string (FNV-1a), so the same reminder keeps its id. */
export function notificationId(key: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < key.length; i++) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 1) % 2_000_000_000 || 1;
}

export function planNotifications(input: PlanInput, now: number, opts: PlanOptions = {}): PlannedNotification[] {
  const horizonDays = opts.horizonDays ?? PLAN_HORIZON_DAYS;
  const max = opts.max ?? PLAN_MAX;
  const end = now + horizonDays * 86_400_000;
  const fa = input.profile.locale === 'fa';
  const t = (a: string, b: string) => (fa ? a : b);
  const dig = (s: string) => (fa ? toPersianDigits(s) : s);
  const mods = new Map(input.modules.map((m) => [m.id, m]));
  const done = new Set(input.completions.map((c) => c.id));
  const doses = currentEvents(input.medEvents);
  const out: Omit<PlannedNotification, 'id'>[] = [];
  let recurring = false;

  for (const task of input.tasks) {
    if (task.reminderOffset === null || !task.revisions || !eligible(mods.get(task.moduleId))) continue;
    const off = task.reminderOffset * 60_000;
    for (const occ of expandByInstants(task.revisions, now + off, end + off)) {
      if (occ.at === null) continue;
      const at = occ.at - off;
      if (at <= now || at > end) continue;
      if (done.has(`${task.id}|${occ.key}`)) continue;
      const time = localTimeHHMM(occ.at, occ.timezone);
      out.push({
        key: `task:${task.id}:${occ.key}:${task.reminderOffset}`,
        at,
        title: task.title,
        body: task.reminderOffset === 0 ? dig(`${t('ساعت', 'At')} ${time}`) : dig(`${t('ساعت', 'At')} ${time} · ${task.reminderOffset} ${t('دقیقه دیگر', 'min from now')}`),
        url: `#/m/${encodeURIComponent(task.moduleId)}`,
        kind: 'task',
      });
    }
    if (task.revisions.some((r) => r.rule.freq !== 'once')) recurring = true;
  }

  for (const med of input.medications) {
    if (!med.active || !med.reminderEnabled || !eligible(mods.get(med.moduleId))) continue;
    for (const occ of expandByInstants(med.revisions, now + 1, end + 1)) {
      if (occ.at === null || occ.at <= now || occ.at > end) continue;
      const key = occurrenceKey(med.id, occ);
      const ev = doses.get(key);
      if (ev && ev.action !== 'cleared') continue;
      out.push({
        key: `med:${key}`,
        at: occ.at,
        title: med.showNameInNotification ? `${t('یادآوری دارو', 'Medication reminder')}: ${med.name}` : t('یادآوری دارو', 'Medication reminder'),
        body: `${t('نوبت ساعت', 'Dose at')} ${dig(localTimeHHMM(occ.at, occ.timezone))}`,
        url: `#/m/${encodeURIComponent(med.moduleId)}?focus=${encodeURIComponent(key)}`,
        kind: 'medication',
      });
    }
    if (med.revisions.some((r) => r.rule.freq !== 'once')) recurring = true;
  }

  for (const r of input.reminders) {
    if (!r.snoozedUntil || r.snoozedUntil <= now || r.snoozedUntil > end || !eligible(mods.get(r.moduleId))) continue;
    if (r.kind === 'medication') {
      const ev = doses.get(r.occurrenceKey);
      if (ev && ev.action !== 'cleared') continue;
    }
    out.push({
      key: `${r.followUpOf ?? r.id}:snooze:${r.snoozedUntil}`,
      at: r.snoozedUntil,
      title: r.title,
      body: r.body,
      url: r.kind === 'medication' ? `#/m/${encodeURIComponent(r.moduleId)}?focus=${encodeURIComponent(r.occurrenceKey)}` : `#/m/${encodeURIComponent(r.moduleId)}`,
      kind: r.kind === 'medication' ? 'medication' : 'task',
    });
  }

  for (const f of input.focus) {
    const mod = mods.get(f.id);
    if (f.status !== 'running' || !f.endAt || f.endAt <= now || f.endAt > end || !mod || mod.archivedAt) continue;
    out.push({
      key: `focus:${f.id}:${f.endAt}`,
      at: f.endAt,
      title: f.phase === 'focus' ? t('زمان تمرکز تمام شد', 'Focus time is over') : t('استراحت تمام شد', 'Break is over'),
      body: mod.title,
      url: `#/m/${encodeURIComponent(f.id)}`,
      kind: 'focus',
    });
  }

  out.sort((a, b) => a.at - b.at || a.key.localeCompare(b.key));
  const kept = out.slice(0, max);
  const truncated = out.length > max;

  // Recurring reminders are planned only so far ahead; ask the person to open the app
  // before the plan runs out (every open extends it).
  if (kept.length && (recurring || truncated)) {
    const last = kept[kept.length - 1]!.at;
    const noticeAt = truncated ? last - 3_600_000 : Math.min(end - 86_400_000, last);
    if (noticeAt > now) {
      kept.push({
        key: `notice:${Math.floor(noticeAt / 3_600_000)}`,
        at: noticeAt,
        title: t('همیار را باز کنید', 'Open Hamyar'),
        body: t('برای ادامه یادآوری‌های کارها و داروها، همیار را یک بار باز کنید.', 'Open Hamyar once to keep task and medication reminders coming.'),
        url: '#/',
        kind: 'notice',
      });
    }
  }

  const used = new Set<number>();
  return kept.map((n) => {
    let id = notificationId(n.key);
    while (used.has(id)) id = (id % 2_000_000_000) + 1;
    used.add(id);
    return { ...n, id };
  });
}
