import { IS_ARTIFACT, IS_MOBILE, IS_NATIVE } from './platform';
import { toast } from './ui-store';

const fa = () => document.documentElement.lang !== 'en';

/**
 * Installable web app (computer and iPhone): registers the service worker that keeps the
 * app working offline. A new version waits until the person taps "Update", so a screen
 * that is in use never swaps code underneath them.
 */
export function registerServiceWorker(): void {
  if (IS_ARTIFACT || IS_NATIVE || !import.meta.env.PROD || !('serviceWorker' in navigator)) return;
  const secure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  if (!secure) return;
  const hadController = !!navigator.serviceWorker.controller;
  let reloading = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (!hadController || reloading) return;
    reloading = true;
    window.location.reload();
  });
  const offer = (worker: ServiceWorker) =>
    toast({
      kind: 'info',
      timeout: 0,
      text: fa() ? 'نسخه تازه همیار آماده است.' : 'A new version of Hamyar is ready.',
      action: { label: fa() ? 'به‌روزرسانی' : 'Update', run: () => worker.postMessage({ type: 'SKIP_WAITING' }) },
    });
  const register = () => {
    navigator.serviceWorker
      .register('./sw.js')
      .then((reg) => {
        if (reg.waiting && navigator.serviceWorker.controller) offer(reg.waiting);
        reg.addEventListener('updatefound', () => {
          const w = reg.installing;
          w?.addEventListener('statechange', () => {
            if (w.state === 'installed' && navigator.serviceWorker.controller) offer(w);
          });
        });
        document.addEventListener('visibilitychange', () => {
          if (document.visibilityState === 'visible') void reg.update().catch(() => undefined);
        });
      })
      .catch(() => undefined);
  };
  if (document.readyState === 'complete') register();
  else window.addEventListener('load', register);
}

/** On phones, ask the browser to keep Hamyar's data even when storage runs low. */
export function requestPersistentStorage(): void {
  if (!IS_MOBILE || IS_NATIVE) return;
  void navigator.storage?.persisted?.().then((done) => (done ? undefined : navigator.storage.persist?.())).catch(() => undefined);
}

/** Android Chrome offers an install prompt we can show from our own button. */
interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}
let deferredPrompt: InstallPromptEvent | null = null;
const listeners = new Set<() => void>();
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e as InstallPromptEvent;
    listeners.forEach((l) => l());
  });
  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    listeners.forEach((l) => l());
  });
}

export function canPromptInstall(): boolean {
  return !!deferredPrompt;
}

export function onInstallPromptChange(l: () => void): () => void {
  listeners.add(l);
  return () => listeners.delete(l);
}

export async function promptInstall(): Promise<boolean> {
  const p = deferredPrompt;
  if (!p) return false;
  await p.prompt();
  const choice = await p.userChoice.catch(() => ({ outcome: 'dismissed' as const }));
  deferredPrompt = null;
  listeners.forEach((l) => l());
  return choice.outcome === 'accepted';
}
