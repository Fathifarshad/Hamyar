import type { CalendarSystem, Locale } from '../domain/types';
import {
  GREGORIAN_MONTHS_EN,
  GREGORIAN_MONTHS_FA,
  JALALI_MONTHS_EN,
  JALALI_MONTHS_FA,
  WEEKDAYS_EN,
  WEEKDAYS_FA,
  isoToJalali,
} from '../domain/jalali';
import { diffDaysISO, parseISODate, utcToLocal, weekdayOfISO, pad2 } from '../domain/time';
import { toPersianDigits } from '../domain/normalize';

export interface FormatContext {
  locale: Locale;
  calendar: CalendarSystem;
  timezone: string;
}

const nfCache = new Map<string, Intl.NumberFormat>();
function nf(locale: Locale, opts: Intl.NumberFormatOptions = {}): Intl.NumberFormat {
  const key = `${locale}|${JSON.stringify(opts)}`;
  let f = nfCache.get(key);
  if (!f) {
    f = new Intl.NumberFormat(locale === 'fa' ? 'fa-IR' : 'en-US', opts);
    nfCache.set(key, f);
  }
  return f;
}

export function digits(v: string | number, locale: Locale): string {
  return locale === 'fa' ? toPersianDigits(String(v)) : String(v);
}

export function fmtNum(n: number, locale: Locale, maxFrac = 0): string {
  return nf(locale, { maximumFractionDigits: maxFrac }).format(n);
}

export type DateStyle = 'long' | 'medium' | 'short' | 'numeric' | 'weekday';

export function fmtDate(iso: string, ctx: Pick<FormatContext, 'locale' | 'calendar'>, style: DateStyle = 'medium'): string {
  const { locale, calendar } = ctx;
  const wd = weekdayOfISO(iso);
  const weekday = locale === 'fa' ? WEEKDAYS_FA[wd]! : WEEKDAYS_EN[wd]!;
  if (style === 'weekday') return weekday;
  if (calendar === 'jalali') {
    const j = isoToJalali(iso);
    const month = (locale === 'fa' ? JALALI_MONTHS_FA : JALALI_MONTHS_EN)[j.jm - 1]!;
    const d = digits(j.jd, locale);
    const y = digits(j.jy, locale);
    switch (style) {
      case 'long':
        return `${weekday} ${d} ${month} ${y}`;
      case 'short':
        return `${d} ${month}`;
      case 'numeric':
        return digits(`${j.jy}/${pad2(j.jm)}/${pad2(j.jd)}`, locale);
      default:
        return `${d} ${month} ${y}`;
    }
  }
  const { y, m, d } = parseISODate(iso);
  if (locale === 'fa') {
    const month = GREGORIAN_MONTHS_FA[m - 1]!;
    switch (style) {
      case 'long':
        return `${weekday} ${digits(d, locale)} ${month} ${digits(y, locale)}`;
      case 'short':
        return `${digits(d, locale)} ${month}`;
      case 'numeric':
        return digits(`${y}/${pad2(m)}/${pad2(d)}`, locale);
      default:
        return `${digits(d, locale)} ${month} ${digits(y, locale)}`;
    }
  }
  const month = GREGORIAN_MONTHS_EN[m - 1]!;
  switch (style) {
    case 'long':
      return `${weekday}, ${month} ${d}, ${y}`;
    case 'short':
      return `${month.slice(0, 3)} ${d}`;
    case 'numeric':
      return `${y}-${pad2(m)}-${pad2(d)}`;
    default:
      return `${month.slice(0, 3)} ${d}, ${y}`;
  }
}

/** Formats a wall time 'HH:mm'. Persian uses 24-hour digits, English 12-hour. */
export function fmtTime(hhmm: string, locale: Locale): string {
  if (locale === 'fa') return digits(hhmm, locale);
  const [h, m] = hhmm.split(':').map(Number);
  const suffix = h! >= 12 ? 'PM' : 'AM';
  const h12 = h! % 12 === 0 ? 12 : h! % 12;
  return `${h12}:${pad2(m!)} ${suffix}`;
}

export function fmtInstantTime(utc: number, tz: string, locale: Locale): string {
  const p = utcToLocal(utc, tz);
  return fmtTime(`${pad2(p.h)}:${pad2(p.min)}`, locale);
}

export function fmtRelDay(iso: string, today: string, ctx: Pick<FormatContext, 'locale' | 'calendar'>): string {
  const diff = diffDaysISO(iso, today);
  const fa = ctx.locale === 'fa';
  if (diff === 0) return fa ? 'امروز' : 'Today';
  if (diff === 1) return fa ? 'فردا' : 'Tomorrow';
  if (diff === -1) return fa ? 'دیروز' : 'Yesterday';
  if (diff > 1 && diff < 7) return fmtDate(iso, ctx, 'weekday');
  return fmtDate(iso, ctx, 'short');
}

export function fmtDuration(totalSeconds: number, locale: Locale): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const out = h > 0 ? `${h}:${pad2(m)}:${pad2(sec)}` : `${pad2(m)}:${pad2(sec)}`;
  return digits(out, locale);
}

const CURRENCY_LABELS: Record<string, [string, string]> = {
  IRT: ['تومان', 'Toman'],
  IRR: ['ریال', 'Rial'],
  AFN: ['افغانی', 'Afghani'],
};

export function currencyLabel(code: string, locale: Locale): string {
  const l = CURRENCY_LABELS[code];
  if (l) return locale === 'fa' ? l[0] : l[1];
  try {
    const parts = new Intl.NumberFormat(locale === 'fa' ? 'fa-IR' : 'en-US', { style: 'currency', currency: code, currencyDisplay: 'name' }).formatToParts(0);
    return parts.find((p) => p.type === 'currency')?.value ?? code;
  } catch {
    return code;
  }
}

export function fmtMoney(amount: number, currency: string, locale: Locale): string {
  if (CURRENCY_LABELS[currency] || currency === 'IRT') return `${fmtNum(amount, locale)} ${currencyLabel(currency, locale)}`;
  try {
    return new Intl.NumberFormat(locale === 'fa' ? 'fa-IR' : 'en-US', { style: 'currency', currency, maximumFractionDigits: 2 }).format(amount);
  } catch {
    return `${fmtNum(amount, locale, 2)} ${currency}`;
  }
}

export function fmtBytes(bytes: number, locale: Locale): string {
  const units = locale === 'fa' ? ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت'] : ['B', 'KB', 'MB', 'GB'];
  let v = bytes;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${fmtNum(v, locale, i === 0 ? 0 : 1)} ${units[i]}`;
}

export function fmtDateTimeShort(utc: number, ctx: FormatContext, today: string): string {
  const p = utcToLocal(utc, ctx.timezone);
  const iso = `${p.y}-${pad2(p.m)}-${pad2(p.d)}`;
  return `${fmtRelDay(iso, today, ctx)} ${fmtTime(`${pad2(p.h)}:${pad2(p.min)}`, ctx.locale)}`;
}
