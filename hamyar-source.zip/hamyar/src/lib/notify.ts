import { IS_ARTIFACT } from './platform';
import { interactionStore } from './ui-store';

/**
 * In-app and system notifications. Permission is only ever requested from a click,
 * after an explanation. "Delivered to the OS" is not the same as "seen".
 */
export type NotifyPermission = 'granted' | 'denied' | 'default' | 'unsupported';

export function notificationPermission(): NotifyPermission {
  if (IS_ARTIFACT || typeof Notification === 'undefined') return 'unsupported';
  return Notification.permission as NotifyPermission;
}

export async function requestNotificationPermission(): Promise<NotifyPermission> {
  if (notificationPermission() === 'unsupported') return 'unsupported';
  try {
    return (await Notification.requestPermission()) as NotifyPermission;
  } catch {
    return notificationPermission();
  }
}

export async function showSystemNotification(title: string, body: string, opts: { tag: string; url: string }): Promise<boolean> {
  if (notificationPermission() !== 'granted') return false;
  const icon = new URL('./icons/icon-192.png', window.location.href).toString();
  try {
    const reg = await navigator.serviceWorker?.getRegistration?.();
    if (reg) {
      await reg.showNotification(title, { body, tag: opts.tag, data: { url: opts.url }, icon, badge: icon });
      return true;
    }
  } catch {
    /* fall back to a page notification */
  }
  try {
    const n = new Notification(title, { body, tag: opts.tag, icon });
    n.onclick = () => {
      window.focus();
      window.location.hash = opts.url.replace(/^.*#/, '#');
      n.close();
    };
    return true;
  } catch {
    return false;
  }
}

let ctx: AudioContext | null = null;

/** A short two-tone chime. Browsers allow sound only after the person has interacted. */
export function playChime(): void {
  if (!interactionStore.get()) return;
  try {
    ctx = ctx ?? new AudioContext();
    if (ctx.state === 'suspended') void ctx.resume();
    const now = ctx.currentTime;
    [880, 1318.5].forEach((freq, i) => {
      const o = ctx!.createOscillator();
      const g = ctx!.createGain();
      o.type = 'sine';
      o.frequency.value = freq;
      g.gain.setValueAtTime(0.0001, now + i * 0.18);
      g.gain.exponentialRampToValueAtTime(0.18, now + i * 0.18 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.18 + 0.5);
      o.connect(g).connect(ctx!.destination);
      o.start(now + i * 0.18);
      o.stop(now + i * 0.18 + 0.55);
    });
  } catch {
    /* audio unavailable */
  }
}
