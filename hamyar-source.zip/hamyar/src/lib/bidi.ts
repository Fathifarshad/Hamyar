/**
 * Base direction for user text inside a bilingual interface.
 *
 * The browser's own `dir="auto"` looks only at the first strong letter, so a Persian
 * title such as «PDF و خلاصه» is laid out left-to-right and reads backwards. Here the
 * interface direction wins for mixed text unless the other script clearly dominates,
 * and single-script text always gets its own direction («3 apples» stays LTR in Persian).
 */
export type Dir = 'rtl' | 'ltr';

const RTL_LETTERS = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/g;
const LTR_LETTERS = /[A-Za-z\u00C0-\u024F\u0370-\u03FF\u0400-\u04FF]/g;

export function dirOf(text: string | null | undefined, ui: Dir): Dir {
  if (!text) return ui;
  const rtl = text.match(RTL_LETTERS)?.length ?? 0;
  const ltr = text.match(LTR_LETTERS)?.length ?? 0;
  if (!rtl && !ltr) return ui;
  if (!ltr) return 'rtl';
  if (!rtl) return 'ltr';
  const [own, other] = ui === 'rtl' ? [rtl, ltr] : [ltr, rtl];
  if (other >= own * 3) return ui === 'rtl' ? 'ltr' : 'rtl';
  return ui;
}

/** Interface direction as currently set on the document (falls back to RTL). */
export function documentDir(): Dir {
  const doc = (globalThis as { document?: { documentElement?: { dir?: string } } }).document;
  return doc?.documentElement?.dir === 'ltr' ? 'ltr' : 'rtl';
}
