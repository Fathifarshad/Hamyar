/**
 * Android app integrations (Capacitor). Loaded only inside the Android app, so the
 * web and iPhone builds never download these plugins.
 *
 * - Reminders are handed to the system alarm service, so they arrive even when
 *   Hamyar is closed. The plan is rebuilt whenever tasks, doses or settings change.
 * - Tapping a notification opens the right section (and the dose confirmation).
 * - Files are offered through the share sheet; the back button closes dialogs first.
 */
import { liveQuery } from 'dexie';
import { App } from '@capacitor/app';
import { SystemBars, SystemBarsStyle } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { db } from '../data/db';
import { planNotifications, PLAN_MAX } from './reminderPlan';
import { tick } from './reminders';

const CHANNEL = 'hamyar-reminders';
let started = false;
let syncTimer = 0;
let syncing: Promise<void> | null = null;
let again = false;

export type NativePermission = 'granted' | 'denied' | 'prompt';

export async function notificationPermission(): Promise<NativePermission> {
  try {
    const p = await LocalNotifications.checkPermissions();
    return p.display === 'granted' ? 'granted' : p.display === 'denied' ? 'denied' : 'prompt';
  } catch {
    return 'denied';
  }
}

export async function requestNotificationPermission(): Promise<NativePermission> {
  try {
    const p = await LocalNotifications.requestPermissions();
    return p.display === 'granted' ? 'granted' : p.display === 'denied' ? 'denied' : 'prompt';
  } catch {
    return 'denied';
  }
}

/** Android 12+ may need "Alarms & reminders" for on-the-minute delivery. */
export async function exactAlarmStatus(): Promise<'granted' | 'denied'> {
  try {
    const s = await LocalNotifications.checkExactNotificationSetting();
    return s.exact_alarm === 'granted' ? 'granted' : 'denied';
  } catch {
    return 'granted';
  }
}

export async function openExactAlarmSettings(): Promise<void> {
  try {
    await LocalNotifications.changeExactNotificationSetting();
  } finally {
    scheduleSync(500);
  }
}

/** Asks for permission (from a tap) and turns phone reminders on when allowed. */
export async function enablePhoneReminders(): Promise<boolean> {
  const perm = await requestNotificationPermission();
  const ok = perm === 'granted';
  const profile = await db.profile.get('profile');
  if (profile && profile.systemNotifications !== ok) await db.profile.update('profile', { systemNotifications: ok });
  scheduleSync(0);
  return ok;
}

export async function sendTestNotification(fa: boolean, seconds = 5): Promise<boolean> {
  if ((await notificationPermission()) !== 'granted') return false;
  await LocalNotifications.schedule({
    notifications: [
      {
        id: 7,
        title: fa ? 'اعلان آزمایشی همیار' : 'Hamyar test notification',
        body: fa ? 'یادآوری‌ها حتی وقتی برنامه بسته است همین‌طور می‌آیند.' : 'Reminders arrive like this even when the app is closed.',
        channelId: CHANNEL,
        schedule: { at: new Date(Date.now() + seconds * 1000), allowWhileIdle: true },
        isExactNotification: (await exactAlarmStatus()) === 'granted',
        extra: { url: '#/settings' },
      },
    ],
  });
  return true;
}

async function readPlanInput() {
  const [profile, modules, tasks, completions, medications, medEvents, reminders, focus] = await Promise.all([
    db.profile.get('profile'),
    db.modules.toArray(),
    db.tasks.toArray(),
    db.taskCompletions.toArray(),
    db.medications.toArray(),
    db.medEvents.toArray(),
    db.reminders.where('snoozedUntil').above(Date.now()).toArray(),
    db.focus.toArray(),
  ]);
  return { profile, modules, tasks, completions, medications, medEvents, reminders, focus };
}

async function clearPending(): Promise<void> {
  const pending = await LocalNotifications.getPending();
  const ids = pending.notifications.filter((n) => n.id !== 7).map((n) => ({ id: n.id }));
  for (let i = 0; i < ids.length; i += 100) await LocalNotifications.cancel({ notifications: ids.slice(i, i + 100) });
}

/** Rebuilds the phone's reminder schedule from the current data. */
export async function syncNotifications(): Promise<number> {
  const data = await readPlanInput();
  if (!data.profile?.onboarded) return 0;
  const allowed = data.profile.systemNotifications && (await notificationPermission()) === 'granted';
  await clearPending();
  if (!allowed) return 0;
  const plan = planNotifications({ ...data, profile: data.profile }, Date.now(), { max: PLAN_MAX });
  if (!plan.length) return 0;
  const exact = (await exactAlarmStatus()) === 'granted';
  for (let i = 0; i < plan.length; i += 50) {
    await LocalNotifications.schedule({
      notifications: plan.slice(i, i + 50).map((n) => ({
        id: n.id,
        title: n.title,
        body: n.body,
        channelId: CHANNEL,
        schedule: { at: new Date(n.at), allowWhileIdle: true },
        // never pop the system settings screen from a background sync
        isExactNotification: exact,
        extra: { url: n.url, kind: n.kind },
      })),
    });
  }
  return plan.length;
}

function runSync() {
  if (syncing) {
    again = true;
    return;
  }
  syncing = syncNotifications()
    .then(() => undefined)
    .catch((e) => console.warn('[hamyar] reminder sync failed', (e as Error)?.message))
    .finally(() => {
      syncing = null;
      if (again) {
        again = false;
        scheduleSync(1000);
      }
    });
}

export function scheduleSync(delay = 1500) {
  window.clearTimeout(syncTimer);
  syncTimer = window.setTimeout(runSync, delay);
}

function applySystemBarStyle() {
  const dark = document.documentElement.getAttribute('data-resolved-theme') === 'dark';
  void SystemBars.setStyle({ style: dark ? SystemBarsStyle.Dark : SystemBarsStyle.Light }).catch(() => undefined);
}

/** Closes the top-most open dialog; returns false when none was open. */
function closeTopDialog(): boolean {
  const open = Array.from(document.querySelectorAll('dialog[open]'));
  const top = open[open.length - 1] as HTMLDialogElement | undefined;
  if (!top) return false;
  top.dispatchEvent(new Event('cancel', { cancelable: true }));
  return true;
}

export async function initNative(): Promise<void> {
  if (started) return;
  started = true;

  try {
    await LocalNotifications.createChannel({
      id: CHANNEL,
      name: document.documentElement.lang === 'en' ? 'Reminders' : 'یادآوری‌ها',
      description: document.documentElement.lang === 'en' ? 'Tasks, medications and focus timer' : 'کارها، داروها و تایمر تمرکز',
      importance: 5,
      visibility: 1,
      vibration: true,
    });
  } catch {
    /* channels exist only on Android 8+ */
  }

  await LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
    const url = (action.notification.extra as { url?: string } | undefined)?.url;
    if (url && url.startsWith('#/')) window.location.hash = url;
  });

  await App.addListener('backButton', ({ canGoBack }) => {
    if (closeTopDialog()) return;
    const hash = window.location.hash;
    if (hash && hash !== '#/' && hash !== '#') {
      if (canGoBack) window.history.back();
      else window.location.hash = '#/';
      return;
    }
    void App.minimizeApp();
  });

  await App.addListener('appStateChange', ({ isActive }) => {
    if (isActive) {
      void tick();
      scheduleSync(800);
    }
  });

  applySystemBarStyle();
  new MutationObserver(applySystemBarStyle).observe(document.documentElement, { attributes: true, attributeFilter: ['data-resolved-theme'] });

  // Any change that affects reminders rebuilds the plan (debounced).
  liveQuery(async () => {
    const [p, mods, tk, tc, md, me, rm, fc] = await Promise.all([
      db.profile.get('profile'),
      db.modules.toArray(),
      db.tasks.toArray(),
      db.taskCompletions.count(),
      db.medications.toArray(),
      db.medEvents.count(),
      db.reminders.where('snoozedUntil').above(0).count(),
      db.focus.toArray(),
    ]);
    return JSON.stringify([
      p?.onboarded,
      p?.systemNotifications,
      p?.locale,
      mods.map((x) => `${x.id}${x.archivedAt ? 'a' : ''}${x.remindersPaused ? 'p' : ''}${x.title}`),
      tk.map((x) => `${x.id}:${x.revision}:${x.reminderOffset}`),
      tc,
      md.map((x) => `${x.id}:${x.revision}:${x.active}:${x.reminderEnabled}:${x.showNameInNotification}`),
      me,
      rm,
      fc.map((x) => `${x.id}:${x.status}:${x.endAt}`),
    ]);
  }).subscribe({ next: () => scheduleSync(), error: () => undefined });
}

/** Saves a generated file through the Android share sheet (Drive, Files, messaging apps…). */
export async function shareFile(filename: string, data: string | Blob): Promise<'saved' | 'declined' | 'unavailable'> {
  try {
    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    const { Share } = await import('@capacitor/share');
    const path = `exports/${filename}`;
    let uri: string;
    if (typeof data === 'string') {
      uri = (await Filesystem.writeFile({ path, data, directory: Directory.Cache, encoding: Encoding.UTF8, recursive: true })).uri;
    } else {
      const base64 = await new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(String(r.result).split(',')[1] ?? '');
        r.onerror = () => reject(r.error);
        r.readAsDataURL(data);
      });
      uri = (await Filesystem.writeFile({ path, data: base64, directory: Directory.Cache, recursive: true })).uri;
    }
    await Share.share({ title: filename, files: [uri], dialogTitle: filename });
    return 'saved';
  } catch (e) {
    const msg = String((e as Error)?.message ?? e);
    return /cancel/i.test(msg) ? 'declined' : 'unavailable';
  }
}
