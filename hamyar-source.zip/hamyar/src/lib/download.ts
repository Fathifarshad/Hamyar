import { IS_ARTIFACT, IS_NATIVE, claudeUse } from './platform';

type Downloads = { save: (r: { filename: string; data: string | Blob }) => Promise<{ status: string }> };

/** Offers a generated file. In the claude.ai preview the viewer confirms the save. */
export async function saveFile(filename: string, data: string | Blob, mime: string): Promise<'saved' | 'declined' | 'unavailable'> {
  if (IS_NATIVE) {
    const { shareFile } = await import('./native');
    return shareFile(filename, data);
  }
  if (IS_ARTIFACT) {
    const dl = await claudeUse<Downloads>('downloads');
    if (!dl) return 'unavailable';
    try {
      await dl.save({ filename, data });
      return 'saved';
    } catch (e) {
      return (e as { code?: string })?.code === 'declined' ? 'declined' : 'unavailable';
    }
  }
  const blob = typeof data === 'string' ? new Blob([data], { type: `${mime};charset=utf-8` }) : data;
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return 'saved';
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
