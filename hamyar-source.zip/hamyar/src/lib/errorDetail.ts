/**
 * A short technical tag for an error ("STORE_FAILED · UnknownError"), shown in small print
 * under the plain-language message. It is never a stack trace and never contains file
 * contents; a screenshot of it is enough to tell what went wrong on someone's phone.
 */
export function errorDetail(e: unknown): string {
  if (typeof e === 'string') return e.slice(0, 80);
  if (!e || typeof e !== 'object') return '';
  const x = e as { code?: unknown; name?: unknown; message?: unknown; inner?: { name?: unknown }; details?: Record<string, unknown> };
  const bits: string[] = [];
  const add = (v: unknown) => {
    if (typeof v === 'string' && v && v !== 'Error' && v !== 'DomainError' && !bits.includes(v)) bits.push(v);
  };
  add(x.code);
  add(x.details?.stage);
  add(x.details?.cause);
  add(x.details?.first);
  add(x.inner?.name);
  add(x.name);
  // Browser errors that carry no name we know: the message is the only clue.
  if (bits.length === 0 && typeof x.message === 'string') add(x.message.slice(0, 60));
  return bits.join(' · ').slice(0, 100);
}
