import Dexie from 'dexie';
import { db, kvGet, kvSet, nowIso } from '../data/db';
import type { ModuleInstance, Profile, ReminderRecord } from '../domain/types';
import { expandByInstants } from '../domain/recurrence';
import { LIMITS } from '../config/limits';
import { currentEvents, occurrenceKey } from '../modules/medications/data';
import { completeIfDue } from '../modules/focus/data';
import { localTimeHHMM, todayISO } from '../domain/time';
import { playChime, showSystemNotification } from './notify';
import { toast } from './ui-store';
import { toPersianDigits } from '../domain/normalize';
import { IS_NATIVE } from './platform';

/**
 * In-app reminder scheduler (local mode). One tab is the leader (Web Locks); every
 * reminder is claimed with a deterministic id, so it fires once even across tabs.
 * Reminders that were due while the app was closed appear in the inbox; anything
 * later than 60 minutes is not pushed as a system notification.
 * This is not a background alarm: with the browser closed nothing runs.
 */

const LOOKBACK_MS = 24 * 3600_000;
let timer = 0;
let running = false;
let started = false;

type T = (fa: string, en: string) => string;

function translator(locale: Profile['locale']): T {
  return (fa, en) => (locale === 'fa' ? fa : en);
}

async function claim(rec: ReminderRecord): Promise<boolean> {
  try {
    await db.reminders.add(rec);
    return true;
  } catch (e) {
    if (e instanceof Dexie.ConstraintError || (e as { name?: string })?.name === 'ConstraintError') return false;
    throw e;
  }
}

function eligible(mod: ModuleInstance | undefined): boolean {
  // Hidden (inactive) sections keep reminding; archived or paused ones do not.
  return !!mod && !mod.archivedAt && !mod.remindersPaused;
}

async function deliver(rec: ReminderRecord, profile: Profile, url: string, t: T) {
  if (rec.late) return;
  if (profile.reminderSound) playChime();
  toast({
    kind: 'reminder',
    text: rec.title,
    detail: rec.body,
    action: {
      label: t('مشاهده', 'Open'),
      run: () => {
        window.location.hash = url;
        void db.reminders.update(rec.id, { readAt: nowIso() });
      },
    },
  });
  // In the Android app the system alarm service already raises this one (see native.ts).
  if (profile.systemNotifications && !IS_NATIVE) {
    const ok = await showSystemNotification(rec.title, rec.body, { tag: rec.occurrenceKey, url });
    if (ok) await db.reminders.update(rec.id, { delivery: 'system' });
  }
}

export function reminderUrl(rec: Pick<ReminderRecord, 'kind' | 'moduleId' | 'occurrenceKey'>): string {
  return rec.kind === 'medication' ? `#/m/${encodeURIComponent(rec.moduleId)}?focus=${encodeURIComponent(rec.occurrenceKey)}` : `#/m/${encodeURIComponent(rec.moduleId)}`;
}

export async function tick(now = Date.now()): Promise<void> {
  if (running) return;
  running = true;
  try {
    const profile = await db.profile.get('profile');
    if (!profile?.onboarded) return;
    const t = translator(profile.locale);
    const dig = (s: string) => (profile.locale === 'fa' ? toPersianDigits(s) : s);
    const last = await kvGet<number>('reminders:lastTick', now - 2 * 60_000);
    const from = Math.max(last, now - LOOKBACK_MS);
    const mods = new Map((await db.modules.toArray()).map((m) => [m.id, m]));
    const stale = LIMITS.staleReminderMinutes * 60_000;

    // tasks
    const tasks = await db.tasks.toArray();
    const completions = new Set((await db.taskCompletions.toArray()).map((c) => c.id));
    for (const task of tasks) {
      if (task.reminderOffset === null || !eligible(mods.get(task.moduleId))) continue;
      const off = task.reminderOffset * 60_000;
      for (const occ of expandByInstants(task.revisions, from + off, now + off + 1)) {
        if (occ.at === null) continue;
        const dueAt = occ.at - off;
        if (dueAt <= from || dueAt > now) continue;
        if (completions.has(`${task.id}|${occ.key}`)) continue;
        const late = now - dueAt > stale;
        const rec: ReminderRecord = {
          id: `task:${task.id}:${occ.key}:${task.reminderOffset}`,
          kind: 'task',
          sourceId: task.id,
          moduleId: task.moduleId,
          occurrenceKey: occ.key,
          dueAt,
          firedAt: nowIso(),
          late,
          title: task.title,
          body:
            task.reminderOffset === 0
              ? dig(`${t('ساعت', 'At')} ${localTimeHHMM(occ.at, occ.timezone)}`)
              : dig(`${t('ساعت', 'At')} ${localTimeHHMM(occ.at, occ.timezone)} · ${task.reminderOffset} ${t('دقیقه دیگر', 'min from now')}`),
          readAt: null,
          snoozedUntil: null,
          followUpOf: null,
          delivery: late ? 'none' : 'in_app',
        };
        if (await claim(rec)) await deliver(rec, profile, reminderUrl(rec), t);
      }
    }

    // medications (generic text unless the person allowed the name)
    const meds = await db.medications.toArray();
    for (const med of meds) {
      if (!med.active || !med.reminderEnabled || !eligible(mods.get(med.moduleId))) continue;
      const occs = expandByInstants(med.revisions, from + 1, now + 1);
      if (!occs.length) continue;
      const events = currentEvents(await db.medEvents.where('medId').equals(med.id).toArray());
      for (const occ of occs) {
        if (occ.at === null || occ.at <= from || occ.at > now) continue;
        const key = occurrenceKey(med.id, occ);
        const ev = events.get(key);
        if (ev && ev.action !== 'cleared') continue;
        const late = now - occ.at > stale;
        const time = dig(localTimeHHMM(occ.at, occ.timezone));
        const rec: ReminderRecord = {
          id: `med:${key}`,
          kind: 'medication',
          sourceId: med.id,
          moduleId: med.moduleId,
          occurrenceKey: key,
          dueAt: occ.at,
          firedAt: nowIso(),
          late,
          title: med.showNameInNotification ? `${t('یادآوری دارو', 'Medication reminder')}: ${med.name}` : t('یادآوری دارو', 'Medication reminder'),
          body: `${t('نوبت ساعت', 'Dose at')} ${time}`,
          readAt: null,
          snoozedUntil: null,
          followUpOf: null,
          delivery: late ? 'none' : 'in_app',
        };
        if (await claim(rec)) await deliver(rec, profile, reminderUrl(rec), t);
      }
    }

    // snoozed follow-ups: re-notify only; no new dose or task occurrence is created
    const snoozed = await db.reminders.where('snoozedUntil').between(from, now, false, true).toArray();
    for (const orig of snoozed) {
      if (!orig.snoozedUntil) continue;
      if (orig.kind === 'medication') {
        const ev = currentEvents(await db.medEvents.where('occurrenceKey').equals(orig.occurrenceKey).toArray()).get(orig.occurrenceKey);
        if (ev && ev.action !== 'cleared') continue;
      }
      if (!eligible(mods.get(orig.moduleId))) continue;
      const rec: ReminderRecord = {
        ...orig,
        id: `${orig.followUpOf ?? orig.id}:snooze:${orig.snoozedUntil}`,
        dueAt: orig.snoozedUntil,
        firedAt: nowIso(),
        late: now - orig.snoozedUntil > stale,
        readAt: null,
        snoozedUntil: null,
        followUpOf: orig.followUpOf ?? orig.id,
        delivery: 'in_app',
      };
      if (await claim(rec)) await deliver(rec, profile, reminderUrl(rec), t);
    }

    // focus timers that ended while the tab was in the background
    const today = todayISO(profile.timezone, now);
    for (const mod of mods.values()) {
      if (mod.type !== 'focus') continue;
      const r = await completeIfDue(mod.id, today, now);
      if (r.completed) {
        if (profile.reminderSound && mod.config.sound !== false) playChime();
        const title = r.phase === 'focus' ? t('زمان تمرکز تمام شد', 'Focus time is over') : t('استراحت تمام شد', 'Break is over');
        toast({ kind: 'reminder', text: title, detail: mod.title });
        if (profile.systemNotifications && !IS_NATIVE) await showSystemNotification(title, mod.title, { tag: `focus:${mod.id}`, url: `#/m/${mod.id}` });
      }
    }
    await kvSet('reminders:lastTick', now);
  } catch (e) {
    console.error('[hamyar] reminder tick failed', e);
  } finally {
    running = false;
  }
}

export async function snoozeReminder(id: string, minutes: number): Promise<void> {
  await db.reminders.update(id, { snoozedUntil: Date.now() + minutes * 60_000, readAt: nowIso() });
}

function loop() {
  window.clearInterval(timer);
  void tick();
  timer = window.setInterval(() => void tick(), LIMITS.reminderTickMs);
  document.addEventListener('visibilitychange', () => document.visibilityState === 'visible' && void tick());
}

/** Starts the scheduler in exactly one tab when Web Locks are available. */
export function startReminderEngine(): void {
  if (started) return;
  started = true;
  const locks = (navigator as Navigator & { locks?: LockManager }).locks;
  if (locks?.request) {
    void locks.request('hamyar-reminder-leader', () => {
      loop();
      return new Promise<void>(() => undefined);
    });
  } else loop();
}
