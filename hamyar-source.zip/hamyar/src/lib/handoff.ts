import { useEffect, useRef } from 'react';
import { createStore, useStore } from './store';

/**
 * The voice assistant opens a section and hands it what was said (minus the word that chose
 * the section). The section runs it through its own command handling — the same parsing and
 * the same "check before saving" screens as its own voice box — so nothing is saved here.
 */
export interface Handoff {
  id: number;
  moduleId: string;
  text: string;
}

export const handoffStore = createStore<Handoff | null>(null);
let seq = 0;

export function handOff(moduleId: string, text: string): void {
  handoffStore.set({ id: ++seq, moduleId, text });
}

/** Runs `run` once for a handoff to this section, as soon as the section's data is ready. */
export function useHandoff(moduleId: string, ready: boolean, run: (text: string) => void): void {
  const h = useStore(handoffStore);
  const latest = useRef(run);
  useEffect(() => {
    latest.current = run;
  });
  useEffect(() => {
    if (!ready || !h || h.moduleId !== moduleId) return;
    handoffStore.set(null);
    latest.current(h.text);
  }, [h, moduleId, ready]);
}
