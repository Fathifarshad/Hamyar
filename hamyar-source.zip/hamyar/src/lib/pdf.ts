import type { PDFDocumentProxy } from 'pdfjs-dist';
import { IS_ARTIFACT } from './platform';
import { reconstructPageText, type RawTextItem } from './pdfText';

/**
 * PDF.js is loaded on demand. Its worker runs from a Blob URL built from the exact
 * worker that ships with the installed pdfjs-dist version, so parsing never blocks the UI.
 *
 * The "legacy" build is used on purpose: the modern build calls very new JavaScript
 * (for example `Math.sumPrecise`) that current Chrome and Safari releases do not all
 * have yet, and pages then fail to render. The legacy build carries those polyfills.
 */
type PdfJs = typeof import('pdfjs-dist');
let loading: Promise<PdfJs> | null = null;

export function loadPdfJs(): Promise<PdfJs> {
  if (!loading) {
    loading = (async () => {
      const lib: PdfJs = await import('pdfjs-dist/legacy/build/pdf.mjs');
      const { default: workerSrc } = await import('pdfjs-dist/legacy/build/pdf.worker.min.mjs?raw');
      const url = URL.createObjectURL(new Blob([workerSrc], { type: 'text/javascript' }));
      lib.GlobalWorkerOptions.workerPort = new Worker(url, { type: 'module' });
      return lib;
    })();
    loading.catch(() => {
      loading = null;
    });
  }
  return loading;
}

export class PdfOpenError extends Error {
  constructor(readonly code: 'encrypted' | 'invalid' | 'failed') {
    super(code);
  }
}

export async function openPdf(data: ArrayBuffer): Promise<PDFDocumentProxy> {
  const lib = await loadPdfJs();
  const base = new URL('./pdfjs/', window.location.href).toString();
  try {
    const task = lib.getDocument({
      data: new Uint8Array(data),
      ...(IS_ARTIFACT ? {} : { cMapUrl: `${base}cmaps/`, cMapPacked: true, standardFontDataUrl: `${base}standard_fonts/`, wasmUrl: `${base}wasm/` }),
      stopAtErrors: false,
    });
    return await task.promise;
  } catch (e) {
    const name = (e as { name?: string })?.name;
    if (name === 'PasswordException') throw new PdfOpenError('encrypted');
    if (name === 'InvalidPDFException') throw new PdfOpenError('invalid');
    throw new PdfOpenError('failed');
  }
}

export interface ExtractedPage {
  n: number;
  text: string;
  hasText: boolean;
}

const LETTERS = /\p{L}/gu;

/** Page-by-page text with stable 1-based page numbers (the file's own order). */
export async function extractPages(doc: PDFDocumentProxy, onProgress?: (done: number, total: number) => void, signal?: AbortSignal): Promise<ExtractedPage[]> {
  const out: ExtractedPage[] = [];
  for (let n = 1; n <= doc.numPages; n++) {
    if (signal?.aborted) throw new DOMException('aborted', 'AbortError');
    const page = await doc.getPage(n);
    const content = await page.getTextContent();
    const text = reconstructPageText(content.items.filter((i) => 'str' in i) as RawTextItem[]);
    const letters = text.match(LETTERS)?.length ?? 0;
    out.push({ n, text, hasText: letters >= 20 });
    page.cleanup();
    onProgress?.(n, doc.numPages);
  }
  return out;
}
