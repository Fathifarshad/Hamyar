import type { ThemeSetting } from '../domain/types';
import type { Scheme } from '../config/appearance';

/**
 * Resolves light/dark from (1) the app setting, (2) the host's data-theme when the page
 * is embedded in a claude.ai viewer, (3) the OS preference — and writes the result to
 * [data-resolved-theme] so tokens.css can switch every color at once.
 */
let setting: ThemeSetting = 'system';
let started = false;

function hostTheme(): 'light' | 'dark' | null {
  const v = document.documentElement.getAttribute('data-theme');
  return v === 'dark' || v === 'light' ? v : null;
}

function resolve(): 'light' | 'dark' {
  if (setting !== 'system') return setting;
  const host = hostTheme();
  if (host) return host;
  return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function apply() {
  const root = document.documentElement;
  const t = resolve();
  if (root.getAttribute('data-resolved-theme') !== t) root.setAttribute('data-resolved-theme', t);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'dark' ? '#0e1625' : '#f5f7f7');
}

export function setThemeSetting(next: ThemeSetting) {
  setting = next;
  if (!started) {
    started = true;
    window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change', apply);
    new MutationObserver(apply).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  }
  apply();
}

export function setScheme(scheme: Scheme) {
  const root = document.documentElement;
  if (scheme === 'teal') root.removeAttribute('data-scheme');
  else root.setAttribute('data-scheme', scheme);
}

export function currentResolvedTheme(): 'light' | 'dark' {
  return document.documentElement.getAttribute('data-resolved-theme') === 'dark' ? 'dark' : 'light';
}
