import type { InputLanguage } from '../domain/types';
import { IS_NATIVE } from './platform';

/** Minimal typing for the Web Speech API (not in TypeScript's DOM lib everywhere). */
interface SRAlternative {
  transcript: string;
}
interface SRResult {
  isFinal: boolean;
  0: SRAlternative;
  length: number;
}
interface SREvent {
  resultIndex: number;
  results: { length: number; [i: number]: SRResult };
}
interface SRErrorEvent {
  error: string;
}
interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((e: SREvent) => void) | null;
  onerror: ((e: SRErrorEvent) => void) | null;
  onend: (() => void) | null;
  onstart: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

function ctor(): (new () => SpeechRecognitionLike) | null {
  const w = globalThis as unknown as Record<string, unknown>;
  return (w.SpeechRecognition || w.webkitSpeechRecognition || null) as (new () => SpeechRecognitionLike) | null;
}

export function speechSupported(): boolean {
  return IS_NATIVE || !!ctor();
}

export type SpeechErrorCode = 'unsupported' | 'denied' | 'no-speech' | 'network' | 'language' | 'audio' | 'failed';

export interface SpeechHandle {
  /** stop listening and deliver what was heard */
  stop: () => void;
  /** stop listening and discard */
  abort: () => void;
}

export function startSpeech(opts: {
  lang: InputLanguage;
  continuous: boolean;
  onInterim: (text: string) => void;
  onFinal: (text: string) => void;
  onError: (code: SpeechErrorCode) => void;
  onEnd: () => void;
}): SpeechHandle {
  if (IS_NATIVE) return startNativeSpeech(opts);
  const C = ctor();
  if (!C) {
    opts.onError('unsupported');
    opts.onEnd();
    return { stop: () => undefined, abort: () => undefined };
  }
  const rec = new C();
  rec.lang = opts.lang;
  rec.continuous = opts.continuous;
  rec.interimResults = true;
  rec.maxAlternatives = 1;
  let finalText = '';
  let aborted = false;
  let errored = false;
  rec.onresult = (e) => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i]!;
      if (r.isFinal) finalText += (finalText ? ' ' : '') + r[0].transcript.trim();
      else interim += r[0].transcript;
    }
    opts.onInterim((finalText + (interim ? ` ${interim}` : '')).trim());
  };
  rec.onerror = (e) => {
    if (e.error === 'aborted') return;
    errored = true;
    const map: Record<string, SpeechErrorCode> = {
      'not-allowed': 'denied',
      'service-not-allowed': 'denied',
      'no-speech': 'no-speech',
      network: 'network',
      'language-not-supported': 'language',
      'audio-capture': 'audio',
    };
    opts.onError(map[e.error] ?? 'failed');
  };
  rec.onend = () => {
    if (!aborted && !errored && finalText.trim()) opts.onFinal(finalText.trim());
    else if (!aborted && !errored && !finalText.trim()) opts.onError('no-speech');
    opts.onEnd();
  };
  try {
    rec.start();
  } catch {
    opts.onError('failed');
    opts.onEnd();
  }
  return {
    stop: () => {
      try {
        rec.stop();
      } catch {
        /* not started */
      }
    },
    abort: () => {
      aborted = true;
      try {
        rec.abort();
      } catch {
        /* not started */
      }
    },
  };
}

function nativeErrorCode(e: unknown): SpeechErrorCode {
  const m = String((e as { message?: string })?.message ?? e).toLowerCase();
  if (m.includes('permission')) return 'denied';
  if (m.includes('network')) return 'network';
  if (m.includes('no match') || m.includes('speech timeout') || m.includes('no speech')) return 'no-speech';
  if (m.includes('audio')) return 'audio';
  if (m.includes('language')) return 'language';
  if (m.includes('not available') || m.includes('unavailable') || m.includes('not implemented')) return 'unsupported';
  return 'failed';
}

/**
 * Android app: the system speech recognizer (Google), through a Capacitor plugin.
 * One utterance per press; the recognizer stops by itself when you stop talking.
 */
function startNativeSpeech(opts: {
  lang: InputLanguage;
  onInterim: (text: string) => void;
  onFinal: (text: string) => void;
  onError: (code: SpeechErrorCode) => void;
  onEnd: () => void;
}): SpeechHandle {
  let aborted = false;
  let ended = false;
  let plugin: { stop: () => Promise<void> } | null = null;
  const end = () => {
    if (ended) return;
    ended = true;
    opts.onEnd();
  };
  void (async () => {
    try {
      const { SpeechRecognition } = await import('@capacitor-community/speech-recognition');
      plugin = SpeechRecognition;
      const { available } = await SpeechRecognition.available();
      if (!available) {
        opts.onError('unsupported');
        return end();
      }
      let perm = await SpeechRecognition.checkPermissions();
      if (perm.speechRecognition !== 'granted') perm = await SpeechRecognition.requestPermissions();
      if (perm.speechRecognition !== 'granted') {
        opts.onError('denied');
        return end();
      }
      if (aborted) return end();
      const res = await SpeechRecognition.start({ language: opts.lang, maxResults: 1, partialResults: false, popup: false });
      if (aborted) return end();
      const text = (res.matches?.[0] ?? '').trim();
      if (text) {
        opts.onInterim(text);
        opts.onFinal(text);
      } else opts.onError('no-speech');
    } catch (e) {
      if (!aborted) opts.onError(nativeErrorCode(e));
    }
    end();
  })();
  return {
    stop: () => {
      void plugin?.stop().catch(() => undefined);
    },
    abort: () => {
      aborted = true;
      void plugin?.stop().catch(() => undefined);
      end();
    },
  };
}
