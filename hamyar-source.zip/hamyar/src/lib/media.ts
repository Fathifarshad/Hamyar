import { createStore } from './store';
import { db } from '../data/db';
import type { MediaItem } from '../domain/types';

/**
 * Media coordinator (PRD M02): every player under Hamyar's control registers here and
 * starting one pauses the others. Autoplay never happens without a user action.
 */
interface Controllable {
  pause: () => void;
}
const registry = new Map<string, Controllable>();

export function registerMedia(id: string, c: Controllable): () => void {
  registry.set(id, c);
  return () => {
    if (registry.get(id) === c) registry.delete(id);
  };
}

export function claimPlayback(id: string) {
  for (const [key, c] of registry) if (key !== id) c.pause();
}

/** Wires a <video>/<audio> element into the coordinator. */
export function coordinateElement(id: string, el: HTMLMediaElement): () => void {
  const onPlay = () => claimPlayback(id);
  el.addEventListener('play', onPlay);
  const off = registerMedia(id, { pause: () => el.pause() });
  return () => {
    el.removeEventListener('play', onPlay);
    off();
  };
}

// ───────────────────────── central music player ─────────────────────────

export type PlayerError = 'source' | 'format' | 'network' | 'blocked' | 'missing' | null;

export interface PlayerState {
  moduleId: string | null;
  queue: string[];
  index: number;
  current: MediaItem | null;
  playing: boolean;
  loading: boolean;
  position: number;
  duration: number;
  volume: number;
  repeat: 'off' | 'one' | 'all';
  /** Whether songs should automatically play one after another */
  continuous: boolean;
  error: PlayerError;
  /**
   * What the queue is: the section's whole list, a chosen part of it (one artist's songs) or a
   * single track asked for by name, which plays once and stops.
   */
  scope: 'all' | 'subset' | 'single';
  /** what was asked for, e.g. «Googoosh» (shown under the title) */
  label: string | null;
}

export const playerStore = createStore<PlayerState>({
  moduleId: null,
  queue: [],
  index: -1,
  current: null,
  playing: false,
  loading: false,
  position: 0,
  duration: 0,
  volume: 0.8,
  repeat: 'all',
  continuous: true,
  error: null,
  scope: 'all',
  label: null,
});

let audio: HTMLAudioElement | null = null;
let objectUrl: string | null = null;
let unlocked = false;
/** 0.05 s of silence (8 kHz mono WAV), used once to unlock playback on phones. */
const SILENT_WAV = 'data:audio/wav;base64,UklGRrQBAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YZABAACAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA';
const PLAYER_ID = 'music-player';

function el(): HTMLAudioElement {
  if (audio) return audio;
  audio = new Audio();
  audio.preload = 'metadata';
  audio.volume = playerStore.get().volume;
  const set = (patch: Partial<PlayerState>) => playerStore.set((s) => ({ ...s, ...patch }));
  audio.addEventListener('play', () => {
    claimPlayback(PLAYER_ID);
    set({ playing: true });
  });
  audio.addEventListener('pause', () => set({ playing: false }));
  audio.addEventListener('waiting', () => set({ loading: true }));
  audio.addEventListener('playing', () => set({ loading: false, error: null }));
  audio.addEventListener('loadedmetadata', () => {
    set({ duration: Number.isFinite(audio!.duration) ? audio!.duration : 0, loading: false });
    const cur = playerStore.get().current;
    if (cur && Number.isFinite(audio!.duration) && cur.duration !== audio!.duration) void db.media.update(cur.id, { duration: audio!.duration });
  });
  audio.addEventListener('timeupdate', () => set({ position: audio!.currentTime }));
  audio.addEventListener('ended', () => void onEnded());
  audio.addEventListener('error', () => {
    const code = audio!.error?.code;
    const err: PlayerError = code === 4 ? 'format' : code === 2 ? 'network' : 'source';
    set({ error: err, playing: false, loading: false });
  });
  registerMedia(PLAYER_ID, { pause: () => audio?.pause() });
  return audio;
}

async function resolveSource(item: MediaItem): Promise<string | null> {
  if (objectUrl) {
    URL.revokeObjectURL(objectUrl);
    objectUrl = null;
  }
  if (item.sourceType === 'file' && item.assetId) {
    const asset = await db.assets.get(item.assetId);
    if (!asset) return null;
    objectUrl = URL.createObjectURL(asset.blob);
    return objectUrl;
  }
  if (item.sourceType === 'url' && item.url) return item.url;
  return null;
}

let preloadedSrc: string | null = null;
let preloadedId: string | null = null;

async function preloadNext(nextIndex: number) {
  const s = playerStore.get();
  if (!s.queue.length) return;
  const id = s.queue[nextIndex];
  if (!id) return;
  const item = await db.media.get(id);
  if (!item) return;
  if (item.sourceType === 'file' && item.assetId) {
    const asset = await db.assets.get(item.assetId);
    if (asset) {
      if (preloadedSrc && preloadedSrc.startsWith('blob:')) URL.revokeObjectURL(preloadedSrc);
      preloadedSrc = URL.createObjectURL(asset.blob);
      preloadedId = id;
    }
  } else if (item.sourceType === 'url' && item.url) {
    preloadedSrc = item.url;
    preloadedId = id;
  }
}

async function loadIndex(index: number, autoplay: boolean) {
  const s = playerStore.get();
  const id = s.queue[index];
  if (!id) return;
  const item = await db.media.get(id);
  if (!item) return;
  playerStore.set((p) => ({ ...p, index, current: item, error: null, position: 0, duration: item.duration ?? 0, loading: true }));
  const src = await resolveSource(item);
  const a = el();
  if (!src) {
    playerStore.set((p) => ({ ...p, error: 'missing', loading: false, playing: false }));
    return;
  }
  a.src = src;
  setMediaSession(item);
  if (autoplay) {
    try {
      await a.play();
    } catch (e) {
      const name = (e as DOMException)?.name;
      playerStore.set((p) => ({ ...p, loading: false, playing: false, error: name === 'NotAllowedError' ? 'blocked' : p.error ?? 'source' }));
    }
  } else playerStore.set((p) => ({ ...p, loading: false }));

  // Preload the following track so transitions have 0ms idle gap (prevents mobile WebView sleep)
  if (s.queue.length > 1) {
    const nextIdx = (index + 1) % s.queue.length;
    void preloadNext(nextIdx);
  }
}

async function onEnded() {
  const s = playerStore.get();
  if (s.repeat === 'one') {
    const a = el();
    a.currentTime = 0;
    await a.play().catch(() => undefined);
    return;
  }
  const last = s.index >= s.queue.length - 1;
  // If continuous playback is off and we're at the end or playing a single track
  if (!s.continuous || s.scope === 'single' || (last && s.repeat === 'off')) {
    playerStore.set((p) => ({ ...p, playing: false }));
    return;
  }

  const nextIdx = last ? 0 : s.index + 1;
  const nextId = s.queue[nextIdx];

  // If next track is already preloaded, switch synchronously to prevent mobile OS suspension
  if (preloadedId === nextId && preloadedSrc) {
    const a = el();
    if (objectUrl && objectUrl.startsWith('blob:') && objectUrl !== preloadedSrc) {
      URL.revokeObjectURL(objectUrl);
    }
    objectUrl = preloadedSrc;
    a.src = preloadedSrc;
    preloadedSrc = null;
    preloadedId = null;
    const item = await db.media.get(nextId);
    if (item) {
      playerStore.set((p) => ({ ...p, index: nextIdx, current: item, error: null, position: 0, duration: item.duration ?? 0, playing: true }));
      setMediaSession(item);
    }
    try {
      await a.play();
    } catch {
      await loadIndex(nextIdx, true);
      return;
    }
    if (s.queue.length > 1) {
      void preloadNext((nextIdx + 1) % s.queue.length);
    }
    return;
  }

  await loadIndex(nextIdx, true);
}

function setMediaSession(item: MediaItem) {
  if (!('mediaSession' in navigator)) return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({ title: item.title, artist: item.artist || 'Hamyar' });
    navigator.mediaSession.setActionHandler('play', () => void player.toggle());
    navigator.mediaSession.setActionHandler('pause', () => player.pause());
    navigator.mediaSession.setActionHandler('nexttrack', () => void player.next());
    navigator.mediaSession.setActionHandler('previoustrack', () => void player.prev());
  } catch {
    /* optional API */
  }
}

export const player = {
  /**
   * Starts an item from a module's list — only call from a user action (or right after one,
   * once `unlock` ran in it). `scope` says whether the queue is the whole list, a chosen part
   * of it, or one track that should play once.
   */
  async play(moduleId: string, queue: string[], itemId: string, opts: { scope?: PlayerState['scope']; label?: string | null } = {}) {
    const index = queue.indexOf(itemId);
    playerStore.set((p) => ({ ...p, moduleId, queue, scope: opts.scope ?? 'all', label: opts.label ?? null }));
    await loadIndex(Math.max(0, index), true);
  },
  /**
   * Lets a later play() start sound without a fresh tap: browsers (Safari above all) allow it
   * once the element has played inside a tap. Call synchronously from the tap's handler.
   */
  unlock() {
    const a = el();
    if (unlocked || !a.paused) {
      unlocked = true;
      return;
    }
    unlocked = true;
    if (a.src) return;
    a.src = SILENT_WAV;
    a.muted = true;
    void a
      .play()
      .then(() => a.pause())
      .catch(() => undefined)
      .finally(() => {
        a.muted = false;
        if (a.src === SILENT_WAV) a.removeAttribute('src');
      });
  },
  async toggle() {
    const a = el();
    const s = playerStore.get();
    if (!s.current) return;
    if (a.paused) {
      try {
        if (!a.src) await loadIndex(s.index, true);
        else await a.play();
      } catch (e) {
        playerStore.set((p) => ({ ...p, error: (e as DOMException)?.name === 'NotAllowedError' ? 'blocked' : 'source' }));
      }
    } else a.pause();
  },
  pause() {
    audio?.pause();
  },
  async resume() {
    if (audio && audio.src && audio.paused) await audio.play().catch(() => undefined);
  },
  async next() {
    const s = playerStore.get();
    if (!s.queue.length) return;
    await loadIndex((s.index + 1) % s.queue.length, true);
  },
  async prev() {
    const s = playerStore.get();
    if (!s.queue.length) return;
    const a = el();
    if (a.currentTime > 4) {
      a.currentTime = 0;
      return;
    }
    await loadIndex((s.index - 1 + s.queue.length) % s.queue.length, true);
  },
  seek(sec: number) {
    const a = el();
    if (Number.isFinite(sec)) a.currentTime = Math.max(0, sec);
  },
  setVolume(v: number) {
    const vol = Math.max(0, Math.min(1, v));
    el().volume = vol;
    playerStore.set((p) => ({ ...p, volume: vol }));
  },
  setRepeat(r: PlayerState['repeat']) {
    playerStore.set((p) => ({ ...p, repeat: r }));
  },
  setContinuous(continuous: boolean) {
    playerStore.set((p) => ({ ...p, continuous }));
  },
  /** Keeps the queue in sync when the list changes (reorder, delete, add). */
  syncQueue(moduleId: string, all: string[]) {
    const s = playerStore.get();
    if (s.moduleId !== moduleId) return;
    // a chosen part (an artist, one track) only loses items that were removed
    const queue = s.scope === 'all' ? all : s.queue.filter((id) => all.includes(id));
    const curId = s.current?.id;
    const index = curId ? queue.indexOf(curId) : -1;
    if (curId && index < 0) {
      audio?.pause();
      playerStore.set((p) => ({ ...p, queue, index: -1, current: null, playing: false }));
      return;
    }
    playerStore.set((p) => ({ ...p, queue, index }));
  },
  stopAndClear() {
    audio?.pause();
    if (audio) audio.removeAttribute('src');
    playerStore.set((p) => ({ ...p, moduleId: null, queue: [], index: -1, current: null, playing: false, position: 0, duration: 0, error: null, scope: 'all', label: null }));
  },
};

/** Probes whether a direct URL is playable by this browser (8 s timeout). */
export function probeMediaUrl(url: string, kind: 'audio' | 'video'): Promise<{ ok: true; duration: number } | { ok: false; reason: 'format' | 'network' | 'timeout' }> {
  return new Promise((resolve) => {
    const m = document.createElement(kind);
    m.preload = 'metadata';
    m.muted = true;
    const done = (r: { ok: true; duration: number } | { ok: false; reason: 'format' | 'network' | 'timeout' }) => {
      window.clearTimeout(timer);
      m.removeAttribute('src');
      m.load();
      resolve(r);
    };
    const timer = window.setTimeout(() => done({ ok: false, reason: 'timeout' }), 8000);
    m.addEventListener('loadedmetadata', () => done({ ok: true, duration: Number.isFinite(m.duration) ? m.duration : 0 }));
    m.addEventListener('error', () => done({ ok: false, reason: m.error?.code === 4 ? 'format' : 'network' }));
    m.src = url;
  });
}

/** Reads the duration of a local media Blob. */
export function blobDuration(blob: Blob, kind: 'audio' | 'video'): Promise<number | null> {
  return new Promise((resolve) => {
    const m = document.createElement(kind);
    const url = URL.createObjectURL(blob);
    const done = (v: number | null) => {
      window.clearTimeout(timer);
      URL.revokeObjectURL(url);
      resolve(v);
    };
    const timer = window.setTimeout(() => done(null), 8000);
    m.preload = 'metadata';
    m.addEventListener('loadedmetadata', () => done(Number.isFinite(m.duration) ? m.duration : null));
    m.addEventListener('error', () => done(null));
    m.src = url;
  });
}
