import { createStore } from './store';
import { db } from '../data/db';
import type { MediaItem } from '../domain/types';

/**
 * Media coordinator (PRD M02): every player under Hamyar's control registers here and
 * starting one pauses the others. Autoplay never happens without a user action.
 */
interface Controllable {
  pause: () => void;
}
const registry = new Map<string, Controllable>();

export function registerMedia(id: string, c: Controllable): () => void {
  registry.set(id, c);
  return () => {
    if (registry.get(id) === c) registry.delete(id);
  };
}

export function claimPlayback(id: string) {
  for (const [key, c] of registry) if (key !== id) c.pause();
}

/** Wires a <video>/<audio> element into the coordinator. */
export function coordinateElement(id: string, el: HTMLMediaElement): () => void {
  const onPlay = () => claimPlayback(id);
  el.addEventListener('play', onPlay);
  const off = registerMedia(id, { pause: () => el.pause() });
  return () => {
    el.removeEventListener('play', onPlay);
    off();
  };
}

// ───────────────────────── central music player ─────────────────────────

export type PlayerError = 'source' | 'format' | 'network' | 'blocked' | 'missing' | null;

export interface PlayerState {
  moduleId: string | null;
  queue: string[];
  index: number;
  current: MediaItem | null;
  playing: boolean;
  loading: boolean;
  position: number;
  duration: number;
  volume: number;
  repeat: 'off' | 'one' | 'all';
  error: PlayerError;
}

export const playerStore = createStore<PlayerState>({
  moduleId: null,
  queue: [],
  index: -1,
  current: null,
  playing: false,
  loading: false,
  position: 0,
  duration: 0,
  volume: 0.8,
  repeat: 'all',
  error: null,
});

let audio: HTMLAudioElement | null = null;
let objectUrl: string | null = null;
const PLAYER_ID = 'music-player';

function el(): HTMLAudioElement {
  if (audio) return audio;
  audio = new Audio();
  audio.preload = 'metadata';
  audio.volume = playerStore.get().volume;
  const set = (patch: Partial<PlayerState>) => playerStore.set((s) => ({ ...s, ...patch }));
  audio.addEventListener('play', () => {
    claimPlayback(PLAYER_ID);
    set({ playing: true });
  });
  audio.addEventListener('pause', () => set({ playing: false }));
  audio.addEventListener('waiting', () => set({ loading: true }));
  audio.addEventListener('playing', () => set({ loading: false, error: null }));
  audio.addEventListener('loadedmetadata', () => {
    set({ duration: Number.isFinite(audio!.duration) ? audio!.duration : 0, loading: false });
    const cur = playerStore.get().current;
    if (cur && Number.isFinite(audio!.duration) && cur.duration !== audio!.duration) void db.media.update(cur.id, { duration: audio!.duration });
  });
  audio.addEventListener('timeupdate', () => set({ position: audio!.currentTime }));
  audio.addEventListener('ended', () => void onEnded());
  audio.addEventListener('error', () => {
    const code = audio!.error?.code;
    const err: PlayerError = code === 4 ? 'format' : code === 2 ? 'network' : 'source';
    set({ error: err, playing: false, loading: false });
  });
  registerMedia(PLAYER_ID, { pause: () => audio?.pause() });
  return audio;
}

async function resolveSource(item: MediaItem): Promise<string | null> {
  if (objectUrl) {
    URL.revokeObjectURL(objectUrl);
    objectUrl = null;
  }
  if (item.sourceType === 'file' && item.assetId) {
    const asset = await db.assets.get(item.assetId);
    if (!asset) return null;
    objectUrl = URL.createObjectURL(asset.blob);
    return objectUrl;
  }
  if (item.sourceType === 'url' && item.url) return item.url;
  return null;
}

async function loadIndex(index: number, autoplay: boolean) {
  const s = playerStore.get();
  const id = s.queue[index];
  if (!id) return;
  const item = await db.media.get(id);
  if (!item) return;
  playerStore.set((p) => ({ ...p, index, current: item, error: null, position: 0, duration: item.duration ?? 0, loading: true }));
  const src = await resolveSource(item);
  const a = el();
  if (!src) {
    playerStore.set((p) => ({ ...p, error: 'missing', loading: false, playing: false }));
    return;
  }
  a.src = src;
  setMediaSession(item);
  if (autoplay) {
    try {
      await a.play();
    } catch (e) {
      const name = (e as DOMException)?.name;
      playerStore.set((p) => ({ ...p, loading: false, playing: false, error: name === 'NotAllowedError' ? 'blocked' : p.error ?? 'source' }));
    }
  } else playerStore.set((p) => ({ ...p, loading: false }));
}

async function onEnded() {
  const s = playerStore.get();
  if (s.repeat === 'one') {
    const a = el();
    a.currentTime = 0;
    await a.play().catch(() => undefined);
    return;
  }
  const last = s.index >= s.queue.length - 1;
  if (last && s.repeat === 'off') {
    playerStore.set((p) => ({ ...p, playing: false }));
    return;
  }
  await loadIndex(last ? 0 : s.index + 1, true);
}

function setMediaSession(item: MediaItem) {
  if (!('mediaSession' in navigator)) return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({ title: item.title, artist: item.artist || 'Hamyar' });
    navigator.mediaSession.setActionHandler('play', () => void player.toggle());
    navigator.mediaSession.setActionHandler('pause', () => player.pause());
    navigator.mediaSession.setActionHandler('nexttrack', () => void player.next());
    navigator.mediaSession.setActionHandler('previoustrack', () => void player.prev());
  } catch {
    /* optional API */
  }
}

export const player = {
  /** Starts an item from a module's list — only call from a user action. */
  async play(moduleId: string, queue: string[], itemId: string) {
    const index = queue.indexOf(itemId);
    playerStore.set((p) => ({ ...p, moduleId, queue }));
    await loadIndex(Math.max(0, index), true);
  },
  async toggle() {
    const a = el();
    const s = playerStore.get();
    if (!s.current) return;
    if (a.paused) {
      try {
        if (!a.src) await loadIndex(s.index, true);
        else await a.play();
      } catch (e) {
        playerStore.set((p) => ({ ...p, error: (e as DOMException)?.name === 'NotAllowedError' ? 'blocked' : 'source' }));
      }
    } else a.pause();
  },
  pause() {
    audio?.pause();
  },
  async resume() {
    if (audio && audio.src && audio.paused) await audio.play().catch(() => undefined);
  },
  async next() {
    const s = playerStore.get();
    if (!s.queue.length) return;
    await loadIndex((s.index + 1) % s.queue.length, true);
  },
  async prev() {
    const s = playerStore.get();
    if (!s.queue.length) return;
    const a = el();
    if (a.currentTime > 4) {
      a.currentTime = 0;
      return;
    }
    await loadIndex((s.index - 1 + s.queue.length) % s.queue.length, true);
  },
  seek(sec: number) {
    const a = el();
    if (Number.isFinite(sec)) a.currentTime = Math.max(0, sec);
  },
  setVolume(v: number) {
    const vol = Math.max(0, Math.min(1, v));
    el().volume = vol;
    playerStore.set((p) => ({ ...p, volume: vol }));
  },
  setRepeat(r: PlayerState['repeat']) {
    playerStore.set((p) => ({ ...p, repeat: r }));
  },
  /** Keeps the queue in sync when the list changes (reorder, delete). */
  syncQueue(moduleId: string, queue: string[]) {
    const s = playerStore.get();
    if (s.moduleId !== moduleId) return;
    const curId = s.current?.id;
    const index = curId ? queue.indexOf(curId) : -1;
    if (curId && index < 0) {
      audio?.pause();
      playerStore.set((p) => ({ ...p, queue, index: -1, current: null, playing: false }));
      return;
    }
    playerStore.set((p) => ({ ...p, queue, index }));
  },
  stopAndClear() {
    audio?.pause();
    if (audio) audio.removeAttribute('src');
    playerStore.set((p) => ({ ...p, moduleId: null, queue: [], index: -1, current: null, playing: false, position: 0, duration: 0, error: null }));
  },
};

/** Probes whether a direct URL is playable by this browser (8 s timeout). */
export function probeMediaUrl(url: string, kind: 'audio' | 'video'): Promise<{ ok: true; duration: number } | { ok: false; reason: 'format' | 'network' | 'timeout' }> {
  return new Promise((resolve) => {
    const m = document.createElement(kind);
    m.preload = 'metadata';
    m.muted = true;
    const done = (r: { ok: true; duration: number } | { ok: false; reason: 'format' | 'network' | 'timeout' }) => {
      window.clearTimeout(timer);
      m.removeAttribute('src');
      m.load();
      resolve(r);
    };
    const timer = window.setTimeout(() => done({ ok: false, reason: 'timeout' }), 8000);
    m.addEventListener('loadedmetadata', () => done({ ok: true, duration: Number.isFinite(m.duration) ? m.duration : 0 }));
    m.addEventListener('error', () => done({ ok: false, reason: m.error?.code === 4 ? 'format' : 'network' }));
    m.src = url;
  });
}

/** Reads the duration of a local media Blob. */
export function blobDuration(blob: Blob, kind: 'audio' | 'video'): Promise<number | null> {
  return new Promise((resolve) => {
    const m = document.createElement(kind);
    const url = URL.createObjectURL(blob);
    const done = (v: number | null) => {
      window.clearTimeout(timer);
      URL.revokeObjectURL(url);
      resolve(v);
    };
    const timer = window.setTimeout(() => done(null), 8000);
    m.preload = 'metadata';
    m.addEventListener('loadedmetadata', () => done(Number.isFinite(m.duration) ? m.duration : null));
    m.addEventListener('error', () => done(null));
    m.src = url;
  });
}
