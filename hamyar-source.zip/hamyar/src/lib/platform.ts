/**
 * Where the app runs and what the browser actually offers. Capabilities are detected,
 * never assumed: the UI shows a reason when something is missing.
 */
export const TARGET: 'app' | 'artifact' | 'mobile' = __HAMYAR_TARGET__;
export const IS_ARTIFACT = TARGET === 'artifact';
/** Phone build: the installable web app (iPhone) and the Android app share this bundle. */
export const IS_MOBILE = TARGET === 'mobile';
/** Inside the Android app: Capacitor injects window.Capacitor before any page script runs. */
export const IS_NATIVE = IS_MOBILE && !!(globalThis as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.();
export const APP_VERSION = __HAMYAR_VERSION__;

/** iPhone/iPad Safari (iPadOS reports itself as a Mac with touch). */
export function isIos(): boolean {
  if (typeof navigator === 'undefined') return false;
  return /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
}

/** Opened from the home screen (installed web app) rather than a browser tab. */
export function isStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  return window.matchMedia?.('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone === true;
}

type ClaudeRuntime = { use: (name: string) => Promise<unknown> };

function runtime(): ClaudeRuntime | null {
  const w = globalThis as unknown as { claude?: ClaudeRuntime };
  return w.claude && typeof w.claude.use === 'function' ? w.claude : null;
}

const cache = new Map<string, Promise<unknown>>();

/** Resolves a claude.ai artifact capability namespace, or null outside a viewer. */
export function claudeUse<T>(name: string): Promise<T | null> {
  const rt = runtime();
  if (!rt) return Promise.resolve(null);
  let p = cache.get(name);
  if (!p) {
    p = rt.use(name).catch(() => null);
    cache.set(name, p);
  }
  return p as Promise<T | null>;
}

export interface BrowserCaps {
  speechRecognition: boolean;
  mediaRecorder: boolean;
  getUserMedia: boolean;
  notifications: boolean;
  serviceWorker: boolean;
  secureContext: boolean;
  persistStorage: boolean;
  locks: boolean;
}

export function detectCaps(): BrowserCaps {
  const w = globalThis as unknown as Record<string, unknown> & { navigator?: Navigator; isSecureContext?: boolean };
  const nav = w.navigator;
  return {
    speechRecognition: IS_NATIVE || !!(w.SpeechRecognition || w.webkitSpeechRecognition),
    mediaRecorder: typeof w.MediaRecorder === 'function',
    getUserMedia: !!nav?.mediaDevices?.getUserMedia,
    notifications: IS_NATIVE || (typeof w.Notification === 'function' && !IS_ARTIFACT),
    serviceWorker: !!nav && 'serviceWorker' in nav && !IS_ARTIFACT && !IS_NATIVE,
    secureContext: !!w.isSecureContext,
    persistStorage: !!nav?.storage?.persist,
    locks: !!nav && 'locks' in nav,
  };
}

/** Picks a recording MIME type this browser really supports (no WebM assumption). */
export function pickRecorderMime(): string | null {
  const MR = (globalThis as unknown as { MediaRecorder?: typeof MediaRecorder }).MediaRecorder;
  if (!MR || typeof MR.isTypeSupported !== 'function') return null;
  const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4;codecs=mp4a.40.2', 'audio/mp4', 'audio/ogg;codecs=opus', 'audio/aac'];
  return candidates.find((t) => MR.isTypeSupported(t)) ?? null;
}

export function isOnline(): boolean {
  return typeof navigator === 'undefined' ? true : navigator.onLine !== false;
}
