import { createStore } from './store';

export interface ToastItem {
  id: number;
  kind: 'info' | 'success' | 'error' | 'warning' | 'reminder';
  text: string;
  detail?: string;
  action?: { label: string; run: () => void };
  timeout: number;
}

export const toastStore = createStore<ToastItem[]>([]);
let seq = 0;

export function toast(t: Omit<ToastItem, 'id' | 'timeout'> & { timeout?: number }) {
  const id = ++seq;
  const item: ToastItem = { timeout: t.kind === 'error' ? 7000 : t.kind === 'reminder' ? 12000 : 4000, ...t, id };
  toastStore.set((list) => [...list.slice(-3), item]);
  if (item.timeout > 0) setTimeout(() => dismissToast(id), item.timeout);
  return id;
}

export function dismissToast(id: number) {
  toastStore.set((list) => list.filter((x) => x.id !== id));
}

export interface ConfirmRequest {
  id: number;
  title: string;
  body?: string;
  confirmText: string;
  cancelText: string;
  danger?: boolean;
  /** when set, the person must type this word to enable the confirm button */
  typeToConfirm?: string;
  resolve: (ok: boolean) => void;
}

export const confirmStore = createStore<ConfirmRequest | null>(null);

export function askConfirm(req: Omit<ConfirmRequest, 'id' | 'resolve'>): Promise<boolean> {
  return new Promise((resolve) => {
    const prev = confirmStore.get();
    if (prev) prev.resolve(false);
    confirmStore.set({ ...req, id: ++seq, resolve });
  });
}

/** Set while the user has interacted at least once (sound and media need it). */
export const interactionStore = createStore(false);
if (typeof window !== 'undefined') {
  const mark = () => {
    interactionStore.set(true);
    window.removeEventListener('pointerdown', mark);
    window.removeEventListener('keydown', mark);
  };
  window.addEventListener('pointerdown', mark);
  window.addEventListener('keydown', mark);
}

export interface TextRequest {
  id: number;
  title: string;
  label: string;
  initial: string;
  confirmText: string;
  cancelText: string;
  maxLength: number;
  resolve: (value: string | null) => void;
}

export const textPromptStore = createStore<TextRequest | null>(null);

/** In-page replacement for window.prompt (which embedded viewers block). */
export function askText(req: Omit<TextRequest, 'id' | 'resolve' | 'maxLength'> & { maxLength?: number }): Promise<string | null> {
  return new Promise((resolve) => {
    const prev = textPromptStore.get();
    if (prev) prev.resolve(null);
    textPromptStore.set({ maxLength: 120, ...req, id: ++seq, resolve });
  });
}
