/**
 * Rebuilds readable page text from pdf.js text items.
 *
 * Many Persian/Arabic PDFs (including ones printed by browsers) store each shaped glyph
 * as its own item, in visual left-to-right order, using Arabic presentation forms.
 * Joining items naively gives reversed words with spaces between letters. This groups
 * items into lines by position, orders them right-to-left on RTL lines (keeping embedded
 * Latin/number runs left-to-right), inserts spaces only where there is a visible gap and
 * normalizes presentation forms (NFKC) back to ordinary letters.
 */

export interface RawTextItem {
  str: string;
  transform: number[];
  width: number;
  height?: number;
  hasEOL?: boolean;
}

const RTL_CHAR = /[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/;
const STRONG_LTR = /[A-Za-z\u00C0-\u024F]/;

const MIRROR: Record<string, string> = { '(': ')', ')': '(', '[': ']', ']': '[', '{': '}', '}': '{', '<': '>', '>': '<', '«': '»', '»': '«', '‹': '›', '›': '‹' };

/** Glyphs drawn mirrored in right-to-left runs map back to their logical character. */
function unmirror(s: string): string {
  return s.length === 1 && MIRROR[s] ? MIRROR[s]! : s;
}

function isRtl(s: string): boolean {
  return RTL_CHAR.test(s);
}

interface Placed {
  str: string;
  x: number;
  y: number;
  w: number;
  size: number;
}

function place(it: RawTextItem): Placed {
  const [a = 1, b = 0, c = 0, d = 1, e = 0, f = 0] = it.transform;
  const size = Math.max(1, Math.hypot(c, d) || it.height || Math.hypot(a, b));
  return { str: it.str, x: e, y: f, w: Math.max(0, it.width), size };
}

function orderLine(items: Placed[]): string {
  const vis = [...items].sort((p, q) => p.x - q.x);
  const rtlCount = vis.reduce((n, p) => n + (isRtl(p.str) ? p.str.length : 0), 0);
  const ltrCount = vis.reduce((n, p) => n + (STRONG_LTR.test(p.str) ? p.str.length : 0), 0);
  // tokens in visual order, with gap-based spaces
  const tokens: { s: string; rtl: boolean | null }[] = [];
  vis.forEach((p, i) => {
    if (i > 0) {
      const prev = vis[i - 1]!;
      const gap = p.x - (prev.x + prev.w);
      if (gap > Math.min(prev.size, p.size) * 0.18) tokens.push({ s: ' ', rtl: null });
    }
    tokens.push({ s: p.str, rtl: isRtl(p.str) ? true : STRONG_LTR.test(p.str) || /\d/.test(p.str) ? false : null });
  });
  if (rtlCount <= ltrCount) return tokens.map((t) => t.s).join('');
  // RTL line: neutral tokens follow their neighbours; LTR runs keep their internal order.
  const runs: { rtl: boolean; parts: string[] }[] = [];
  tokens.forEach((t, i) => {
    let dir = t.rtl;
    if (dir === null) {
      const before = tokens.slice(0, i).reverse().find((x) => x.rtl !== null)?.rtl;
      const after = tokens.slice(i + 1).find((x) => x.rtl !== null)?.rtl;
      dir = before === false && after === false ? false : true;
    }
    const last = runs[runs.length - 1];
    if (last && last.rtl === dir) last.parts.push(t.s);
    else runs.push({ rtl: dir, parts: [t.s] });
  });
  return runs
    .reverse()
    .map((r) => (r.rtl ? r.parts.reverse().map(unmirror).join('') : r.parts.join('')))
    .join('');
}

export function reconstructPageText(rawItems: RawTextItem[]): string {
  const items = rawItems.filter((it) => it.str && it.str.trim() !== '' && Array.isArray(it.transform)).map(place);
  if (!items.length) return '';
  // group into lines (PDF y grows upward)
  const sorted = [...items].sort((p, q) => q.y - p.y);
  const lines: { y: number; size: number; items: Placed[] }[] = [];
  for (const it of sorted) {
    const line = lines.find((l) => Math.abs(l.y - it.y) < Math.max(l.size, it.size) * 0.5);
    if (line) {
      line.items.push(it);
      line.size = Math.max(line.size, it.size);
    } else lines.push({ y: it.y, size: it.size, items: [it] });
  }
  lines.sort((p, q) => q.y - p.y);
  const out: string[] = [];
  lines.forEach((l, i) => {
    if (i > 0) {
      const gap = lines[i - 1]!.y - l.y;
      if (gap > l.size * 2.2) out.push('');
    }
    out.push(orderLine(l.items).replace(/\s+/g, ' ').trim());
  });
  return out
    .join('\n')
    .normalize('NFKC')
    .replace(/ـ/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}
