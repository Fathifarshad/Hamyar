import { createStore } from './store';
import { IS_ARTIFACT, IS_MOBILE, claudeUse } from './platform';
import { summarizeDocument, type FinalSummary } from '../../shared/summaryCore.mjs';
import { LIMITS } from '../config/limits';
import { kvGet, kvSet } from '../data/db';

/**
 * Client for the two AI features. In the runnable app they go to the local server
 * (keys stay server-side). In the claude.ai preview, summaries use the viewer's Claude
 * through the `sample` capability; file transcription is unavailable there.
 * No fallback ever invents output.
 */

export type AiReason =
  | 'checking'
  | 'ok'
  | 'not_configured'
  | 'server_missing'
  | 'offline'
  | 'preview_claude'
  | 'preview_unavailable'
  | 'mobile_unavailable'
  | 'not_granted';

export interface AiFeatureStatus {
  available: boolean;
  provider: string | null;
  reason: AiReason;
}

export interface AiStatus {
  summary: AiFeatureStatus;
  transcription: AiFeatureStatus;
  checkedAt: number;
}

const checking: AiFeatureStatus = { available: false, provider: null, reason: 'checking' };
export const aiStatusStore = createStore<AiStatus>({ summary: checking, transcription: checking, checkedAt: 0 });

type SampleFn = ((input: string, opts?: Record<string, unknown>) => Promise<{ text: string }>) & {
  json: <T>(input: string, opts?: Record<string, unknown>) => Promise<T>;
};

let inflight: Promise<AiStatus> | null = null;

export function refreshAiStatus(force = false): Promise<AiStatus> {
  const cur = aiStatusStore.get();
  if (!force && cur.checkedAt && Date.now() - cur.checkedAt < 30_000) return Promise.resolve(cur);
  if (inflight) return inflight;
  inflight = (async () => {
    let next: AiStatus;
    if (IS_MOBILE) {
      // The phone apps have no server and never hold API keys.
      next = {
        summary: { available: false, provider: null, reason: 'mobile_unavailable' },
        transcription: { available: false, provider: null, reason: 'mobile_unavailable' },
        checkedAt: Date.now(),
      };
    } else if (IS_ARTIFACT) {
      const sample = await claudeUse<SampleFn>('sample');
      next = {
        summary: sample ? { available: true, provider: 'Claude', reason: 'preview_claude' } : { available: false, provider: null, reason: 'preview_unavailable' },
        transcription: { available: false, provider: null, reason: 'preview_unavailable' },
        checkedAt: Date.now(),
      };
    } else if (!navigator.onLine) {
      next = { summary: { available: false, provider: null, reason: 'offline' }, transcription: { available: false, provider: null, reason: 'offline' }, checkedAt: Date.now() };
    } else {
      try {
        const res = await fetch('./api/health', { cache: 'no-store' });
        if (!res.ok) throw new Error(String(res.status));
        const h = (await res.json()) as { summary: { available: boolean; provider: string | null }; transcription: { available: boolean; provider: string | null } };
        next = {
          summary: { available: h.summary.available, provider: h.summary.provider, reason: h.summary.available ? 'ok' : 'not_configured' },
          transcription: { available: h.transcription.available, provider: h.transcription.provider, reason: h.transcription.available ? 'ok' : 'not_configured' },
          checkedAt: Date.now(),
        };
      } catch {
        next = {
          summary: { available: false, provider: null, reason: 'server_missing' },
          transcription: { available: false, provider: null, reason: 'server_missing' },
          checkedAt: Date.now(),
        };
      }
    }
    aiStatusStore.set(next);
    inflight = null;
    return next;
  })();
  return inflight;
}

export class AiError extends Error {
  constructor(
    readonly code: string,
    readonly retryable = false,
  ) {
    super(code);
  }
}

function usageKey(): string {
  return `usage:${new Date().toISOString().slice(0, 10)}`;
}

export async function getUsage(): Promise<{ summaries: number; transcriptionSec: number }> {
  return kvGet(usageKey(), { summaries: 0, transcriptionSec: 0 });
}

async function addUsage(patch: { summaries?: number; transcriptionSec?: number }) {
  const cur = await getUsage();
  await kvSet(usageKey(), { summaries: cur.summaries + (patch.summaries ?? 0), transcriptionSec: cur.transcriptionSec + (patch.transcriptionSec ?? 0) });
}

interface JobView<T> {
  id: string;
  state: 'queued' | 'processing' | 'succeeded' | 'failed' | 'cancelled';
  progress?: { done: number; total: number };
  result?: T;
  error?: { code: string; retryable: boolean };
}

async function pollJob<T>(jobId: string, signal: AbortSignal | undefined, onProgress?: (done: number, total: number) => void): Promise<T> {
  for (;;) {
    if (signal?.aborted) {
      await fetch(`./api/jobs/${encodeURIComponent(jobId)}/cancel`, { method: 'POST' }).catch(() => undefined);
      throw new AiError('CANCELLED');
    }
    await new Promise((r) => setTimeout(r, 1200));
    let res: Response;
    try {
      res = await fetch(`./api/jobs/${encodeURIComponent(jobId)}`, { cache: 'no-store' });
    } catch {
      throw new AiError('NETWORK', true);
    }
    if (res.status === 404) throw new AiError('JOB_EXPIRED', true);
    const job = (await res.json()) as JobView<T>;
    if (job.progress) onProgress?.(job.progress.done, job.progress.total);
    if (job.state === 'succeeded' && job.result) return job.result;
    if (job.state === 'failed') throw new AiError(job.error?.code ?? 'FAILED', job.error?.retryable ?? false);
    if (job.state === 'cancelled') throw new AiError('CANCELLED');
  }
}

async function postJson(url: string, body: unknown): Promise<{ jobId: string }> {
  let res: Response;
  try {
    res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  } catch {
    throw new AiError('NETWORK', true);
  }
  const data = (await res.json().catch(() => ({}))) as { jobId?: string; error?: { code: string; retryable?: boolean } };
  if (res.status !== 202 || !data.jobId) throw new AiError(data.error?.code ?? `HTTP_${res.status}`, data.error?.retryable ?? res.status >= 500);
  return { jobId: data.jobId };
}

export interface SummarizeInput {
  pages: { n: number; text: string }[];
  totalPages: number;
  language: 'fa' | 'en';
  length: 'short' | 'medium';
  signal?: AbortSignal;
  onProgress?: (done: number, total: number) => void;
}

export async function summarizePages(input: SummarizeInput): Promise<{ summary: FinalSummary; provider: string }> {
  if (IS_MOBILE) throw new AiError('CAPABILITY_UNAVAILABLE');
  const usage = await getUsage();
  if (usage.summaries >= LIMITS.dailySummaries) throw new AiError('QUOTA_EXCEEDED');
  if (IS_ARTIFACT) {
    const sample = await claudeUse<SampleFn>('sample');
    if (!sample) throw new AiError('CAPABILITY_UNAVAILABLE');
    try {
      const summary = await summarizeDocument({
        pages: input.pages,
        totalPages: input.totalPages,
        language: input.language,
        length: input.length,
        maxChars: LIMITS.summaryChunkChars,
        signal: input.signal,
        onProgress: input.onProgress,
        // Options must be a plain object with only valid members: no `signal: undefined`.
        complete: ({ system, user, signal }) => sample.json(`${system}\n\n${user}`, signal ? { signal, cache: { gcTime: 86_400_000 } } : { cache: { gcTime: 86_400_000 } }),
      });
      await addUsage({ summaries: 1 });
      return { summary, provider: 'Claude' };
    } catch (e) {
      const code = (e as { code?: string }).code ?? 'FAILED';
      if (code === 'cancelled' || code === 'CANCELLED') throw new AiError('CANCELLED');
      if (code === 'not_granted' || code === 'sampling_disabled') {
        aiStatusStore.set({ ...aiStatusStore.get(), summary: { available: false, provider: null, reason: 'not_granted' } });
        throw new AiError('NOT_GRANTED');
      }
      if (code === 'rate_limited') throw new AiError('RATE_LIMITED', true);
      if (code === 'prompt_too_large') throw new AiError('TOO_LARGE');
      if (code === 'refused') throw new AiError('REFUSED');
      if (code === 'session_expired') throw new AiError('SESSION_EXPIRED');
      if (code === 'INVALID_OUTPUT' || code === 'invalid_json') throw new AiError('INVALID_OUTPUT', true);
      throw new AiError('PROVIDER_ERROR', true);
    }
  }
  const { jobId } = await postJson('./api/summaries', { pages: input.pages, totalPages: input.totalPages, language: input.language, length: input.length });
  const result = await pollJob<{ summary: FinalSummary; provider: string }>(jobId, input.signal, input.onProgress);
  await addUsage({ summaries: 1 });
  return result;
}

export async function transcribeAudio(blob: Blob, opts: { language: 'fa' | 'en'; durationSec: number; filename: string; signal?: AbortSignal }): Promise<{ text: string; provider: string }> {
  if (IS_ARTIFACT || IS_MOBILE) throw new AiError('CAPABILITY_UNAVAILABLE');
  const usage = await getUsage();
  if (usage.transcriptionSec + opts.durationSec > LIMITS.dailyTranscriptionMinutes * 60) throw new AiError('QUOTA_EXCEEDED');
  if (blob.size > LIMITS.transcriptionBytes) throw new AiError('TOO_LARGE');
  const qs = new URLSearchParams({ lang: opts.language, duration: String(Math.round(opts.durationSec)), name: opts.filename.slice(0, 100) });
  let res: Response;
  try {
    res = await fetch(`./api/transcriptions?${qs.toString()}`, { method: 'POST', headers: { 'content-type': blob.type || 'application/octet-stream' }, body: blob, signal: opts.signal });
  } catch (e) {
    if ((e as DOMException)?.name === 'AbortError') throw new AiError('CANCELLED');
    throw new AiError('NETWORK', true);
  }
  const data = (await res.json().catch(() => ({}))) as { jobId?: string; error?: { code: string; retryable?: boolean } };
  if (res.status !== 202 || !data.jobId) throw new AiError(data.error?.code ?? `HTTP_${res.status}`, data.error?.retryable ?? res.status >= 500);
  const out = await pollJob<{ text: string; provider: string }>(data.jobId, opts.signal);
  await addUsage({ transcriptionSec: opts.durationSec });
  return out;
}
