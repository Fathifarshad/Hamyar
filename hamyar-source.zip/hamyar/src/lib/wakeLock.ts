/**
 * Keeps the screen on while a video plays — a film would otherwise dim and lock the phone
 * after a minute without a touch. Where the browser has no Screen Wake Lock this does nothing.
 */
interface Sentinel {
  released: boolean;
  release(): Promise<void>;
}

let sentinel: Sentinel | null = null;
let wanted = false;

async function acquire(): Promise<void> {
  const wl = (typeof navigator === 'undefined' ? undefined : (navigator as Navigator & { wakeLock?: { request(type: 'screen'): Promise<Sentinel> } }).wakeLock);
  if (!wl || (sentinel && !sentinel.released)) return;
  try {
    const s = await wl.request('screen');
    if (!wanted) void s.release().catch(() => undefined);
    else sentinel = s;
  } catch {
    sentinel = null; // refused (battery saver, hidden page…): playback is not affected
  }
}

export function holdScreenOn(): void {
  wanted = true;
  void acquire();
}

export function releaseScreenOn(): void {
  wanted = false;
  const s = sentinel;
  sentinel = null;
  void s?.release().catch(() => undefined);
}

// The browser drops the lock whenever the page is hidden; take it back when the page returns mid-playback.
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (wanted && document.visibilityState === 'visible') void acquire();
  });
}
