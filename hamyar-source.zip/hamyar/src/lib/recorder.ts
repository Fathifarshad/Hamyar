import { pickRecorderMime } from './platform';

export interface RecorderHandle {
  mime: string;
  /** resolves with the recorded audio */
  stop: () => Promise<Blob>;
  /** stops without keeping anything and releases the microphone */
  cancel: () => void;
}

export interface RecorderOptions {
  maxMs: number;
  maxBytes: number;
  onTick?: (elapsedMs: number) => void;
  onLevel?: (level: number) => void;
  /** called when a limit stops the recording on its own */
  onAutoStop?: (reason: 'time' | 'size', blob: Blob) => void;
}

export class RecorderError extends Error {
  constructor(readonly code: 'unsupported' | 'denied' | 'no-device' | 'failed') {
    super(code);
  }
}

/** Starts a MediaRecorder session with a supported MIME type and hard time/size limits. */
export async function startRecording(opts: RecorderOptions): Promise<RecorderHandle> {
  const mime = pickRecorderMime();
  if (!mime || !navigator.mediaDevices?.getUserMedia) throw new RecorderError('unsupported');
  let stream: MediaStream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
  } catch (e) {
    const name = (e as DOMException)?.name;
    throw new RecorderError(name === 'NotAllowedError' || name === 'SecurityError' ? 'denied' : name === 'NotFoundError' ? 'no-device' : 'failed');
  }
  const rec = new MediaRecorder(stream, { mimeType: mime });
  const chunks: Blob[] = [];
  let bytes = 0;
  const started = performance.now();
  let finished = false;
  let resolveStop: ((b: Blob) => void) | null = null;

  let ctx: AudioContext | null = null;
  let raf = 0;
  try {
    ctx = new AudioContext();
    const src = ctx.createMediaStreamSource(stream);
    const an = ctx.createAnalyser();
    an.fftSize = 256;
    src.connect(an);
    const buf = new Uint8Array(an.frequencyBinCount);
    const loop = () => {
      an.getByteTimeDomainData(buf);
      let peak = 0;
      for (const v of buf) peak = Math.max(peak, Math.abs(v - 128));
      opts.onLevel?.(Math.min(1, peak / 64));
      opts.onTick?.(performance.now() - started);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
  } catch {
    ctx = null;
  }

  const release = () => {
    cancelAnimationFrame(raf);
    stream.getTracks().forEach((t) => t.stop());
    ctx?.close().catch(() => undefined);
  };

  const timer = window.setTimeout(() => autoStop('time'), opts.maxMs);

  const finish = (): Promise<Blob> =>
    new Promise((resolve) => {
      if (finished) return resolve(new Blob(chunks, { type: mime }));
      finished = true;
      window.clearTimeout(timer);
      resolveStop = resolve;
      if (rec.state !== 'inactive') rec.stop();
      else resolve(new Blob(chunks, { type: mime }));
    });

  async function autoStop(reason: 'time' | 'size') {
    const blob = await finish();
    opts.onAutoStop?.(reason, blob);
  }

  rec.ondataavailable = (e) => {
    if (e.data && e.data.size) {
      chunks.push(e.data);
      bytes += e.data.size;
      if (bytes >= opts.maxBytes && !finished) void autoStop('size');
    }
  };
  rec.onstop = () => {
    release();
    resolveStop?.(new Blob(chunks, { type: mime }));
  };
  rec.start(1000);

  return {
    mime,
    stop: finish,
    cancel: () => {
      finished = true;
      window.clearTimeout(timer);
      rec.ondataavailable = null;
      rec.onstop = null;
      try {
        if (rec.state !== 'inactive') rec.stop();
      } catch {
        /* already stopped */
      }
      release();
    },
  };
}
