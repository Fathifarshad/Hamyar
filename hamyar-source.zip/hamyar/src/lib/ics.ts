import type { Medication, ScheduleRule, Task } from '../domain/types';
import { currentRule } from '../domain/recurrence';
import { addDaysISO, weekdayOfISO } from '../domain/time';
import { saveFile } from './download';

/**
 * Calendar file (iCalendar, RFC 5545) for tasks and medication times. Importing it into
 * the phone's own calendar gives dependable alerts even when Hamyar is closed — the
 * reliable reminder path on iPhone, where web apps cannot schedule notifications.
 * Times are "floating" local times: 08:00 stays 08:00 in the phone's time zone.
 */

export interface IcsEvent {
  uid: string;
  title: string;
  description?: string;
  /** first local date YYYY-MM-DD */
  date: string;
  /** HH:mm, or null for an all-day item */
  time: string | null;
  durationMin?: number;
  repeat?: { freq: 'DAILY' | 'WEEKLY'; byDay?: number[]; until?: string | null } | null;
  /** minutes before the start; null = no alert */
  alarmBefore?: number | null;
}

const DAYS = ['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'];

function escapeText(s: string): string {
  return s.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');
}

/** Folds a content line at 75 octets without splitting a UTF-8 character. */
export function foldLine(line: string): string {
  const enc = new TextEncoder();
  const parts: string[] = [];
  let cur = '';
  let bytes = 0;
  let limit = 75;
  for (const ch of line) {
    const n = enc.encode(ch).length;
    if (bytes + n > limit) {
      parts.push(cur);
      cur = '';
      bytes = 0;
      limit = 74; // continuation lines start with a space
    }
    cur += ch;
    bytes += n;
  }
  parts.push(cur);
  return parts.join('\r\n ');
}

const compactDate = (iso: string) => iso.replace(/-/g, '');
const compactTime = (hhmm: string) => `${hhmm.replace(':', '')}00`;

function utcStamp(d: Date): string {
  return d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
}

function trigger(minutesBefore: number): string {
  return minutesBefore > 0 ? `-PT${minutesBefore}M` : 'PT0M';
}

export function buildIcs(events: IcsEvent[], now = new Date()): string {
  const lines: string[] = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Hamyar//Hamyar MVP//FA', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH'];
  for (const e of events) {
    lines.push('BEGIN:VEVENT', `UID:${e.uid}`, `DTSTAMP:${utcStamp(now)}`);
    if (e.time) {
      lines.push(`DTSTART:${compactDate(e.date)}T${compactTime(e.time)}`, `DURATION:PT${e.durationMin ?? 15}M`);
    } else {
      lines.push(`DTSTART;VALUE=DATE:${compactDate(e.date)}`, `DTEND;VALUE=DATE:${compactDate(addDaysISO(e.date, 1))}`);
    }
    if (e.repeat) {
      const parts = [`FREQ=${e.repeat.freq}`];
      if (e.repeat.freq === 'WEEKLY' && e.repeat.byDay?.length) parts.push(`BYDAY=${[...new Set(e.repeat.byDay)].sort((a, b) => a - b).map((d) => DAYS[d]).join(',')}`);
      if (e.repeat.until) parts.push(`UNTIL=${compactDate(e.repeat.until)}${e.time ? 'T235959' : ''}`);
      lines.push(`RRULE:${parts.join(';')}`);
    }
    lines.push(`SUMMARY:${escapeText(e.title)}`);
    if (e.description) lines.push(`DESCRIPTION:${escapeText(e.description)}`);
    if (e.alarmBefore !== null && e.alarmBefore !== undefined) {
      // all-day items alert at 09:00 on the day
      lines.push('BEGIN:VALARM', 'ACTION:DISPLAY', `DESCRIPTION:${escapeText(e.title)}`, `TRIGGER:${e.time ? trigger(e.alarmBefore) : 'PT9H'}`, 'END:VALARM');
    }
    lines.push('END:VEVENT');
  }
  lines.push('END:VCALENDAR');
  return lines.map(foldLine).join('\r\n') + '\r\n';
}

/** First date on or after `from` that a weekly rule actually uses (RFC: DTSTART must be an occurrence). */
function firstWeeklyDate(from: string, weekdays: number[]): string {
  for (let i = 0; i < 7; i++) {
    const d = addDaysISO(from, i);
    if (weekdays.includes(weekdayOfISO(d))) return d;
  }
  return from;
}

function eventsForRule(uidBase: string, rule: ScheduleRule, title: string, description: string | undefined, alarmBefore: number | null, today: string): IcsEvent[] {
  const repeat =
    rule.freq === 'daily' ? { freq: 'DAILY' as const, until: rule.endDate } : rule.freq === 'weekly' ? { freq: 'WEEKLY' as const, byDay: rule.weekdays, until: rule.endDate } : null;
  // Repeating schedules start from today (no alerts for the past); one-off items keep their date.
  let start = repeat && rule.startDate < today ? today : rule.startDate;
  if (rule.freq === 'weekly') start = firstWeeklyDate(start, rule.weekdays);
  const times = rule.times.length ? rule.times : [null];
  return times.map((time) => ({ uid: `${uidBase}-${time ? time.replace(':', '') : 'day'}@hamyar.app`, title, description, date: start, time, repeat, alarmBefore }));
}

export function taskCalendarEvents(task: Task, today: string, fa: boolean): IcsEvent[] {
  const rule = task.revisions ? currentRule(task.revisions) : null;
  if (!rule) return [];
  return eventsForRule(`task-${task.id}`, rule, task.title, task.notes || (fa ? 'از همیار' : 'From Hamyar'), task.reminderOffset, today);
}

export function medicationCalendarEvents(med: Medication, today: string, fa: boolean): IcsEvent[] {
  const rule = currentRule(med.revisions);
  if (!rule || !med.active) return [];
  const generic = fa ? 'یادآوری دارو' : 'Medication reminder';
  const title = med.showNameInNotification ? `${generic}: ${med.name}` : generic;
  const description = med.showNameInNotification ? [med.dosageText, med.unitText].filter(Boolean).join(' ') || undefined : fa ? 'از همیار' : 'From Hamyar';
  // The point of adding doses to the phone calendar is the alert, so every dose gets one.
  return eventsForRule(`med-${med.id}`, rule, title, description, 0, today);
}

/** Offers the calendar file; the phone opens it in its Calendar app to add the events. */
export function saveCalendar(filename: string, events: IcsEvent[]): Promise<'saved' | 'declined' | 'unavailable' | 'empty'> {
  if (!events.length) return Promise.resolve('empty');
  return saveFile(filename, buildIcs(events), 'text/calendar');
}
