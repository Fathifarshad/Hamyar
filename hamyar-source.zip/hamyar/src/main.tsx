import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '@fontsource-variable/vazirmatn';
import './styles/tokens.css';
import './styles/base.css';
import './styles/components.css';
import './styles/shell.css';
import './styles/modules.css';
import App from './App';
import { IS_NATIVE } from './lib/platform';
import { registerServiceWorker, requestPersistentStorage } from './lib/pwa';

if (IS_NATIVE) document.documentElement.classList.add('is-native');

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

// Installable web app: offline start and notification clicks. Never caches private data.
registerServiceWorker();
requestPersistentStorage();

// Android app: phone reminders, back button, share sheet (loaded only inside the app).
if (IS_NATIVE) {
  void import('./lib/native').then((m) => m.initNative()).catch((e) => console.warn('[hamyar] native init failed', (e as Error)?.message));
}
