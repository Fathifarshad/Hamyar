import { db, nowIso, uid } from './db';
import { createModule } from './modules';
import { LIMITS } from '../config/limits';
import type { InputLanguage, Locale, ModuleInstance, ModuleType } from '../domain/types';
import { DST_POLICY } from '../domain/types';
import { addDaysISO, localTimeHHMM, todayISO } from '../domain/time';
import { MODULE_TEXT } from '../modules/registry';
import { saveAsset } from './assets';
import { importPdf } from '../modules/pdf/data';
import { nextJalaliMonthDay } from '../domain/jalali';

/**
 * Example content, created only when the person asks for it (or in the claude.ai preview).
 * Every item is visibly marked as an example.
 */

const SAMPLE_TYPES: ModuleType[] = ['tasks', 'calendar', 'notes', 'music', 'pdf', 'checklists', 'habits', 'medications', 'focus', 'weather'];

/** A short pentatonic tune rendered to 16-bit PCM WAV — generated here, no external file. */
export function synthMelodyWav(seconds = 14): Blob {
  const rate = 22050;
  const n = Math.floor(seconds * rate);
  const data = new Int16Array(n);
  const notes = [392, 440, 523.25, 587.33, 659.25, 587.33, 523.25, 440, 392, 523.25, 659.25, 783.99, 659.25, 587.33, 523.25, 440];
  const beat = 0.42;
  for (let i = 0; i < n; i++) {
    const tsec = i / rate;
    const k = Math.floor(tsec / beat);
    const f = notes[k % notes.length]!;
    const local = tsec - k * beat;
    const env = Math.min(1, local * 30) * Math.exp(-local * 3.2);
    const bass = 0.25 * Math.sin(2 * Math.PI * (notes[(Math.floor(k / 4) * 4) % notes.length]! / 2) * tsec) * Math.exp(-((tsec % (beat * 4)) * 0.9));
    const s = 0.55 * env * (Math.sin(2 * Math.PI * f * tsec) + 0.3 * Math.sin(4 * Math.PI * f * tsec)) + bass;
    const fade = Math.min(1, (seconds - tsec) / 1.2, tsec / 0.2);
    data[i] = Math.max(-1, Math.min(1, s * 0.6 * fade)) * 32767;
  }
  const buf = new ArrayBuffer(44 + data.byteLength);
  const v = new DataView(buf);
  const w = (o: number, s: string) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF');
  v.setUint32(4, 36 + data.byteLength, true);
  w(8, 'WAVE');
  w(12, 'fmt ');
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, 1, true);
  v.setUint32(24, rate, true);
  v.setUint32(28, rate * 2, true);
  v.setUint16(32, 2, true);
  v.setUint16(34, 16, true);
  w(36, 'data');
  v.setUint32(40, data.byteLength, true);
  new Int16Array(buf, 44).set(data);
  return new Blob([buf], { type: 'audio/wav' });
}

async function ensureModules(locale: Locale, inputLanguage: InputLanguage): Promise<Map<ModuleType, ModuleInstance>> {
  const all = await db.modules.toArray();
  const out = new Map<ModuleType, ModuleInstance>();
  let live = all.filter((m) => m.active === 1 && !m.archivedAt).length;
  for (const type of SAMPLE_TYPES) {
    const existing = all.find((m) => m.type === type && !m.archivedAt);
    if (existing) {
      out.set(type, existing);
      continue;
    }
    if (all.length + out.size >= LIMITS.maxTotalModules) break;
    const active = live < LIMITS.maxActiveModules;
    const mod = await createModule({ type, title: MODULE_TEXT[type].name[locale === 'fa' ? 0 : 1], active, inputLanguage, locale });
    if (active) live++;
    out.set(type, mod);
  }
  return out;
}

export async function loadSampleData(locale: Locale, tz: string): Promise<void> {
  const fa = locale === 'fa';
  const L = (a: string, b: string) => (fa ? a : b);
  const ex = L(' (نمونه)', ' (example)');
  const inputLanguage: InputLanguage = fa ? 'fa-IR' : 'en-US';
  const mods = await ensureModules(locale, inputLanguage);
  const now = Date.now();
  const today = todayISO(tz, now);
  const ts = nowIso();

  const tasks = mods.get('tasks');
  if (tasks) {
    const soon = localTimeHHMM(now + 2 * 3600_000 - ((now + 2 * 3600_000) % (15 * 60_000)), tz);
    const later = soon < '23:00' && soon > localTimeHHMM(now, tz) ? soon : null;
    const mk = (title: string, kind: 'task' | 'event', date: string | null, time: string | null, freq: 'once' | 'daily' | 'weekly' = 'once', reminder: number | null = 0, priority: 'low' | 'normal' | 'high' = 'normal') => ({
      id: uid(),
      moduleId: tasks.id,
      kind,
      title: title + ex,
      notes: '',
      priority,
      revisions: date ? [{ validFrom: 0, rule: { freq, startDate: date, endDate: null, weekdays: freq === 'weekly' ? [1, 3] : [], times: time ? [time] : [], timezone: tz } }] : null,
      reminderOffset: time ? reminder : null,
      dstPolicy: DST_POLICY,
      revision: 1,
      createdAt: ts,
      updatedAt: ts,
    });
    await db.tasks.bulkAdd([
      ...(later ? [mk(L('تماس با دفتر بیمه', 'Call the insurance office'), 'task' as const, today, later, 'once', 0, 'high')] : []),
      mk(L('جلسه هفتگی تیم', 'Weekly team meeting'), 'event', addDaysISO(today, 1), '09:00', 'once', 15),
      mk(L('پیاده‌روی عصر', 'Evening walk'), 'task', today, '18:30', 'daily', null),
      mk(L('خرید نان و میوه', 'Buy bread and fruit'), 'task', today, null),
      mk(L('کلاس زبان', 'Language class'), 'event', addDaysISO(today, 1), '17:00', 'weekly', 30),
      mk(L('خواندن فصل ۳ کتاب', 'Read chapter 3'), 'task', null, null),
    ]);
  }

  const notes = mods.get('notes');
  if (notes) {
    await db.notes.bulkAdd([
      { id: uid(), moduleId: notes.id, title: L('ایده‌های سفر نوروز', 'Spring trip ideas') + ex, body: L('شیراز و اصفهان؟\nبلیت قطار را زودتر بگیرم.\nفهرست وسایل در چک‌لیست.', 'Two cities or one?\nBook train tickets early.\nPacking list is in the checklist.'), tags: [L('سفر', 'travel')], pinned: true, createdAt: ts, updatedAt: ts },
      { id: uid(), moduleId: notes.id, title: L('نکته‌های جلسه', 'Meeting notes') + ex, body: L('گزارش ماهانه تا پنجشنبه.\nپیش‌نویس طرح جدید را برای سارا بفرستم.', 'Monthly report due Thursday.\nSend the new draft to Sara.'), tags: [L('کار', 'work')], pinned: false, createdAt: ts, updatedAt: ts },
    ]);
  }

  const checklists = mods.get('checklists');
  if (checklists) {
    const list = { id: uid(), moduleId: checklists.id, name: L('خرید هفته', 'Weekly groceries') + ex, archived: false, order: 0, createdAt: ts };
    await db.checklists.add(list);
    const items = fa ? ['شیر', 'نان سنگک', 'سبزی خوردن', 'چای', 'پنیر'] : ['Milk', 'Bread', 'Greens', 'Tea', 'Cheese'];
    await db.checkItems.bulkAdd(items.map((text, i) => ({ id: uid(), listId: list.id, moduleId: checklists.id, text, done: i === 1, order: i, createdAt: ts })));
  }

  const habits = mods.get('habits');
  if (habits) {
    const h1 = { id: uid(), moduleId: habits.id, name: L('ورزش', 'Exercise') + ex, order: 0, archived: false, createdAt: ts };
    const h2 = { id: uid(), moduleId: habits.id, name: L('مطالعه ۲۰ دقیقه', 'Read 20 minutes') + ex, order: 1, archived: false, createdAt: ts };
    await db.habits.bulkAdd([h1, h2]);
    const logs = [];
    for (let i = 1; i <= 5; i++) logs.push({ id: `${h1.id}|${addDaysISO(today, -i)}`, habitId: h1.id, moduleId: habits.id, date: addDaysISO(today, -i) });
    for (const i of [0, 2, 3]) logs.push({ id: `${h2.id}|${addDaysISO(today, -i)}`, habitId: h2.id, moduleId: habits.id, date: addDaysISO(today, -i) });
    await db.habitLogs.bulkAdd(logs);
    const counts = [6, 8, 5, 7, 9, 4, 3];
    await db.water.bulkPut(counts.map((c, i) => ({ id: `${habits.id}|${addDaysISO(today, i - 6)}`, moduleId: habits.id, date: addDaysISO(today, i - 6), count: c })));
  }

  const meds = mods.get('medications');
  if (meds) {
    await db.medications.add({
      id: uid(),
      moduleId: meds.id,
      name: L('داروی نمونه', 'Example medication'),
      dosageText: L('۱ عدد', '1 tablet'),
      unitText: '',
      notes: L('این فقط یک نمونه است؛ آن را حذف کنید و برنامه واقعی خود را وارد کنید.', 'This is only an example; delete it and enter your real schedule.'),
      revisions: [{ validFrom: 0, rule: { freq: 'daily', startDate: today, endDate: null, weekdays: [], times: ['08:00', '20:00'], timezone: tz } }],
      active: true,
      // No reminders for an example medicine: a real-looking dose alert for a drug the
      // person does not take would be confusing.
      reminderEnabled: false,
      showNameInNotification: false,
      dstPolicy: DST_POLICY,
      revision: 1,
      createdAt: ts,
      updatedAt: ts,
    });
  }

  const calendar = mods.get('calendar');
  if (calendar) {
    const nowruz = nextJalaliMonthDay(1, 1, today);
    const yalda = nextJalaliMonthDay(9, 30, today);
    await db.countdowns.bulkAdd([
      ...(nowruz ? [{ id: uid(), moduleId: calendar.id, title: L('نوروز', 'Nowruz'), date: nowruz, repeatYearly: true, calendar: 'jalali' as const, createdAt: ts }] : []),
      ...(yalda ? [{ id: uid(), moduleId: calendar.id, title: L('شب یلدا', 'Yalda night'), date: yalda, repeatYearly: true, calendar: 'jalali' as const, createdAt: ts }] : []),
      { id: uid(), moduleId: calendar.id, title: L('تولد مامان', 'Mom’s birthday') + ex, date: addDaysISO(today, 23), repeatYearly: true, calendar: fa ? 'jalali' : 'gregorian', createdAt: ts },
    ]);
  }

  const music = mods.get('music');
  if (music) {
    try {
      const blob = synthMelodyWav();
      const asset = await saveAsset({ moduleId: music.id, kind: 'audio', blob, name: 'sample-melody.wav', maxBytes: LIMITS.musicBytes, mime: 'audio/wav' });
      await db.media.add({
        id: uid(),
        moduleId: music.id,
        kind: 'audio',
        sourceType: 'file',
        assetId: asset.id,
        url: null,
        embedId: null,
        title: L('ملودی نمونه (ساخته‌شده در مرورگر)', 'Example melody (made in the browser)'),
        artist: L('همیار', 'Hamyar'),
        favorite: true,
        order: 0,
        position: 0,
        duration: 14,
        missingFile: false,
        createdAt: ts,
      });
    } catch {
      /* storage may be unavailable; skip the example track */
    }
  }

  const pdf = mods.get('pdf');
  if (pdf) {
    try {
      const res = await fetch(new URL('./samples/hamyar-sample-fa.pdf', window.location.href).toString());
      if (res.ok) {
        const blob = await res.blob();
        await importPdf(pdf, new File([blob], fa ? 'راهنمای مدیریت زمان (نمونه).pdf' : 'Time management guide (example).pdf', { type: 'application/pdf' }));
      }
    } catch {
      /* sample PDF is optional */
    }
  }
}
