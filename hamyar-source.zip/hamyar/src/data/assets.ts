import { db, nowIso, uid } from './db';
import { LIMITS } from '../config/limits';
import { DomainError, type Asset } from '../domain/types';
import { sha256 } from '../lib/hash';

/**
 * Stores real file bytes (Blob) in IndexedDB — not just a name or a temporary object URL.
 * The declared MIME type is not trusted: the first bytes are checked for known signatures.
 *
 * Nothing here reads a whole file into JavaScript memory: phones kill pages that do, and a
 * film can be far larger than the memory a web page is allowed to use.
 */

export type AssetKind = Asset['kind'];
export type FileFamily = 'pdf' | 'audio' | 'video' | 'av' | 'unknown';

const SIGNATURES: { kind: 'pdf' | 'audio' | 'video' | 'av'; test: (b: Uint8Array) => boolean; mime: string }[] = [
  { kind: 'pdf', mime: 'application/pdf', test: (b) => findAscii(b, '%PDF-', 1024) },
  { kind: 'audio', mime: 'audio/mpeg', test: (b) => ascii(b, 0, 'ID3') || (b[0] === 0xff && (b[1]! & 0xe0) === 0xe0) },
  { kind: 'audio', mime: 'audio/wav', test: (b) => ascii(b, 0, 'RIFF') && ascii(b, 8, 'WAVE') },
  { kind: 'video', mime: 'video/x-msvideo', test: (b) => ascii(b, 0, 'RIFF') && ascii(b, 8, 'AVI ') },
  { kind: 'audio', mime: 'audio/ogg', test: (b) => ascii(b, 0, 'OggS') },
  { kind: 'audio', mime: 'audio/flac', test: (b) => ascii(b, 0, 'fLaC') },
  { kind: 'audio', mime: 'audio/aac', test: (b) => b[0] === 0xff && (b[1]! & 0xf6) === 0xf0 },
  { kind: 'av', mime: 'video/mp4', test: (b) => ascii(b, 4, 'ftyp') },
  { kind: 'av', mime: 'video/webm', test: (b) => b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3 },
];

/** MP4-family "major brands" that only ever mean audio (M4A, M4B audiobook, M4P, F4A, F4B). */
const AUDIO_BRANDS = /^(M4A |M4B |M4P |F4A |F4B )$/;

function ascii(b: Uint8Array, offset: number, s: string): boolean {
  for (let i = 0; i < s.length; i++) if (b[offset + i] !== s.charCodeAt(i)) return false;
  return true;
}

function findAscii(b: Uint8Array, s: string, within: number): boolean {
  for (let i = 0; i <= Math.min(within, b.length - s.length); i++) if (ascii(b, i, s)) return true;
  return false;
}

/** Short technical name of whatever a browser threw (NotReadableError, QuotaExceededError…). */
export function errName(e: unknown): string {
  const x = e as { name?: unknown; inner?: { name?: unknown } } | null;
  const inner = x?.inner?.name;
  if (typeof inner === 'string' && inner && inner !== 'Error') return inner;
  return typeof x?.name === 'string' && x.name ? x.name : 'Error';
}

function isQuota(e: unknown): boolean {
  return errName(e) === 'QuotaExceededError';
}

/** Detects the real file family from its first bytes. Throws FILE_UNREADABLE when the bytes cannot be read. */
export async function sniff(file: Blob): Promise<{ family: FileFamily; mime: string }> {
  let head: Uint8Array;
  try {
    head = new Uint8Array(await file.slice(0, 1100).arrayBuffer());
  } catch (e) {
    throw new DomainError('FILE_UNREADABLE', undefined, { cause: errName(e), stage: 'sniff' });
  }
  for (const s of SIGNATURES) {
    if (s.test(head)) {
      if (s.kind === 'av') {
        // MP4/M4A share 'ftyp'; WebM/Matroska can be audio or video — the declared type breaks the tie,
        // and a few brands are audio for certain. Anything else stays ambiguous ('av').
        const declared = file.type || '';
        const brand = String.fromCharCode(...head.slice(8, 12));
        const audioish = declared.startsWith('audio/') || (ascii(head, 4, 'ftyp') && AUDIO_BRANDS.test(brand));
        return { family: declared.startsWith('video/') ? 'video' : audioish ? 'audio' : 'av', mime: declared || s.mime };
      }
      return { family: s.kind, mime: s.kind === 'pdf' ? s.mime : file.type || s.mime };
    }
  }
  return { family: 'unknown', mime: file.type || 'application/octet-stream' };
}

export async function storageUsed(): Promise<number> {
  let total = 0;
  await db.assets.each((a) => {
    total += a.size;
  });
  return total;
}

export async function storageEstimate(): Promise<{ usage: number; quota: number } | null> {
  try {
    const e = await navigator.storage?.estimate?.();
    return e && e.quota ? { usage: e.usage ?? 0, quota: e.quota } : null;
  } catch {
    return null;
  }
}

/** Files up to this size get a full SHA-256; bigger ones are identified by size plus three samples. */
const FULL_HASH_MAX = 8 * 1024 * 1024;
const SAMPLE = 256 * 1024;

/**
 * Content id of a stored file. A small file is hashed completely; a large one (a film) is
 * identified by its size and three 256 KiB samples (start, middle, end), so it is never read
 * into memory as a whole. Throws FILE_UNREADABLE when the file cannot be read.
 */
export async function fingerprint(blob: Blob): Promise<string> {
  try {
    if (blob.size <= FULL_HASH_MAX) return await sha256(blob);
    const mid = Math.max(0, Math.floor(blob.size / 2 - SAMPLE / 2));
    const sample = new Blob([blob.slice(0, SAMPLE), blob.slice(mid, mid + SAMPLE), blob.slice(blob.size - SAMPLE)]);
    return `s${blob.size}-${await sha256(sample)}`;
  } catch (e) {
    throw new DomainError('FILE_UNREADABLE', undefined, { cause: errName(e), stage: 'fingerprint' });
  }
}

const COPY_CHUNK = 4 * 1024 * 1024;

/**
 * Makes an independent copy of a Blob by reading it in 4 MiB pieces. Used when the browser cannot
 * store the picked file directly (a file handed over by a phone's file picker still points at
 * the original). Only one piece is held in memory at a time.
 */
export async function copyBlob(blob: Blob): Promise<Blob> {
  let copy = new Blob([], { type: blob.type });
  for (let at = 0; at < blob.size; at += COPY_CHUNK) {
    const piece = await blob.slice(at, Math.min(blob.size, at + COPY_CHUNK)).arrayBuffer();
    copy = new Blob([copy, piece], { type: blob.type });
  }
  return copy;
}

export interface SaveAssetInput {
  moduleId: string;
  kind: AssetKind;
  blob: Blob;
  name: string;
  maxBytes: number;
  mime?: string;
}

/** Writes the asset; if the browser rejects the picked file itself, retries with a plain copy of it. */
async function putAsset(asset: Asset): Promise<Asset> {
  try {
    await db.assets.add(asset);
    return asset;
  } catch (first) {
    if (isQuota(first)) throw new DomainError('BROWSER_STORAGE_FULL');
    let copy: Blob;
    try {
      copy = await copyBlob(asset.blob);
    } catch (e) {
      throw new DomainError('FILE_UNREADABLE', undefined, { cause: errName(e), stage: 'copy', first: errName(first) });
    }
    const stored = { ...asset, blob: copy };
    try {
      await db.assets.add(stored);
      return stored;
    } catch (second) {
      if (isQuota(second)) throw new DomainError('BROWSER_STORAGE_FULL');
      throw new DomainError('STORE_FAILED', undefined, { cause: errName(second), first: errName(first) });
    }
  }
}

/** Validates size and quota, fingerprints, and stores the bytes. Throws DomainError on failure. */
export async function saveAsset(input: SaveAssetInput): Promise<Asset> {
  if (input.blob.size === 0) throw new DomainError('EMPTY_FILE');
  if (input.blob.size > input.maxBytes) throw new DomainError('FILE_TOO_LARGE', undefined, { max: input.maxBytes });
  const used = await storageUsed();
  if (used + input.blob.size > LIMITS.accountStorageBytes) throw new DomainError('QUOTA_EXCEEDED', undefined, { used });
  const est = await storageEstimate();
  if (est && est.usage + input.blob.size > est.quota * 0.9) throw new DomainError('BROWSER_STORAGE_FULL');
  return putAsset({
    id: uid(),
    moduleId: input.moduleId,
    kind: input.kind,
    name: input.name.slice(0, 200),
    mime: input.mime ?? (input.blob.type || 'application/octet-stream'),
    size: input.blob.size,
    hash: await fingerprint(input.blob),
    blob: input.blob,
    createdAt: nowIso(),
  });
}

export async function deleteAsset(id: string | null | undefined): Promise<void> {
  if (id) await db.assets.delete(id);
}

export async function assetObjectUrl(id: string): Promise<string | null> {
  const a = await db.assets.get(id);
  return a ? URL.createObjectURL(a.blob) : null;
}
