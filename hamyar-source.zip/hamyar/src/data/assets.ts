import { db, nowIso, uid } from './db';
import { LIMITS } from '../config/limits';
import { DomainError, type Asset } from '../domain/types';
import { sha256 } from '../lib/hash';

/**
 * Stores real file bytes (Blob) in IndexedDB — not just a name or a temporary object URL.
 * The declared MIME type is not trusted: the first bytes are checked for known signatures.
 */

export type AssetKind = Asset['kind'];

const SIGNATURES: { kind: 'pdf' | 'audio' | 'video' | 'av'; test: (b: Uint8Array) => boolean; mime: string }[] = [
  { kind: 'pdf', mime: 'application/pdf', test: (b) => findAscii(b, '%PDF-', 1024) },
  { kind: 'audio', mime: 'audio/mpeg', test: (b) => ascii(b, 0, 'ID3') || (b[0] === 0xff && (b[1]! & 0xe0) === 0xe0) },
  { kind: 'audio', mime: 'audio/wav', test: (b) => ascii(b, 0, 'RIFF') && ascii(b, 8, 'WAVE') },
  { kind: 'audio', mime: 'audio/ogg', test: (b) => ascii(b, 0, 'OggS') },
  { kind: 'audio', mime: 'audio/flac', test: (b) => ascii(b, 0, 'fLaC') },
  { kind: 'audio', mime: 'audio/aac', test: (b) => b[0] === 0xff && (b[1]! & 0xf6) === 0xf0 },
  { kind: 'av', mime: 'video/mp4', test: (b) => ascii(b, 4, 'ftyp') },
  { kind: 'av', mime: 'video/webm', test: (b) => b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3 },
];

function ascii(b: Uint8Array, offset: number, s: string): boolean {
  for (let i = 0; i < s.length; i++) if (b[offset + i] !== s.charCodeAt(i)) return false;
  return true;
}

function findAscii(b: Uint8Array, s: string, within: number): boolean {
  for (let i = 0; i <= Math.min(within, b.length - s.length); i++) if (ascii(b, i, s)) return true;
  return false;
}

/** Detects the real file family from its first bytes. */
export async function sniff(file: Blob): Promise<{ family: 'pdf' | 'audio' | 'video' | 'av' | 'unknown'; mime: string }> {
  const head = new Uint8Array(await file.slice(0, 1100).arrayBuffer());
  for (const s of SIGNATURES) {
    if (s.test(head)) {
      if (s.kind === 'av') {
        // MP4/M4A share 'ftyp'; WebM can be audio or video — use the declared type to pick.
        const declared = file.type || '';
        const audioish = declared.startsWith('audio/') || /^(M4A |M4B |mp42)/.test(String.fromCharCode(...head.slice(8, 12)));
        return { family: declared.startsWith('video/') ? 'video' : audioish ? 'audio' : 'av', mime: declared || s.mime };
      }
      return { family: s.kind, mime: s.kind === 'pdf' ? s.mime : file.type || s.mime };
    }
  }
  return { family: 'unknown', mime: file.type || 'application/octet-stream' };
}

export async function storageUsed(): Promise<number> {
  let total = 0;
  await db.assets.each((a) => {
    total += a.size;
  });
  return total;
}

export async function storageEstimate(): Promise<{ usage: number; quota: number } | null> {
  try {
    const e = await navigator.storage?.estimate?.();
    return e && e.quota ? { usage: e.usage ?? 0, quota: e.quota } : null;
  } catch {
    return null;
  }
}

export interface SaveAssetInput {
  moduleId: string;
  kind: AssetKind;
  blob: Blob;
  name: string;
  maxBytes: number;
  mime?: string;
}

/** Validates size and quota, hashes, and stores the bytes. Throws DomainError on failure. */
export async function saveAsset(input: SaveAssetInput): Promise<Asset> {
  if (input.blob.size === 0) throw new DomainError('EMPTY_FILE');
  if (input.blob.size > input.maxBytes) throw new DomainError('FILE_TOO_LARGE', undefined, { max: input.maxBytes });
  const used = await storageUsed();
  if (used + input.blob.size > LIMITS.accountStorageBytes) throw new DomainError('QUOTA_EXCEEDED', undefined, { used });
  const est = await storageEstimate();
  if (est && est.usage + input.blob.size > est.quota * 0.9) throw new DomainError('BROWSER_STORAGE_FULL');
  const asset: Asset = {
    id: uid(),
    moduleId: input.moduleId,
    kind: input.kind,
    name: input.name.slice(0, 200),
    mime: input.mime ?? (input.blob.type || 'application/octet-stream'),
    size: input.blob.size,
    hash: await sha256(input.blob),
    blob: input.blob,
    createdAt: nowIso(),
  };
  try {
    await db.assets.add(asset);
  } catch (e) {
    if ((e as DOMException)?.name === 'QuotaExceededError' || (e as { inner?: DOMException })?.inner?.name === 'QuotaExceededError') {
      throw new DomainError('BROWSER_STORAGE_FULL');
    }
    throw e;
  }
  return asset;
}

export async function deleteAsset(id: string | null | undefined): Promise<void> {
  if (id) await db.assets.delete(id);
}

export async function assetObjectUrl(id: string): Promise<string | null> {
  const a = await db.assets.get(id);
  return a ? URL.createObjectURL(a.blob) : null;
}
