import { db, MODULE_CHILD_TABLES, nowIso, uid } from './db';
import { LIMITS } from '../config/limits';
import { CATALOG, PRESETS, defaultAppearanceFor, sanitizeConfig, type PresetDef } from '../domain/catalog';
import { DomainError, type InputLanguage, type ModuleAppearance, type ModuleInstance, type ModuleType, type VoiceMode } from '../domain/types';
import { isAccent, isIconKey, CARD_PRESETS } from '../config/appearance';

/**
 * Module-instance rules (PRD §5). The 10-active cap is enforced inside one IndexedDB
 * read-write transaction on the `modules` store: overlapping read-write transactions on
 * the same store are serialized by the browser, so two tabs cannot both take the tenth slot.
 */

function isLive(m: ModuleInstance): boolean {
  return m.active === 1 && !m.archivedAt;
}

export async function countActive(): Promise<number> {
  const all = await db.modules.toArray();
  return all.filter(isLive).length;
}

export interface NewModuleInput {
  type: ModuleType;
  title: string;
  active: boolean;
  inputLanguage: InputLanguage;
  appearance?: Partial<ModuleAppearance>;
  config?: Record<string, unknown>;
  locale?: 'fa' | 'en';
}

export function sanitizeAppearance(type: ModuleType, a: Partial<ModuleAppearance> | undefined): ModuleAppearance {
  const def = defaultAppearanceFor(type);
  return {
    preset: a?.preset && (CARD_PRESETS as readonly string[]).includes(a.preset) ? a.preset : def.preset,
    accent: isAccent(a?.accent) ? a!.accent! : def.accent,
    icon: isIconKey(a?.icon) ? a!.icon! : def.icon,
    width: a?.width === 'wide' || a?.width === 'normal' ? a.width : def.width,
    density: a?.density === 'compact' || a?.density === 'comfortable' ? a.density : def.density,
  };
}

function buildModule(input: NewModuleInput, order: number, active: boolean): ModuleInstance {
  const ts = nowIso();
  return {
    id: uid(),
    type: input.type,
    title: input.title.trim().slice(0, 60) || input.type,
    active: active ? 1 : 0,
    archivedAt: null,
    order,
    inputLanguage: input.inputLanguage,
    voiceMode: CATALOG[input.type].commands ? 'command' : 'dictation',
    remindersPaused: false,
    appearance: sanitizeAppearance(input.type, input.appearance),
    config: sanitizeConfig(input.type, input.config, input.locale),
    configVersion: 1,
    version: 1,
    createdAt: ts,
    updatedAt: ts,
  };
}

/** Creates a module; throws MODULE_LIMIT_REACHED if it should be active and 10 are already live. */
export async function createModule(input: NewModuleInput): Promise<ModuleInstance> {
  return db.transaction('rw', db.modules, async () => {
    const all = await db.modules.toArray();
    if (all.length >= LIMITS.maxTotalModules) throw new DomainError('MODULE_TOTAL_LIMIT');
    const live = all.filter(isLive).length;
    if (input.active && live >= LIMITS.maxActiveModules) throw new DomainError('MODULE_LIMIT_REACHED', undefined, { active: live });
    const order = all.reduce((mx, m) => Math.max(mx, m.order), -1) + 1;
    const mod = buildModule(input, order, input.active);
    await db.modules.add(mod);
    return mod;
  });
}

export async function setActive(id: string, active: boolean): Promise<void> {
  await db.transaction('rw', db.modules, async () => {
    const mod = await db.modules.get(id);
    if (!mod) throw new DomainError('NOT_FOUND');
    if (active) {
      if (mod.archivedAt) throw new DomainError('MODULE_ARCHIVED');
      if (mod.active === 1) return;
      const all = await db.modules.toArray();
      const live = all.filter((m) => m.id !== id && isLive(m)).length;
      if (live >= LIMITS.maxActiveModules) throw new DomainError('MODULE_LIMIT_REACHED', undefined, { active: live });
    }
    await db.modules.update(id, { active: active ? 1 : 0, updatedAt: nowIso(), version: mod.version + 1 });
  });
}

/** Swaps one live module for another inside a single transaction. */
export async function replaceActive(activateId: string, deactivateId: string): Promise<void> {
  await db.transaction('rw', db.modules, async () => {
    const a = await db.modules.get(activateId);
    const d = await db.modules.get(deactivateId);
    if (!a || !d) throw new DomainError('NOT_FOUND');
    if (a.archivedAt) throw new DomainError('MODULE_ARCHIVED');
    const ts = nowIso();
    await db.modules.update(deactivateId, { active: 0, updatedAt: ts, version: d.version + 1 });
    const all = await db.modules.toArray();
    const live = all.filter((m) => m.id !== activateId && isLive(m)).length;
    if (live >= LIMITS.maxActiveModules) throw new DomainError('MODULE_LIMIT_REACHED');
    await db.modules.update(activateId, { active: 1, updatedAt: ts, version: a.version + 1 });
  });
}

/** Archive keeps data, hides the card and stops this module's future reminders. */
export async function archiveModule(id: string): Promise<void> {
  await db.transaction('rw', db.modules, async () => {
    const mod = await db.modules.get(id);
    if (!mod) throw new DomainError('NOT_FOUND');
    await db.modules.update(id, { archivedAt: nowIso(), active: 0, updatedAt: nowIso(), version: mod.version + 1 });
  });
}

export async function unarchiveModule(id: string, activate: boolean): Promise<void> {
  await db.transaction('rw', db.modules, async () => {
    const mod = await db.modules.get(id);
    if (!mod) throw new DomainError('NOT_FOUND');
    let active: 0 | 1 = 0;
    if (activate) {
      const all = await db.modules.toArray();
      const live = all.filter((m) => m.id !== id && isLive(m)).length;
      if (live >= LIMITS.maxActiveModules) throw new DomainError('MODULE_LIMIT_REACHED');
      active = 1;
    }
    await db.modules.update(id, { archivedAt: null, active, updatedAt: nowIso(), version: mod.version + 1 });
  });
}

/** Permanent delete: the module and every row that belongs to it. */
export async function deleteModule(id: string): Promise<{ assetsRemoved: number }> {
  const tables = [db.modules, db.pages, db.summaries, db.focus, ...MODULE_CHILD_TABLES.map((t) => db.table(t))];
  return db.transaction('rw', tables, async () => {
    const docs = await db.documents.where('moduleId').equals(id).primaryKeys();
    for (const docId of docs) {
      await db.pages.where('docId').equals(docId).delete();
      await db.summaries.where('docId').equals(docId).delete();
    }
    const assetsRemoved = await db.assets.where('moduleId').equals(id).count();
    for (const t of MODULE_CHILD_TABLES) await db.table(t).where('moduleId').equals(id).delete();
    await db.focus.delete(id);
    await db.modules.delete(id);
    return { assetsRemoved };
  });
}

export interface ModulePatch {
  title?: string;
  inputLanguage?: InputLanguage;
  voiceMode?: VoiceMode;
  remindersPaused?: boolean;
  appearance?: Partial<ModuleAppearance>;
  config?: Record<string, unknown>;
}

/** Optimistic update: rejects with VERSION_CONFLICT if another tab changed the module first. */
export async function updateModule(id: string, patch: ModulePatch, expectedVersion?: number, locale: 'fa' | 'en' = 'fa'): Promise<ModuleInstance> {
  return db.transaction('rw', db.modules, async () => {
    const mod = await db.modules.get(id);
    if (!mod) throw new DomainError('NOT_FOUND');
    if (expectedVersion !== undefined && mod.version !== expectedVersion) throw new DomainError('VERSION_CONFLICT');
    const next: ModuleInstance = {
      ...mod,
      title: patch.title !== undefined ? patch.title.trim().slice(0, 60) || mod.title : mod.title,
      inputLanguage: patch.inputLanguage ?? mod.inputLanguage,
      voiceMode: patch.voiceMode ?? mod.voiceMode,
      remindersPaused: patch.remindersPaused ?? mod.remindersPaused,
      appearance: patch.appearance ? sanitizeAppearance(mod.type, { ...mod.appearance, ...patch.appearance }) : mod.appearance,
      config: patch.config ? sanitizeConfig(mod.type, { ...mod.config, ...patch.config }, locale) : mod.config,
      version: mod.version + 1,
      updatedAt: nowIso(),
    };
    await db.modules.put(next);
    return next;
  });
}

/**
 * After a language switch, sections that still carry their default name get the default
 * name of the new language. Names the person typed themselves are never touched.
 */
export async function relabelDefaultTitles(nameOf: (type: ModuleType) => readonly [string, string] | undefined, to: 'fa' | 'en'): Promise<number> {
  return db.transaction('rw', db.modules, async () => {
    let changed = 0;
    for (const mod of await db.modules.toArray()) {
      const pair = nameOf(mod.type);
      if (!pair) continue;
      const target = to === 'fa' ? pair[0] : pair[1];
      const other = to === 'fa' ? pair[1] : pair[0];
      if (mod.title === other && target !== other) {
        await db.modules.update(mod.id, { title: target, version: mod.version + 1, updatedAt: nowIso() });
        changed++;
      }
    }
    return changed;
  });
}

export async function resetAppearance(id: string): Promise<void> {
  await db.transaction('rw', db.modules, async () => {
    const mod = await db.modules.get(id);
    if (!mod) return;
    await db.modules.update(id, { appearance: defaultAppearanceFor(mod.type), version: mod.version + 1, updatedAt: nowIso() });
  });
}

/** Moves a module one step within the dashboard order (keyboard-friendly reorder). */
export async function moveModule(id: string, direction: -1 | 1): Promise<void> {
  await db.transaction('rw', db.modules, async () => {
    const live = (await db.modules.toArray()).filter(isLive).sort((a, b) => a.order - b.order);
    const i = live.findIndex((m) => m.id === id);
    const j = i + direction;
    if (i < 0 || j < 0 || j >= live.length) return;
    const a = live[i]!;
    const b = live[j]!;
    await db.modules.update(a.id, { order: b.order });
    await db.modules.update(b.id, { order: a.order });
  });
}

/** Persists a full order (after drag and drop). Unknown ids are ignored. */
export async function reorderModules(ids: string[]): Promise<void> {
  await db.transaction('rw', db.modules, async () => {
    const all = await db.modules.toArray();
    const orders = all.filter((m) => ids.includes(m.id)).map((m) => m.order).sort((a, b) => a - b);
    for (let k = 0; k < ids.length; k++) {
      const order = orders[k];
      if (order !== undefined) await db.modules.update(ids[k]!, { order });
    }
  });
}

export interface PresetPlan {
  preset: PresetDef;
  mode: 'add' | 'switch';
  /** existing modules that will be shown */
  activate: ModuleInstance[];
  /** existing modules that will be hidden (data kept) */
  deactivate: ModuleInstance[];
  /** new modules that will be created, and whether each will be shown */
  create: { type: ModuleType; active: boolean }[];
  /** existing preset modules that stay hidden because the cap is reached */
  skipped: ModuleInstance[];
  activeAfter: number;
}

/** Computes what applying a preset would do, without writing anything (preview). */
export async function planPreset(presetId: PresetDef['id'], mode: 'add' | 'switch'): Promise<PresetPlan> {
  const preset = PRESETS.find((p) => p.id === presetId)!;
  const all = (await db.modules.toArray()).filter((m) => !m.archivedAt).sort((a, b) => a.order - b.order);
  const plan: PresetPlan = { preset, mode, activate: [], deactivate: [], create: [], skipped: [], activeAfter: 0 };
  const used = new Set<string>();
  const wanted: (ModuleInstance | ModuleType)[] = [];
  for (const type of preset.types) {
    const existing = all.find((m) => m.type === type && !used.has(m.id));
    if (existing) {
      used.add(existing.id);
      wanted.push(existing);
    } else wanted.push(type);
  }
  let live = mode === 'switch' ? 0 : all.filter(isLive).length;
  if (mode === 'switch') plan.deactivate = all.filter((m) => isLive(m) && !used.has(m.id));
  for (const w of wanted) {
    if (typeof w === 'string') {
      const canShow = live < LIMITS.maxActiveModules;
      plan.create.push({ type: w, active: canShow });
      if (canShow) live++;
    } else if (w.active === 1) {
      if (mode === 'switch') live++;
    } else if (live < LIMITS.maxActiveModules) {
      plan.activate.push(w);
      live++;
    } else plan.skipped.push(w);
  }
  plan.activeAfter = live;
  if (all.length + plan.create.length > LIMITS.maxTotalModules) throw new DomainError('MODULE_TOTAL_LIMIT');
  return plan;
}

/** Applies a preset atomically. Never deletes data; respects the active cap. */
export async function applyPreset(
  plan: PresetPlan,
  titles: (type: ModuleType) => string,
  inputLanguage: InputLanguage,
  locale: 'fa' | 'en',
): Promise<void> {
  await db.transaction('rw', db.modules, async () => {
    const ts = nowIso();
    for (const m of plan.deactivate) {
      const cur = await db.modules.get(m.id);
      if (cur) await db.modules.update(m.id, { active: 0, updatedAt: ts, version: cur.version + 1 });
    }
    const all = await db.modules.toArray();
    let live = all.filter(isLive).length;
    let order = all.reduce((mx, m) => Math.max(mx, m.order), -1) + 1;
    for (const m of plan.activate) {
      if (live >= LIMITS.maxActiveModules) break;
      const cur = await db.modules.get(m.id);
      if (cur && !cur.archivedAt && cur.active === 0) {
        await db.modules.update(m.id, { active: 1, order: order++, updatedAt: ts, version: cur.version + 1 });
        live++;
      }
    }
    if (all.length + plan.create.length > LIMITS.maxTotalModules) throw new DomainError('MODULE_TOTAL_LIMIT');
    for (const c of plan.create) {
      const active = c.active && live < LIMITS.maxActiveModules;
      await db.modules.add(buildModule({ type: c.type, title: titles(c.type), active, inputLanguage, locale }, order++, active));
      if (active) live++;
    }
    if (live > LIMITS.maxActiveModules) throw new DomainError('MODULE_LIMIT_REACHED');
  });
}
