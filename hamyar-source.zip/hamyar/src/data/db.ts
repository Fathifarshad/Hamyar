import Dexie, { type Table } from 'dexie';
import type {
  Asset,
  Bookmark,
  Checklist,
  ChecklistItem,
  Consent,
  CountdownEvent,
  CustomEntry,
  Expense,
  FocusSession,
  FocusState,
  Habit,
  HabitLog,
  KvRecord,
  MediaItem,
  MedEvent,
  Medication,
  ModuleInstance,
  Note,
  PdfDocument,
  PdfPage,
  Profile,
  ReminderRecord,
  SummaryRecord,
  Task,
  TaskCompletion,
  Transcript,
  WaterLog,
} from '../domain/types';

/**
 * Local repository (demo/local mode, PRD §10): everything lives in this browser's
 * IndexedDB, including real Blobs for media and PDFs.
 */
export class HamyarDB extends Dexie {
  kv!: Table<KvRecord, string>;
  profile!: Table<Profile, string>;
  modules!: Table<ModuleInstance, string>;
  tasks!: Table<Task, string>;
  taskCompletions!: Table<TaskCompletion, string>;
  medications!: Table<Medication, string>;
  medEvents!: Table<MedEvent, string>;
  reminders!: Table<ReminderRecord, string>;
  assets!: Table<Asset, string>;
  media!: Table<MediaItem, string>;
  documents!: Table<PdfDocument, string>;
  pages!: Table<PdfPage, string>;
  summaries!: Table<SummaryRecord, string>;
  transcripts!: Table<Transcript, string>;
  notes!: Table<Note, string>;
  bookmarks!: Table<Bookmark, string>;
  focus!: Table<FocusState, string>;
  focusSessions!: Table<FocusSession, string>;
  checklists!: Table<Checklist, string>;
  checkItems!: Table<ChecklistItem, string>;
  habits!: Table<Habit, string>;
  habitLogs!: Table<HabitLog, string>;
  water!: Table<WaterLog, string>;
  expenses!: Table<Expense, string>;
  countdowns!: Table<CountdownEvent, string>;
  customEntries!: Table<CustomEntry, string>;
  consents!: Table<Consent, string>;

  constructor(name = 'hamyar') {
    super(name);
    this.version(1).stores({
      kv: 'key',
      profile: 'id',
      modules: 'id, type, active, order',
      tasks: 'id, moduleId',
      taskCompletions: 'id, taskId, moduleId',
      medications: 'id, moduleId',
      medEvents: 'id, medId, moduleId, occurrenceKey, &idempotencyKey',
      reminders: 'id, moduleId, sourceId, dueAt, snoozedUntil',
      assets: 'id, moduleId',
      media: 'id, moduleId, order',
      documents: 'id, moduleId',
      pages: 'id, docId',
      summaries: 'id, docId, cacheKey',
      transcripts: 'id, moduleId, updatedAt',
      notes: 'id, moduleId, updatedAt',
      bookmarks: 'id, moduleId',
      focus: 'id',
      focusSessions: 'id, moduleId',
      checklists: 'id, moduleId',
      checkItems: 'id, listId, moduleId',
      habits: 'id, moduleId',
      habitLogs: 'id, habitId, moduleId, date',
      water: 'id, moduleId, date',
      expenses: 'id, moduleId, date',
      countdowns: 'id, moduleId',
      customEntries: 'id, moduleId',
      consents: 'id',
    });
  }
}

export let db = new HamyarDB();

/** Tests use a fresh database per case. */
export function openDatabase(name: string): HamyarDB {
  db = new HamyarDB(name);
  return db;
}

/** Tables that hold per-module data; used for cascade delete and export. */
export const MODULE_CHILD_TABLES = [
  'tasks',
  'taskCompletions',
  'medications',
  'medEvents',
  'reminders',
  'assets',
  'media',
  'documents',
  'transcripts',
  'notes',
  'bookmarks',
  'focusSessions',
  'checklists',
  'checkItems',
  'habits',
  'habitLogs',
  'water',
  'expenses',
  'countdowns',
  'customEntries',
] as const;

export function uid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function nowIso(): string {
  return new Date().toISOString();
}

export async function kvGet<T>(key: string, fallback: T): Promise<T> {
  try {
    const rec = await db.kv.get(key);
    return rec ? (rec.value as T) : fallback;
  } catch {
    return fallback;
  }
}

export async function kvSet(key: string, value: unknown): Promise<void> {
  await db.kv.put({ key, value });
}
