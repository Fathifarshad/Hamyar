import { db, uid } from './db';
import { LIMITS } from '../config/limits';
import { MODULE_TYPES, type ModuleInstance } from '../domain/types';
import { sanitizeAppearance } from './modules';
import { sanitizeConfig } from '../domain/catalog';
import { APP_VERSION } from '../lib/platform';

/**
 * JSON export: settings, sections, text data, schedules and history. It contains no
 * keys and no binary files (files are listed so they can be added again by hand).
 * Import is two-step — validate (preview) then commit in one transaction — and ids
 * are always regenerated; nothing in the file is trusted as an identity.
 */

export const EXPORT_VERSION = 1;

const TABLES = [
  'modules',
  'tasks',
  'taskCompletions',
  'medications',
  'medEvents',
  'media',
  'documents',
  'pages',
  'summaries',
  'transcripts',
  'notes',
  'bookmarks',
  'focus',
  'focusSessions',
  'checklists',
  'checkItems',
  'habits',
  'habitLogs',
  'water',
  'expenses',
  'countdowns',
  'customEntries',
] as const;
type TableName = (typeof TABLES)[number];
type Row = Record<string, unknown>;

export interface ExportFile {
  app: 'hamyar';
  version: number;
  appVersion: string;
  exportedAt: string;
  profile: Row | null;
  tables: Record<TableName, Row[]>;
  files: { name: string; kind: string; size: number; mime: string }[];
}

export async function buildExport(): Promise<ExportFile> {
  const tables = {} as Record<TableName, Row[]>;
  for (const name of TABLES) tables[name] = (await db.table(name).toArray()) as Row[];
  const files: ExportFile['files'] = [];
  await db.assets.each((a) => files.push({ name: a.name, kind: a.kind, size: a.size, mime: a.mime }));
  const profile = (await db.profile.get('profile')) as Row | undefined;
  return { app: 'hamyar', version: EXPORT_VERSION, appVersion: APP_VERSION, exportedAt: new Date().toISOString(), profile: profile ?? null, tables, files };
}

export interface ImportPlan {
  ok: boolean;
  errors: string[];
  counts: Partial<Record<TableName, number>>;
  modules: { title: string; type: string; active: boolean }[];
  activeAfter: number;
  totalAfter: number;
  missingFiles: number;
  data: ExportFile | null;
}

function isObj(v: unknown): v is Row {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

/** Step 1: checks the file and shows exactly what would happen. Writes nothing. */
export async function validateImport(raw: unknown): Promise<ImportPlan> {
  const errors: string[] = [];
  const plan: ImportPlan = { ok: false, errors, counts: {}, modules: [], activeAfter: 0, totalAfter: 0, missingFiles: 0, data: null };
  if (!isObj(raw) || raw.app !== 'hamyar') {
    errors.push('not_hamyar');
    return plan;
  }
  if (typeof raw.version !== 'number' || raw.version > EXPORT_VERSION) {
    errors.push('version');
    return plan;
  }
  if (!isObj(raw.tables)) {
    errors.push('tables');
    return plan;
  }
  const tables = raw.tables as Record<string, unknown>;
  for (const name of TABLES) {
    const v = tables[name] ?? [];
    if (!Array.isArray(v) || v.some((r) => !isObj(r))) errors.push(`table:${name}`);
    else plan.counts[name] = v.length;
  }
  if (errors.length) return plan;
  const mods = tables.modules as Row[];
  for (const m of mods) {
    if (typeof m.id !== 'string' || !MODULE_TYPES.includes(m.type as never) || typeof m.title !== 'string') errors.push('module_shape');
  }
  const existing = await db.modules.toArray();
  let live = existing.filter((m) => m.active === 1 && !m.archivedAt).length;
  plan.totalAfter = existing.length + mods.length;
  if (plan.totalAfter > LIMITS.maxTotalModules) errors.push('total_limit');
  for (const m of mods) {
    const wantsActive = m.active === 1 && !m.archivedAt;
    const active = wantsActive && live < LIMITS.maxActiveModules;
    if (active) live++;
    plan.modules.push({ title: String(m.title).slice(0, 60), type: String(m.type), active });
  }
  plan.activeAfter = live;
  plan.missingFiles = ((tables.media as Row[]) ?? []).filter((r) => r.sourceType === 'file').length + ((tables.documents as Row[]) ?? []).length;
  plan.ok = errors.length === 0;
  plan.data = plan.ok ? (raw as unknown as ExportFile) : null;
  return plan;
}

/** Step 2: writes everything in one transaction with fresh ids. All or nothing. */
export async function commitImport(plan: ImportPlan, locale: 'fa' | 'en'): Promise<void> {
  if (!plan.ok || !plan.data) throw new Error('invalid_plan');
  const T = plan.data.tables;
  const all = TABLES.map((n) => db.table(n));
  await db.transaction('rw', [...all, db.modules], async () => {
    const existing = await db.modules.toArray();
    if (existing.length + T.modules.length > LIMITS.maxTotalModules) throw Object.assign(new Error(), { code: 'MODULE_TOTAL_LIMIT' });
    let live = existing.filter((m) => m.active === 1 && !m.archivedAt).length;
    let order = existing.reduce((mx, m) => Math.max(mx, m.order), -1) + 1;
    const modMap = new Map<string, string>();
    const idMap = new Map<string, string>();
    const map = (old: unknown) => {
      const k = String(old);
      if (!idMap.has(k)) idMap.set(k, uid());
      return idMap.get(k)!;
    };
    const ts = new Date().toISOString();
    for (const m of T.modules) {
      const id = uid();
      modMap.set(String(m.id), id);
      const type = m.type as ModuleInstance['type'];
      const wantsActive = m.active === 1 && !m.archivedAt;
      const active = wantsActive && live < LIMITS.maxActiveModules;
      if (active) live++;
      const mod: ModuleInstance = {
        id,
        type,
        title: String(m.title).slice(0, 60),
        active: active ? 1 : 0,
        archivedAt: typeof m.archivedAt === 'string' ? m.archivedAt : null,
        order: order++,
        inputLanguage: m.inputLanguage === 'en-US' ? 'en-US' : 'fa-IR',
        voiceMode: m.voiceMode === 'command' ? 'command' : 'dictation',
        remindersPaused: m.remindersPaused === true,
        appearance: sanitizeAppearance(type, isObj(m.appearance) ? (m.appearance as never) : undefined),
        config: sanitizeConfig(type, isObj(m.config) ? m.config : undefined, locale),
        configVersion: 1,
        version: 1,
        createdAt: ts,
        updatedAt: ts,
      };
      await db.modules.add(mod);
    }
    const mod = (r: Row) => modMap.get(String(r.moduleId));
    const put = async (table: TableName, rows: Row[]) => {
      if (rows.length) await db.table(table).bulkAdd(rows);
    };
    const keep = (rows: Row[] | undefined) => (rows ?? []).filter((r) => mod(r));

    await put('tasks', keep(T.tasks).map((r) => ({ ...r, id: map(r.id), moduleId: mod(r) })));
    await put(
      'taskCompletions',
      keep(T.taskCompletions).map((r) => ({ ...r, id: `${map(r.taskId)}|${String(r.occurrence)}`, taskId: map(r.taskId), moduleId: mod(r) })),
    );
    await put('medications', keep(T.medications).map((r) => ({ ...r, id: map(r.id), moduleId: mod(r) })));
    await put(
      'medEvents',
      keep(T.medEvents).map((r) => {
        const medId = map(r.medId);
        const key = String(r.occurrenceKey ?? '');
        return { ...r, id: map(r.id), medId, moduleId: mod(r), occurrenceKey: key.replace(/^[^|]+/, medId), supersedesId: r.supersedesId ? map(r.supersedesId) : null, idempotencyKey: uid() };
      }),
    );
    await put(
      'media',
      keep(T.media).map((r) => ({ ...r, id: map(r.id), moduleId: mod(r), assetId: null, missingFile: r.sourceType === 'file' })),
    );
    await put('documents', keep(T.documents).map((r) => ({ ...r, id: map(r.id), moduleId: mod(r), assetId: null })));
    const docIds = new Set(keep(T.documents).map((d) => String(d.id)));
    await put(
      'pages',
      (T.pages ?? []).filter((p) => docIds.has(String(p.docId))).map((p) => ({ ...p, id: `${map(p.docId)}|${Number(p.pageNumber)}`, docId: map(p.docId) })),
    );
    await put('summaries', (T.summaries ?? []).filter((s) => docIds.has(String(s.docId))).map((s) => ({ ...s, id: uid(), docId: map(s.docId) })));
    await put('transcripts', keep(T.transcripts).map((r) => ({ ...r, id: map(r.id), moduleId: mod(r), assetId: null })));
    for (const name of ['notes', 'bookmarks', 'focusSessions', 'expenses', 'countdowns', 'customEntries'] as const) {
      await put(name, keep(T[name]).map((r) => ({ ...r, id: map(r.id), moduleId: mod(r) })));
    }
    await put(
      'focus',
      (T.focus ?? []).filter((f) => modMap.has(String(f.id))).map((f) => ({ ...f, id: modMap.get(String(f.id)), status: 'idle', endAt: null, pausedRemainingMs: null })),
    );
    await put('checklists', keep(T.checklists).map((r) => ({ ...r, id: map(r.id), moduleId: mod(r) })));
    await put('checkItems', keep(T.checkItems).map((r) => ({ ...r, id: map(r.id), listId: map(r.listId), moduleId: mod(r) })));
    await put('habits', keep(T.habits).map((r) => ({ ...r, id: map(r.id), moduleId: mod(r) })));
    await put(
      'habitLogs',
      keep(T.habitLogs).map((r) => ({ ...r, id: `${map(r.habitId)}|${String(r.date)}`, habitId: map(r.habitId), moduleId: mod(r) })),
    );
    await put('water', keep(T.water).map((r) => ({ ...r, id: `${mod(r)}|${String(r.date)}`, moduleId: mod(r) })));
    if (live > LIMITS.maxActiveModules) throw Object.assign(new Error(), { code: 'MODULE_LIMIT_REACHED' });
  });
}

/** Erases this browser's Hamyar database and caches. */
export async function deleteAllData(): Promise<void> {
  db.close();
  await db.delete();
  try {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k.startsWith('hamyar')).map((k) => caches.delete(k)));
  } catch {
    /* Cache Storage unavailable */
  }
}

/** After a deliberate wipe, the claude.ai preview should not refill itself with examples. */
export function markSkipSeed(): void {
  try {
    localStorage.setItem('hamyar:skip-seed', '1');
  } catch {
    /* storage blocked: the preview will offer onboarding anyway after a reload */
  }
}
