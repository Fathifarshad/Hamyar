import { Component, useEffect, useRef, type ReactNode } from 'react';
import { AppProvider, useApp } from './shell/AppContext';
import { Layout } from './shell/Layout';
import { useRoute } from './shell/router';
import { Dashboard } from './shell/Dashboard';
import { ModulePage } from './shell/ModulePage';
import { Library } from './shell/Library';
import { Inbox } from './shell/Inbox';
import { Settings } from './shell/Settings';
import { Onboarding } from './shell/Onboarding';
import { AddModuleDialog } from './shell/AddModuleDialog';
import { ModuleSettingsSheet } from './shell/ModuleSettingsSheet';
import { PresetDialog } from './shell/PresetDialog';
import { ConfirmHost, TextPromptHost, ToastHost } from './shell/Hosts';
import { Spinner } from './ui/primitives';
import { startReminderEngine } from './lib/reminders';
import { refreshAiStatus } from './lib/ai';
import { abortMic } from './lib/mic';
import { IS_ARTIFACT } from './lib/platform';
import { loadSampleData } from './data/sample';
import { db, kvGet, kvSet } from './data/db';
import { defaultProfile, saveProfile } from './shell/AppContext';
import { planPreset, applyPreset } from './data/modules';
import { MODULE_TEXT } from './modules/registry';

function Routes() {
  const route = useRoute();
  useEffect(() => {
    abortMic();
  }, [route.name, route.name === 'module' ? route.id : '']); // eslint-disable-line react-hooks/exhaustive-deps
  switch (route.name) {
    case 'library':
      return <Library />;
    case 'inbox':
      return <Inbox />;
    case 'settings':
      return <Settings />;
    case 'module':
      return <ModulePage id={route.id} focus={route.focus} />;
    default:
      return <Dashboard />;
  }
}

/** In the claude.ai preview, open straight into a filled, clearly labelled example dashboard. */
export function previewSeedSkipped(): boolean {
  try {
    return localStorage.getItem('hamyar:skip-seed') === '1';
  } catch {
    return false;
  }
}

async function seedPreview() {
  const seeded = await kvGet('preview:seeded', false);
  const base = (await db.profile.get('profile')) ?? defaultProfile(navigator.language?.startsWith('en') ? 'en' : 'fa');
  if (!seeded) {
    await kvSet('preview:seeded', true);
    await saveProfile({ onboarded: false }, base);
    const locale = base.locale;
    await applyPreset(await planPreset('starter', 'add'), (type) => MODULE_TEXT[type].name[locale === 'fa' ? 0 : 1], locale === 'fa' ? 'fa-IR' : 'en-US', locale);
    await loadSampleData(locale, base.timezone);
  }
  await saveProfile({ onboarded: true, sampleData: !seeded || base.sampleData }, base);
}

function Shell() {
  const { profile, loaded, t } = useApp();
  const seeded = useRef(false);
  useEffect(() => {
    startReminderEngine();
    void refreshAiStatus();
  }, []);
  useEffect(() => {
    if (IS_ARTIFACT && loaded && !profile.onboarded && !seeded.current && !previewSeedSkipped()) {
      seeded.current = true;
      void seedPreview();
    }
  }, [loaded, profile.onboarded]);
  if (!loaded || (IS_ARTIFACT && !profile.onboarded && !previewSeedSkipped())) {
    return (
      <div className="boot">
        <Spinner label={t('در حال آماده‌سازی…', 'Getting ready…')} />
      </div>
    );
  }
  if (!profile.onboarded) {
    return (
      <>
        <Onboarding />
        <ToastHost />
        <ConfirmHost />
      </>
    );
  }
  return (
    <>
      <Layout>
        <Routes />
      </Layout>
      <AddModuleDialog />
      <ModuleSettingsSheet />
      <PresetDialog />
      <ToastHost />
      <ConfirmHost />
      <TextPromptHost />
    </>
  );
}

/**
 * Last line of defence: if browser storage is blocked (private mode, disabled site data)
 * or something unexpected breaks, show a plain explanation instead of a blank page.
 */
class AppBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  override state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  override componentDidCatch(err: unknown) {
    console.error('[hamyar] app crashed', (err as Error)?.name, (err as Error)?.message);
  }
  override render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="boot">
        <div className="boot-error" role="alert">
          <p lang="fa" dir="rtl">
            همیار نتوانست شروع شود. ممکن است ذخیره‌سازی مرورگر (IndexedDB) در این پنجره غیرفعال باشد؛ مثلاً در حالت خصوصی. یک پنجره معمولی را امتحان کنید.
          </p>
          <p lang="en" dir="ltr">
            Hamyar could not start. Browser storage (IndexedDB) may be blocked in this window, for example in private mode. Try a normal window.
          </p>
          <button type="button" className="btn btn-primary btn-md" onClick={() => window.location.reload()}>
            <span className="btn-label">تلاش دوباره · Try again</span>
          </button>
        </div>
      </div>
    );
  }
}

export default function App() {
  return (
    <AppBoundary>
      <AppProvider>
        <Shell />
      </AppProvider>
    </AppBoundary>
  );
}
