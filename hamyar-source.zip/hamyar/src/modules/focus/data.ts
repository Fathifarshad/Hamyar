import { db, nowIso, uid } from '../../data/db';
import type { FocusState, ModuleInstance } from '../../domain/types';

/**
 * The timer stores its end instant (and the remaining time while paused), so a reload
 * or a closed tab never restarts the count — the display is always derived from the clock.
 */

export function focusConfig(mod: ModuleInstance) {
  return { focusMin: Number(mod.config.focusMin ?? 25), breakMin: Number(mod.config.breakMin ?? 5), sound: mod.config.sound !== false };
}

export function idleState(moduleId: string, today: string): FocusState {
  return { id: moduleId, phase: 'focus', status: 'idle', endAt: null, pausedRemainingMs: null, sessionsDate: today, sessionsCount: 0, updatedAt: nowIso() };
}

export function remainingMs(s: FocusState, phaseMinutes: number, now: number): number {
  if (s.status === 'running' && s.endAt) return Math.max(0, s.endAt - now);
  if (s.status === 'paused' && s.pausedRemainingMs !== null) return s.pausedRemainingMs;
  return phaseMinutes * 60_000;
}

async function load(moduleId: string, today: string): Promise<FocusState> {
  const s = (await db.focus.get(moduleId)) ?? idleState(moduleId, today);
  if (s.sessionsDate !== today) return { ...s, sessionsDate: today, sessionsCount: 0 };
  return s;
}

export async function startFocus(mod: ModuleInstance, today: string, minutes?: number | null, phase?: FocusState['phase']) {
  await db.transaction('rw', db.focus, async () => {
    const s = await load(mod.id, today);
    const cfg = focusConfig(mod);
    const ph = phase ?? s.phase;
    const mins = minutes ?? (ph === 'focus' ? cfg.focusMin : cfg.breakMin);
    await db.focus.put({ ...s, phase: ph, status: 'running', endAt: Date.now() + mins * 60_000, pausedRemainingMs: null, updatedAt: nowIso() });
  });
}

export async function pauseFocus(moduleId: string, today: string) {
  await db.transaction('rw', db.focus, async () => {
    const s = await load(moduleId, today);
    if (s.status !== 'running' || !s.endAt) return;
    await db.focus.put({ ...s, status: 'paused', pausedRemainingMs: Math.max(0, s.endAt - Date.now()), endAt: null, updatedAt: nowIso() });
  });
}

export async function resumeFocus(moduleId: string, today: string) {
  await db.transaction('rw', db.focus, async () => {
    const s = await load(moduleId, today);
    if (s.status !== 'paused' || s.pausedRemainingMs === null) return;
    await db.focus.put({ ...s, status: 'running', endAt: Date.now() + s.pausedRemainingMs, pausedRemainingMs: null, updatedAt: nowIso() });
  });
}

export async function resetFocus(moduleId: string, today: string) {
  await db.transaction('rw', db.focus, async () => {
    const s = await load(moduleId, today);
    await db.focus.put({ ...s, status: 'idle', endAt: null, pausedRemainingMs: null, updatedAt: nowIso() });
  });
}

export async function skipPhase(moduleId: string, today: string) {
  await db.transaction('rw', db.focus, async () => {
    const s = await load(moduleId, today);
    await db.focus.put({ ...s, phase: s.phase === 'focus' ? 'break' : 'focus', status: 'idle', endAt: null, pausedRemainingMs: null, updatedAt: nowIso() });
  });
}

/**
 * Completes a running phase whose end has passed. Compare-and-set on endAt makes the
 * completion happen once even if several tabs or components notice it.
 */
export async function completeIfDue(moduleId: string, today: string, now = Date.now()): Promise<{ completed: false } | { completed: true; phase: FocusState['phase']; minutes: number }> {
  return db.transaction('rw', db.focus, db.focusSessions, db.modules, async () => {
    const s = await db.focus.get(moduleId);
    if (!s || s.status !== 'running' || !s.endAt || s.endAt > now) return { completed: false as const };
    const mod = await db.modules.get(moduleId);
    const cfg = mod ? focusConfig(mod) : { focusMin: 25, breakMin: 5 };
    const base = s.sessionsDate === today ? s : { ...s, sessionsDate: today, sessionsCount: 0 };
    const finishedPhase = s.phase;
    const minutes = finishedPhase === 'focus' ? cfg.focusMin : cfg.breakMin;
    if (finishedPhase === 'focus') {
      await db.focusSessions.add({ id: uid(), moduleId, startedAt: new Date(s.endAt - minutes * 60_000).toISOString(), endedAt: new Date(s.endAt).toISOString(), minutes });
    }
    await db.focus.put({
      ...base,
      phase: finishedPhase === 'focus' ? 'break' : 'focus',
      status: 'idle',
      endAt: null,
      pausedRemainingMs: null,
      sessionsCount: base.sessionsCount + (finishedPhase === 'focus' ? 1 : 0),
      updatedAt: nowIso(),
    });
    return { completed: true as const, phase: finishedPhase, minutes };
  });
}
