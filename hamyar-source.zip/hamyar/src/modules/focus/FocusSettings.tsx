import { useApp } from '../../shell/AppContext';
import type { ModuleSettingsProps } from '../registry';
import { Field, Input, Switch } from '../../ui/primitives';

export default function FocusSettings({ config, onChange }: ModuleSettingsProps) {
  const { t } = useApp();
  return (
    <div className="form-row">
      <Field label={t('تمرکز (دقیقه)', 'Focus (minutes)')}>
        <Input type="number" min={1} max={180} value={Number(config.focusMin ?? 25)} onChange={(e) => onChange({ focusMin: Number(e.target.value) })} />
      </Field>
      <Field label={t('استراحت (دقیقه)', 'Break (minutes)')}>
        <Input type="number" min={1} max={60} value={Number(config.breakMin ?? 5)} onChange={(e) => onChange({ breakMin: Number(e.target.value) })} />
      </Field>
      <Switch checked={config.sound !== false} onChange={(sound) => onChange({ sound })} label={t('صدای پایان', 'End sound')} />
    </div>
  );
}
