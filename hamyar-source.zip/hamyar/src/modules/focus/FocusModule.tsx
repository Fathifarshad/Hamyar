import { useEffect, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import { completeIfDue, focusConfig, idleState, pauseFocus, remainingMs, resetFocus, resumeFocus, skipPhase, startFocus } from './data';
import { Button, IconButton } from '../../ui/primitives';
import { Coffee, Pause, Play, RotateCcw, SkipForward, Timer } from '../../ui/icons';
import { VoiceInput } from '../../ui/VoiceInput';
import { parseCommand } from '../../domain/commands/parse';
import { useGenericCommand, useVoiceMode, examplesFor } from '../shared';
import { toast } from '../../lib/ui-store';
import { todayISO } from '../../domain/time';

export default function FocusModule({ mod, variant }: ModuleViewProps) {
  const { t, today, duration, num, tz, locale } = useApp();
  const stored = useLiveQuery(() => db.focus.get(mod.id), [mod.id]);
  const sessions = useLiveQuery(() => db.focusSessions.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const [now, setNow] = useState(Date.now());
  const [voice, setVoice] = useState('');
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);
  const cfg = focusConfig(mod);
  const s = stored ?? idleState(mod.id, today);
  const phaseMin = s.phase === 'focus' ? cfg.focusMin : cfg.breakMin;

  useEffect(() => {
    if (s.status !== 'running') return;
    const id = window.setInterval(() => {
      const n = Date.now();
      setNow(n);
      if (s.endAt && n >= s.endAt) void completeIfDue(mod.id, today, n);
    }, 250);
    return () => window.clearInterval(id);
  }, [s.status, s.endAt, mod.id, today]);

  const left = remainingMs(s, phaseMin, now);
  const total = phaseMin * 60_000;
  const progress = s.status === 'idle' ? 0 : 1 - left / total;
  const todayCount = s.sessionsDate === today ? s.sessionsCount : 0;
  const todayMinutes = (sessions ?? []).filter((x) => todayISO(tz, Date.parse(x.endedAt)) === today).reduce((a, x) => a + x.minutes, 0);

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'focus', now: Date.now(), timezone: tz });
    if (d.kind === 'focus') {
      if (d.action === 'start') await startFocus(mod, today, d.minutes, s.status === 'idle' ? s.phase : 'focus');
      else if (d.action === 'pause') await pauseFocus(mod.id, today);
      else if (d.action === 'resume') await resumeFocus(mod.id, today);
      else if (d.action === 'reset') await resetFocus(mod.id, today);
      else await skipPhase(mod.id, today);
      toast({ kind: 'success', text: t('انجام شد: {a}', 'Done: {a}', { a: text }) });
      return;
    }
    await generic(d);
  };

  const R = 54;
  const C = 2 * Math.PI * R;
  const big = variant === 'full';
  return (
    <div className={`focus${big ? ' is-big' : ''}`}>
      <div className="focus-ring" role="timer" aria-live="off" aria-label={t('زمان باقی‌مانده {d}', 'Time left {d}', { d: duration(Math.ceil(left / 1000)) })}>
        <svg viewBox="0 0 128 128" aria-hidden="true">
          <circle cx="64" cy="64" r={R} className="ring-bg" />
          <circle cx="64" cy="64" r={R} className="ring-fg" strokeDasharray={C} strokeDashoffset={C * (1 - progress)} />
        </svg>
        <div className="focus-center">
          <div className="focus-phase">
            {s.phase === 'focus' ? <Timer size={14} aria-hidden="true" /> : <Coffee size={14} aria-hidden="true" />}
            {s.phase === 'focus' ? t('تمرکز', 'Focus') : t('استراحت', 'Break')}
          </div>
          <div className="focus-time num">{duration(Math.ceil(left / 1000))}</div>
          <div className="focus-state">{s.status === 'running' ? t('در حال اجرا', 'Running') : s.status === 'paused' ? t('متوقف', 'Paused') : t('آماده', 'Ready')}</div>
        </div>
      </div>
      <div className="focus-controls">
        {s.status === 'running' ? (
          <Button variant="accent" icon={<Pause size={16} />} onClick={() => void pauseFocus(mod.id, today)}>
            {t('توقف', 'Pause')}
          </Button>
        ) : s.status === 'paused' ? (
          <Button variant="accent" icon={<Play size={16} />} onClick={() => void resumeFocus(mod.id, today)}>
            {t('ادامه', 'Resume')}
          </Button>
        ) : (
          <Button variant="accent" icon={<Play size={16} />} onClick={() => void startFocus(mod, today)}>
            {s.phase === 'focus' ? t('شروع تمرکز', 'Start focus') : t('شروع استراحت', 'Start break')}
          </Button>
        )}
        <IconButton label={t('از اول', 'Reset')} variant="soft" onClick={() => void resetFocus(mod.id, today)} disabled={s.status === 'idle'}>
          <RotateCcw size={17} />
        </IconButton>
        <IconButton label={s.phase === 'focus' ? t('رفتن به استراحت', 'Skip to break') : t('رفتن به تمرکز', 'Skip to focus')} variant="soft" onClick={() => void skipPhase(mod.id, today)}>
          <SkipForward size={17} className="flip-rtl" />
        </IconButton>
      </div>
      <div className="focus-stats">
        <span>{t('جلسه‌های امروز: {n}', 'Sessions today: {n}', { n: todayCount })}</span>
        <span>{t('{m} دقیقه تمرکز', '{m} min focused', { m: todayMinutes })}</span>
        <span className="subtle">
          {num(cfg.focusMin)}/{num(cfg.breakMin)}
        </span>
      </div>
      {(variant === 'full' || mod.voiceMode === 'command') && (
        <VoiceInput
          value={voice}
          onChange={setVoice}
          lang={mod.inputLanguage}
          ownerId={`focus-${mod.id}-${variant}`}
          inputLabel={t('فرمان تایمر', 'Timer command')}
          placeholder={t('مثلاً «شروع ۴۰ دقیقه»', 'e.g. “start 40 minutes”')}
          mode={mode}
          onModeChange={setMode}
          onCommand={(x) => void onCommand(x)}
          onSubmit={(x) => void onCommand(x)}
          submitLabel={t('اجرا', 'Run')}
          examples={examplesFor(mod, locale)}
        />
      )}
      <p className="subtle xsmall">{t('پایان زمان فقط وقتی همیار باز است با صدا و اعلان خبر داده می‌شود.', 'The end is announced with sound and a notification only while Hamyar is open.')}</p>
    </div>
  );
}
