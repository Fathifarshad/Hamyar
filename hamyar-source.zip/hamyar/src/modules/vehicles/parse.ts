import type { Vehicle, VehicleRecordKind } from '../../domain/types';
import { Scanner, WB_END as E, WB_START as S, normalizeKeepLength, stripFillers } from '../../domain/commands/scanner';
import { extractDateTime } from '../../domain/commands/datetime';
import { CURRENCY_RE, NUMBER_RE, currencyCode, readNumber } from '../../domain/commands/numbers';
import { addMonthsInCalendar } from '../../domain/jalali';
import { addDaysISO, todayISO } from '../../domain/time';
import { KINDS } from './kinds';

/**
 * Reads one sentence about a car — «پژو تعویض روغن امروز کیلومتر ۸۵ هزار، بعدی ۵ هزار
 * کیلومتر دیگه، هزینه ۲ میلیون» or «بیمه ثالث تا ۲۰ اسفند» — into the fields of a record.
 * Nothing is saved from here: the result fills the record form, which the person checks.
 */

export interface VehicleParseContext {
  now: number;
  timezone: string;
  calendar: 'jalali' | 'gregorian';
  vehicles: Pick<Vehicle, 'id' | 'name' | 'make' | 'model' | 'odometer'>[];
}

export interface VehicleEntry {
  /** the car the sentence names, or the only car; null when it is unclear */
  vehicleId: string | null;
  kind: VehicleRecordKind | null;
  title: string;
  date: string | null;
  validUntil: string | null;
  odometer: number | null;
  nextDueKm: number | null;
  nextDueDate: string | null;
  cost: number | null;
  currency: string | null;
  /** only a new odometer reading was said («کیلومتر ۸۶ هزار») */
  odometerOnly: boolean;
}

const KM = '(?:کیلو\\s*متر|کیلومتر|کیلو|km|kilometers?|kilometres?|kms)';
const LATER = '(?:دیگه|دیگر|بعد|later|from\\s*now)';
const NEXT = '(?:بعدی|دفعه\\s*بعد(?:ی)?|نوبت\\s*بعد(?:ی)?|سری\\s*بعد|next(?:\\s*(?:one|at|due|in))?)';
const UNIT_WORD: Record<string, 'day' | 'month' | 'year'> = { روز: 'day', ماه: 'month', سال: 'year', day: 'day', days: 'day', month: 'month', months: 'month', year: 'year', years: 'year' };

function escapeRe(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * The car named in the sentence: the longest name, «make model», model or make that appears,
 * or a word of them that belongs to only one car («پژو» for «پژو سفید»).
 */
function findVehicle(sc: Scanner, vehicles: VehicleParseContext['vehicles']): string | null {
  const candidates: { id: string; phrase: string }[] = [];
  const owners = new Map<string, Set<string>>();
  for (const v of vehicles) {
    for (const p of [v.name, `${v.make} ${v.model}`, v.model, v.make]) {
      const n = normalizeKeepLength(p).replace(/\s+/g, ' ').trim();
      if (n.length >= 2) candidates.push({ id: v.id, phrase: n });
      for (const w of n.split(' ')) if (w.length >= 3 && !/^\d+$/.test(w)) owners.set(w, (owners.get(w) ?? new Set()).add(v.id));
    }
  }
  for (const [w, ids] of owners) if (ids.size === 1) candidates.push({ id: [...ids][0]!, phrase: w });
  candidates.sort((a, b) => b.phrase.length - a.phrase.length);
  for (const c of candidates) {
    const re = new RegExp(`${S}${c.phrase.split(' ').map(escapeRe).join('\\s*')}(?:\\s*م)?${E}`);
    if (sc.take(re)) return c.id;
  }
  return vehicles.length === 1 ? vehicles[0]!.id : null;
}

function findKind(sc: Scanner): VehicleRecordKind | null {
  const words: { kind: VehicleRecordKind; re: string }[] = [];
  for (const k of KINDS) for (const w of k.words) words.push({ kind: k.kind, re: w });
  // «بیمه» alone means the compulsory third-party policy unless «بدنه» is said
  words.push({ kind: 'insurance_third', re: 'بیمه(?:\\s*نامه)?' }, { kind: 'insurance_third', re: 'insurance' });
  let best: { kind: VehicleRecordKind; len: number; at: number } | null = null;
  for (const w of words) {
    const m = new RegExp(`${S}(?:${w.re})${E}`, 'u').exec(sc.norm);
    if (m && (!best || m[0].length > best.len || (m[0].length === best.len && m.index < best.at))) best = { kind: w.kind, len: m[0].length, at: m.index };
  }
  if (!best) return null;
  const chosen = words.filter((w) => w.kind === best!.kind);
  for (const w of [...chosen].sort((a, b) => b.re.length - a.re.length)) if (sc.take(new RegExp(`${S}(?:${w.re})${E}`))) break;
  return best.kind;
}

function addSpan(base: string, n: number, unit: 'day' | 'month' | 'year', calendar: VehicleParseContext['calendar']): string {
  if (unit === 'day') return addDaysISO(base, Math.round(n));
  return addMonthsInCalendar(base, Math.round(unit === 'year' ? n * 12 : n), calendar);
}

/** Splits off «تا …» (until) when what follows it really is a date or a length of time. */
function splitUntil(raw: string, ctx: VehicleParseContext): { main: string; until: string | null; span: { n: number; unit: 'day' | 'month' | 'year' } | null } {
  const norm = normalizeKeepLength(raw);
  const re = new RegExp(`${S}(?:اعتبار(?:\\s*ش)?\\s*)?(?:تا|الی|until|till|expires?(?:\\s*on)?|valid\\s*until|انقضا(?:ی|ش)?|سررسید(?:ش)?)\\s+`, 'gu');
  let m: RegExpExecArray | null;
  while ((m = re.exec(norm))) {
    const after = raw.slice(m.index + m[0].length);
    const usc = new Scanner(after);
    const u = extractDateTime(usc, { now: ctx.now, timezone: ctx.timezone });
    if (u.date && !u.dateAssumed) return { main: `${raw.slice(0, m.index)} ${usc.rest()}`, until: u.date, span: null };
    const span = new Scanner(after).take(new RegExp(`^\\s*(${NUMBER_RE})?\\s*(سال|ماه|روز|years?|months?|days?)\\s*(?:دیگه|دیگر|بعد|later)?${E}`));
    if (span) {
      const n = span[1] ? readNumber(span[1]) : 1;
      if (n !== null) return { main: `${raw.slice(0, m.index)} ${after.slice(span.index + span[0].length)}`, until: null, span: { n, unit: UNIT_WORD[span[2]!] ?? 'year' } };
    }
  }
  return { main: raw, until: null, span: null };
}

export function parseVehicleCommand(raw: string, ctx: VehicleParseContext): VehicleEntry {
  const today = todayISO(ctx.timezone, ctx.now);
  // «تا …» (until) carries the end date of a policy; read it separately so the start date and
  // the end date do not get mixed up.
  const split = splitUntil(raw, ctx);

  // which car first; the rest is read without its name in the way («کیلومتر پژو ۸۷ هزار»)
  const pre = new Scanner(split.main);
  pre.take(new RegExp(`^\\s*(?:ماشین|خودرو|اتومبیل|اتول|my\\s*car|car|vehicle)(?:\\s*م)?${E}`));
  const vehicleId = findVehicle(pre, ctx.vehicles);
  const sc = new Scanner(pre.rest());
  const known = ctx.vehicles.find((v) => v.id === vehicleId);
  const kind = findKind(sc);
  const validity = kind !== null && KINDS.find((k) => k.kind === kind)!.validity;

  let odometer: number | null = null;
  let nextDueKm: number | null = null;
  let nextKmDelta: number | null = null;
  let nextDueDate: string | null = null;
  let nextSpan: { n: number; unit: 'day' | 'month' | 'year' } | null = null;
  let validSpan: { n: number; unit: 'day' | 'month' | 'year' } | null = split.span;
  let cost: number | null = null;
  let currency: string | null = null;

  // next time, by distance: «بعدی ۵ هزار کیلومتر دیگه», «۵۰۰۰ کیلومتر دیگه», «بعدی ۹۰ هزار»
  let m = sc.take(new RegExp(`${S}(?:${NEXT}\\s*(?:در|سر|تو|at|in)?\\s*)?(${NUMBER_RE})\\s*${KM}\\s*${LATER}${E}`));
  if (m) nextKmDelta = readNumber(m[1]!);
  if (nextKmDelta === null) {
    m = sc.take(new RegExp(`${S}${NEXT}\\s*(?:در|سر|تو|at|in)?\\s*(${NUMBER_RE})\\s*${KM}?${E}`));
    if (m) {
      const n = readNumber(m[1]!);
      if (n !== null) nextDueKm = n;
    }
  }
  // a length of time from now: «بعدی ۶ ماه دیگه», «سه ماه دیگه» (for a policy: when it runs out)
  m = sc.take(new RegExp(`${S}(?:${NEXT}\\s*(?:در|in)?\\s*)?(${NUMBER_RE})\\s*(روز|ماه|سال|days?|months?|years?)\\s*${LATER}${E}`));
  if (m) {
    const n = readNumber(m[1]!);
    if (n !== null) nextSpan = { n, unit: UNIT_WORD[m[2]!] ?? 'month' };
  }
  // how long a policy runs: «یک ساله», «۶ ماهه», «برای یک سال», «for one year»
  m = sc.take(new RegExp(`${S}(?:برای\\s*|به\\s*مدت\\s*|for\\s*(?:a|one)?\\s*)?(${NUMBER_RE})?\\s*(سال|ماه|years?|months?)(?:ه\\s*ای|ه|ی)?${E}`));
  if (m) {
    const n = m[1] ? readNumber(m[1]) : 1;
    if (n !== null) validSpan ??= { n, unit: UNIT_WORD[m[2]!] ?? 'year' };
  }
  // odometer: «کیلومتر ۸۵ هزار», «کارکرد ۸۵۰۰۰», «۸۵ هزار کیلومتر»
  m =
    sc.take(new RegExp(`${S}(?:کیلومتر|کیلو\\s*متر|کارکرد|کیلومتراژ|کیلومتر\\s*شمار|odometer|mileage)\\s*(?:(?:ش|اش|فعلی|الان|ماشین|خودرو|روی|is|at|:)\\s*)*(${NUMBER_RE})${E}`)) ??
    sc.take(new RegExp(`${S}(?:(?:در|سر|با|at)\\s*)?(${NUMBER_RE})\\s*${KM}${E}`));
  if (m) odometer = readNumber(m[1]!);
  // cost: «هزینه ۲ میلیون», «۲ میلیون تومان», «$40»
  m =
    sc.take(new RegExp(`${S}(?:هزینه|قیمت|مبلغ|پول|پرداخت|حق\\s*بیمه|cost|price|paid|for)(?:\\s*(?:ش|اش|شد|کردم|دادم|:))*\\s*(${NUMBER_RE})(?:\\s*(${CURRENCY_RE}))?${E}`)) ??
    sc.take(new RegExp(`${S}(${NUMBER_RE})\\s*(${CURRENCY_RE})${E}`));
  if (m) {
    cost = readNumber(m[1]!);
    if (m[2]) currency = currencyCode(m[2]);
  } else {
    const dollars = sc.take(/\$\s*(\d+(?:[.,]\d+)?)/);
    if (dollars) {
      cost = Number(dollars[1]!.replace(',', '.'));
      currency = 'USD';
    }
  }

  // the day it was done (or the policy starts)
  const dt = extractDateTime(sc, { now: ctx.now, timezone: ctx.timezone });
  const date = dt.date && !dt.dateAssumed ? dt.date : today;
  let validUntil: string | null = split.until;
  if (validity && !validUntil && nextSpan) validUntil = addSpan(today, nextSpan.n, nextSpan.unit, ctx.calendar);
  if (!validUntil && validSpan) validUntil = addSpan(date, validSpan.n, validSpan.unit, ctx.calendar);
  if (nextSpan && !validity) nextDueDate = addSpan(date, nextSpan.n, nextSpan.unit, ctx.calendar);
  const base = odometer ?? known?.odometer ?? null;
  if (nextKmDelta !== null) nextDueKm = base !== null ? base + nextKmDelta : null;
  else if (nextDueKm !== null && base !== null && nextDueKm < base) nextDueKm = base + nextDueKm;

  const title = stripFillers(
    sc.rest(),
    ['از', 'ثبت\\s*کن', 'برای', 'و', 'را', 'رو', 'record', 'add', 'log', 'the', 'did', 'got', 'had'],
    [
      'انجام\\s*شد',
      'انجام\\s*دادم',
      'عوض\\s*کردم',
      'عوض\\s*شد',
      'تعویض\\s*شد',
      'تمدید\\s*شد',
      'تمدید\\s*کردم',
      'تمام\\s*می\\s*شه',
      'تموم\\s*می\\s*شه',
      'تمام\\s*میشه',
      'تموم\\s*میشه',
      'تمام\\s*می\\s*شود',
      'منقضی\\s*میشه',
      'کردم',
      'زدم',
      'شد',
      'دادم',
      'گرفتم',
      'خریدم',
      'ثبت\\s*کن',
      'است',
      'هست',
      'و',
      'از',
      'را',
      'رو',
      'done',
      'today',
    ],
  );

  const saidMore = cost !== null || nextDueKm !== null || nextKmDelta !== null || nextDueDate !== null || !!validUntil || (!!dt.date && !dt.dateAssumed);
  const odometerOnly = kind === null && odometer !== null && !saidMore && !title;
  return {
    vehicleId,
    kind,
    title: odometerOnly ? '' : title,
    date,
    validUntil,
    odometer,
    nextDueKm: nextDueKm !== null ? Math.round(nextDueKm) : null,
    nextDueDate,
    cost,
    currency,
    odometerOnly,
  };
}
