import { db, nowIso, uid } from '../../data/db';
import { DomainError, VEHICLE_RECORD_KINDS, type Vehicle, type VehicleRecord, type VehicleRecordKind } from '../../domain/types';
import { toAsciiDigits } from '../../domain/normalize';
import { isValidISODate } from '../../domain/time';
import { kindMeta } from './kinds';

/**
 * Cars and their records. A car holds what identifies it (plate, VIN…) and its last odometer
 * reading; every insurance policy, inspection, oil change or repair is a record of its own,
 * so the history stays complete and the latest record of a kind is what counts as current.
 */

export interface VehicleInput {
  name: string;
  make: string;
  model: string;
  year: string;
  color: string;
  plate: string;
  vin: string;
  engineNo: string;
  odometer: number | null;
  notes: string;
}

export function emptyVehicle(): VehicleInput {
  return { name: '', make: '', model: '', year: '', color: '', plate: '', vin: '', engineNo: '', odometer: null, notes: '' };
}

export function inputFromVehicle(v: Vehicle): VehicleInput {
  return { name: v.name, make: v.make, model: v.model, year: v.year, color: v.color, plate: v.plate, vin: v.vin, engineNo: v.engineNo, odometer: v.odometer, notes: v.notes };
}

/** VIN as stored: Latin digits, upper case, no spaces or dashes. */
export function normalizeVin(v: string): string {
  return toAsciiDigits(v).toUpperCase().replace(/[\s\-_.]/g, '');
}

/**
 * A modern VIN has 17 characters and never uses I, O or Q. Older or local chassis numbers can
 * differ, so this only warns.
 */
export function vinProblem(vin: string): 'chars' | 'length' | null {
  const v = normalizeVin(vin);
  if (!v) return null;
  if (!/^[A-HJ-NPR-Z0-9]+$/.test(v)) return 'chars';
  if (v.length !== 17) return 'length';
  return null;
}

export function validateVehicle(i: VehicleInput): Record<string, string> {
  const e: Record<string, string> = {};
  if (!i.name.trim() && !i.make.trim() && !i.model.trim()) e.name = 'required';
  if (i.odometer !== null && !(Number.isFinite(i.odometer) && i.odometer >= 0)) e.odometer = 'invalid';
  return e;
}

/** The name shown everywhere: what the person typed, or make + model. */
export function displayName(i: Pick<VehicleInput, 'name' | 'make' | 'model'>): string {
  return i.name.trim() || `${i.make.trim()} ${i.model.trim()}`.trim();
}

function clean(i: VehicleInput) {
  return {
    name: displayName(i).slice(0, 80),
    make: i.make.trim().slice(0, 60),
    model: i.model.trim().slice(0, 60),
    year: toAsciiDigits(i.year.trim()).slice(0, 12),
    color: i.color.trim().slice(0, 40),
    plate: i.plate.trim().replace(/\s+/g, ' ').slice(0, 40),
    vin: normalizeVin(i.vin).slice(0, 30),
    engineNo: toAsciiDigits(i.engineNo).trim().toUpperCase().slice(0, 40),
    notes: i.notes.trim().slice(0, 2000),
  };
}

export async function createVehicle(moduleId: string, i: VehicleInput, today: string): Promise<Vehicle> {
  const errors = validateVehicle(i);
  if (Object.keys(errors).length) throw new DomainError('INVALID_INPUT', undefined, errors);
  const ts = nowIso();
  const order = (await db.vehicles.where('moduleId').equals(moduleId).toArray()).reduce((m, v) => Math.max(m, v.order), -1) + 1;
  const v: Vehicle = {
    id: uid(),
    moduleId,
    ...clean(i),
    odometer: i.odometer,
    odometerDate: i.odometer !== null ? today : null,
    order,
    createdAt: ts,
    updatedAt: ts,
  };
  await db.vehicles.add(v);
  return v;
}

export async function updateVehicle(id: string, i: VehicleInput, today: string): Promise<void> {
  const errors = validateVehicle(i);
  if (Object.keys(errors).length) throw new DomainError('INVALID_INPUT', undefined, errors);
  await db.transaction('rw', db.vehicles, async () => {
    const v = await db.vehicles.get(id);
    if (!v) throw new DomainError('NOT_FOUND');
    const odometerChanged = i.odometer !== v.odometer;
    await db.vehicles.put({ ...v, ...clean(i), odometer: i.odometer, odometerDate: odometerChanged ? (i.odometer !== null ? today : null) : v.odometerDate, updatedAt: nowIso() });
  });
}

/** Records a new odometer reading (from the quick "km" button or a voice command). */
export async function setOdometer(id: string, km: number, today: string): Promise<void> {
  if (!(Number.isFinite(km) && km >= 0)) throw new DomainError('INVALID_INPUT', undefined, { odometer: 'invalid' });
  await db.vehicles.update(id, { odometer: Math.round(km), odometerDate: today, updatedAt: nowIso() });
}

/** Removes a car with all its records and the reminders raised for them. */
export async function deleteVehicle(id: string): Promise<void> {
  await db.transaction('rw', db.vehicles, db.vehicleRecords, db.reminders, async () => {
    const ids = await db.vehicleRecords.where('vehicleId').equals(id).primaryKeys();
    for (const rid of ids) await db.reminders.where('sourceId').equals(rid).delete();
    await db.vehicleRecords.where('vehicleId').equals(id).delete();
    await db.vehicles.delete(id);
  });
}

export interface RecordInput {
  kind: VehicleRecordKind;
  title: string;
  date: string;
  validUntil: string | null;
  odometer: number | null;
  nextDueKm: number | null;
  nextDueDate: string | null;
  cost: number | null;
  currency: string;
  provider: string;
  reference: string;
  items: string[];
  notes: string;
  remind: boolean;
}

export function emptyRecord(kind: VehicleRecordKind, today: string, currency: string): RecordInput {
  const meta = kindMeta(kind);
  return {
    kind,
    title: '',
    date: today,
    validUntil: null,
    odometer: null,
    nextDueKm: null,
    nextDueDate: null,
    cost: null,
    currency,
    provider: '',
    reference: '',
    items: [],
    notes: '',
    remind: meta.validity || meta.nextDue,
  };
}

export function inputFromRecord(r: VehicleRecord): RecordInput {
  return {
    kind: r.kind,
    title: r.title,
    date: r.date,
    validUntil: r.validUntil,
    odometer: r.odometer,
    nextDueKm: r.nextDueKm,
    nextDueDate: r.nextDueDate,
    cost: r.cost,
    currency: r.currency,
    provider: r.provider,
    reference: r.reference,
    items: [...r.items],
    notes: r.notes,
    remind: r.remind,
  };
}

const okNum = (n: number | null) => n === null || (Number.isFinite(n) && n >= 0);

export function validateRecord(i: RecordInput): Record<string, string> {
  const e: Record<string, string> = {};
  const meta = kindMeta(i.kind);
  if (!(VEHICLE_RECORD_KINDS as readonly string[]).includes(i.kind)) e.kind = 'invalid';
  if (!isValidISODate(i.date)) e.date = 'required';
  if (meta.validity) {
    if (!i.validUntil || !isValidISODate(i.validUntil)) e.validUntil = 'required';
    else if (isValidISODate(i.date) && i.validUntil < i.date) e.validUntil = 'before_start';
  }
  if (!okNum(i.odometer)) e.odometer = 'invalid';
  if (!okNum(i.cost)) e.cost = 'invalid';
  if (!okNum(i.nextDueKm)) e.nextDueKm = 'invalid';
  else if (i.nextDueKm !== null && i.odometer !== null && i.nextDueKm <= i.odometer) e.nextDueKm = 'not_after';
  if (i.nextDueDate && (!isValidISODate(i.nextDueDate) || (isValidISODate(i.date) && i.nextDueDate < i.date))) e.nextDueDate = 'before_start';
  if (i.kind === 'other' && !i.title.trim()) e.title = 'required';
  return e;
}

function cleanRecord(i: RecordInput) {
  const meta = kindMeta(i.kind);
  return {
    kind: i.kind,
    title: i.title.trim().slice(0, 120),
    date: i.date,
    validUntil: meta.validity ? i.validUntil : null,
    odometer: i.odometer === null ? null : Math.round(i.odometer),
    nextDueKm: meta.validity || i.nextDueKm === null ? null : Math.round(i.nextDueKm),
    nextDueDate: meta.validity ? null : i.nextDueDate,
    cost: i.cost,
    currency: i.currency,
    provider: i.provider.trim().slice(0, 80),
    reference: toAsciiDigits(i.reference).trim().slice(0, 60),
    items: [...new Set(i.items.map((x) => x.trim()).filter(Boolean))].slice(0, 12),
    notes: i.notes.trim().slice(0, 2000),
    remind: i.remind,
  };
}

/** A reading in a record moves the car's odometer forward (never backward). */
async function bumpOdometer(vehicleId: string, km: number | null, date: string) {
  if (km === null) return;
  const v = await db.vehicles.get(vehicleId);
  if (v && (v.odometer === null || km > v.odometer)) await db.vehicles.update(vehicleId, { odometer: Math.round(km), odometerDate: date, updatedAt: nowIso() });
}

export async function addRecord(vehicleId: string, i: RecordInput, idem?: string): Promise<VehicleRecord> {
  const errors = validateRecord(i);
  if (Object.keys(errors).length) throw new DomainError('INVALID_INPUT', undefined, errors);
  return db.transaction('rw', db.vehicles, db.vehicleRecords, db.kv, async () => {
    if (idem) {
      const seen = await db.kv.get(`idem:veh:${idem}`);
      const existing = seen ? await db.vehicleRecords.get(String(seen.value)) : undefined;
      if (existing) return existing;
    }
    const v = await db.vehicles.get(vehicleId);
    if (!v) throw new DomainError('NOT_FOUND');
    const ts = nowIso();
    const rec: VehicleRecord = { id: uid(), vehicleId, moduleId: v.moduleId, ...cleanRecord(i), createdAt: ts, updatedAt: ts };
    await db.vehicleRecords.add(rec);
    if (idem) await db.kv.put({ key: `idem:veh:${idem}`, value: rec.id });
    await bumpOdometer(vehicleId, rec.odometer, rec.date);
    return rec;
  });
}

export async function updateRecord(id: string, i: RecordInput): Promise<void> {
  const errors = validateRecord(i);
  if (Object.keys(errors).length) throw new DomainError('INVALID_INPUT', undefined, errors);
  await db.transaction('rw', db.vehicles, db.vehicleRecords, async () => {
    const r = await db.vehicleRecords.get(id);
    if (!r) throw new DomainError('NOT_FOUND');
    const next = { ...r, ...cleanRecord(i), updatedAt: nowIso() };
    await db.vehicleRecords.put(next);
    await bumpOdometer(r.vehicleId, next.odometer, next.date);
  });
}

export async function deleteRecord(id: string): Promise<void> {
  await db.transaction('rw', db.vehicleRecords, db.reminders, async () => {
    await db.reminders.where('sourceId').equals(id).delete();
    await db.vehicleRecords.delete(id);
  });
}
