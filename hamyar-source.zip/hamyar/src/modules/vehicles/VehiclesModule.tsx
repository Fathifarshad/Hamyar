import { useEffect, useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { ModuleInstance, Vehicle, VehicleRecord, VehicleRecordKind } from '../../domain/types';
import { VEHICLE_RECORD_KINDS } from '../../domain/types';
import { Button, Chip, EmptyState, Field, IconButton, Input, Modal, Notice, Select, Switch } from '../../ui/primitives';
import { DatePicker } from '../../ui/DatePicker';
import { VoiceInput } from '../../ui/VoiceInput';
import { CalendarClock, Car, Copy, Gauge, Info, Pencil, Plus, TrashIcon, TriangleAlert, Wrench } from '../../ui/icons';
import { CURRENCY_CODES } from '../../domain/catalog';
import { currencyLabel } from '../../lib/format';
import { parseLocaleNumber, toAsciiDigits } from '../../domain/normalize';
import { addMonthsInCalendar } from '../../domain/jalali';
import { askConfirm, toast } from '../../lib/ui-store';
import { errorText } from '../../i18n/errors';
import { useHandoff } from '../../lib/handoff';
import { useVoiceMode, examplesFor, MoreLink } from '../shared';
import { KINDS, kindLabel, kindMeta } from './kinds';
import { attention, costTotals, dueItems, type DueItem } from './due';
import {
  addRecord,
  createVehicle,
  deleteRecord,
  deleteVehicle,
  emptyRecord,
  emptyVehicle,
  inputFromRecord,
  inputFromVehicle,
  normalizeVin,
  setOdometer,
  updateRecord,
  updateVehicle,
  validateRecord,
  validateVehicle,
  vinProblem,
  type RecordInput,
  type VehicleInput,
} from './data';
import { parseVehicleCommand } from './parse';

type T = (fa: string, en: string, params?: Record<string, string | number>) => string;

const numOrNull = (s: string): number | null => {
  if (!s.trim()) return null;
  const n = parseLocaleNumber(s);
  return n === null ? NaN : n;
};
const numText = (n: number | null) => (n === null || Number.isNaN(n) ? '' : String(n));

function unitOf(mod: ModuleInstance): 'km' | 'mi' {
  return mod.config.unit === 'mi' ? 'mi' : 'km';
}

function useDistance(mod: ModuleInstance) {
  const { t, num } = useApp();
  const unit = unitOf(mod);
  return (n: number) => (unit === 'mi' ? t('{n} مایل', '{n} mi', { n: num(n) }) : t('{n} کیلومتر', '{n} km', { n: num(n) }));
}

// ───────────────────────── car form ─────────────────────────

function VehicleForm({ mod, vehicle, open, onClose, onSaved }: { mod: ModuleInstance; vehicle: Vehicle | null; open: boolean; onClose: () => void; onSaved?: (v: Vehicle) => void }) {
  const { t, today } = useApp();
  const base = useMemo(() => (vehicle ? inputFromVehicle(vehicle) : emptyVehicle()), [vehicle]);
  const [v, setV] = useState<VehicleInput>(base);
  const [odo, setOdo] = useState('');
  const [tried, setTried] = useState(false);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (open) {
      setV(base);
      setOdo(numText(base.odometer));
      setTried(false);
    }
  }, [open, base]);
  const set = (p: Partial<VehicleInput>) => setV((x) => ({ ...x, ...p }));
  const input: VehicleInput = { ...v, odometer: numOrNull(odo) };
  const errors = validateVehicle(input);
  const vin = vinProblem(v.vin);

  const save = async () => {
    setTried(true);
    if (Object.keys(errors).length) return;
    setBusy(true);
    try {
      if (vehicle) await updateVehicle(vehicle.id, input, today);
      else {
        const created = await createVehicle(mod.id, input, today);
        onSaved?.(created);
      }
      toast({ kind: 'success', text: t('مشخصات خودرو ذخیره شد.', 'Car details saved.') });
      onClose();
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!vehicle) return;
    const ok = await askConfirm({
      title: t('حذف «{name}» و همه سوابق آن؟', 'Delete “{name}” and all its records?', { name: vehicle.name }),
      body: t('بیمه‌ها، معاینه‌ها، سرویس‌ها و تعمیرات ثبت‌شده‌ی این خودرو هم حذف می‌شوند.', 'Its insurance, inspection, service and repair records are deleted too.'),
      confirmText: t('حذف', 'Delete'),
      cancelText: t('انصراف', 'Cancel'),
      danger: true,
    });
    if (!ok) return;
    await deleteVehicle(vehicle.id);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={vehicle ? t('ویرایش مشخصات خودرو', 'Edit car') : t('افزودن خودرو', 'Add a car')}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          {vehicle && (
            <Button variant="danger" icon={<TrashIcon size={15} />} onClick={() => void remove()} className="me-auto">
              {t('حذف', 'Delete')}
            </Button>
          )}
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" busy={busy} onClick={() => void save()}>
            {t('ذخیره', 'Save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" data-accent={mod.appearance.accent}>
        <Field label={t('نام خودرو', 'Name')} hint={t('مثلاً «پژو سفید» یا «ماشین بابا»', 'e.g. “White Peugeot” or “Dad’s car”')} error={tried && errors.name ? t('یک نام یا سازنده و مدل بنویسید.', 'Enter a name, or the make and model.') : undefined}>
          <VoiceInput value={v.name} onChange={(name) => set({ name })} lang={mod.inputLanguage} ownerId={`veh-name-${mod.id}`} inputLabel={t('نام خودرو', 'Name')} maxLength={80} />
        </Field>
        <div className="form-row">
          <Field label={t('سازنده', 'Make')}>
            <Input aria-label={t('سازنده', 'Make')} value={v.make} onChange={(e) => set({ make: e.target.value })} maxLength={60} placeholder={t('مثلاً ایران‌خودرو، تویوتا', 'e.g. Toyota')} />
          </Field>
          <Field label={t('مدل', 'Model')}>
            <Input aria-label={t('مدل', 'Model')} value={v.model} onChange={(e) => set({ model: e.target.value })} maxLength={60} placeholder={t('مثلاً ۲۰۶ تیپ ۲', 'e.g. Corolla')} />
          </Field>
        </div>
        <div className="form-row">
          <Field label={t('سال ساخت', 'Year')}>
            <Input aria-label={t('سال ساخت', 'Year')} value={v.year} onChange={(e) => set({ year: e.target.value })} maxLength={12} inputMode="numeric" />
          </Field>
          <Field label={t('رنگ', 'Colour')}>
            <Input aria-label={t('رنگ', 'Colour')} value={v.color} onChange={(e) => set({ color: e.target.value })} maxLength={40} />
          </Field>
        </div>
        <Field label={t('پلاک', 'Plate')}>
          <Input aria-label={t('پلاک', 'Plate')} value={v.plate} onChange={(e) => set({ plate: e.target.value })} maxLength={40} placeholder={t('مثلاً ۱۲ ب ۳۴۵ ایران ۶۷', 'e.g. AB-CD-12')} />
        </Field>
        <Field
          label={t('شماره شاسی (VIN)', 'VIN')}
          hint={vin === 'length' ? t('VIN استاندارد ۱۷ نویسه است؛ اگر شماره‌ی خودروی شما فرق دارد، همان را نگه دارید.', 'A standard VIN has 17 characters; keep yours if it differs.') : vin === 'chars' ? t('در VIN حروف I، O و Q به کار نمی‌روند؛ شاید ۱ یا ۰ بوده‌اند.', 'VINs never use I, O or Q; they may be 1 or 0.') : t('روی کارت ماشین یا پایین شیشه‌ی جلو', 'On the registration card or under the windscreen')}
        >
          <Input aria-label={t('شماره شاسی (VIN)', 'VIN')} value={v.vin} onChange={(e) => set({ vin: e.target.value })} onBlur={() => set({ vin: normalizeVin(v.vin) })} maxLength={30} dir="ltr" className="mono" autoCapitalize="characters" spellCheck={false} />
        </Field>
        <div className="form-row">
          <Field label={t('شماره موتور', 'Engine number')}>
            <Input aria-label={t('شماره موتور', 'Engine number')} value={v.engineNo} onChange={(e) => set({ engineNo: e.target.value })} maxLength={40} dir="ltr" spellCheck={false} />
          </Field>
          <Field label={unitOf(mod) === 'mi' ? t('کیلومتر فعلی (مایل)', 'Odometer (mi)') : t('کیلومتر فعلی', 'Odometer (km)')} error={tried && errors.odometer ? t('عدد معتبر بنویسید.', 'Enter a valid number.') : undefined}>
            <Input aria-label={t('کیلومتر فعلی', 'Odometer')} value={odo} onChange={(e) => setOdo(e.target.value)} inputMode="numeric" dir="ltr" />
          </Field>
        </div>
        <Field label={t('یادداشت (اختیاری)', 'Notes (optional)')}>
          <VoiceInput value={v.notes} onChange={(notes) => set({ notes })} lang={mod.inputLanguage} ownerId={`veh-notes-${mod.id}`} inputLabel={t('یادداشت', 'Notes')} multiline rows={2} maxLength={2000} />
        </Field>
      </div>
    </Modal>
  );
}

// ───────────────────────── record form ─────────────────────────

function providerLabel(kind: VehicleRecordKind, t: T): string {
  if (kind === 'insurance_third' || kind === 'insurance_body') return t('شرکت بیمه', 'Insurer');
  if (kind === 'inspection') return t('مرکز معاینه فنی', 'Inspection centre');
  if (kind === 'toll') return t('محل پرداخت', 'Paid at');
  return t('تعمیرگاه یا فروشگاه', 'Garage or shop');
}

function referenceLabel(kind: VehicleRecordKind, t: T): string {
  if (kind === 'insurance_third' || kind === 'insurance_body') return t('شماره بیمه‌نامه', 'Policy number');
  if (kind === 'inspection') return t('شماره برگه', 'Certificate number');
  return t('شماره فاکتور / رسید', 'Invoice / receipt no.');
}

export interface RecordDraft {
  vehicleId: string | null;
  record: VehicleRecord | null;
  initial: Partial<RecordInput> & { kind: VehicleRecordKind };
}

function RecordForm({ mod, vehicles, draft, onClose }: { mod: ModuleInstance; vehicles: Vehicle[]; draft: RecordDraft | null; onClose: () => void }) {
  const { t, today, locale, profile, num } = useApp();
  const currency = (mod.config.currency as string) ?? 'IRT';
  const [vehicleId, setVehicleId] = useState<string>('');
  const [v, setV] = useState<RecordInput>(() => emptyRecord('oil', today, currency));
  const [text, setText] = useState({ odometer: '', nextDueKm: '', cost: '' });
  const [tried, setTried] = useState(false);
  const [busy, setBusy] = useState(false);
  const idem = useMemo(() => uid(), [draft]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!draft) return;
    const start = draft.record ? inputFromRecord(draft.record) : { ...emptyRecord(draft.initial.kind, today, currency), ...draft.initial };
    setV(start);
    setText({ odometer: numText(start.odometer), nextDueKm: numText(start.nextDueKm), cost: numText(start.cost) });
    setVehicleId(draft.record?.vehicleId ?? draft.vehicleId ?? (vehicles.length === 1 ? vehicles[0]!.id : ''));
    setTried(false);
  }, [draft, today, currency, vehicles]);
  if (!draft) return null;
  const meta = kindMeta(v.kind);
  const vehicle = vehicles.find((x) => x.id === vehicleId) ?? null;
  const input: RecordInput = { ...v, odometer: numOrNull(text.odometer), nextDueKm: numOrNull(text.nextDueKm), cost: numOrNull(text.cost) };
  const errors = validateRecord(input);
  const err = (k: string): string | undefined => {
    if (!tried || !errors[k]) return undefined;
    if (k === 'validUntil') return errors[k] === 'before_start' ? t('پایان نمی‌تواند قبل از شروع باشد.', 'The end cannot be before the start.') : t('تاریخ پایان اعتبار را وارد کنید.', 'Enter the end date.');
    if (k === 'nextDueKm') return errors[k] === 'not_after' ? t('باید بیشتر از کیلومتر همین سرویس باشد.', 'Must be more than this service’s reading.') : t('عدد معتبر بنویسید.', 'Enter a valid number.');
    if (k === 'nextDueDate') return t('نباید قبل از تاریخ انجام باشد.', 'Cannot be before the service date.');
    if (k === 'title') return t('بنویسید چه کاری انجام شد.', 'Say what was done.');
    if (k === 'date') return t('تاریخ را وارد کنید.', 'Enter the date.');
    return t('عدد معتبر بنویسید.', 'Enter a valid number.');
  };
  const set = (p: Partial<RecordInput>) => setV((x) => ({ ...x, ...p }));
  const plusMonths = (from: string, n: number) => addMonthsInCalendar(from, n, profile.calendar);
  const baseKm = input.odometer ?? vehicle?.odometer ?? null;

  const save = async () => {
    setTried(true);
    if (!vehicleId || Object.keys(errors).length) return;
    setBusy(true);
    try {
      if (draft.record) await updateRecord(draft.record.id, input);
      else await addRecord(vehicleId, input, idem);
      toast({ kind: 'success', text: t('«{k}» برای {car} ثبت شد.', '“{k}” saved for {car}.', { k: input.title || (locale === 'fa' ? meta.fa : meta.en), car: vehicle?.name ?? '' }) });
      onClose();
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!draft.record) return;
    const ok = await askConfirm({ title: t('حذف این سابقه؟', 'Delete this record?'), confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (!ok) return;
    await deleteRecord(draft.record.id);
    onClose();
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={draft.record ? t('ویرایش سابقه', 'Edit record') : t('ثبت برای خودرو', 'New car record')}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          {draft.record && (
            <Button variant="danger" icon={<TrashIcon size={15} />} onClick={() => void remove()} className="me-auto">
              {t('حذف', 'Delete')}
            </Button>
          )}
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" busy={busy} onClick={() => void save()}>
            {t('ذخیره', 'Save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" data-accent={mod.appearance.accent}>
        <div className="form-row">
          <Field label={t('خودرو', 'Car')} error={tried && !vehicleId ? t('خودرو را انتخاب کنید.', 'Choose the car.') : undefined}>
            <Select value={vehicleId} onChange={(e) => setVehicleId(e.target.value)} aria-label={t('خودرو', 'Car')}>
              {!vehicleId && <option value="">{t('انتخاب کنید…', 'Choose…')}</option>}
              {vehicles.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={t('نوع', 'Type')}>
            <Select value={v.kind} onChange={(e) => set({ kind: e.target.value as VehicleRecordKind, remind: kindMeta(e.target.value as VehicleRecordKind).validity || kindMeta(e.target.value as VehicleRecordKind).nextDue })} aria-label={t('نوع', 'Type')}>
              {VEHICLE_RECORD_KINDS.map((k) => (
                <option key={k} value={k}>
                  {kindLabel(k, locale)}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label={v.kind === 'other' ? t('چه کاری؟', 'What was done?') : t('شرح (اختیاری)', 'Details (optional)')} error={err('title')}>
          <VoiceInput value={v.title} onChange={(title) => set({ title })} lang={mod.inputLanguage} ownerId={`veh-title-${mod.id}`} inputLabel={t('شرح', 'Details')} maxLength={120} placeholder={meta.validity ? '' : t('مثلاً روغن ۱۰W40 بهران', 'e.g. 5W-30 synthetic')} />
        </Field>
        <div className="form-row">
          <Field label={meta.validity ? t('تاریخ شروع', 'Starts on') : t('تاریخ انجام', 'Date done')} error={err('date')}>
            <DatePicker value={v.date} onChange={(d) => d && set({ date: d })} label={t('تاریخ', 'Date')} />
          </Field>
          {meta.validity ? (
            <Field label={t('اعتبار تا', 'Valid until')} error={err('validUntil')}>
              <DatePicker value={v.validUntil} onChange={(d) => set({ validUntil: d })} label={t('اعتبار تا', 'Valid until')} allowClear />
            </Field>
          ) : (
            <Field label={unitOf(mod) === 'mi' ? t('کارکرد (مایل)', 'Odometer (mi)') : t('کیلومتر', 'Odometer (km)')} error={err('odometer')}>
              <Input aria-label={t('کیلومتر', 'Odometer')} value={text.odometer} onChange={(e) => setText({ ...text, odometer: e.target.value })} inputMode="numeric" dir="ltr" placeholder={vehicle?.odometer ? toAsciiDigits(String(vehicle.odometer)) : ''} />
            </Field>
          )}
        </div>
        {meta.validity && (
          <div className="chip-row">
            <Button size="sm" variant="soft" onClick={() => set({ validUntil: plusMonths(v.date, 12) })}>
              {t('یک ساله', '1 year')}
            </Button>
            <Button size="sm" variant="soft" onClick={() => set({ validUntil: plusMonths(v.date, 6) })}>
              {t('شش ماهه', '6 months')}
            </Button>
          </div>
        )}
        {!meta.validity && meta.nextDue && (
          <fieldset className="fieldset">
            <legend>{t('نوبت بعدی (اختیاری)', 'Next due (optional)')}</legend>
            <div className="form-row">
              <Field label={unitOf(mod) === 'mi' ? t('در کارکرد (مایل)', 'At (mi)') : t('در کیلومتر', 'At (km)')} error={err('nextDueKm')}>
                <Input aria-label={t('در کیلومتر', 'At (km)')} value={text.nextDueKm} onChange={(e) => setText({ ...text, nextDueKm: e.target.value })} inputMode="numeric" dir="ltr" />
              </Field>
              <Field label={t('یا تا تاریخ', 'Or by date')} error={err('nextDueDate')}>
                <DatePicker value={v.nextDueDate} onChange={(d) => set({ nextDueDate: d })} label={t('تاریخ نوبت بعد', 'Next due date')} allowClear />
              </Field>
            </div>
            <div className="chip-row">
              {baseKm !== null &&
                [5000, 10000].map((n) => (
                  <Button key={n} size="sm" variant="soft" onClick={() => setText({ ...text, nextDueKm: String(baseKm + n) })}>
                    +{num(n)}
                  </Button>
                ))}
              {[3, 6, 12].map((n) => (
                <Button key={n} size="sm" variant="soft" onClick={() => set({ nextDueDate: plusMonths(v.date, n) })}>
                  {n === 12 ? t('+۱ سال', '+1 year') : t('+{n} ماه', '+{n} months', { n })}
                </Button>
              ))}
            </div>
          </fieldset>
        )}
        {meta.items && (
          <div className="chip-row" role="group" aria-label={t('همراه با', 'Also done')}>
            {meta.items.map(([fa, en]) => {
              const label = locale === 'fa' ? fa : en;
              const on = v.items.includes(label);
              return (
                <button key={label} type="button" className={`day-chip${on ? ' is-on' : ''}`} aria-pressed={on} onClick={() => set({ items: on ? v.items.filter((x) => x !== label) : [...v.items, label] })}>
                  {label}
                </button>
              );
            })}
          </div>
        )}
        <div className="form-row">
          <Field label={t('هزینه (اختیاری)', 'Cost (optional)')} error={err('cost')}>
            <Input aria-label={t('هزینه (اختیاری)', 'Cost (optional)')} value={text.cost} onChange={(e) => setText({ ...text, cost: e.target.value })} inputMode="decimal" dir="ltr" />
          </Field>
          <Field label={t('واحد پول', 'Currency')}>
            <Select aria-label={t('واحد پول', 'Currency')} value={v.currency} onChange={(e) => set({ currency: e.target.value })}>
              {CURRENCY_CODES.map((c) => (
                <option key={c} value={c}>
                  {currencyLabel(c, locale)}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <div className="form-row">
          <Field label={providerLabel(v.kind, t)}>
            <Input aria-label={providerLabel(v.kind, t)} value={v.provider} onChange={(e) => set({ provider: e.target.value })} maxLength={80} />
          </Field>
          <Field label={referenceLabel(v.kind, t)}>
            <Input aria-label={referenceLabel(v.kind, t)} value={v.reference} onChange={(e) => set({ reference: e.target.value })} maxLength={60} dir="ltr" />
          </Field>
        </div>
        <Field label={t('یادداشت (اختیاری)', 'Notes (optional)')}>
          <VoiceInput value={v.notes} onChange={(notes) => set({ notes })} lang={mod.inputLanguage} ownerId={`veh-rnotes-${mod.id}`} inputLabel={t('یادداشت', 'Notes')} multiline rows={2} maxLength={2000} />
        </Field>
        {(meta.validity || v.nextDueDate) && (
          <Switch
            checked={v.remind}
            onChange={(remind) => set({ remind })}
            label={meta.validity ? t('یادآوری پیش از پایان اعتبار', 'Remind me before it runs out') : t('یادآوری پیش از نوبت بعد', 'Remind me before it is due')}
            description={t('۳۰، ۷ و ۱ روز قبل و همان روز، ساعت ۱۰ صبح.', '30, 7 and 1 day before, and on the day, at 10:00.')}
          />
        )}
      </div>
    </Modal>
  );
}

// ───────────────────────── odometer ─────────────────────────

function OdometerDialog({ mod, vehicle, initial, onClose }: { mod: ModuleInstance; vehicle: Vehicle | null; initial?: number | null; onClose: () => void }) {
  const { t, today } = useApp();
  const [value, setValue] = useState('');
  const [tried, setTried] = useState(false);
  useEffect(() => {
    setValue(numText(initial ?? vehicle?.odometer ?? null));
    setTried(false);
  }, [vehicle, initial]);
  if (!vehicle) return null;
  const n = numOrNull(value);
  const valid = n !== null && Number.isFinite(n) && n >= 0;
  const lower = valid && vehicle.odometer !== null && n! < vehicle.odometer;
  const save = async () => {
    setTried(true);
    if (!valid) return;
    await setOdometer(vehicle.id, n!, today);
    toast({ kind: 'success', text: t('کیلومتر «{car}» به‌روز شد.', 'Odometer of “{car}” updated.', { car: vehicle.name }) });
    onClose();
  };
  return (
    <Modal
      open
      onClose={onClose}
      size="sm"
      title={t('کیلومتر فعلی «{car}»', 'Current odometer of “{car}”', { car: vehicle.name })}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" onClick={() => void save()}>
            {t('ذخیره', 'Save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" data-accent={mod.appearance.accent}>
        <Field label={unitOf(mod) === 'mi' ? t('کارکرد (مایل)', 'Reading (mi)') : t('کیلومتر', 'Reading (km)')} error={tried && !valid ? t('عدد معتبر بنویسید.', 'Enter a valid number.') : undefined}>
          <Input aria-label={t('کیلومتر', 'Reading')} value={value} onChange={(e) => setValue(e.target.value)} inputMode="numeric" dir="ltr" autoFocus />
        </Field>
        {lower && (
          <Notice tone="warn" icon={<Info size={16} />}>
            {t('این عدد از کیلومتر قبلی کمتر است. اگر درست است، ذخیره کنید.', 'This is lower than the last reading. Save if it is right.')}
          </Notice>
        )}
      </div>
    </Modal>
  );
}

// ───────────────────────── status ─────────────────────────

function statusTone(s: DueItem['status']): 'danger' | 'warn' | 'ok' | 'neutral' {
  return s === 'overdue' || s === 'due' ? 'danger' : s === 'soon' ? 'warn' : s === 'ok' ? 'ok' : 'neutral';
}

function useDueText(mod: ModuleInstance) {
  const { t, date, num } = useApp();
  const dist = useDistance(mod);
  return (d: DueItem): string => {
    const meta = kindMeta(d.kind);
    if (!d.record) return t('ثبت نشده', 'Not recorded');
    const parts: string[] = [];
    if (d.daysLeft !== null) {
      if (d.daysLeft < 0) parts.push(meta.validity ? t('{n} روز است که تمام شده', 'Ran out {n} days ago', { n: num(-d.daysLeft) }) : t('{n} روز گذشته', '{n} days late', { n: num(-d.daysLeft) }));
      else if (d.daysLeft === 0) parts.push(meta.validity ? t('امروز تمام می‌شود', 'Runs out today') : t('موعدش امروز است', 'Due today'));
      else parts.push(t('{n} روز مانده', '{n} days left', { n: num(d.daysLeft) }));
    }
    if (d.kmLeft !== null) parts.push(d.kmLeft < 0 ? t('{d} گذشته', '{d} over', { d: dist(-d.kmLeft) }) : t('{d} مانده', '{d} to go', { d: dist(d.kmLeft) }));
    else if (d.dueKm !== null) parts.push(t('در {d}', 'at {d}', { d: dist(d.dueKm) }));
    if (!parts.length) parts.push(t('آخرین بار: {d}', 'Last: {d}', { d: date(d.record.date, 'short') }));
    return parts.join(' · ');
  };
}

function StatusTile({ mod, item, onAdd }: { mod: ModuleInstance; item: DueItem; onAdd: () => void }) {
  const { t, locale, date } = useApp();
  const text = useDueText(mod);
  const tone = statusTone(item.status);
  return (
    <li className={`veh-tile is-${item.status}`}>
      <div className="veh-tile-head">
        <span className="veh-tile-kind">{kindLabel(item.kind, locale)}</span>
        {item.status !== 'none' && item.status !== 'ok' && (
          <Chip tone={tone} icon={<TriangleAlert size={12} />}>
            {item.status === 'soon' ? t('نزدیک', 'Soon') : item.status === 'due' ? t('امروز', 'Today') : t('گذشته', 'Late')}
          </Chip>
        )}
      </div>
      <div className="veh-tile-main">{text(item)}</div>
      {item.dueDate && <div className="veh-tile-sub subtle xsmall">{kindMeta(item.kind).validity ? t('تا {d}', 'Until {d}', { d: date(item.dueDate, 'medium') }) : t('نوبت بعد: {d}', 'Next: {d}', { d: date(item.dueDate, 'medium') })}</div>}
      <Button size="sm" variant="soft" icon={<Plus size={13} />} onClick={onAdd}>
        {item.record ? (kindMeta(item.kind).validity ? t('تمدید', 'Renew') : t('ثبت جدید', 'Log again')) : t('ثبت', 'Add')}
      </Button>
    </li>
  );
}

// ───────────────────────── module ─────────────────────────

export default function VehiclesModule({ mod, variant, focus }: ModuleViewProps) {
  const { t, today, tz, locale, date, money, profile, bidi } = useApp();
  const vehicles = useLiveQuery(() => db.vehicles.where('moduleId').equals(mod.id).sortBy('order'), [mod.id]);
  const records = useLiveQuery(() => db.vehicleRecords.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const [selected, setSelected] = useState<string | null>(focus ?? null);
  const [vform, setVform] = useState<{ open: boolean; vehicle: Vehicle | null }>({ open: false, vehicle: null });
  const [rdraft, setRdraft] = useState<RecordDraft | null>(null);
  const [odo, setOdo] = useState<{ vehicle: Vehicle; initial?: number | null } | null>(null);
  const [voice, setVoice] = useState('');
  const [kindFilter, setKindFilter] = useState<'all' | VehicleRecordKind>('all');
  const { mode, setMode } = useVoiceMode(mod);
  const dist = useDistance(mod);
  const dueText = useDueText(mod);
  const currency = (mod.config.currency as string) ?? 'IRT';

  useEffect(() => {
    if (focus) setSelected(focus);
  }, [focus]);

  const current = (vehicles ?? []).find((v) => v.id === selected) ?? vehicles?.[0] ?? null;

  const onCommand = async (text: string) => {
    const list = vehicles ?? [];
    if (!list.length) {
      toast({ kind: 'warning', text: t('اول یک خودرو اضافه کنید.', 'Add a car first.') });
      setVform({ open: true, vehicle: null });
      return;
    }
    const e = parseVehicleCommand(text, { now: Date.now(), timezone: tz, calendar: profile.calendar, vehicles: list });
    const vehicle = list.find((v) => v.id === e.vehicleId) ?? null;
    if (vehicle) setSelected(vehicle.id);
    if (e.odometerOnly && e.odometer !== null) {
      if (vehicle) setOdo({ vehicle, initial: e.odometer });
      else toast({ kind: 'warning', text: t('بگویید کیلومتر کدام خودرو است.', 'Say which car the reading is for.') });
      return;
    }
    setRdraft({
      vehicleId: vehicle?.id ?? null,
      record: null,
      initial: {
        kind: e.kind ?? 'other',
        title: e.title,
        date: e.date ?? today,
        validUntil: e.validUntil,
        odometer: e.odometer,
        nextDueKm: e.nextDueKm,
        nextDueDate: e.nextDueDate,
        cost: e.cost,
        currency: e.currency ?? currency,
      },
    });
    setVoice('');
  };

  useHandoff(mod.id, variant === 'full' && !!vehicles && !!records, (text) => void onCommand(text));

  if (!vehicles || !records) return <div className="mod-loading" />;

  const dialogs = (
    <>
      <VehicleForm mod={mod} vehicle={vform.vehicle} open={vform.open} onClose={() => setVform({ open: false, vehicle: null })} onSaved={(v) => setSelected(v.id)} />
      <RecordForm mod={mod} vehicles={vehicles} draft={rdraft} onClose={() => setRdraft(null)} />
      {odo && <OdometerDialog mod={mod} vehicle={odo.vehicle} initial={odo.initial} onClose={() => setOdo(null)} />}
    </>
  );

  const voiceBox = (
    <VoiceInput
      value={voice}
      onChange={setVoice}
      lang={mod.inputLanguage}
      ownerId={`veh-${mod.id}-${variant}`}
      inputLabel={t('ثبت سریع برای خودرو', 'Quick car entry')}
      placeholder={t('مثلاً «تعویض روغن امروز کیلومتر ۸۵ هزار»', 'e.g. “oil change today at 85000 km”')}
      mode={mode}
      onModeChange={setMode}
      onCommand={(s) => void onCommand(s)}
      onSubmit={(s) => void onCommand(s)}
      submitLabel={t('بررسی و ثبت', 'Review and save')}
      examples={examplesFor(mod, locale)}
      maxLength={300}
    />
  );

  if (vehicles.length === 0) {
    return (
      <div className="stack">
        <EmptyState
          icon={<Car size={22} />}
          title={t('هنوز خودرویی ثبت نشده', 'No cars yet')}
          text={t('مشخصات خودرو را وارد کنید تا بیمه، معاینه فنی، تعویض روغن و تعمیرات را اینجا نگه دارید و پیش از سررسید یادآوری بگیرید.', 'Add a car to keep its insurance, inspection, oil changes and repairs here, with reminders before they are due.')}
          action={
            <Button variant="accent" icon={<Plus size={16} />} onClick={() => setVform({ open: true, vehicle: null })}>
              {t('افزودن خودرو', 'Add a car')}
            </Button>
          }
        />
        {dialogs}
      </div>
    );
  }

  if (variant === 'card') {
    const urgent = attention(vehicles, records, today);
    const shown = vehicles.slice(0, 3);
    return (
      <div className="stack">
        {mode === 'command' && voiceBox}
        {urgent.length > 0 && (
          <ul className="rows">
            {urgent.slice(0, mod.appearance.density === 'compact' ? 5 : 3).map((d) => (
              <li key={`${d.vehicle.id}|${d.kind}`} className="row">
                <a className="row-main" href={`#/m/${mod.id}?focus=${encodeURIComponent(d.vehicle.id)}`}>
                  <span className="row-title">
                    {kindLabel(d.kind, locale)} · <span className="auto-dir" dir={bidi(d.vehicle.name)}>{d.vehicle.name}</span>
                  </span>
                  <span className="row-meta">
                    <Chip tone={statusTone(d.status)}>{dueText(d)}</Chip>
                  </span>
                </a>
              </li>
            ))}
          </ul>
        )}
        <ul className="rows">
          {shown.map((v) => (
            <li key={v.id} className="row">
              <a className="row-main" href={`#/m/${mod.id}?focus=${encodeURIComponent(v.id)}`}>
                <span className="row-title auto-dir" dir={bidi(v.name)}>
                  {v.name}
                </span>
                <span className="row-meta">
                  {v.plate && <span className="veh-plate">{v.plate}</span>}
                  {v.odometer !== null && <span className="num">{dist(v.odometer)}</span>}
                </span>
              </a>
            </li>
          ))}
        </ul>
        {urgent.length === 0 && <p className="subtle small">{t('همه‌ی بیمه‌ها و سرویس‌های ثبت‌شده مرتب‌اند.', 'All recorded insurance and services are in order.')}</p>}
        <MoreLink mod={mod} count={vehicles.length - shown.length} />
        {dialogs}
      </div>
    );
  }

  // full view
  const car = current!;
  const carRecords = records.filter((r) => r.vehicleId === car.id);
  const items = dueItems(car, records, today);
  const history = carRecords.filter((r) => kindFilter === 'all' || r.kind === kindFilter).sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : a.createdAt < b.createdAt ? 1 : -1));
  const totalsAll = costTotals(carRecords);
  const twelveMonthsAgo = addMonthsInCalendar(today, -12, profile.calendar);
  const totalsYear = costTotals(carRecords, twelveMonthsAgo);
  const newRecord = (kind: VehicleRecordKind) => setRdraft({ vehicleId: car.id, record: null, initial: { kind, currency } });
  const copyVin = async () => {
    try {
      await navigator.clipboard.writeText(car.vin);
      toast({ kind: 'success', text: t('VIN کپی شد.', 'VIN copied.') });
    } catch {
      toast({ kind: 'warning', text: t('کپی ممکن نشد.', 'Could not copy.') });
    }
  };

  return (
    <div className="stack">
      <div className="full-toolbar">
        <div className="chip-row" role="tablist" aria-label={t('خودروها', 'Cars')}>
          {vehicles.map((v) => (
            <button key={v.id} type="button" role="tab" aria-selected={v.id === car.id} className={`day-chip${v.id === car.id ? ' is-on' : ''}`} onClick={() => setSelected(v.id)}>
              <span className="auto-dir" dir={bidi(v.name)}>
                {v.name}
              </span>
            </button>
          ))}
        </div>
        <Button variant="soft" icon={<Plus size={16} />} onClick={() => setVform({ open: true, vehicle: null })}>
          {t('خودروی دیگر', 'Another car')}
        </Button>
      </div>
      {voiceBox}

      <section className="veh-head card-flat" aria-label={t('مشخصات', 'Details')}>
        <div className="veh-head-top">
          <span className="veh-icon" aria-hidden="true">
            <Car size={22} />
          </span>
          <div className="grow">
            <h3 className="veh-name auto-dir" dir={bidi(car.name)}>
              {car.name}
            </h3>
            <div className="subtle small">{[car.make, car.model, car.year, car.color].filter(Boolean).join(' · ')}</div>
          </div>
          <IconButton label={t('ویرایش مشخصات', 'Edit details')} size="sm" onClick={() => setVform({ open: true, vehicle: car })}>
            <Pencil size={15} />
          </IconButton>
        </div>
        <dl className="veh-ids">
          {car.plate && (
            <div>
              <dt>{t('پلاک', 'Plate')}</dt>
              <dd>
                <span className="veh-plate">{car.plate}</span>
              </dd>
            </div>
          )}
          {car.vin && (
            <div>
              <dt>VIN</dt>
              <dd className="row-flex">
                <span className="mono ltr">{car.vin}</span>
                <IconButton label={t('کپی VIN', 'Copy VIN')} size="sm" onClick={() => void copyVin()}>
                  <Copy size={14} />
                </IconButton>
              </dd>
            </div>
          )}
          {car.engineNo && (
            <div>
              <dt>{t('شماره موتور', 'Engine no.')}</dt>
              <dd className="mono ltr">{car.engineNo}</dd>
            </div>
          )}
          <div>
            <dt>{t('کیلومتر', 'Odometer')}</dt>
            <dd className="row-flex">
              <span className="num">{car.odometer !== null ? dist(car.odometer) : t('ثبت نشده', 'not set')}</span>
              {car.odometerDate && <span className="subtle xsmall">({date(car.odometerDate, 'short')})</span>}
              <Button size="sm" variant="soft" icon={<Gauge size={14} />} onClick={() => setOdo({ vehicle: car })}>
                {t('به‌روزرسانی', 'Update')}
              </Button>
            </dd>
          </div>
        </dl>
      </section>

      <ul className="veh-tiles" aria-label={t('وضعیت', 'Status')}>
        {items.map((d) => (
          <StatusTile key={d.kind} mod={mod} item={d} onAdd={() => newRecord(d.kind)} />
        ))}
      </ul>

      <div className="row-flex wrap">
        <Select value="" onChange={(e) => e.target.value && newRecord(e.target.value as VehicleRecordKind)} aria-label={t('ثبت مورد جدید', 'Add a record')} className="grow">
          <option value="">{t('＋ ثبت سرویس، تعمیر یا مدرک…', '+ Log a service, repair or document…')}</option>
          {KINDS.map((k) => (
            <option key={k.kind} value={k.kind}>
              {locale === 'fa' ? k.fa : k.en}
            </option>
          ))}
        </Select>
      </div>

      {(totalsAll.size > 0 || totalsYear.size > 0) && (
        <div className="stat-pair">
          <div className="stat">
            <div className="stat-label">{t('هزینه‌ی ۱۲ ماه اخیر', 'Last 12 months')}</div>
            <div className="stat-value num">{[...totalsYear.entries()].map(([c, v]) => money(v, c)).join(' + ') || money(0, currency)}</div>
          </div>
          <div className="stat">
            <div className="stat-label">{t('کل هزینه‌ها', 'All costs')}</div>
            <div className="stat-value num">{[...totalsAll.entries()].map(([c, v]) => money(v, c)).join(' + ')}</div>
          </div>
        </div>
      )}

      <section aria-label={t('سابقه', 'History')} className="stack-sm">
        <div className="row-flex spread wrap">
          <h3 className="sec-h">{t('سابقه', 'History')}</h3>
          <Select value={kindFilter} onChange={(e) => setKindFilter(e.target.value as typeof kindFilter)} aria-label={t('فیلتر نوع', 'Filter by type')}>
            <option value="all">{t('همه', 'All')}</option>
            {KINDS.filter((k) => carRecords.some((r) => r.kind === k.kind)).map((k) => (
              <option key={k.kind} value={k.kind}>
                {locale === 'fa' ? k.fa : k.en}
              </option>
            ))}
          </Select>
        </div>
        {history.length === 0 ? (
          <EmptyState icon={<Wrench size={22} />} title={t('هنوز چیزی برای این خودرو ثبت نشده', 'Nothing recorded for this car yet')} text={t('بیمه، معاینه فنی یا آخرین تعویض روغن را ثبت کنید.', 'Add its insurance, inspection or last oil change.')} />
        ) : (
          <ul className="rows">
            {history.map((r) => (
              <li key={r.id} className="row">
                <button type="button" className="row-main" onClick={() => setRdraft({ vehicleId: car.id, record: r, initial: { kind: r.kind } })}>
                  <span className="row-title auto-dir" dir={bidi(r.title || kindLabel(r.kind, locale))}>
                    {kindLabel(r.kind, locale)}
                    {r.title ? ` · ${r.title}` : ''}
                  </span>
                  <span className="row-meta">
                    <span>{date(r.date, 'short')}</span>
                    {r.validUntil && (
                      <span>
                        <CalendarClock size={12} aria-hidden="true" /> {t('تا {d}', 'to {d}', { d: date(r.validUntil, 'short') })}
                      </span>
                    )}
                    {r.odometer !== null && <span className="num">{dist(r.odometer)}</span>}
                    {r.provider && <span className="auto-dir" dir={bidi(r.provider)}>{r.provider}</span>}
                    {r.items.length > 0 && <span>{r.items.join('، ')}</span>}
                  </span>
                </button>
                {r.cost !== null && <span className="amount num">{money(r.cost, r.currency)}</span>}
              </li>
            ))}
          </ul>
        )}
      </section>
      {car.notes && <p className="subtle small para-dir pre-wrap">{car.notes}</p>}
      <p className="subtle xsmall">{t('یادآوری‌ها ۳۰، ۷ و ۱ روز پیش از پایان بیمه، معاینه فنی و نوبت‌های تاریخ‌دار، و همان روز می‌آیند.', 'Reminders come 30, 7 and 1 day before insurance, inspection and dated services run out or are due, and on the day.')}</p>
      {dialogs}
    </div>
  );
}

