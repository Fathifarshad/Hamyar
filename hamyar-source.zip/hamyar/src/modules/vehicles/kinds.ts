import type { VehicleRecordKind } from '../../domain/types';

/**
 * What each kind of car record means. `validity` kinds (insurance, inspection, road tax) are
 * valid until a date the person enters; the others are work done that may be due again.
 * `tracked` kinds get a status tile on every car even before anything is recorded.
 */
export interface KindMeta {
  kind: VehicleRecordKind;
  fa: string;
  en: string;
  validity: boolean;
  nextDue: boolean;
  tracked: boolean;
  /** voice/typed words that name this kind (normalized: «ا» for «آ», spaces where ZWNJ was) */
  words: string[];
  /** suggestions for the "done with it" chips */
  items?: [fa: string, en: string][];
}

export const KINDS: KindMeta[] = [
  {
    kind: 'insurance_third',
    fa: 'بیمه شخص ثالث',
    en: 'Third-party insurance',
    validity: true,
    nextDue: false,
    tracked: true,
    words: ['بیمه\\s*(?:ی\\s*)?(?:شخص\\s*)?ثالث', 'بیمه\\s*نامه\\s*(?:ی\\s*)?ثالث', 'ثالث', 'third\\s*party(?:\\s*insurance)?', 'liability\\s*insurance'],
  },
  {
    kind: 'insurance_body',
    fa: 'بیمه بدنه',
    en: 'Body insurance',
    validity: true,
    nextDue: false,
    tracked: true,
    words: ['بیمه\\s*(?:ی\\s*)?بدنه', 'بدنه', 'body\\s*insurance', 'collision\\s*insurance', 'comprehensive(?:\\s*insurance)?'],
  },
  {
    kind: 'inspection',
    fa: 'معاینه فنی',
    en: 'Inspection',
    validity: true,
    nextDue: false,
    tracked: true,
    words: ['معاینه\\s*(?:ی\\s*)?فنی', 'معاینه', 'inspection', 'mot', 'revision\\s*tecnica', 'revisión\\s*técnica'],
  },
  {
    kind: 'toll',
    fa: 'عوارض سالیانه',
    en: 'Road tax',
    validity: true,
    nextDue: false,
    tracked: false,
    words: ['عوارض\\s*(?:ی\\s*)?(?:سالیانه|سالانه|شهرداری)', 'عوارض', 'road\\s*tax', 'registration\\s*fee', 'permiso\\s*de\\s*circulacion'],
  },
  {
    kind: 'oil',
    fa: 'تعویض روغن',
    en: 'Oil change',
    validity: false,
    nextDue: true,
    tracked: true,
    words: ['تعویض\\s*(?:ی\\s*)?روغن(?:\\s*موتور)?', 'روغن\\s*موتور', 'روغن', 'oil\\s*change', 'oil'],
    items: [
      ['فیلتر روغن', 'Oil filter'],
      ['فیلتر هوا', 'Air filter'],
      ['فیلتر کابین', 'Cabin filter'],
      ['فیلتر بنزین', 'Fuel filter'],
    ],
  },
  {
    kind: 'service',
    fa: 'سرویس دوره‌ای',
    en: 'Scheduled service',
    validity: false,
    nextDue: true,
    tracked: false,
    words: ['سرویس\\s*(?:ی\\s*)?(?:دوره\\s*ای|کامل|ادواری)', 'سرویس', 'service'],
  },
  {
    kind: 'tires',
    fa: 'لاستیک',
    en: 'Tires',
    validity: false,
    nextDue: true,
    tracked: false,
    words: ['لاستیک(?:\\s*ها)?', 'تایر', 'تعویض\\s*لاستیک', 'tires?', 'tyres?'],
    items: [
      ['بالانس', 'Balancing'],
      ['تنظیم فرمان', 'Alignment'],
      ['جابه‌جایی لاستیک‌ها', 'Rotation'],
    ],
  },
  {
    kind: 'brakes',
    fa: 'لنت و ترمز',
    en: 'Brakes',
    validity: false,
    nextDue: true,
    tracked: false,
    words: ['لنت(?:\\s*ترمز)?', 'ترمز', 'brakes?', 'brake\\s*pads?'],
  },
  {
    kind: 'battery',
    fa: 'باتری',
    en: 'Battery',
    validity: false,
    nextDue: true,
    tracked: false,
    words: ['باتری', 'battery'],
  },
  {
    kind: 'repair',
    fa: 'تعمیر',
    en: 'Repair',
    validity: false,
    nextDue: false,
    tracked: false,
    words: ['تعمیرات', 'تعمیر', 'صافکاری', 'نقاشی', 'مکانیکی', 'repairs?', 'fixed', 'bodywork'],
  },
  {
    kind: 'other',
    fa: 'سایر',
    en: 'Other',
    validity: false,
    nextDue: true,
    tracked: false,
    words: ['کارواش', 'شستشو', 'car\\s*wash'],
  },
];

export const KIND_BY_ID = new Map(KINDS.map((k) => [k.kind, k]));

export function kindMeta(kind: VehicleRecordKind): KindMeta {
  return KIND_BY_ID.get(kind) ?? KINDS[KINDS.length - 1]!;
}

export function kindLabel(kind: VehicleRecordKind, locale: 'fa' | 'en'): string {
  const k = kindMeta(kind);
  return locale === 'fa' ? k.fa : k.en;
}
