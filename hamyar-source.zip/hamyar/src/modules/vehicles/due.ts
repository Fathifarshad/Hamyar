import type { ModuleInstance, Vehicle, VehicleRecord, VehicleRecordKind } from '../../domain/types';
import { addDaysISO, diffDaysISO, zonedToUtc } from '../../domain/time';
import { KINDS, kindMeta } from './kinds';

/**
 * What is due on each car: the latest record of a kind is the one that counts (a renewed
 * policy replaces the old one), its end date or next-service date/odometer is compared with
 * today and the car's last odometer reading. Pure functions, shared by the screen, the in-app
 * reminders and the Android reminder plan.
 */

export type DueStatus = 'none' | 'ok' | 'soon' | 'due' | 'overdue';

export interface DueItem {
  vehicle: Vehicle;
  kind: VehicleRecordKind;
  /** the latest record of this kind (null: a tracked kind nothing is recorded for yet) */
  record: VehicleRecord | null;
  dueDate: string | null;
  dueKm: number | null;
  daysLeft: number | null;
  kmLeft: number | null;
  status: DueStatus;
}

export const SOON_DAYS = 30;
export const SOON_KM = 1000;

const RANK: Record<DueStatus, number> = { overdue: 0, due: 1, soon: 2, ok: 3, none: 4 };

/** Latest record per kind: by date, then by when it was entered. */
export function latestByKind(records: VehicleRecord[]): Map<VehicleRecordKind, VehicleRecord> {
  const map = new Map<VehicleRecordKind, VehicleRecord>();
  for (const r of records) {
    const cur = map.get(r.kind);
    if (!cur || r.date > cur.date || (r.date === cur.date && r.createdAt > cur.createdAt)) map.set(r.kind, r);
  }
  return map;
}

function dateStatus(days: number, soonDays: number): DueStatus {
  if (days < 0) return 'overdue';
  if (days === 0) return 'due';
  return days <= soonDays ? 'soon' : 'ok';
}

function worst(a: DueStatus, b: DueStatus): DueStatus {
  return RANK[a] <= RANK[b] ? a : b;
}

export function dueItems(vehicle: Vehicle, records: VehicleRecord[], today: string, opts: { soonDays?: number; soonKm?: number } = {}): DueItem[] {
  const soonDays = opts.soonDays ?? SOON_DAYS;
  const soonKm = opts.soonKm ?? SOON_KM;
  const latest = latestByKind(records.filter((r) => r.vehicleId === vehicle.id));
  const out: DueItem[] = [];
  for (const meta of KINDS) {
    const rec = latest.get(meta.kind) ?? null;
    if (!rec && !meta.tracked) continue;
    const item: DueItem = { vehicle, kind: meta.kind, record: rec, dueDate: null, dueKm: null, daysLeft: null, kmLeft: null, status: 'none' };
    if (rec && meta.validity && rec.validUntil) {
      item.dueDate = rec.validUntil;
      item.daysLeft = diffDaysISO(rec.validUntil, today);
      item.status = dateStatus(item.daysLeft, soonDays);
    } else if (rec && !meta.validity) {
      let status: DueStatus | null = null;
      if (rec.nextDueDate) {
        item.dueDate = rec.nextDueDate;
        item.daysLeft = diffDaysISO(rec.nextDueDate, today);
        status = dateStatus(item.daysLeft, soonDays);
      }
      if (rec.nextDueKm !== null) {
        item.dueKm = rec.nextDueKm;
        if (vehicle.odometer !== null) {
          item.kmLeft = rec.nextDueKm - vehicle.odometer;
          const km: DueStatus = item.kmLeft < 0 ? 'overdue' : item.kmLeft === 0 ? 'due' : item.kmLeft <= soonKm ? 'soon' : 'ok';
          status = status ? worst(status, km) : km;
        } else status ??= 'ok';
      }
      item.status = status ?? 'none';
      if (item.status === 'none' && !meta.tracked) continue;
    }
    out.push(item);
  }
  return out.sort((a, b) => RANK[a.status] - RANK[b.status] || (a.daysLeft ?? 1e9) - (b.daysLeft ?? 1e9));
}

/** The items that need attention (due soon or late), across all cars. */
export function attention(vehicles: Vehicle[], records: VehicleRecord[], today: string, opts?: { soonDays?: number; soonKm?: number }): DueItem[] {
  return vehicles
    .flatMap((v) => dueItems(v, records, today, opts))
    .filter((d) => d.status === 'overdue' || d.status === 'due' || d.status === 'soon')
    .sort((a, b) => RANK[a.status] - RANK[b.status] || (a.daysLeft ?? 1e9) - (b.daysLeft ?? 1e9));
}

export interface VehicleReminder {
  key: string;
  at: number;
  title: string;
  body: string;
  url: string;
  moduleId: string;
  sourceId: string;
  /** the date the reminder is about */
  due: string;
  daysBefore: number;
}

export interface VehicleReminderInput {
  modules: ModuleInstance[];
  vehicles: Vehicle[];
  records: VehicleRecord[];
  timezone: string;
  locale: 'fa' | 'en';
  /** formats an ISO date the way the person reads dates (Jalali/Gregorian, digits) */
  formatDate: (iso: string) => string;
  dig: (s: string) => string;
}

function eligible(mod: ModuleInstance | undefined): boolean {
  return !!mod && !mod.archivedAt && !mod.remindersPaused;
}

/**
 * Every reminder (before an insurance or inspection runs out, or before a service is due by
 * date) whose moment falls in (from, to]. Only the latest record of each kind counts.
 */
export function vehicleReminders(input: VehicleReminderInput, from: number, to: number): VehicleReminder[] {
  const fa = input.locale === 'fa';
  const t = (a: string, b: string) => (fa ? a : b);
  const mods = new Map(input.modules.filter((m) => m.type === 'vehicles').map((m) => [m.id, m]));
  const out: VehicleReminder[] = [];
  for (const vehicle of input.vehicles) {
    const mod = mods.get(vehicle.moduleId);
    if (!eligible(mod)) continue;
    const days = ((mod!.config.remindDays as number[] | undefined) ?? [30, 7, 1, 0]).filter((d) => Number.isFinite(d) && d >= 0);
    const time = typeof mod!.config.remindTime === 'string' ? (mod!.config.remindTime as string) : '10:00';
    const latest = latestByKind(input.records.filter((r) => r.vehicleId === vehicle.id));
    for (const rec of latest.values()) {
      if (!rec.remind) continue;
      const meta = kindMeta(rec.kind);
      const due = meta.validity ? rec.validUntil : rec.nextDueDate;
      if (!due) continue;
      const label = fa ? meta.fa : meta.en;
      for (const d of days) {
        const day = addDaysISO(due, -d);
        let at: number;
        try {
          at = zonedToUtc(day, time, input.timezone);
        } catch {
          continue;
        }
        if (at <= from || at > to) continue;
        const when = input.formatDate(due);
        const body = meta.validity
          ? d === 0
            ? t(`امروز (${when}) تمام می‌شود.`, `Runs out today (${when}).`)
            : d === 1
              ? t(`فردا (${when}) تمام می‌شود.`, `Runs out tomorrow (${when}).`)
              : t(`${d} روز دیگر (${when}) تمام می‌شود.`, `Runs out in ${d} days (${when}).`)
          : d === 0
            ? t(`موعدش امروز است (${when}).`, `Due today (${when}).`)
            : t(`${d} روز دیگر موعد آن است (${when}).`, `Due in ${d} days (${when}).`);
        out.push({
          key: `veh:${rec.id}:${due}:${d}`,
          at,
          title: `${label} · ${vehicle.name}`,
          body: input.dig(body),
          url: `#/m/${encodeURIComponent(vehicle.moduleId)}?focus=${encodeURIComponent(vehicle.id)}`,
          moduleId: vehicle.moduleId,
          sourceId: rec.id,
          due,
          daysBefore: d,
        });
      }
    }
  }
  return out.sort((a, b) => a.at - b.at || a.key.localeCompare(b.key));
}

/** Money spent per currency, optionally only from a date on. */
export function costTotals(records: VehicleRecord[], fromIso?: string): Map<string, number> {
  const map = new Map<string, number>();
  for (const r of records) {
    if (r.cost === null || !(r.cost > 0)) continue;
    if (fromIso && r.date < fromIso) continue;
    map.set(r.currency, (map.get(r.currency) ?? 0) + r.cost);
  }
  return map;
}
