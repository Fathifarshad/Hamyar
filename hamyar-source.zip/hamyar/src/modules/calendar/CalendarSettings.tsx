import { useApp } from '../../shell/AppContext';
import type { ModuleSettingsProps } from '../registry';
import { Switch } from '../../ui/primitives';

export default function CalendarSettings({ config, onChange }: ModuleSettingsProps) {
  const { t } = useApp();
  return <Switch checked={config.showHijri === true} onChange={(showHijri) => onChange({ showHijri })} label={t('نمایش تاریخ قمری', 'Show the Hijri date')} description={t('محاسبه مرورگر (ام‌القری)؛ ممکن است با تقویم رسمی یک روز فرق کند.', 'Browser calculation (Umm al-Qura); may differ by a day from official calendars.')} />;
}
