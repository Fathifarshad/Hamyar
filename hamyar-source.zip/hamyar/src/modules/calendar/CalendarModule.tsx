import { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { CalendarSystem, CountdownEvent, ModuleInstance } from '../../domain/types';
import { Button, EmptyState, Field, IconButton, Modal, Switch } from '../../ui/primitives';
import { DatePicker, MonthGrid, monthOf } from '../../ui/DatePicker';
import { VoiceInput } from '../../ui/VoiceInput';
import { CalendarDays, Gift, Plus, TrashIcon, Repeat } from '../../ui/icons';
import { diffDaysISO, parseISODate, weekdayOfISO, addDaysISO } from '../../domain/time';
import { isoToJalali, jalaliToISO, jalaliMonthDays, nextGregorianMonthDay, nextJalaliMonthDay } from '../../domain/jalali';
import { parseCommand } from '../../domain/commands/parse';
import { useGenericCommand, useVoiceMode, examplesFor } from '../shared';
import { askConfirm, toast } from '../../lib/ui-store';
import { fmtDate } from '../../lib/format';

/** The next date (today included) an event happens, following the calendar it repeats in. */
export function nextDate(e: CountdownEvent, today: string): string | null {
  if (!e.repeatYearly) return e.date;
  if (e.calendar === 'jalali') {
    const j = isoToJalali(e.date);
    return nextJalaliMonthDay(j.jm, j.jd, today) ?? nextJalaliMonthDay(j.jm, Math.min(j.jd, 29), today);
  }
  const g = parseISODate(e.date);
  return nextGregorianMonthDay(g.m, g.d, today) ?? nextGregorianMonthDay(g.m, Math.min(g.d, 28), today);
}

function chaharshanbeSuri(today: string): string {
  const jy = isoToJalali(today).jy;
  for (const y of [jy, jy + 1]) {
    let d = jalaliToISO(y, 12, jalaliMonthDays(y, 12));
    while (weekdayOfISO(d) !== 3) d = addDaysISO(d, -1);
    const tue = addDaysISO(d, -1);
    if (tue >= today) return tue;
  }
  return today;
}

function suggestions(today: string, locale: 'fa' | 'en'): { title: string; date: string; calendar: CalendarSystem; repeat: boolean }[] {
  const j = (m: number, d: number) => nextJalaliMonthDay(m, d, today)!;
  const list = [
    { title: locale === 'fa' ? 'نوروز' : 'Nowruz', date: j(1, 1), calendar: 'jalali' as const, repeat: true },
    { title: locale === 'fa' ? 'سیزده‌به‌در' : 'Sizdah Bedar', date: j(1, 13), calendar: 'jalali' as const, repeat: true },
    { title: locale === 'fa' ? 'شب یلدا' : 'Yalda night', date: j(9, 30), calendar: 'jalali' as const, repeat: true },
    { title: locale === 'fa' ? 'چهارشنبه‌سوری' : 'Chaharshanbe Suri', date: chaharshanbeSuri(today), calendar: 'jalali' as const, repeat: false },
    { title: locale === 'fa' ? 'آغاز سال میلادی' : 'New Year’s Day', date: nextGregorianMonthDay(1, 1, today)!, calendar: 'gregorian' as const, repeat: true },
  ];
  return list.sort((a, b) => (a.date < b.date ? -1 : 1));
}

function EventForm({ mod, initial, onClose }: { mod: ModuleInstance; initial: { title: string; date: string | null } | null; onClose: () => void }) {
  const { t, profile } = useApp();
  const [title, setTitle] = useState(initial?.title ?? '');
  const [date, setDate] = useState<string | null>(initial?.date ?? null);
  const [repeat, setRepeat] = useState(false);
  const [tried, setTried] = useState(false);
  if (!initial) return null;
  const save = async () => {
    setTried(true);
    if (!title.trim() || !date) return;
    await db.countdowns.add({ id: uid(), moduleId: mod.id, title: title.trim().slice(0, 80), date, repeatYearly: repeat, calendar: profile.calendar, createdAt: nowIso() });
    toast({ kind: 'success', text: t('رویداد ثبت شد.', 'Event saved.') });
    onClose();
  };
  return (
    <Modal
      open
      onClose={onClose}
      title={t('رویداد و شمارش معکوس', 'Event & countdown')}
      closeLabel={t('بستن', 'Close')}
      size="sm"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" onClick={() => void save()}>
            {t('ثبت', 'Save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" data-accent={mod.appearance.accent}>
        <Field label={t('عنوان', 'Title')} error={tried && !title.trim() ? t('عنوان را بنویسید.', 'Enter a title.') : undefined}>
          <VoiceInput value={title} onChange={setTitle} lang={mod.inputLanguage} ownerId={`cd-title-${mod.id}`} inputLabel={t('عنوان', 'Title')} maxLength={80} />
        </Field>
        <Field label={t('تاریخ', 'Date')} error={tried && !date ? t('تاریخ را انتخاب کنید.', 'Pick a date.') : undefined}>
          <DatePicker value={date} onChange={setDate} label={t('تاریخ', 'Date')} />
        </Field>
        <Switch
          checked={repeat}
          onChange={setRepeat}
          label={t('تکرار سالانه', 'Repeat every year')}
          description={profile.calendar === 'jalali' ? t('بر اساس تقویم شمسی تکرار می‌شود.', 'Repeats by the Jalali calendar.') : t('بر اساس تقویم میلادی تکرار می‌شود.', 'Repeats by the Gregorian calendar.')}
        />
      </div>
    </Modal>
  );
}

export default function CalendarModule({ mod, variant }: ModuleViewProps) {
  const { t, today, profile, locale, date, num, tz, bidi } = useApp();
  const events = useLiveQuery(() => db.countdowns.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const [cursor, setCursor] = useState(() => monthOf(today, profile.calendar));
  const [form, setForm] = useState<{ title: string; date: string | null } | null>(null);
  const [voice, setVoice] = useState('');
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);

  const upcoming = useMemo(
    () =>
      (events ?? [])
        .map((e) => ({ e, next: nextDate(e, today) }))
        .filter((x): x is { e: CountdownEvent; next: string } => !!x.next)
        .sort((a, b) => {
          const pa = a.next < today ? 1 : 0;
          const pb = b.next < today ? 1 : 0;
          return pa - pb || (a.next < b.next ? -1 : 1);
        }),
    [events, today],
  );
  const marks = useMemo(() => new Set(upcoming.map((u) => u.next)), [upcoming]);

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'calendar', now: Date.now(), timezone: tz });
    if (d.kind === 'create_countdown') {
      setForm({ title: d.title, date: d.date });
      return;
    }
    await generic(d);
  };

  if (!events) return <div className="mod-loading" />;
  const other: CalendarSystem = profile.calendar === 'jalali' ? 'gregorian' : 'jalali';
  let hijri = '';
  if (mod.config.showHijri) {
    try {
      hijri = new Intl.DateTimeFormat(locale === 'fa' ? 'fa-IR-u-ca-islamic-umalqura' : 'en-u-ca-islamic-umalqura', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${today}T12:00:00Z`));
    } catch {
      hijri = '';
    }
  }
  const j = isoToJalali(today);
  const yearDays = jalaliMonthDays(j.jy, 12) === 30 ? 366 : 365;
  const dayOfYear = diffDaysISO(today, jalaliToISO(j.jy, 1, 1)) + 1;

  const countdown = (next: string) => {
    const n = diffDaysISO(next, today);
    if (n === 0) return t('امروز', 'Today');
    if (n === 1) return t('فردا', 'Tomorrow');
    if (n < 0) return t('گذشته', 'Passed');
    return t('{n} روز مانده', '{n} days left', { n });
  };

  const list = upcoming.slice(0, variant === 'card' ? 3 : 100);
  return (
    <div className="stack">
      <div className="today-block">
        <div className="today-big">{date(today, 'long')}</div>
        <div className="subtle small">
          {fmtDate(today, { locale, calendar: other }, 'long')}
          {hijri && ` · ${hijri}`}
        </div>
        {profile.calendar === 'jalali' && (
          <div className="subtle xsmall">{t('روز {d} از {y} روز سال', 'Day {d} of {y}', { d: dayOfYear, y: yearDays })}</div>
        )}
      </div>
      {variant === 'full' && (
        <div className="cal-wrap">
          <MonthGrid value={today} cursor={cursor} setCursor={setCursor} marks={marks} onPick={(iso) => setForm({ title: '', date: iso })} />
        </div>
      )}
      {(variant === 'full' || mode === 'command') && (
        <VoiceInput
          value={voice}
          onChange={setVoice}
          lang={mod.inputLanguage}
          ownerId={`cal-${mod.id}-${variant}`}
          inputLabel={t('رویداد جدید', 'New event')}
          placeholder={t('مثلاً «۳۰ آذر شب یلدا»', 'e.g. “December 25 Christmas”')}
          mode={mode}
          onModeChange={setMode}
          onCommand={(s) => void onCommand(s)}
          onSubmit={(s) => void onCommand(s)}
          submitLabel={t('بررسی و ثبت', 'Review and save')}
          examples={examplesFor(mod, locale)}
        />
      )}
      {list.length === 0 ? (
        <EmptyState icon={<Gift size={22} />} title={t('رویدادی برای شمارش ندارید', 'No countdowns yet')} />
      ) : (
        <ul className="rows">
          {list.map(({ e, next }) => (
            <li key={e.id} className={`row countdown${next < today ? ' is-muted' : ''}`}>
              <div className="cd-days num">{diffDaysISO(next, today) >= 0 ? num(diffDaysISO(next, today)) : '—'}</div>
              <div className="row-main is-static">
                <span className="row-title auto-dir" dir={bidi(e.title)}>{e.title}</span>
                <span className="row-meta">
                  <span>{date(next, 'medium')}</span>
                  <span>{countdown(next)}</span>
                  {e.repeatYearly && <Repeat size={12} aria-label={t('سالانه', 'Yearly')} />}
                </span>
              </div>
              {variant === 'full' && (
                <IconButton
                  label={t('حذف', 'Delete')}
                  size="sm"
                  onClick={async () => {
                    const ok = await askConfirm({ title: t('حذف «{n}»؟', 'Delete “{n}”?', { n: e.title }), confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
                    if (ok) await db.countdowns.delete(e.id);
                  }}
                >
                  <TrashIcon size={15} />
                </IconButton>
              )}
            </li>
          ))}
        </ul>
      )}
      <div className="row-flex spread wrap">
        {variant === 'card' && upcoming.length > list.length ? (
          <a className="more-link" href={`#/m/${mod.id}`}>
            {t('همه رویدادها', 'All events')}
          </a>
        ) : (
          <span />
        )}
        <Button size="sm" variant="soft" icon={<Plus size={14} />} onClick={() => setForm({ title: '', date: null })}>
          {t('رویداد', 'Event')}
        </Button>
      </div>
      {variant === 'full' && (
        <div className="stack-sm">
          <h3 className="sec-title-plain">
            <CalendarDays size={15} aria-hidden="true" /> {t('پیشنهادها', 'Suggestions')}
          </h3>
          <div className="suggest-chips">
            {suggestions(today, locale)
              .filter((s) => !events.some((e) => e.title === s.title))
              .map((s) => (
                <button
                  key={s.title}
                  type="button"
                  className="suggest-chip"
                  onClick={async () => {
                    await db.countdowns.add({ id: uid(), moduleId: mod.id, title: s.title, date: s.date, repeatYearly: s.repeat, calendar: s.calendar, createdAt: nowIso() });
                    toast({ kind: 'success', text: t('«{n}» اضافه شد.', '“{n}” added.', { n: s.title }) });
                  }}
                >
                  <Plus size={13} aria-hidden="true" /> {s.title} · {date(s.date, 'short')}
                </button>
              ))}
          </div>
        </div>
      )}
      {form && <EventForm key={`${form.title}|${form.date}`} mod={mod} initial={form} onClose={() => setForm(null)} />}
    </div>
  );
}
