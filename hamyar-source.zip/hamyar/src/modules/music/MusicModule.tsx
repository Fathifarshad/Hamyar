import { useEffect, useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { MediaItem, ModuleInstance } from '../../domain/types';
import { Button, EmptyState, Field, IconButton, Input, Modal, Notice, Segmented, Tabs } from '../../ui/primitives';
import { FileDrop } from '../../ui/FileDrop';
import { VoiceInput } from '../../ui/VoiceInput';
import {
  ArrowDown,
  ArrowUp,
  ExternalLink,
  Info,
  ListMusic,
  Music,
  Pause,
  Pencil,
  Play,
  Plus,
  Repeat,
  Repeat1,
  SkipBack,
  SkipForward,
  Star,
  TrashIcon,
  TriangleAlert,
  Volume2,
} from '../../ui/icons';
import { player, playerStore, probeMediaUrl, blobDuration } from '../../lib/media';
import { useStore } from '../../lib/store';
import { saveAsset, sniff, deleteAsset } from '../../data/assets';
import { LIMITS } from '../../config/limits';
import { checkLinkUrl, hostOf, isExternalMusicPage } from '../../domain/urls';
import { errorText } from '../../i18n/errors';
import { askConfirm, askText, toast } from '../../lib/ui-store';
import { parseCommand } from '../../domain/commands/parse';
import { matchesQuery } from '../../domain/normalize';
import { useGenericCommand, useVoiceMode, examplesFor, MoreLink } from '../shared';
import { IS_ARTIFACT } from '../../lib/platform';

function titleFromFile(name: string): string {
  return name.replace(/\.[a-z0-9]{2,5}$/i, '').replace(/[_]+/g, ' ').trim().slice(0, 120) || name;
}

async function nextOrder(moduleId: string): Promise<number> {
  const items = await db.media.where('moduleId').equals(moduleId).toArray();
  return items.reduce((m, i) => Math.max(m, i.order), -1) + 1;
}

export function AddMusicDialog({ mod, open, onClose }: { mod: ModuleInstance; open: boolean; onClose: () => void }) {
  const { t, bytes } = useApp();
  const [tab, setTab] = useState<'file' | 'url' | 'page'>('file');
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [busy, setBusy] = useState(false);
  const [log, setLog] = useState<{ name: string; ok: boolean; msg: string }[]>([]);
  const [urlError, setUrlError] = useState<string | null>(null);
  const [offerExternal, setOfferExternal] = useState(false);

  useEffect(() => {
    if (open) {
      setLog([]);
      setUrl('');
      setTitle('');
      setUrlError(null);
      setOfferExternal(false);
    }
  }, [open]);

  const addFiles = async (files: File[]) => {
    setBusy(true);
    const results: typeof log = [];
    for (const f of files) {
      try {
        const kind = await sniff(f);
        if (kind.family !== 'audio' && kind.family !== 'av') {
          results.push({ name: f.name, ok: false, msg: t('فایل صوتی شناخته‌شده نیست (MP3، M4A، WAV، OGG، FLAC).', 'Not a recognised audio file (MP3, M4A, WAV, OGG, FLAC).') });
          continue;
        }
        if (f.size > LIMITS.musicBytes) {
          results.push({ name: f.name, ok: false, msg: t('بیشتر از {max} است.', 'Larger than {max}.', { max: bytes(LIMITS.musicBytes) }) });
          continue;
        }
        const probe = document.createElement('audio');
        const can = probe.canPlayType(kind.mime);
        const asset = await saveAsset({ moduleId: mod.id, kind: 'audio', blob: f, name: f.name, maxBytes: LIMITS.musicBytes, mime: kind.mime });
        const duration = await blobDuration(f, 'audio');
        await db.media.add({
          id: uid(),
          moduleId: mod.id,
          kind: 'audio',
          sourceType: 'file',
          assetId: asset.id,
          url: null,
          embedId: null,
          title: titleFromFile(f.name),
          artist: '',
          favorite: false,
          order: await nextOrder(mod.id),
          position: 0,
          duration,
          missingFile: false,
          createdAt: nowIso(),
        });
        results.push({
          name: f.name,
          ok: true,
          msg: duration === null || can === '' ? t('ذخیره شد؛ ممکن است این مرورگر آن را پخش نکند.', 'Saved; this browser may not be able to play it.') : t('ذخیره شد.', 'Saved.'),
        });
      } catch (e) {
        results.push({ name: f.name, ok: false, msg: errorText(e, t) });
      }
      setLog([...results]);
    }
    setBusy(false);
  };

  const addUrl = async (asExternal = false) => {
    const check = checkLinkUrl(url, { requireHttps: !asExternal });
    if (!check.ok) {
      setUrlError(check.reason === 'insecure' ? t('فقط نشانی‌های https برای پخش پذیرفته می‌شوند.', 'Only https addresses can be played.') : t('نشانی معتبر نیست.', 'This address is not valid.'));
      return;
    }
    setUrlError(null);
    if (!asExternal && isExternalMusicPage(check.url)) {
      setOfferExternal(true);
      setUrlError(t('این صفحه یک سرویس پخش آنلاین است و در همیار قابل پخش نیست. می‌توانید آن را به‌عنوان لینک بیرونی ذخیره کنید.', 'This is a streaming-service page and cannot play inside Hamyar. You can save it as an external link.'));
      return;
    }
    setBusy(true);
    try {
      let duration: number | null = null;
      if (!asExternal) {
        const probe = await probeMediaUrl(check.url, 'audio');
        if (!probe.ok) {
          setOfferExternal(true);
          setUrlError(
            probe.reason === 'format'
              ? t('این نشانی فایل صوتی قابل پخش در این مرورگر نیست. می‌توانید آن را در سایت اصلی باز کنید.', 'This address is not audio this browser can play. You can open it on its own site.')
              : t('به این نشانی دسترسی نشد (مسدود، منقضی یا بدون اینترنت). می‌توانید آن را به‌عنوان لینک بیرونی ذخیره کنید.', 'Could not reach this address (blocked, expired or offline). You can save it as an external link.'),
          );
          return;
        }
        duration = probe.duration || null;
      }
      await db.media.add({
        id: uid(),
        moduleId: mod.id,
        kind: 'audio',
        sourceType: asExternal ? 'external' : 'url',
        assetId: null,
        url: check.url,
        embedId: null,
        title: (title.trim() || hostOf(check.url)).slice(0, 120),
        artist: '',
        favorite: false,
        order: await nextOrder(mod.id),
        position: 0,
        duration,
        missingFile: false,
        createdAt: nowIso(),
      });
      toast({ kind: 'success', text: asExternal ? t('لینک بیرونی ذخیره شد.', 'External link saved.') : t('به فهرست اضافه شد.', 'Added to the list.') });
      onClose();
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={t('افزودن موسیقی', 'Add music')} closeLabel={t('بستن', 'Close')}>
      <div className="stack" data-accent={mod.appearance.accent}>
        <Segmented
          label={t('منبع', 'Source')}
          value={tab}
          onChange={(v) => {
            setTab(v);
            setUrlError(null);
            setOfferExternal(false);
          }}
          options={[
            { value: 'file', label: t('فایل من', 'My files') },
            { value: 'url', label: t('نشانی مستقیم', 'Direct link') },
            { value: 'page', label: t('صفحه سایت موسیقی', 'Music site page') },
          ]}
        />
        {tab === 'file' && (
          <>
            <FileDrop
              accept="audio/*,.mp3,.m4a,.wav,.ogg,.flac,.aac,.opus"
              multiple
              onFiles={(f) => void addFiles(f)}
              disabled={busy}
              title={t('انتخاب یا رها کردن فایل‌های صوتی', 'Choose or drop audio files')}
              hint={t('MP3، M4A، WAV و… تا {max} برای هر فایل؛ فایل در همین مرورگر ذخیره می‌شود.', 'MP3, M4A, WAV… up to {max} each; stored in this browser.', { max: bytes(LIMITS.musicBytes) })}
            />
            {log.length > 0 && (
              <ul className="file-log">
                {log.map((l, i) => (
                  <li key={i} className={l.ok ? 'ok' : 'bad'}>
                    <span className="ellipsis">{l.name}</span>
                    <span>{l.msg}</span>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
        {tab !== 'file' && (
          <>
            <Field
              label={tab === 'url' ? t('نشانی مستقیم فایل صوتی (https)', 'Direct audio file address (https)') : t('نشانی صفحه (Spotify، SoundCloud، …)', 'Page address (Spotify, SoundCloud, …)')}
              error={urlError ?? undefined}
              hint={tab === 'url' ? t('مثلاً نشانی‌ای که به ‎.mp3 ختم می‌شود یا استریم رادیوی اینترنتی.', 'For example an address ending in .mp3, or an internet radio stream.') : t('این لینک فقط در سایت خودش باز می‌شود؛ پخش داخلی ندارد.', 'This link opens on its own site; it does not play inside Hamyar.')}
            >
              <Input value={url} onChange={(e) => setUrl(e.target.value)} dir="ltr" placeholder="https://" inputMode="url" />
            </Field>
            <Field label={t('عنوان (اختیاری)', 'Title (optional)')}>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
            </Field>
            {IS_ARTIFACT && tab === 'url' && (
              <Notice tone="warn" icon={<Info size={16} />}>
                {t('در پیش‌نمایش claude.ai دسترسی به اینترنت مسدود است و نشانی‌های بیرونی پخش نمی‌شوند. در نسخه قابل اجرا کار می‌کند.', 'The claude.ai preview blocks the internet, so external addresses do not play there. It works in the runnable app.')}
              </Notice>
            )}
            <div className="row-flex wrap">
              {tab === 'url' && (
                <Button variant="accent" busy={busy} onClick={() => void addUrl(false)} disabled={!url.trim()}>
                  {t('بررسی و افزودن', 'Check and add')}
                </Button>
              )}
              {(tab === 'page' || offerExternal) && (
                <Button variant={tab === 'page' ? 'accent' : 'outline'} busy={busy && tab === 'page'} icon={<ExternalLink size={15} />} onClick={() => void addUrl(true)} disabled={!url.trim()}>
                  {t('ذخیره به‌عنوان لینک بیرونی', 'Save as external link')}
                </Button>
              )}
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}

function PlayerBar({ mod, items, full }: { mod: ModuleInstance; items: MediaItem[]; full: boolean }) {
  const { t, duration, bidi } = useApp();
  const ps = useStore(playerStore);
  const mine = ps.moduleId === mod.id && ps.current;
  const playable = items.filter((i) => i.sourceType === 'file' || i.sourceType === 'url');
  if (!mine) {
    if (!playable.length) return null;
    return (
      <div className="player is-idle">
        <Button
          variant="accent"
          icon={<Play size={16} />}
          onClick={() =>
            void player.play(
              mod.id,
              playable.map((i) => i.id),
              playable[0]!.id,
            )
          }
        >
          {t('پخش فهرست', 'Play all')}
        </Button>
      </div>
    );
  }
  const errorMsg =
    ps.error === 'format'
      ? t('این فایل در این مرورگر قابل پخش نیست.', 'This file cannot play in this browser.')
      : ps.error === 'network'
        ? t('منبع در دسترس نیست (مسدود، منقضی یا بدون اینترنت).', 'The source is unreachable (blocked, expired or offline).')
        : ps.error === 'blocked'
          ? t('مرورگر پخش خودکار را اجازه نداد؛ دکمه پخش را بزنید.', 'The browser blocked autoplay; press play.')
          : ps.error === 'missing'
            ? t('فایل این مورد در این مرورگر نیست؛ دوباره اضافه‌اش کنید.', 'This item’s file is not in this browser; add it again.')
            : ps.error
              ? t('پخش انجام نشد.', 'Playback failed.')
              : null;
  return (
    <div className="player">
      <div className="player-now">
        <span className="player-art" aria-hidden="true">
          <Music size={18} />
        </span>
        <div className="grow">
          <div className="player-title auto-dir ellipsis" dir={bidi(ps.current!.title)}>{ps.current!.title}</div>
          <div className="player-sub subtle xsmall">
            <span className="num">{duration(ps.position)}</span> / <span className="num">{duration(ps.duration || ps.current!.duration || 0)}</span>
          </div>
        </div>
      </div>
      <input
        type="range"
        className="player-seek"
        min={0}
        max={Math.max(1, ps.duration)}
        step={1}
        value={Math.min(ps.position, ps.duration || 0)}
        onChange={(e) => player.seek(Number(e.target.value))}
        aria-label={t('موقعیت پخش', 'Playback position')}
        disabled={!ps.duration}
      />
      <div className="player-controls">
        <IconButton label={t('قبلی', 'Previous')} onClick={() => void player.prev()}>
          <SkipBack size={18} className="flip-rtl" />
        </IconButton>
        <IconButton label={ps.playing ? t('توقف', 'Pause') : t('پخش', 'Play')} variant="accent" onClick={() => void player.toggle()}>
          {ps.playing ? <Pause size={20} /> : <Play size={20} />}
        </IconButton>
        <IconButton label={t('بعدی', 'Next')} onClick={() => void player.next()}>
          <SkipForward size={18} className="flip-rtl" />
        </IconButton>
        <IconButton
          label={ps.repeat === 'one' ? t('تکرار یک قطعه', 'Repeat one') : ps.repeat === 'all' ? t('تکرار فهرست', 'Repeat all') : t('بدون تکرار', 'No repeat')}
          pressed={ps.repeat !== 'off'}
          onClick={() => player.setRepeat(ps.repeat === 'all' ? 'one' : ps.repeat === 'one' ? 'off' : 'all')}
        >
          {ps.repeat === 'one' ? <Repeat1 size={17} /> : <Repeat size={17} />}
        </IconButton>
        {full && (
          <label className="volume">
            <Volume2 size={16} aria-hidden="true" />
            <input type="range" min={0} max={1} step={0.05} value={ps.volume} onChange={(e) => player.setVolume(Number(e.target.value))} aria-label={t('بلندی صدا', 'Volume')} />
          </label>
        )}
      </div>
      {errorMsg && (
        <div className="player-error" role="alert">
          <TriangleAlert size={14} aria-hidden="true" /> {errorMsg}
        </div>
      )}
    </div>
  );
}

export default function MusicModule({ mod, variant }: ModuleViewProps) {
  const { t, duration, tz, locale, bidi } = useApp();
  const items = useLiveQuery(() => db.media.where('moduleId').equals(mod.id).sortBy('order'), [mod.id]);
  const ps = useStore(playerStore);
  const [adding, setAdding] = useState(false);
  const [filter, setFilter] = useState<'all' | 'fav'>('all');
  const [voice, setVoice] = useState('');
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);
  const list = useMemo(() => (items ?? []).filter((i) => filter === 'all' || i.favorite), [items, filter]);
  const queue = useMemo(() => (items ?? []).filter((i) => i.sourceType === 'file' || i.sourceType === 'url').map((i) => i.id), [items]);

  useEffect(() => {
    player.syncQueue(mod.id, queue);
  }, [mod.id, queue]);

  const playItem = (i: MediaItem) => {
    if (i.sourceType === 'external' && i.url) {
      window.open(i.url, '_blank', 'noopener,noreferrer');
      return;
    }
    if (ps.moduleId === mod.id && ps.current?.id === i.id) void player.toggle();
    else void player.play(mod.id, queue, i.id);
  };

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'music', now: Date.now(), timezone: tz });
    if (d.kind === 'media') {
      const mine = ps.moduleId === mod.id && ps.current;
      if (d.action === 'pause') player.pause();
      else if (d.action === 'play') {
        if (mine) await player.resume();
        else if (queue.length) await player.play(mod.id, queue, queue[0]!);
      } else if (d.action === 'next') await player.next();
      else await player.prev();
      return;
    }
    if (d.kind === 'media_search') {
      const hit = (items ?? []).find((i) => i.sourceType !== 'external' && matchesQuery(`${i.title} ${i.artist}`, d.query));
      if (hit) await player.play(mod.id, queue, hit.id);
      else toast({ kind: 'warning', text: t('قطعه‌ای با «{q}» در این فهرست نیست.', 'No track matches “{q}” in this list.', { q: d.query }) });
      return;
    }
    await generic(d);
  };

  const remove = async (i: MediaItem) => {
    const ok = await askConfirm({ title: t('حذف «{title}»؟', 'Remove “{title}”?', { title: i.title }), body: i.sourceType === 'file' ? t('فایل از این مرورگر پاک می‌شود.', 'The file is erased from this browser.') : undefined, confirmText: t('حذف', 'Remove'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (!ok) return;
    if (ps.current?.id === i.id) player.stopAndClear();
    await db.transaction('rw', db.media, db.assets, async () => {
      await deleteAsset(i.assetId);
      await db.media.delete(i.id);
    });
  };

  const edit = async (i: MediaItem) => {
    const v = await askText({ title: t('عنوان قطعه', 'Track title'), label: t('عنوان', 'Title'), initial: i.title, confirmText: t('ذخیره', 'Save'), cancelText: t('انصراف', 'Cancel') });
    if (v && v.trim()) await db.media.update(i.id, { title: v.trim().slice(0, 120) });
  };

  const move = async (i: MediaItem, dir: -1 | 1) => {
    const arr = items ?? [];
    const idx = arr.findIndex((x) => x.id === i.id);
    const other = arr[idx + dir];
    if (!other) return;
    await db.transaction('rw', db.media, async () => {
      await db.media.update(i.id, { order: other.order });
      await db.media.update(other.id, { order: i.order });
    });
  };

  if (!items) return <div className="mod-loading" />;
  const max = variant === 'card' ? (mod.appearance.density === 'compact' ? 6 : 4) : Infinity;
  const shown = list.slice(0, max);

  return (
    <div className="stack">
      <PlayerBar mod={mod} items={items} full={variant === 'full'} />
      {(variant === 'full' || mode === 'command') && (
        <VoiceInput
          value={voice}
          onChange={setVoice}
          lang={mod.inputLanguage}
          ownerId={`music-${mod.id}-${variant}`}
          inputLabel={t('فرمان یا جست‌وجوی قطعه', 'Command or track search')}
          placeholder={t('«پخش»، «بعدی» یا «پخش کن …»', '“play”, “next” or “play …”')}
          mode={mode}
          onModeChange={setMode}
          onCommand={(s) => void onCommand(s)}
          onSubmit={(s) => void onCommand(s)}
          submitLabel={t('اجرا', 'Run')}
          examples={examplesFor(mod, locale)}
        />
      )}
      <div className="row-flex spread wrap">
        {variant === 'full' ? (
          <Tabs
            label={t('فیلتر', 'Filter')}
            value={filter}
            onChange={setFilter}
            tabs={[
              { value: 'all', label: t('همه', 'All'), count: items.length },
              { value: 'fav', label: t('علاقه‌مندی‌ها', 'Favourites'), count: items.filter((i) => i.favorite).length },
            ]}
          />
        ) : (
          <span />
        )}
        <Button size="sm" variant="soft" icon={<Plus size={14} />} onClick={() => setAdding(true)}>
          {t('افزودن', 'Add')}
        </Button>
      </div>
      {items.length === 0 ? (
        <EmptyState
          icon={<ListMusic size={22} />}
          title={t('هنوز موسیقی اضافه نکرده‌اید', 'No music yet')}
          text={t('فایل‌های صوتی خودتان، نشانی مستقیم یا لینک صفحه سایت‌های موسیقی را اضافه کنید.', 'Add your own audio files, direct links, or music-site pages.')}
        />
      ) : (
        <ul className="rows">
          {shown.map((i, idx) => {
            const current = ps.moduleId === mod.id && ps.current?.id === i.id;
            return (
              <li key={i.id} className={`row media-row${current ? ' is-current' : ''}`}>
                <IconButton
                  label={i.sourceType === 'external' ? t('باز کردن در سایت', 'Open on site') : current && ps.playing ? t('توقف', 'Pause') : t('پخش «{title}»', 'Play “{title}”', { title: i.title })}
                  variant={current ? 'accent' : 'soft'}
                  size="sm"
                  onClick={() => playItem(i)}
                >
                  {i.sourceType === 'external' ? <ExternalLink size={15} /> : current && ps.playing ? <Pause size={15} /> : <Play size={15} />}
                </IconButton>
                <div className="row-main is-static">
                  <span className="row-title auto-dir" dir={bidi(i.title)}>{i.title}</span>
                  <span className="row-meta">
                    {i.sourceType === 'file' && <span>{t('فایل', 'File')}</span>}
                    {i.sourceType === 'url' && <span className="ltr">{hostOf(i.url ?? '')}</span>}
                    {i.sourceType === 'external' && <span>{t('لینک بیرونی', 'External link')}</span>}
                    {i.duration ? <span className="num">{duration(i.duration)}</span> : null}
                  </span>
                </div>
                <div className="row-actions">
                  <IconButton label={i.favorite ? t('حذف از علاقه‌مندی', 'Unfavourite') : t('علاقه‌مندی', 'Favourite')} size="sm" pressed={i.favorite} onClick={() => void db.media.update(i.id, { favorite: !i.favorite })}>
                    <Star size={15} fill={i.favorite ? 'currentColor' : 'none'} />
                  </IconButton>
                  {variant === 'full' && (
                    <>
                      <IconButton label={t('بالاتر', 'Move up')} size="sm" disabled={idx === 0} onClick={() => void move(i, -1)}>
                        <ArrowUp size={15} />
                      </IconButton>
                      <IconButton label={t('پایین‌تر', 'Move down')} size="sm" disabled={idx === shown.length - 1} onClick={() => void move(i, 1)}>
                        <ArrowDown size={15} />
                      </IconButton>
                      <IconButton label={t('ویرایش عنوان', 'Edit title')} size="sm" onClick={() => void edit(i)}>
                        <Pencil size={15} />
                      </IconButton>
                      <IconButton label={t('حذف', 'Remove')} size="sm" onClick={() => void remove(i)}>
                        <TrashIcon size={15} />
                      </IconButton>
                    </>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
      {variant === 'card' && <MoreLink mod={mod} count={list.length - shown.length} />}
      <AddMusicDialog mod={mod} open={adding} onClose={() => setAdding(false)} />
    </div>
  );
}
