/**
 * Title and artist of a music file, read from the tags inside it (ID3 in MP3, iTunes-style
 * tags in M4A) or, when it has none, from a file name such as «Artist - Title.mp3».
 * Only the first part of the file (and its last 128 bytes) is read, never the whole file.
 */

export interface AudioTags {
  title: string;
  artist: string;
  album: string;
}

const MAX_TAG_BYTES = 8 * 1024 * 1024;

async function bytes(blob: Blob, start: number, end: number): Promise<Uint8Array> {
  return new Uint8Array(await blob.slice(start, Math.min(end, blob.size)).arrayBuffer());
}

function ascii(b: Uint8Array, at: number, len: number): string {
  let s = '';
  for (let i = 0; i < len && at + i < b.length; i++) s += String.fromCharCode(b[at + i]!);
  return s;
}

function decoder(label: string): TextDecoder | null {
  try {
    return new TextDecoder(label);
  } catch {
    return null;
  }
}

/**
 * Text in a "Latin-1" tag. Many Persian MP3s were tagged on Windows with the Arabic code page
 * (1256) but marked as Latin-1, so a run of high bytes is read as Windows-1256 instead.
 */
export function decodeLegacy(b: Uint8Array): string {
  let high = 0;
  let arabicRange = 0;
  for (const x of b) {
    if (x >= 0x80) high++;
    if (x >= 0xc1 && x <= 0xfe) arabicRange++;
  }
  if (high === 0) return String.fromCharCode(...b);
  if (arabicRange / high > 0.6) {
    const d = decoder('windows-1256');
    if (d) return d.decode(b);
  }
  return (decoder('windows-1252') ?? decoder('latin1'))?.decode(b) ?? String.fromCharCode(...b);
}

function clean(s: string): string {
  return s
    .split('\u0000')
    .map((x) => x.trim())
    .filter(Boolean)[0]
    ?.replace(/\s+/g, ' ')
    .slice(0, 120) ?? '';
}

function decodeId3Text(b: Uint8Array): string {
  if (!b.length) return '';
  const enc = b[0]!;
  const body = b.subarray(1);
  if (enc === 0) return clean(decodeLegacy(trimNul(body, 1)));
  if (enc === 3) return clean(new TextDecoder('utf-8').decode(trimNul(body, 1)));
  if (enc === 1) {
    const le = body[0] === 0xff && body[1] === 0xfe;
    const be = body[0] === 0xfe && body[1] === 0xff;
    const rest = le || be ? body.subarray(2) : body;
    return clean((decoder(be ? 'utf-16be' : 'utf-16le') ?? new TextDecoder()).decode(trimNul(rest, 2)));
  }
  if (enc === 2) return clean((decoder('utf-16be') ?? new TextDecoder()).decode(trimNul(body, 2)));
  return '';
}

/** Cuts at the first terminator (one zero byte, or two aligned zero bytes for UTF-16). */
function trimNul(b: Uint8Array, width: 1 | 2): Uint8Array {
  for (let i = 0; i + width <= b.length; i += width) {
    if (b[i] === 0 && (width === 1 || b[i + 1] === 0)) return b.subarray(0, i);
  }
  return b;
}

const synchsafe = (b: Uint8Array, at: number) => ((b[at]! & 0x7f) << 21) | ((b[at + 1]! & 0x7f) << 14) | ((b[at + 2]! & 0x7f) << 7) | (b[at + 3]! & 0x7f);
const u32 = (b: Uint8Array, at: number) => ((b[at]! << 24) >>> 0) + (b[at + 1]! << 16) + (b[at + 2]! << 8) + b[at + 3]!;
const u24 = (b: Uint8Array, at: number) => (b[at]! << 16) + (b[at + 1]! << 8) + b[at + 2]!;

const ID3_FIELDS: Record<string, keyof AudioTags> = {
  TIT2: 'title',
  TT2: 'title',
  TPE1: 'artist',
  TP1: 'artist',
  TPE2: 'artist',
  TP2: 'artist',
  TALB: 'album',
  TAL: 'album',
};

/** ID3v2.2 / 2.3 / 2.4 text frames. `tag` starts with the 10-byte header. */
export function parseId3v2(tag: Uint8Array): Partial<AudioTags> {
  if (ascii(tag, 0, 3) !== 'ID3') return {};
  const major = tag[3]!;
  const flags = tag[5]!;
  const size = synchsafe(tag, 6);
  const end = Math.min(tag.length, 10 + size);
  let at = 10;
  if (flags & 0x40 && major >= 3) at += major === 4 ? synchsafe(tag, 10) : u32(tag, 10) + 4;
  const out: Partial<AudioTags> = {};
  const idLen = major === 2 ? 3 : 4;
  const headLen = major === 2 ? 6 : 10;
  while (at + headLen <= end) {
    const id = ascii(tag, at, idLen);
    if (!/^[A-Z0-9]+$/.test(id)) break; // padding
    const len = major === 2 ? u24(tag, at + 3) : major === 4 ? synchsafe(tag, at + 4) : u32(tag, at + 4);
    const fflags = major === 2 ? 0 : (tag[at + 8]! << 8) | tag[at + 9]!;
    let dataAt = at + headLen;
    let dataLen = len;
    if (major === 4 && fflags & 0x0001) {
      dataAt += 4;
      dataLen -= 4;
    }
    const field = ID3_FIELDS[id];
    // TPE2 (album artist) only fills in when there is no TPE1
    if (field && dataLen > 0 && dataAt + dataLen <= tag.length && !(fflags & 0x0008) && !(major === 3 && fflags & 0x0080)) {
      const text = decodeId3Text(tag.subarray(dataAt, dataAt + dataLen));
      if (text && (!out[field] || (field === 'artist' && (id === 'TPE1' || id === 'TP1')))) out[field] = text;
    }
    if (len <= 0) break;
    at += headLen + len;
  }
  return out;
}

/** The old fixed 128-byte tag at the very end of an MP3. */
export function parseId3v1(b: Uint8Array): Partial<AudioTags> {
  if (b.length < 128 || ascii(b, b.length - 128, 3) !== 'TAG') return {};
  const at = b.length - 128;
  const field = (o: number) => clean(decodeLegacy(trimNul(b.subarray(at + o, at + o + 30), 1)));
  const out: Partial<AudioTags> = {};
  const title = field(3);
  const artist = field(33);
  const album = field(63);
  if (title) out.title = title;
  if (artist) out.artist = artist;
  if (album) out.album = album;
  return out;
}

/** Finds a child box inside an MP4 container box's payload. */
function child(b: Uint8Array, from: number, to: number, type: string): { start: number; end: number } | null {
  let at = from;
  while (at + 8 <= to) {
    let size = u32(b, at);
    const t = ascii(b, at + 4, 4);
    let head = 8;
    if (size === 1 && at + 16 <= to) {
      size = u32(b, at + 8) * 2 ** 32 + u32(b, at + 12);
      head = 16;
    } else if (size === 0) size = to - at;
    if (size < head) return null;
    if (t === type) return { start: at + head, end: Math.min(to, at + size) };
    at += size;
  }
  return null;
}

const MP4_FIELDS: Record<string, keyof AudioTags> = { '©nam': 'title', '©ART': 'artist', aART: 'artist', '©alb': 'album' };

/** iTunes-style tags in an MP4/M4A `moov` box (the box itself, header included). */
export function parseMp4Tags(moov: Uint8Array): Partial<AudioTags> {
  const out: Partial<AudioTags> = {};
  const udta = child(moov, 8, moov.length, 'udta');
  if (!udta) return out;
  const meta = child(moov, udta.start, udta.end, 'meta');
  if (!meta) return out;
  // `meta` is a full box: 4 bytes of version and flags (some writers leave them out)
  const ilst = child(moov, meta.start + 4, meta.end, 'ilst') ?? child(moov, meta.start, meta.end, 'ilst');
  if (!ilst) return out;
  let at = ilst.start;
  while (at + 8 <= ilst.end) {
    const size = u32(moov, at);
    const type = new TextDecoder('latin1').decode(moov.subarray(at + 4, at + 8));
    if (size < 8) break;
    const field = MP4_FIELDS[type];
    if (field) {
      const data = child(moov, at + 8, Math.min(ilst.end, at + size), 'data');
      if (data && data.end - data.start > 8 && u32(moov, data.start) === 1) {
        const text = clean(new TextDecoder('utf-8').decode(moov.subarray(data.start + 8, data.end)));
        if (text && (!out[field] || type === '©ART')) out[field] = text;
      }
    }
    at += size;
  }
  return out;
}

async function readMp4(blob: Blob): Promise<Partial<AudioTags>> {
  let at = 0;
  for (let guard = 0; guard < 64 && at + 8 <= blob.size; guard++) {
    const h = await bytes(blob, at, at + 16);
    let size = u32(h, 0);
    const type = ascii(h, 4, 4);
    if (size === 1) size = u32(h, 8) * 2 ** 32 + u32(h, 12);
    else if (size === 0) size = blob.size - at;
    if (size < 8) break;
    if (type === 'moov') return size <= MAX_TAG_BYTES ? parseMp4Tags(await bytes(blob, at, at + size)) : {};
    at += size;
  }
  return {};
}

/** Reads the tags of an audio file. Never throws; returns what it found. */
export async function readAudioTags(blob: Blob): Promise<Partial<AudioTags>> {
  try {
    const head = await bytes(blob, 0, 10);
    if (ascii(head, 0, 3) === 'ID3') {
      const size = synchsafe(head, 6) + 10;
      const v2 = parseId3v2(await bytes(blob, 0, Math.min(size, MAX_TAG_BYTES)));
      if (v2.title && v2.artist) return v2;
      const v1 = blob.size >= 128 ? parseId3v1(await bytes(blob, blob.size - 128, blob.size)) : {};
      return { ...v1, ...v2 };
    }
    if (ascii(head, 4, 4) === 'ftyp') return await readMp4(blob);
    if (blob.size >= 128) return parseId3v1(await bytes(blob, blob.size - 128, blob.size));
  } catch {
    /* unreadable: the file name is used instead */
  }
  return {};
}

const NOISE = /[([{](?:[^)\]}]*(?:\.com|\.ir|\.net|\.org|www\.|music|موزیک|kbps|\d{3})[^)\]}]*)[)\]}]|\b(?:www\.\S+|\S+\.(?:com|ir|net|org))\b|\b(?:320|128|192|256)\s*(?:kbps|k)?\b|\b(?:official\s*(?:audio|video|music\s*video)?|lyrics?|hq|hd|mp3)\b/giu;

/** A readable title from a file name: no extension, no download-site tags, no underscores. */
export function titleFromFileName(name: string): string {
  const base = name.replace(/\.[a-z0-9]{2,5}$/i, '');
  const t = base.replace(/_+/g, ' ').replace(NOISE, ' ').replace(/\s+/g, ' ').replace(/^[\s\-–—.]+|[\s\-–—.]+$/g, '').trim();
  return (t || base).slice(0, 120);
}

/** «Artist - Title» (also with an en or em dash). Returns null when the name has no such split. */
export function splitArtistTitle(text: string): { artist: string; title: string } | null {
  const m = text.match(/^(.{2,60}?)\s+[-–—]\s+(.{1,120})$/u) ?? text.match(/^(.{2,60}?)\s*[–—]\s*(.{1,120})$/u);
  if (!m) return null;
  const artist = m[1]!.trim();
  const title = m[2]!.trim();
  if (!artist || !title || /^\d+$/.test(artist)) return null;
  return { artist, title };
}

/** What to call a newly added file: its tags first, then its file name. */
export function describeTrack(fileName: string, tags: Partial<AudioTags>): { title: string; artist: string } {
  const fromName = titleFromFileName(fileName);
  const split = splitArtistTitle(fromName);
  return {
    title: tags.title || split?.title || fromName,
    artist: tags.artist || split?.artist || '',
  };
}
