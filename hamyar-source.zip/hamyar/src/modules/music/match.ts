import { normalizeForMatch } from '../../domain/normalize';
import { splitArtistTitle } from './tags';

/**
 * Finds what someone asked to hear. Names are compared as written and, because a phone's
 * speech engine writes «گوگوش» while the file's tag says «Googoosh», also by a script-free
 * sound key: both are reduced to their consonants (Persian letters and Latin spellings mapped
 * to one alphabet, vowels dropped). «محسن یگانه» and «Mohsen Yeganeh» both become «mhsn ygn».
 */

const FA: Record<string, string> = {
  ب: 'b',
  پ: 'p',
  ت: 't',
  ث: 's',
  ج: 'j',
  چ: 'c',
  ح: 'h',
  خ: 'x',
  د: 'd',
  ذ: 'z',
  ر: 'r',
  ز: 'z',
  ژ: 'z',
  س: 's',
  ش: 'S',
  ص: 's',
  ض: 'z',
  ط: 't',
  ظ: 'z',
  غ: 'q',
  ف: 'f',
  ق: 'q',
  ک: 'k',
  گ: 'g',
  ل: 'l',
  م: 'm',
  ن: 'n',
  ه: 'h',
};
const FA_VOWELISH = new Set(['ا', 'آ', 'أ', 'إ', 'ع', 'ء', 'ئ']);

function faWordKey(w: string): string {
  const ch = [...w];
  let out = '';
  for (let i = 0; i < ch.length; i++) {
    const c = ch[i]!;
    const prev = ch[i - 1];
    const next = ch[i + 1];
    if (FA_VOWELISH.has(c)) continue;
    if (c === 'ی') {
      if (i === 0) out += 'y';
      continue;
    }
    if (c === 'و') {
      if (i === 0 || prev === 'ا' || prev === 'آ' || next === 'ا' || next === 'آ') out += 'v';
      continue;
    }
    if (c === 'ه' && i === ch.length - 1 && ch.length > 1) continue;
    if (/\d/.test(c)) {
      out += c;
      continue;
    }
    out += FA[c] ?? '';
  }
  return out;
}

function enWordKey(w: string): string {
  let s = w.toLowerCase().replace(/[^a-z0-9]/g, '');
  s = s
    .replace(/ch/g, 'C')
    .replace(/c/g, 'k')
    .replace(/C/g, 'c')
    .replace(/kh/g, 'x')
    .replace(/gh/g, 'q')
    .replace(/sh/g, 'S')
    .replace(/zh/g, 'z')
    .replace(/ph/g, 'f')
    .replace(/th/g, 't')
    .replace(/ck/g, 'k')
    .replace(/w/g, 'v')
    .replace(/([ae])h$/, '$1');
  let out = '';
  for (let i = 0; i < s.length; i++) {
    const c = s[i]!;
    if ('aeiou'.includes(c)) continue;
    if (c === 'y') {
      if (i === 0) out += 'y';
      continue;
    }
    out += c;
  }
  return out;
}

const collapse = (s: string) => s.replace(/(.)\1+/g, '$1');

/** Sound key of a name in Persian or Latin letters (words kept apart by spaces). */
export function soundKey(text: string): string {
  return normalizeForMatch(text)
    .split(/\s+/)
    .map((w) => collapse(/[a-z]/.test(w) && !/[؀-ۿ]/.test(w) ? enWordKey(w) : faWordKey(w)))
    .filter(Boolean)
    .join(' ');
}

function lev(a: string, b: string): number {
  if (a === b) return 0;
  const prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let diag = prev[0]!;
    prev[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = prev[j]!;
      prev[j] = Math.min(prev[j]! + 1, prev[j - 1]! + 1, diag + (a[i - 1] === b[j - 1] ? 0 : 1));
      diag = tmp;
    }
  }
  return prev[b.length]!;
}

const plain = (s: string) => normalizeForMatch(s).replace(/\s+/g, '');

/** How well `name` answers `query`, 0…1 (0.6 and up counts as a match). */
export function nameScore(query: string, name: string): number {
  const q = plain(query);
  const n = plain(name);
  if (!q || !n) return 0;
  if (q === n) return 1;
  if (q.length >= 3 && n.includes(q)) return 0.7 + 0.25 * (q.length / n.length);
  if (n.length >= 3 && q.includes(n)) return 0.65 + 0.2 * (n.length / q.length);
  const qk = soundKey(query);
  const nk = soundKey(name);
  const qc = qk.replace(/\s/g, '');
  const nc = nk.replace(/\s/g, '');
  if (!qc || !nc) return 0;
  if (qc === nc) return qc.length >= 3 ? 0.92 : qc.length === 2 ? 0.8 : 0.7;
  const shorter = Math.min(qc.length, nc.length);
  if (shorter >= 3) {
    const sim = 1 - lev(qc, nc) / Math.max(qc.length, nc.length);
    if (sim >= 0.75) return 0.55 + 0.35 * sim;
    // every spoken word sounds like a word of the name («یگانه» → «Mohsen Yeganeh»)
    const qw = qk.split(' ');
    const nw = nk.split(' ');
    if (qw.every((w) => w.length >= 2 && nw.includes(w))) return 0.62 + 0.2 * (qc.length / nc.length);
  }
  return 0;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
}

export type MusicMatch =
  | { kind: 'artist'; artist: string; ids: string[] }
  | { kind: 'track'; id: string; title: string; artist: string }
  | { kind: 'none'; suggestions: string[] };

export const MATCH_THRESHOLD = 0.6;

/** The artist of a track: its tag, or the «Artist - Title» part of its title. */
export function artistOf(t: Track): string {
  return t.artist.trim() || splitArtistTitle(t.title)?.artist || '';
}

function titleOf(t: Track): string {
  return t.artist.trim() ? t.title : splitArtistTitle(t.title)?.title ?? t.title;
}

/**
 * «آهنگ‌های X» → every track by X (in list order); «آهنگ X» → that one track; plain «X» →
 * whichever fits better (a title that matches exactly wins over an artist).
 */
export function resolveMusicQuery(tracks: Track[], query: string, target: 'artist' | 'track' | 'any'): MusicMatch {
  const q = query.trim();
  if (!q) return { kind: 'none', suggestions: [] };
  const byArtist = new Map<string, { name: string; ids: string[] }>();
  for (const t of tracks) {
    const a = artistOf(t);
    if (!a) continue;
    const key = plain(a);
    const g = byArtist.get(key) ?? { name: a, ids: [] };
    g.ids.push(t.id);
    byArtist.set(key, g);
  }
  let bestArtist: { name: string; ids: string[]; score: number } | null = null;
  for (const g of byArtist.values()) {
    const score = nameScore(q, g.name);
    if (!bestArtist || score > bestArtist.score) bestArtist = { ...g, score };
  }
  let bestTrack: { t: Track; score: number } | null = null;
  for (const t of tracks) {
    const a = artistOf(t);
    const title = titleOf(t);
    const score = Math.max(nameScore(q, title), a ? nameScore(q, `${a} ${title}`) * 0.98 : 0, a ? nameScore(q, `${title} ${a}`) * 0.98 : 0);
    if (!bestTrack || score > bestTrack.score) bestTrack = { t, score };
  }
  const artistOk = bestArtist && bestArtist.score >= MATCH_THRESHOLD ? bestArtist : null;
  const trackOk = bestTrack && bestTrack.score >= MATCH_THRESHOLD ? bestTrack : null;
  const asArtist = (): MusicMatch => ({ kind: 'artist', artist: artistOk!.name, ids: artistOk!.ids });
  const asTrack = (): MusicMatch => ({ kind: 'track', id: trackOk!.t.id, title: titleOf(trackOk!.t), artist: artistOf(trackOk!.t) });
  if (target === 'artist') {
    if (artistOk) return asArtist();
    // no artist tags: every track whose title or name mentions it
    const ids = tracks.filter((t) => nameScore(q, `${t.artist} ${t.title}`) >= 0.7).map((t) => t.id);
    if (ids.length) return { kind: 'artist', artist: q, ids };
  } else if (target === 'track') {
    if (trackOk) return asTrack();
    if (artistOk) return asArtist();
  } else {
    if (trackOk && (!artistOk || trackOk.score >= artistOk.score)) return asTrack();
    if (artistOk) return asArtist();
  }
  const suggestions = [...byArtist.values()].map((g) => g.name).slice(0, 5);
  return { kind: 'none', suggestions };
}
