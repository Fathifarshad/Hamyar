import { lazy, type ComponentType, type LazyExoticComponent } from 'react';
import type { ModuleInstance, ModuleType } from '../domain/types';

export interface ModuleViewProps {
  mod: ModuleInstance;
  variant: 'card' | 'full';
  /** deep-link target inside the module (e.g. an occurrence key from a reminder) */
  focus?: string;
}

export interface ModuleSettingsProps {
  mod: ModuleInstance;
  config: Record<string, unknown>;
  onChange: (patch: Record<string, unknown>) => void;
}

type View = LazyExoticComponent<ComponentType<ModuleViewProps>>;
type SettingsView = LazyExoticComponent<ComponentType<ModuleSettingsProps>>;

export const MODULE_VIEWS: Record<ModuleType, View> = {
  tasks: lazy(() => import('./tasks/TasksModule')),
  music: lazy(() => import('./music/MusicModule')),
  pdf: lazy(() => import('./pdf/PdfModule')),
  video: lazy(() => import('./video/VideoModule')),
  transcription: lazy(() => import('./transcription/TranscriptionModule')),
  medications: lazy(() => import('./medications/MedicationsModule')),
  notes: lazy(() => import('./notes/NotesModule')),
  bookmarks: lazy(() => import('./bookmarks/BookmarksModule')),
  focus: lazy(() => import('./focus/FocusModule')),
  checklists: lazy(() => import('./checklists/ChecklistsModule')),
  habits: lazy(() => import('./habits/HabitsModule')),
  expenses: lazy(() => import('./expenses/ExpensesModule')),
  weather: lazy(() => import('./weather/WeatherModule')),
  calendar: lazy(() => import('./calendar/CalendarModule')),
  custom: lazy(() => import('./custom/CustomModule')),
};

export const MODULE_SETTINGS: Partial<Record<ModuleType, SettingsView>> = {
  focus: lazy(() => import('./focus/FocusSettings')),
  habits: lazy(() => import('./habits/HabitsSettings')),
  expenses: lazy(() => import('./expenses/ExpensesSettings')),
  weather: lazy(() => import('./weather/WeatherSettings')),
  custom: lazy(() => import('./custom/CustomSettings')),
  pdf: lazy(() => import('./pdf/PdfSettings')),
  transcription: lazy(() => import('./transcription/TranscriptionSettings')),
  calendar: lazy(() => import('./calendar/CalendarSettings')),
};

type Pair = [fa: string, en: string];

export const MODULE_TEXT: Record<ModuleType, { name: Pair; desc: Pair; examples?: { fa: string[]; en: string[] } }> = {
  tasks: {
    name: ['کارها و قرارها', 'Tasks & appointments'],
    desc: ['کارهای امروز، قرارها، تکرار و یادآوری در ساعت مشخص', 'Today’s tasks, appointments, repeats and timed reminders'],
    examples: { fa: ['فردا ساعت ۹ صبح جلسه تیم', 'نیم ساعت دیگه زنگ بزنم به مامان', '۲۰ مهر ساعت ۱۸ تولد سارا'], en: ['tomorrow at 9am team meeting', 'in 30 minutes call mom'] },
  },
  music: {
    name: ['موسیقی', 'Music'],
    desc: ['فایل‌های خودتان یا لینک مستقیم صوتی، با پخش‌کننده و علاقه‌مندی', 'Your own files or direct audio links, with a player and favourites'],
    examples: { fa: ['پخش', 'بعدی', 'پخش کن باران'], en: ['play', 'next', 'play rain'] },
  },
  pdf: {
    name: ['PDF و خلاصه', 'PDF & summaries'],
    desc: ['نمایش PDF، جست‌وجو در متن و خلاصه با شماره صفحه', 'View PDFs, search their text and summarise with page references'],
    examples: { fa: ['برو صفحه ۱۲', 'خلاصه کن'], en: ['go to page 12', 'summarize'] },
  },
  video: {
    name: ['ویدئو', 'Video'],
    desc: ['ویدئوی خودتان، لینک مستقیم، YouTube و آپارات', 'Your videos, direct links, YouTube and Aparat'],
    examples: { fa: ['پخش', 'توقف'], en: ['play', 'pause'] },
  },
  transcription: {
    name: ['صوت به متن', 'Speech to text'],
    desc: ['ضبط یا فایل صوتی، تبدیل به متن قابل ویرایش', 'Record or upload audio and get editable text'],
  },
  medications: {
    name: ['داروها', 'Medications'],
    desc: ['ساعت مصرف، نکات شما و ثبت «مصرف شد / رد شد»', 'Dose times, your notes and taken/skipped tracking'],
  },
  notes: {
    name: ['یادداشت‌ها', 'Notes'],
    desc: ['یادداشت سریع با پین، برچسب، جست‌وجو و ذخیره خودکار', 'Quick notes with pins, tags, search and autosave'],
    examples: { fa: ['کتاب جدید برای کلاس زبان بخرم'], en: ['buy a new book for class'] },
  },
  bookmarks: {
    name: ['لینک‌های منتخب', 'Saved links'],
    desc: ['سایت‌های پرکاربرد با برچسب و باز کردن امن', 'Frequent sites with tags, opened safely'],
    examples: { fa: ['باز کن گوگل'], en: ['open github'] },
  },
  focus: {
    name: ['تمرکز', 'Focus timer'],
    desc: ['تایمر ۲۵/۵ قابل تنظیم با شمارش جلسه‌ها', 'Adjustable 25/5 timer with session count'],
    examples: { fa: ['شروع', 'شروع ۴۰ دقیقه', 'توقف'], en: ['start', 'start 40 minutes', 'pause'] },
  },
  checklists: {
    name: ['چک‌لیست', 'Checklists'],
    desc: ['فهرست خرید، سفر یا هر کاری با تیک و ترتیب', 'Shopping, travel or any list with checks and order'],
    examples: { fa: ['شیر رو اضافه کن', 'تیک بزن نان'], en: ['add milk', 'check bread'] },
  },
  habits: {
    name: ['عادت‌ها و آب', 'Habits & water'],
    desc: ['عادت‌های روزانه با رشته روزها و شمارش لیوان آب', 'Daily habits with streaks and a water counter'],
    examples: { fa: ['یک لیوان آب', 'ورزش انجام شد'], en: ['one glass of water', 'exercise done'] },
  },
  expenses: {
    name: ['هزینه‌های روزانه', 'Daily expenses'],
    desc: ['ثبت خرج با دسته‌بندی، جمع روز و ماه', 'Log spending by category with daily and monthly totals'],
    examples: { fa: ['۵۰ هزار تومان نان', '۱۲ دلار قهوه'], en: ['12 dollars coffee', '$40 groceries'] },
  },
  weather: {
    name: ['آب‌وهوا و ساعت شهرها', 'Weather & world clock'],
    desc: ['هوای شهرهای انتخابی و ساعت هم‌زمان آن‌ها', 'Weather and local time for the cities you pick'],
  },
  calendar: {
    name: ['تقویم و شمارش معکوس', 'Calendar & countdowns'],
    desc: ['تاریخ شمسی و میلادی، ماه جاری و روزهای مانده تا رویدادها', 'Jalali and Gregorian dates, month view and countdowns'],
    examples: { fa: ['۱ فروردین نوروز', '۳۰ آذر شب یلدا'], en: ['December 25 Christmas'] },
  },
  custom: {
    name: ['بخش دلخواه', 'Custom section'],
    desc: ['بخشی که فیلدهایش را خودتان می‌سازید: کتاب، مخاطب، سرویس خودرو…', 'A section with your own fields: books, contacts, car service…'],
  },
};
