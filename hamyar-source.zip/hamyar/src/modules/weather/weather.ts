import { kvGet, kvSet } from '../../data/db';
import type { CityRef } from '../../domain/catalog';
import { IS_ARTIFACT } from '../../lib/platform';

export interface WeatherData {
  at: number;
  current: { temp: number; code: number; isDay: boolean; wind: number; humidity: number };
  daily: { date: string; code: number; max: number; min: number }[];
}

export type WeatherError = 'offline' | 'blocked' | 'failed';

const TTL = 30 * 60_000;

/** Open-Meteo (no key). Only the city coordinates are sent. Cached for 30 minutes. */
export async function fetchWeather(city: CityRef, unit: 'c' | 'f', force = false): Promise<{ data: WeatherData | null; error: WeatherError | null; stale: boolean }> {
  const key = `weather:${city.lat.toFixed(2)},${city.lon.toFixed(2)}:${unit}`;
  const cached = await kvGet<WeatherData | null>(key, null);
  if (!force && cached && Date.now() - cached.at < TTL) return { data: cached, error: null, stale: false };
  if (IS_ARTIFACT) return { data: cached, error: 'blocked', stale: !!cached };
  if (!navigator.onLine) return { data: cached, error: 'offline', stale: !!cached };
  const params = new URLSearchParams({
    latitude: String(city.lat),
    longitude: String(city.lon),
    current: 'temperature_2m,weather_code,is_day,wind_speed_10m,relative_humidity_2m',
    daily: 'weather_code,temperature_2m_max,temperature_2m_min',
    forecast_days: '4',
    timezone: 'auto',
  });
  if (unit === 'f') params.set('temperature_unit', 'fahrenheit');
  try {
    const res = await fetch(`https://api.open-meteo.com/v1/forecast?${params.toString()}`);
    if (!res.ok) throw new Error(String(res.status));
    const j = (await res.json()) as {
      current: { temperature_2m: number; weather_code: number; is_day: number; wind_speed_10m: number; relative_humidity_2m: number };
      daily: { time: string[]; weather_code: number[]; temperature_2m_max: number[]; temperature_2m_min: number[] };
    };
    const data: WeatherData = {
      at: Date.now(),
      current: { temp: j.current.temperature_2m, code: j.current.weather_code, isDay: j.current.is_day === 1, wind: j.current.wind_speed_10m, humidity: j.current.relative_humidity_2m },
      daily: j.daily.time.map((d, i) => ({ date: d, code: j.daily.weather_code[i]!, max: j.daily.temperature_2m_max[i]!, min: j.daily.temperature_2m_min[i]! })),
    };
    await kvSet(key, data);
    return { data, error: null, stale: false };
  } catch {
    return { data: cached, error: 'failed', stale: !!cached };
  }
}

export interface GeoResult extends CityRef {
  country: string;
}

export async function searchCities(q: string, lang: 'fa' | 'en'): Promise<GeoResult[]> {
  if (IS_ARTIFACT) throw new Error('blocked');
  const params = new URLSearchParams({ name: q, count: '6', language: lang, format: 'json' });
  const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?${params.toString()}`);
  if (!res.ok) throw new Error(String(res.status));
  const j = (await res.json()) as { results?: { id: number; name: string; country?: string; latitude: number; longitude: number; timezone: string }[] };
  return (j.results ?? []).map((r) => ({ id: `geo-${r.id}`, name: r.name, nameFa: lang === 'fa' ? r.name : undefined, lat: r.latitude, lon: r.longitude, tz: r.timezone, country: r.country ?? '' }));
}

/** WMO weather code → label key + icon name. */
export function describeCode(code: number): { fa: string; en: string; icon: 'sun' | 'cloud-sun' | 'cloud' | 'fog' | 'drizzle' | 'rain' | 'snow' | 'storm' } {
  if (code === 0) return { fa: 'صاف', en: 'Clear', icon: 'sun' };
  if (code === 1 || code === 2) return { fa: 'کمی ابری', en: 'Partly cloudy', icon: 'cloud-sun' };
  if (code === 3) return { fa: 'ابری', en: 'Overcast', icon: 'cloud' };
  if (code === 45 || code === 48) return { fa: 'مه', en: 'Fog', icon: 'fog' };
  if (code >= 51 && code <= 57) return { fa: 'نم‌نم باران', en: 'Drizzle', icon: 'drizzle' };
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) return { fa: 'باران', en: 'Rain', icon: 'rain' };
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return { fa: 'برف', en: 'Snow', icon: 'snow' };
  if (code >= 95) return { fa: 'رعد و برق', en: 'Thunderstorm', icon: 'storm' };
  return { fa: 'نامشخص', en: 'Unknown', icon: 'cloud' };
}
