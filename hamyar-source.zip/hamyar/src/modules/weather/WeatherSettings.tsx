import { useState } from 'react';
import { useApp } from '../../shell/AppContext';
import type { ModuleSettingsProps } from '../registry';
import { CITY_LIBRARY, type CityRef } from '../../domain/catalog';
import { Button, Field, IconButton, Input, Segmented, Select } from '../../ui/primitives';
import { ArrowDown, ArrowUp, Plus, Search, X } from '../../ui/icons';
import { searchCities, type GeoResult } from './weather';

export default function WeatherSettings({ config, onChange }: ModuleSettingsProps) {
  const { t, locale } = useApp();
  const cities = (config.cities as CityRef[]) ?? [];
  const [pick, setPick] = useState('');
  const [q, setQ] = useState('');
  const [results, setResults] = useState<GeoResult[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const set = (next: CityRef[]) => onChange({ cities: next.slice(0, 8) });
  const label = (c: CityRef) => (locale === 'fa' ? c.nameFa ?? c.name : c.name);
  const search = async () => {
    setErr(null);
    try {
      setResults(await searchCities(q, locale));
    } catch {
      setErr(t('جست‌وجوی شهر در دسترس نیست (اینترنت لازم است). از فهرست آماده انتخاب کنید.', 'City search is unavailable (needs internet). Pick from the built-in list.'));
    }
  };
  return (
    <div className="stack-sm">
      <Field label={t('واحد دما', 'Temperature unit')}>
        <Segmented label={t('واحد', 'Unit')} value={(config.unit as 'c' | 'f') ?? 'c'} onChange={(unit) => onChange({ unit })} options={[{ value: 'c', label: '°C' }, { value: 'f', label: '°F' }]} size="sm" />
      </Field>
      <Field label={t('شهرها (حداکثر ۸)', 'Cities (up to 8)')}>
        <ul className="rows">
          {cities.map((c, i) => (
            <li key={c.id} className="row">
              <span className="grow">{label(c)}</span>
              <span className="subtle xsmall ltr">{c.tz}</span>
              <IconButton label={t('بالاتر', 'Move up')} size="sm" disabled={i === 0} onClick={() => set(cities.map((x, j) => (j === i - 1 ? c : j === i ? cities[i - 1]! : x)))}>
                <ArrowUp size={14} />
              </IconButton>
              <IconButton label={t('پایین‌تر', 'Move down')} size="sm" disabled={i === cities.length - 1} onClick={() => set(cities.map((x, j) => (j === i + 1 ? c : j === i ? cities[i + 1]! : x)))}>
                <ArrowDown size={14} />
              </IconButton>
              <IconButton label={t('حذف', 'Remove')} size="sm" onClick={() => set(cities.filter((x) => x.id !== c.id))} disabled={cities.length <= 1}>
                <X size={14} />
              </IconButton>
            </li>
          ))}
        </ul>
      </Field>
      <div className="row-flex">
        <Select value={pick} onChange={(e) => setPick(e.target.value)} aria-label={t('فهرست آماده', 'Built-in list')}>
          <option value="">{t('افزودن از فهرست آماده…', 'Add from the built-in list…')}</option>
          {CITY_LIBRARY.filter((c) => !cities.some((x) => x.id === c.id)).map((c) => (
            <option key={c.id} value={c.id}>
              {label(c)}
            </option>
          ))}
        </Select>
        <Button
          variant="soft"
          icon={<Plus size={15} />}
          disabled={!pick || cities.length >= 8}
          onClick={() => {
            const c = CITY_LIBRARY.find((x) => x.id === pick);
            if (c) set([...cities, c]);
            setPick('');
          }}
        >
          {t('افزودن', 'Add')}
        </Button>
      </div>
      <div className="row-flex">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('جست‌وجوی شهر دیگر', 'Search another city')} />
        <IconButton label={t('جست‌وجو', 'Search')} variant="soft" onClick={() => void search()} disabled={q.trim().length < 2}>
          <Search size={16} />
        </IconButton>
      </div>
      {err && <p className="field-err">{err}</p>}
      {results && (
        <ul className="rows">
          {results.length === 0 && <li className="subtle small">{t('پیدا نشد.', 'Not found.')}</li>}
          {results.map((r) => (
            <li key={r.id} className="row">
              <span className="grow">
                {r.name} <span className="subtle xsmall">{r.country}</span>
              </span>
              <Button size="sm" variant="soft" disabled={cities.length >= 8} onClick={() => (set([...cities, r]), setResults(null), setQ(''))}>
                {t('افزودن', 'Add')}
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
