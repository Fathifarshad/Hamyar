import { useEffect, useState } from 'react';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { CityRef } from '../../domain/catalog';
import { describeCode, fetchWeather, type WeatherData, type WeatherError } from './weather';
import { Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudRain, CloudSnow, CloudSun, Moon, RefreshCw, Sun, WifiOff } from '../../ui/icons';
import { IconButton, Notice } from '../../ui/primitives';
import { getOffsetMinutes, localTimeHHMM, todayISO, utcToLocal } from '../../domain/time';
import { openModuleSettings } from '../../shell/settingsStore';

const ICONS = { sun: Sun, 'cloud-sun': CloudSun, cloud: Cloud, fog: CloudFog, drizzle: CloudDrizzle, rain: CloudRain, snow: CloudSnow, storm: CloudLightning };

function CityCard({ city, unit, refreshKey, full }: { city: CityRef; unit: 'c' | 'f'; refreshKey: number; full: boolean }) {
  const { t, locale, now, time, num, dig, date, instantTime } = useApp();
  const [state, setState] = useState<{ data: WeatherData | null; error: WeatherError | null; stale: boolean; loading: boolean }>({ data: null, error: null, stale: false, loading: true });
  useEffect(() => {
    let alive = true;
    setState((s) => ({ ...s, loading: true }));
    void fetchWeather(city, unit, refreshKey > 0).then((r) => alive && setState({ ...r, loading: false }));
    return () => {
      alive = false;
    };
  }, [city.lat, city.lon, unit, refreshKey]); // eslint-disable-line react-hooks/exhaustive-deps
  const localTime = localTimeHHMM(now, city.tz);
  const hour = utcToLocal(now, city.tz).h;
  const night = hour < 6 || hour >= 19;
  const diff = getOffsetMinutes(now, city.tz) - getOffsetMinutes(now, Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC');
  const diffLabel = diff === 0 ? t('هم‌زمان با شما', 'Same as you') : `${diff > 0 ? '+' : '−'}${dig(Math.floor(Math.abs(diff) / 60))}${Math.abs(diff) % 60 ? `:${dig(String(Math.abs(diff) % 60).padStart(2, '0'))}` : ''} ${t('ساعت', 'h')}`;
  const cityDay = todayISO(city.tz, now);
  const d = state.data;
  const desc = d ? describeCode(d.current.code) : null;
  const Icon = desc ? (desc.icon === 'sun' && !d!.current.isDay ? Moon : ICONS[desc.icon]) : night ? Moon : Sun;
  return (
    <div className={`city${night ? ' is-night' : ''}`}>
      <div className="city-head">
        <div>
          <div className="city-name">{locale === 'fa' ? city.nameFa ?? city.name : city.name}</div>
          <div className="city-sub subtle xsmall">
            {date(cityDay, 'weekday')} · {diffLabel}
          </div>
        </div>
        <div className="city-time num">{time(localTime)}</div>
      </div>
      <div className="city-weather">
        <Icon size={28} aria-hidden="true" className="city-icon" />
        {d ? (
          <>
            <div className="city-temp num">
              {num(Math.round(d.current.temp))}°{unit === 'f' ? 'F' : 'C'}
            </div>
            <div className="city-desc">
              <div>{locale === 'fa' ? desc!.fa : desc!.en}</div>
              <div className="subtle xsmall">
                {t('رطوبت {h}٪ · باد {w}', 'Humidity {h}% · wind {w}', { h: Math.round(d.current.humidity), w: `${num(Math.round(d.current.wind))} km/h` })}
              </div>
            </div>
          </>
        ) : (
          <div className="subtle small">{state.loading ? t('در حال دریافت…', 'Loading…') : state.error === 'blocked' ? t('در پیش‌نمایش، اینترنت مسدود است', 'Internet is blocked in the preview') : t('هوا در دسترس نیست', 'Weather unavailable')}</div>
        )}
      </div>
      {d && full && (
        <div className="forecast">
          {d.daily.slice(1, 4).map((f) => {
            const fd = describeCode(f.code);
            const FIcon = ICONS[fd.icon];
            return (
              <div key={f.date} className="fc-day" title={locale === 'fa' ? fd.fa : fd.en}>
                <span className="subtle xsmall">{date(f.date, 'weekday')}</span>
                <FIcon size={18} aria-hidden="true" />
                <span className="num small">
                  {num(Math.round(f.max))}° / {num(Math.round(f.min))}°
                </span>
              </div>
            );
          })}
        </div>
      )}
      {d && (state.stale || state.error) && (
        <div className="subtle xsmall city-stale">
          <WifiOff size={12} aria-hidden="true" /> {t('آخرین داده: {t}', 'Last update: {t}', { t: instantTime(d.at) })}
        </div>
      )}
    </div>
  );
}

export default function WeatherModule({ mod, variant }: ModuleViewProps) {
  const { t } = useApp();
  const cities = (mod.config.cities as CityRef[]) ?? [];
  const unit = (mod.config.unit as 'c' | 'f') ?? 'c';
  const [refreshKey, setRefreshKey] = useState(0);
  const shown = variant === 'card' ? cities.slice(0, mod.appearance.width === 'wide' ? 4 : 2) : cities;
  return (
    <div className="stack">
      <div className={`city-grid${variant === 'full' ? ' is-full' : ''}`}>
        {shown.map((c) => (
          <CityCard key={c.id} city={c} unit={unit} refreshKey={refreshKey} full={variant === 'full'} />
        ))}
      </div>
      <div className="row-flex spread">
        <button type="button" className="more-link as-button" onClick={() => openModuleSettings(mod.id)}>
          {t('مدیریت شهرها', 'Manage cities')}
        </button>
        <IconButton label={t('به‌روزرسانی هوا', 'Refresh weather')} size="sm" onClick={() => setRefreshKey((k) => k + 1)}>
          <RefreshCw size={15} />
        </IconButton>
      </div>
      {variant === 'full' && (
        <Notice tone="neutral">
          {t('برای دریافت هوا فقط مختصات شهرهای انتخابی به سرویس رایگان Open-Meteo فرستاده می‌شود. ساعت‌ها بدون اینترنت هم کار می‌کنند.', 'Only the chosen cities’ coordinates are sent to the free Open-Meteo service. Clocks work offline.')}
        </Notice>
      )}
    </div>
  );
}
