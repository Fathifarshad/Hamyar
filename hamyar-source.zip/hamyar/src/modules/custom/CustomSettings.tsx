import { useApp } from '../../shell/AppContext';
import type { ModuleSettingsProps } from '../registry';
import type { CustomField, CustomFieldType } from '../../domain/types';
import { CUSTOM_FIELD_TYPES } from '../../domain/catalog';
import { Button, Field, IconButton, Input, Select } from '../../ui/primitives';
import { ArrowDown, ArrowUp, Plus, X } from '../../ui/icons';
import { LIMITS } from '../../config/limits';
import { fieldTypeLabel } from './labels';

export default function CustomSettings({ config, onChange }: ModuleSettingsProps) {
  const { t } = useApp();
  const fields = (config.fields as CustomField[]) ?? [];
  const set = (next: CustomField[]) => onChange({ fields: next });
  return (
    <Field label={t('فیلدهای این بخش (حداکثر {n})', 'Fields of this section (up to {n})', { n: LIMITS.maxCustomFields })} hint={t('اولین فیلد عنوان هر مورد است. حذف فیلد، مقدارهای آن را از نمایش برمی‌دارد.', 'The first field is each item’s title. Removing a field hides its values.')}>
      <div className="stack-sm">
        {fields.map((f, i) => (
          <div key={f.id} className="field-editor">
            <Input value={f.label} onChange={(e) => set(fields.map((x) => (x.id === f.id ? { ...x, label: e.target.value.slice(0, 40) } : x)))} aria-label={t('نام فیلد', 'Field name')} />
            <Select value={f.type} onChange={(e) => set(fields.map((x) => (x.id === f.id ? { ...x, type: e.target.value as CustomFieldType } : x)))} aria-label={t('نوع فیلد', 'Field type')}>
              {CUSTOM_FIELD_TYPES.map((ty) => (
                <option key={ty} value={ty}>
                  {fieldTypeLabel(ty, t)}
                </option>
              ))}
            </Select>
            <IconButton label={t('بالاتر', 'Move up')} size="sm" disabled={i === 0} onClick={() => set(fields.map((x, j) => (j === i - 1 ? f : j === i ? fields[i - 1]! : x)))}>
              <ArrowUp size={14} />
            </IconButton>
            <IconButton label={t('پایین‌تر', 'Move down')} size="sm" disabled={i === fields.length - 1} onClick={() => set(fields.map((x, j) => (j === i + 1 ? f : j === i ? fields[i + 1]! : x)))}>
              <ArrowDown size={14} />
            </IconButton>
            <IconButton label={t('حذف فیلد', 'Remove field')} size="sm" disabled={fields.length <= 1} onClick={() => set(fields.filter((x) => x.id !== f.id))}>
              <X size={14} />
            </IconButton>
          </div>
        ))}
        <Button
          size="sm"
          variant="soft"
          icon={<Plus size={14} />}
          disabled={fields.length >= LIMITS.maxCustomFields}
          onClick={() => set([...fields, { id: `f${Date.now().toString(36)}`, label: t('فیلد جدید', 'New field'), type: 'text' }])}
        >
          {t('افزودن فیلد', 'Add field')}
        </Button>
      </div>
    </Field>
  );
}
