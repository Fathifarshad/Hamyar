import { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { CustomEntry, CustomField, ModuleInstance } from '../../domain/types';
import { Button, EmptyState, Field, IconButton, Input, Modal, Segmented, Switch } from '../../ui/primitives';
import { DatePicker } from '../../ui/DatePicker';
import { VoiceInput } from '../../ui/VoiceInput';
import { ArrowDown, ArrowUp, ExternalLink, LayoutGrid, Pencil, Plus, Search, Settings2, Star, TrashIcon, Rows3 } from '../../ui/icons';
import { checkLinkUrl, hostOf } from '../../domain/urls';
import { matchesQuery, parseLocaleNumber } from '../../domain/normalize';
import { askConfirm, toast } from '../../lib/ui-store';
import { openModuleSettings } from '../../shell/settingsStore';
import { updateModule } from '../../data/modules';

type Values = CustomEntry['values'];

function FieldValue({ field, value }: { field: CustomField; value: Values[string] }) {
  const { t, num, date } = useApp();
  if (value === null || value === undefined || value === '') return <span className="subtle">—</span>;
  switch (field.type) {
    case 'checkbox':
      return <span>{value ? t('بله', 'Yes') : t('خیر', 'No')}</span>;
    case 'number':
      return <span className="num">{num(Number(value), 2)}</span>;
    case 'date':
      return <span>{date(String(value), 'medium')}</span>;
    case 'rating':
      return (
        <span className="stars" aria-label={t('{n} از ۵', '{n} of 5', { n: Number(value) })}>
          {Array.from({ length: 5 }, (_, i) => (
            <Star key={i} size={13} fill={i < Number(value) ? 'currentColor' : 'none'} aria-hidden="true" />
          ))}
        </span>
      );
    case 'link': {
      const ok = checkLinkUrl(String(value));
      return ok.ok ? (
        <a href={ok.url} target="_blank" rel="noopener noreferrer" className="ltr">
          {hostOf(ok.url)} <ExternalLink size={11} aria-hidden="true" />
        </a>
      ) : (
        <span className="ltr">{String(value)}</span>
      );
    }
    default:
      return <span className="para-dir pre-wrap">{String(value)}</span>;
  }
}

function EntryForm({ mod, fields, entry, open, onClose }: { mod: ModuleInstance; fields: CustomField[]; entry: CustomEntry | null; open: boolean; onClose: () => void }) {
  const { t } = useApp();
  const [values, setValues] = useState<Values>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [lastOpen, setLastOpen] = useState(false);
  if (open !== lastOpen) {
    setLastOpen(open);
    if (open) {
      setValues(entry?.values ?? {});
      setErrors({});
    }
  }
  const set = (id: string, v: Values[string]) => setValues((x) => ({ ...x, [id]: v }));
  const save = async () => {
    const errs: Record<string, string> = {};
    const out: Values = {};
    for (const f of fields) {
      const v = values[f.id];
      if (f.type === 'number' && v !== null && v !== undefined && v !== '') {
        const n = parseLocaleNumber(String(v));
        if (n === null) errs[f.id] = t('عدد معتبر نیست.', 'Not a valid number.');
        else out[f.id] = n;
      } else if (f.type === 'link' && v) {
        const c = checkLinkUrl(String(v));
        if (!c.ok) errs[f.id] = t('فقط نشانی‌های http و https.', 'Only http and https addresses.');
        else out[f.id] = c.url;
      } else if (typeof v === 'string') out[f.id] = v.slice(0, 4000);
      else out[f.id] = v ?? null;
    }
    const first = fields[0];
    if (first && !String(out[first.id] ?? '').trim() && first.type !== 'checkbox') errs[first.id] = t('این فیلد را پر کنید.', 'Fill in this field.');
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const ts = nowIso();
    if (entry) await db.customEntries.update(entry.id, { values: out, updatedAt: ts });
    else {
      const count = await db.customEntries.where('moduleId').equals(mod.id).count();
      await db.customEntries.add({ id: uid(), moduleId: mod.id, values: out, order: count, createdAt: ts, updatedAt: ts });
    }
    toast({ kind: 'success', text: t('ذخیره شد.', 'Saved.') });
    onClose();
  };
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={entry ? t('ویرایش مورد', 'Edit item') : t('مورد جدید', 'New item')}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" onClick={() => void save()}>
            {t('ذخیره', 'Save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" data-accent={mod.appearance.accent}>
        {fields.map((f) => (
          <Field key={f.id} label={f.label} error={errors[f.id]}>
            {f.type === 'text' && <VoiceInput value={String(values[f.id] ?? '')} onChange={(v) => set(f.id, v)} lang={mod.inputLanguage} ownerId={`cf-${mod.id}-${f.id}`} inputLabel={f.label} maxLength={300} />}
            {f.type === 'longtext' && <VoiceInput value={String(values[f.id] ?? '')} onChange={(v) => set(f.id, v)} lang={mod.inputLanguage} ownerId={`cf-${mod.id}-${f.id}`} inputLabel={f.label} multiline rows={3} maxLength={4000} />}
            {f.type === 'number' && <Input value={values[f.id] === null || values[f.id] === undefined ? '' : String(values[f.id])} onChange={(e) => set(f.id, e.target.value)} inputMode="decimal" dir="ltr" />}
            {f.type === 'date' && <DatePicker value={(values[f.id] as string) || null} onChange={(d) => set(f.id, d)} label={f.label} allowClear />}
            {f.type === 'checkbox' && <Switch checked={values[f.id] === true} onChange={(v) => set(f.id, v)} label={f.label} />}
            {f.type === 'link' && <Input value={String(values[f.id] ?? '')} onChange={(e) => set(f.id, e.target.value)} dir="ltr" placeholder="https://" inputMode="url" />}
            {f.type === 'rating' && (
              <div className="rating-input" role="radiogroup" aria-label={f.label}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} type="button" role="radio" aria-checked={Number(values[f.id] ?? 0) === n} aria-label={t('{n} ستاره', '{n} stars', { n })} onClick={() => set(f.id, Number(values[f.id] ?? 0) === n ? 0 : n)}>
                    <Star size={20} fill={n <= Number(values[f.id] ?? 0) ? 'currentColor' : 'none'} />
                  </button>
                ))}
              </div>
            )}
          </Field>
        ))}
      </div>
    </Modal>
  );
}

export default function CustomModule({ mod, variant }: ModuleViewProps) {
  const { t } = useApp();
  const fields = (mod.config.fields as CustomField[]) ?? [];
  const layout = (mod.config.layout as 'cards' | 'table') ?? 'cards';
  const entries = useLiveQuery(() => db.customEntries.where('moduleId').equals(mod.id).sortBy('order'), [mod.id]);
  const [form, setForm] = useState<{ open: boolean; entry: CustomEntry | null }>({ open: false, entry: null });
  const [q, setQ] = useState('');
  const filtered = useMemo(() => (entries ?? []).filter((e) => !q || matchesQuery(Object.values(e.values).join(' '), q)), [entries, q]);
  if (!entries) return <div className="mod-loading" />;
  const [first, ...rest] = fields;
  const shown = variant === 'card' ? filtered.slice(0, mod.appearance.density === 'compact' ? 6 : 4) : filtered;

  const move = async (e: CustomEntry, dir: -1 | 1) => {
    const idx = entries.findIndex((x) => x.id === e.id);
    const other = entries[idx + dir];
    if (!other) return;
    await db.transaction('rw', db.customEntries, async () => {
      await db.customEntries.update(e.id, { order: other.order });
      await db.customEntries.update(other.id, { order: e.order });
    });
  };
  const remove = async (e: CustomEntry) => {
    const ok = await askConfirm({ title: t('حذف این مورد؟', 'Delete this item?'), confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (ok) await db.customEntries.delete(e.id);
  };

  return (
    <div className="stack">
      {variant === 'full' && (
        <div className="full-toolbar">
          <div className="search-box grow">
            <Search size={16} aria-hidden="true" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('جست‌وجو', 'Search')} aria-label={t('جست‌وجو', 'Search')} />
          </div>
          <Segmented
            size="sm"
            label={t('نمایش', 'View')}
            value={layout}
            onChange={(v) => void updateModule(mod.id, { config: { layout: v } })}
            options={[
              { value: 'cards', label: '', icon: <LayoutGrid size={15} aria-label={t('کارتی', 'Cards')} />, title: t('کارتی', 'Cards') },
              { value: 'table', label: '', icon: <Rows3 size={15} aria-label={t('جدولی', 'Table')} />, title: t('جدولی', 'Table') },
            ]}
          />
          <IconButton label={t('ویرایش فیلدها', 'Edit fields')} variant="soft" onClick={() => openModuleSettings(mod.id)}>
            <Settings2 size={17} />
          </IconButton>
        </div>
      )}
      {entries.length === 0 ? (
        <EmptyState
          icon={<LayoutGrid size={22} />}
          title={t('این بخش هنوز خالی است', 'This section is empty')}
          text={t('فیلدها: {f}', 'Fields: {f}', { f: fields.map((f) => f.label).join('، ') })}
        />
      ) : variant === 'full' && layout === 'table' ? (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                {fields.map((f) => (
                  <th key={f.id} scope="col">
                    {f.label}
                  </th>
                ))}
                <th scope="col">
                  <span className="visually-hidden">{t('کارها', 'Actions')}</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {shown.map((e) => (
                <tr key={e.id}>
                  {fields.map((f) => (
                    <td key={f.id}>
                      <FieldValue field={f} value={e.values[f.id] ?? null} />
                    </td>
                  ))}
                  <td>
                    <div className="row-actions">
                      <IconButton label={t('ویرایش', 'Edit')} size="sm" onClick={() => setForm({ open: true, entry: e })}>
                        <Pencil size={14} />
                      </IconButton>
                      <IconButton label={t('حذف', 'Delete')} size="sm" onClick={() => void remove(e)}>
                        <TrashIcon size={14} />
                      </IconButton>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <ul className={`entry-grid${variant === 'full' ? ' is-full' : ''}`}>
          {shown.map((e, i) => (
            <li key={e.id} className="entry">
              <button type="button" className="entry-main" onClick={() => setForm({ open: true, entry: e })}>
                {first && (
                  <span className="entry-title">
                    <FieldValue field={first} value={e.values[first.id] ?? null} />
                  </span>
                )}
                {rest.slice(0, variant === 'card' ? 2 : 8).map((f) => (
                  <span key={f.id} className="entry-field">
                    <span className="subtle xsmall">{f.label}</span>
                    <FieldValue field={f} value={e.values[f.id] ?? null} />
                  </span>
                ))}
              </button>
              {variant === 'full' && (
                <div className="row-actions">
                  <IconButton label={t('بالاتر', 'Move up')} size="sm" disabled={i === 0} onClick={() => void move(e, -1)}>
                    <ArrowUp size={14} />
                  </IconButton>
                  <IconButton label={t('پایین‌تر', 'Move down')} size="sm" disabled={i === shown.length - 1} onClick={() => void move(e, 1)}>
                    <ArrowDown size={14} />
                  </IconButton>
                  <IconButton label={t('حذف', 'Delete')} size="sm" onClick={() => void remove(e)}>
                    <TrashIcon size={14} />
                  </IconButton>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
      <div className="row-flex spread">
        {variant === 'card' && filtered.length > shown.length ? (
          <a className="more-link" href={`#/m/${mod.id}`}>
            {t('همه ({n})', 'All ({n})', { n: filtered.length })}
          </a>
        ) : (
          <span />
        )}
        <Button size="sm" variant="soft" icon={<Plus size={14} />} onClick={() => setForm({ open: true, entry: null })} disabled={!fields.length}>
          {t('مورد جدید', 'New item')}
        </Button>
      </div>
      <EntryForm mod={mod} fields={fields} entry={form.entry} open={form.open} onClose={() => setForm({ open: false, entry: null })} />
    </div>
  );
}
