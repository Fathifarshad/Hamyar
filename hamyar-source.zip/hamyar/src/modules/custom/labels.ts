import type { CustomFieldType } from '../../domain/types';

export function fieldTypeLabel(type: CustomFieldType, t: (fa: string, en: string) => string): string {
  switch (type) {
    case 'text':
      return t('متن کوتاه', 'Short text');
    case 'longtext':
      return t('متن بلند', 'Long text');
    case 'number':
      return t('عدد', 'Number');
    case 'date':
      return t('تاریخ', 'Date');
    case 'checkbox':
      return t('بله/خیر', 'Yes/no');
    case 'link':
      return t('لینک', 'Link');
    case 'rating':
      return t('امتیاز ۱ تا ۵', 'Rating 1–5');
  }
}
