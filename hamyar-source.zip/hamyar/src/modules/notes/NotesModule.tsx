import { useEffect, useMemo, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { ModuleInstance, Note } from '../../domain/types';
import { Button, EmptyState, IconButton, Input, Modal, SaveStatus, type SaveState } from '../../ui/primitives';
import { VoiceInput } from '../../ui/VoiceInput';
import { NotebookPen, Pin, PinOff, Plus, Search, TrashIcon, ArrowLeft, ArrowRight } from '../../ui/icons';
import { matchesQuery } from '../../domain/normalize';
import { parseCommand } from '../../domain/commands/parse';
import { useGenericCommand, useVoiceMode, examplesFor, MoreLink } from '../shared';
import { askConfirm, toast } from '../../lib/ui-store';
import { todayISO } from '../../domain/time';

async function createNote(moduleId: string, body: string, title = ''): Promise<Note> {
  const ts = nowIso();
  const note: Note = { id: uid(), moduleId, title: title.slice(0, 120), body: body.slice(0, 20000), tags: [], pinned: false, createdAt: ts, updatedAt: ts };
  await db.notes.add(note);
  return note;
}

function firstLine(n: Note): string {
  return n.title || n.body.split('\n').find((l) => l.trim())?.slice(0, 80) || '';
}

/** Editor with real autosave: the status reflects the IndexedDB write, not a timer. */
function NoteEditor({ mod, note, onDeleted }: { mod: ModuleInstance; note: Note; onDeleted: () => void }) {
  const { t } = useApp();
  const [title, setTitle] = useState(note.title);
  const [body, setBody] = useState(note.body);
  const [tags, setTags] = useState(note.tags.join('، '));
  const [state, setState] = useState<SaveState>('idle');
  const timer = useRef<number>(0);
  const pending = useRef<Partial<Note> | null>(null);

  useEffect(() => {
    setTitle(note.title);
    setBody(note.body);
    setTags(note.tags.join('، '));
    setState('idle');
  }, [note.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const flush = async () => {
    const patch = pending.current;
    if (!patch) return;
    pending.current = null;
    setState('saving');
    try {
      await db.notes.update(note.id, { ...patch, updatedAt: nowIso() });
      setState('saved');
    } catch {
      setState('error');
      pending.current = patch;
    }
  };

  const queue = (patch: Partial<Note>) => {
    pending.current = { ...(pending.current ?? {}), ...patch };
    setState('saving');
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => void flush(), 600);
  };

  useEffect(
    () => () => {
      window.clearTimeout(timer.current);
      void flush();
    },
    [note.id], // eslint-disable-line react-hooks/exhaustive-deps
  );

  const remove = async () => {
    const ok = await askConfirm({ title: t('حذف این یادداشت؟', 'Delete this note?'), confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (!ok) return;
    window.clearTimeout(timer.current);
    pending.current = null;
    await db.notes.delete(note.id);
    onDeleted();
  };

  return (
    <div className="note-editor stack-sm">
      <div className="row-flex">
        <Input
          className="note-title-input"
          value={title}
          placeholder={t('عنوان (اختیاری)', 'Title (optional)')}
          aria-label={t('عنوان یادداشت', 'Note title')}
          onChange={(e) => {
            setTitle(e.target.value);
            queue({ title: e.target.value.slice(0, 120) });
          }}
        />
        <IconButton label={note.pinned ? t('برداشتن سنجاق', 'Unpin') : t('سنجاق کردن', 'Pin')} pressed={note.pinned} onClick={() => void db.notes.update(note.id, { pinned: !note.pinned })}>
          {note.pinned ? <PinOff size={17} /> : <Pin size={17} />}
        </IconButton>
        <IconButton label={t('حذف یادداشت', 'Delete note')} onClick={() => void remove()}>
          <TrashIcon size={17} />
        </IconButton>
      </div>
      <VoiceInput
        value={body}
        onChange={(v) => {
          setBody(v);
          queue({ body: v.slice(0, 20000) });
        }}
        lang={mod.inputLanguage}
        ownerId={`note-body-${note.id}`}
        inputLabel={t('متن یادداشت', 'Note text')}
        multiline
        rows={10}
        maxLength={20000}
        placeholder={t('بنویسید یا میکروفن را بزنید…', 'Write, or press the microphone…')}
      />
      <div className="row-flex spread wrap">
        <Input
          value={tags}
          onChange={(e) => {
            setTags(e.target.value);
            queue({ tags: e.target.value.split(/[،,]/).map((x) => x.trim()).filter(Boolean).slice(0, 10) });
          }}
          placeholder={t('برچسب‌ها با ویرگول: کار، ایده', 'Tags, comma separated: work, ideas')}
          aria-label={t('برچسب‌ها', 'Tags')}
          className="grow"
          style={{ maxWidth: 360 }}
        />
        <SaveStatus state={state} labels={{ saving: t('در حال ذخیره…', 'Saving…'), saved: t('ذخیره شد', 'Saved'), error: t('ذخیره نشد — دوباره تلاش می‌شود', 'Not saved — retrying') }} />
      </div>
      {state === 'error' && (
        <Button size="sm" variant="danger" onClick={() => void flush()}>
          {t('تلاش دوباره برای ذخیره', 'Retry saving')}
        </Button>
      )}
    </div>
  );
}

export default function NotesModule({ mod, variant }: ModuleViewProps) {
  const { t, relDay, tz, locale, bidi } = useApp();
  const notes = useLiveQuery(() => db.notes.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const [quick, setQuick] = useState('');
  const [query, setQuery] = useState('');
  const [openId, setOpenId] = useState<string | null>(null);
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);

  const sorted = useMemo(
    () =>
      (notes ?? [])
        .filter((n) => !query || matchesQuery(`${n.title} ${n.body} ${n.tags.join(' ')}`, query))
        .sort((a, b) => Number(b.pinned) - Number(a.pinned) || (a.updatedAt < b.updatedAt ? 1 : -1)),
    [notes, query],
  );
  const open = notes?.find((n) => n.id === openId) ?? null;

  const add = async (text: string) => {
    const n = await createNote(mod.id, text);
    setQuick('');
    toast({ kind: 'success', text: t('یادداشت ذخیره شد.', 'Note saved.') });
    if (variant === 'full') setOpenId(n.id);
  };

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'notes', now: Date.now(), timezone: tz });
    if (await generic(d)) return;
    if (d.kind === 'create_note' && d.text) {
      const ok = await askConfirm({ title: t('ذخیره این یادداشت؟', 'Save this note?'), body: d.text, confirmText: t('ذخیره', 'Save'), cancelText: t('انصراف', 'Cancel') });
      if (ok) await add(d.text);
    }
  };

  if (!notes) return <div className="mod-loading" />;

  const quickAdd = (
    <VoiceInput
      value={quick}
      onChange={setQuick}
      lang={mod.inputLanguage}
      ownerId={`notes-${mod.id}-${variant}`}
      inputLabel={t('یادداشت سریع', 'Quick note')}
      placeholder={t('یادداشت سریع…', 'Quick note…')}
      onSubmit={(s) => void add(s)}
      submitLabel={t('ذخیره یادداشت', 'Save note')}
      mode={mode}
      onModeChange={setMode}
      onCommand={(s) => void onCommand(s)}
      examples={examplesFor(mod, locale)}
      maxLength={2000}
    />
  );

  const list = (items: Note[]) => (
    <ul className="rows note-list">
      {items.map((n) => (
        <li key={n.id} className={`row${openId === n.id ? ' is-selected' : ''}`}>
          <button type="button" className="row-main" onClick={() => setOpenId(n.id)}>
            <span className="row-title auto-dir" dir={bidi(firstLine(n))}>
              {n.pinned && <Pin size={12} className="pin-mark" aria-label={t('سنجاق‌شده', 'Pinned')} />} {firstLine(n) || t('بدون عنوان', 'Untitled')}
            </span>
            <span className="row-meta">
              <span>{relDay(todayISO(tz, Date.parse(n.updatedAt)))}</span>
              {n.tags.slice(0, 3).map((tg) => (
                <span key={tg} className="tag">
                  #{tg}
                </span>
              ))}
            </span>
          </button>
        </li>
      ))}
    </ul>
  );

  if (variant === 'card') {
    const max = mod.appearance.density === 'compact' ? 5 : 3;
    return (
      <div className="stack">
        {quickAdd}
        {notes.length === 0 ? (
          <EmptyState icon={<NotebookPen size={22} />} title={t('هنوز یادداشتی ندارید', 'No notes yet')} text={t('بنویسید یا بگویید؛ خودکار ذخیره می‌شود.', 'Type or speak; it saves automatically.')} />
        ) : (
          list(sorted.slice(0, max))
        )}
        <MoreLink mod={mod} count={sorted.length - max} />
        <Modal open={!!open} onClose={() => setOpenId(null)} title={t('یادداشت', 'Note')} closeLabel={t('بستن', 'Close')} size="lg">
          {open && <NoteEditor mod={mod} note={open} onDeleted={() => setOpenId(null)} />}
        </Modal>
      </div>
    );
  }

  const Back = locale === 'fa' ? ArrowRight : ArrowLeft;
  return (
    <div className={`split${open ? ' has-detail' : ''}`}>
      <div className="split-list stack">
        {quickAdd}
        <div className="search-box">
          <Search size={16} aria-hidden="true" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t('جست‌وجو در یادداشت‌ها', 'Search notes')} aria-label={t('جست‌وجو', 'Search')} />
        </div>
        {sorted.length === 0 ? (
          <EmptyState icon={<NotebookPen size={22} />} title={query ? t('چیزی پیدا نشد', 'Nothing found') : t('هنوز یادداشتی ندارید', 'No notes yet')} />
        ) : (
          list(sorted)
        )}
        <Button variant="soft" icon={<Plus size={15} />} onClick={() => void createNote(mod.id, '').then((n) => setOpenId(n.id))}>
          {t('یادداشت خالی', 'Blank note')}
        </Button>
      </div>
      <div className="split-detail">
        {open ? (
          <>
            <Button size="sm" variant="ghost" icon={<Back size={15} />} onClick={() => setOpenId(null)} className="split-back">
              {t('فهرست', 'List')}
            </Button>
            <NoteEditor mod={mod} note={open} onDeleted={() => setOpenId(null)} />
          </>
        ) : (
          <EmptyState icon={<NotebookPen size={22} />} title={t('یک یادداشت را انتخاب کنید', 'Pick a note')} />
        )}
      </div>
    </div>
  );
}
