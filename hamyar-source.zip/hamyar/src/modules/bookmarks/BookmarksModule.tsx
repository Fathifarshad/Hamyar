import { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { Bookmark, ModuleInstance } from '../../domain/types';
import { Button, EmptyState, Field, IconButton, Input, Modal } from '../../ui/primitives';
import { VoiceInput } from '../../ui/VoiceInput';
import { ArrowDown, ArrowUp, Bookmark as BookmarkIcon, ExternalLink, Pencil, Plus, Search, TrashIcon } from '../../ui/icons';
import { checkLinkUrl, hostOf } from '../../domain/urls';
import { matchesQuery } from '../../domain/normalize';
import { parseCommand } from '../../domain/commands/parse';
import { useGenericCommand, useVoiceMode, examplesFor, MoreLink } from '../shared';
import { askConfirm, toast } from '../../lib/ui-store';

const AVATAR_HUES = ['teal', 'blue', 'indigo', 'violet', 'pink', 'orange', 'green', 'amber'] as const;

function avatarAccent(host: string) {
  let h = 0;
  for (const c of host) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return AVATAR_HUES[h % AVATAR_HUES.length]!;
}

function BookmarkForm({ mod, item, open, onClose }: { mod: ModuleInstance; item: Bookmark | null; open: boolean; onClose: () => void }) {
  const { t } = useApp();
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');
  const [tags, setTags] = useState('');
  const [tried, setTried] = useState(false);
  const [lastOpen, setLastOpen] = useState(false);
  if (open !== lastOpen) {
    setLastOpen(open);
    if (open) {
      setTitle(item?.title ?? '');
      setUrl(item?.url ?? '');
      setTags(item?.tags.join('، ') ?? '');
      setTried(false);
    }
  }
  const check = checkLinkUrl(url);
  const urlError = !check.ok
    ? check.reason === 'empty'
      ? t('نشانی را وارد کنید.', 'Enter an address.')
      : check.reason === 'scheme' || check.reason === 'html'
        ? t('فقط نشانی‌های http و https پذیرفته می‌شوند.', 'Only http and https addresses are accepted.')
        : t('این نشانی معتبر نیست.', 'This address is not valid.')
    : undefined;
  const save = async () => {
    setTried(true);
    if (!check.ok) return;
    const tagList = tags.split(/[،,]/).map((x) => x.trim()).filter(Boolean).slice(0, 8);
    const finalTitle = title.trim() || hostOf(check.url);
    if (item) await db.bookmarks.update(item.id, { title: finalTitle, url: check.url, tags: tagList });
    else {
      const count = await db.bookmarks.where('moduleId').equals(mod.id).count();
      await db.bookmarks.add({ id: uid(), moduleId: mod.id, title: finalTitle.slice(0, 120), url: check.url, tags: tagList, order: count, createdAt: nowIso() });
    }
    toast({ kind: 'success', text: t('لینک ذخیره شد.', 'Link saved.') });
    onClose();
  };
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={item ? t('ویرایش لینک', 'Edit link') : t('افزودن لینک', 'Add link')}
      closeLabel={t('بستن', 'Close')}
      size="sm"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" onClick={() => void save()}>
            {t('ذخیره', 'Save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" data-accent={mod.appearance.accent}>
        <Field label={t('نشانی', 'Address')} error={tried ? urlError : undefined} hint={t('محتوای سایت خوانده نمی‌شود؛ فقط لینک ذخیره می‌شود.', 'The site is not fetched; only the link is saved.')}>
          <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://" dir="ltr" inputMode="url" autoComplete="url" />
        </Field>
        <Field label={t('عنوان', 'Title')}>
          <VoiceInput value={title} onChange={setTitle} lang={mod.inputLanguage} ownerId={`bm-title-${mod.id}`} inputLabel={t('عنوان', 'Title')} maxLength={120} />
        </Field>
        <Field label={t('برچسب‌ها', 'Tags')}>
          <Input value={tags} onChange={(e) => setTags(e.target.value)} placeholder={t('کار، خبر', 'work, news')} />
        </Field>
      </div>
    </Modal>
  );
}

export default function BookmarksModule({ mod, variant }: ModuleViewProps) {
  const { t, tz, locale, bidi } = useApp();
  const items = useLiveQuery(() => db.bookmarks.where('moduleId').equals(mod.id).sortBy('order'), [mod.id]);
  const [form, setForm] = useState<{ open: boolean; item: Bookmark | null }>({ open: false, item: null });
  const [query, setQuery] = useState('');
  const [voice, setVoice] = useState('');
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);
  const filtered = useMemo(() => (items ?? []).filter((b) => !query || matchesQuery(`${b.title} ${b.url} ${b.tags.join(' ')}`, query)), [items, query]);

  const move = async (b: Bookmark, dir: -1 | 1) => {
    const list = items ?? [];
    const i = list.findIndex((x) => x.id === b.id);
    const other = list[i + dir];
    if (!other) return;
    await db.transaction('rw', db.bookmarks, async () => {
      await db.bookmarks.update(b.id, { order: other.order });
      await db.bookmarks.update(other.id, { order: b.order });
    });
  };

  const remove = async (b: Bookmark) => {
    const ok = await askConfirm({ title: t('حذف «{title}»؟', 'Delete “{title}”?', { title: b.title }), confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (ok) await db.bookmarks.delete(b.id);
  };

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'bookmarks', now: Date.now(), timezone: tz });
    if (d.kind === 'open_bookmark') {
      const hit = (items ?? []).find((b) => matchesQuery(`${b.title} ${hostOf(b.url)} ${b.tags.join(' ')}`, d.query));
      if (hit) {
        toast({ kind: 'info', text: t('«{title}» پیدا شد.', 'Found “{title}”.', { title: hit.title }), action: { label: t('باز کردن', 'Open'), run: () => window.open(hit.url, '_blank', 'noopener,noreferrer') } });
      } else toast({ kind: 'warning', text: t('لینکی با «{q}» پیدا نشد.', 'No link matches “{q}”.', { q: d.query }) });
      return;
    }
    await generic(d);
  };

  if (!items) return <div className="mod-loading" />;
  const max = variant === 'card' ? (mod.appearance.density === 'compact' ? 8 : 5) : Infinity;
  const shown = filtered.slice(0, max);

  return (
    <div className="stack">
      {variant === 'full' && (
        <div className="full-toolbar">
          <div className="search-box grow">
            <Search size={16} aria-hidden="true" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t('جست‌وجو در لینک‌ها', 'Search links')} aria-label={t('جست‌وجو', 'Search')} />
          </div>
          <Button variant="accent" icon={<Plus size={16} />} onClick={() => setForm({ open: true, item: null })}>
            {t('افزودن لینک', 'Add link')}
          </Button>
        </div>
      )}
      <VoiceInput
        value={voice}
        onChange={setVoice}
        lang={mod.inputLanguage}
        ownerId={`bm-${mod.id}-${variant}`}
        inputLabel={t('جست‌وجو یا فرمان صوتی', 'Search or voice command')}
        placeholder={t('جست‌وجو یا «باز کن …»', 'Search or “open …”')}
        mode={mode}
        onModeChange={setMode}
        onCommand={(s) => void onCommand(s)}
        onSubmit={(s) => setQuery(s)}
        submitLabel={t('جست‌وجو', 'Search')}
        submitIcon={<Search size={16} />}
        examples={examplesFor(mod, locale)}
      />
      {items.length === 0 ? (
        <EmptyState
          icon={<BookmarkIcon size={22} />}
          title={t('لینکی ذخیره نکرده‌اید', 'No saved links')}
          action={
            <Button variant="accent" size="sm" icon={<Plus size={14} />} onClick={() => setForm({ open: true, item: null })}>
              {t('افزودن لینک', 'Add link')}
            </Button>
          }
        />
      ) : (
        <ul className={`link-grid${variant === 'full' ? ' is-full' : ''}`}>
          {shown.map((b, i) => {
            const host = hostOf(b.url);
            return (
              <li key={b.id} className="link-item">
                <a href={b.url} target="_blank" rel="noopener noreferrer" className="link-main">
                  <span className="link-avatar" data-accent={avatarAccent(host)} aria-hidden="true">
                    {(host[0] ?? '?').toUpperCase()}
                  </span>
                  <span className="link-text">
                    <span className="link-title auto-dir" dir={bidi(b.title)}>{b.title}</span>
                    <span className="link-host ltr">{host}</span>
                  </span>
                  <ExternalLink size={14} className="link-ext" aria-hidden="true" />
                </a>
                {variant === 'full' && (
                  <div className="row-actions">
                    <IconButton label={t('بالاتر', 'Move up')} size="sm" disabled={i === 0} onClick={() => void move(b, -1)}>
                      <ArrowUp size={15} />
                    </IconButton>
                    <IconButton label={t('پایین‌تر', 'Move down')} size="sm" disabled={i === shown.length - 1} onClick={() => void move(b, 1)}>
                      <ArrowDown size={15} />
                    </IconButton>
                    <IconButton label={t('ویرایش', 'Edit')} size="sm" onClick={() => setForm({ open: true, item: b })}>
                      <Pencil size={15} />
                    </IconButton>
                    <IconButton label={t('حذف', 'Delete')} size="sm" onClick={() => void remove(b)}>
                      <TrashIcon size={15} />
                    </IconButton>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
      {variant === 'card' && items.length > 0 && (
        <div className="row-flex spread">
          <MoreLink mod={mod} count={filtered.length - shown.length} />
          <Button size="sm" variant="soft" icon={<Plus size={14} />} onClick={() => setForm({ open: true, item: null })}>
            {t('لینک', 'Link')}
          </Button>
        </div>
      )}
      <BookmarkForm mod={mod} item={form.item} open={form.open} onClose={() => setForm({ open: false, item: null })} />
    </div>
  );
}
