import { useEffect, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { Transcript } from '../../domain/types';
import { Button, EmptyState, IconButton, Input, Modal, Notice, Progress } from '../../ui/primitives';
import { FileDrop } from '../../ui/FileDrop';
import { VoiceInput } from '../../ui/VoiceInput';
import { AudioLines, Copy, Download, Info, Mic, Save, Square, TrashIcon, TriangleAlert, Wand2Icon, X, ShieldCheck } from '../../ui/icons';
import { RecorderError, startRecording, type RecorderHandle } from '../../lib/recorder';
import { abortMic } from '../../lib/mic';
import { AiError, aiStatusStore, refreshAiStatus, transcribeAudio } from '../../lib/ai';
import { useStore } from '../../lib/store';
import { LIMITS } from '../../config/limits';
import { blobDuration } from '../../lib/media';
import { saveAsset, sniff } from '../../data/assets';
import { errorText } from '../../i18n/errors';
import { copyText, saveFile } from '../../lib/download';
import { askConfirm, toast } from '../../lib/ui-store';
import { IS_ARTIFACT, pickRecorderMime } from '../../lib/platform';
import { todayISO } from '../../domain/time';

interface PendingAudio {
  blob: Blob;
  url: string;
  name: string;
  duration: number | null;
  source: 'recording' | 'file';
}

export default function TranscriptionModule({ mod, variant }: ModuleViewProps) {
  const { t, duration, bytes, relDay, tz, bidi } = useApp();
  const status = useStore(aiStatusStore);
  const transcripts = useLiveQuery(() => db.transcripts.where('moduleId').equals(mod.id).reverse().sortBy('updatedAt'), [mod.id]);
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [rec, setRec] = useState<RecorderHandle | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [level, setLevel] = useState(0);
  const [audio, setAudio] = useState<PendingAudio | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [consentOpen, setConsentOpen] = useState(false);
  const ctl = useRef<AbortController | null>(null);
  const keepAudio = mod.config.keepAudio === true;
  const canRecord = !!pickRecorderMime() && !!navigator.mediaDevices?.getUserMedia;

  useEffect(() => {
    void refreshAiStatus();
  }, []);
  useEffect(
    () => () => {
      rec?.cancel();
      ctl.current?.abort();
    },
    [rec],
  );
  useEffect(() => () => (audio ? URL.revokeObjectURL(audio.url) : undefined), [audio]);

  const startRec = async () => {
    setError(null);
    abortMic();
    try {
      const h = await startRecording({
        maxMs: LIMITS.transcriptionSeconds * 1000,
        maxBytes: LIMITS.transcriptionBytes,
        onTick: (ms) => setElapsed(ms / 1000),
        onLevel: setLevel,
        onAutoStop: (reason, blob) => {
          setRec(null);
          setAudio({ blob, url: URL.createObjectURL(blob), name: 'recording', duration: elapsed, source: 'recording' });
          toast({ kind: 'warning', text: reason === 'time' ? t('ضبط به سقف ۱۰ دقیقه رسید و متوقف شد.', 'Recording reached the 10-minute limit and stopped.') : t('ضبط به سقف حجم رسید و متوقف شد.', 'Recording reached the size limit and stopped.') });
        },
      });
      setElapsed(0);
      setRec(h);
    } catch (e) {
      const code = e instanceof RecorderError ? e.code : 'failed';
      setError(
        code === 'denied'
          ? IS_ARTIFACT
            ? t('در پیش‌نمایش claude.ai میکروفن در دسترس نیست. فایل صوتی را بارگذاری کنید یا نسخه قابل اجرا را باز کنید.', 'The microphone is not available in the claude.ai preview. Upload an audio file or run the app.')
            : t('اجازه میکروفن داده نشد. از نماد قفل کنار نشانی سایت، میکروفن را مجاز کنید.', 'Microphone permission was denied. Allow it from the lock icon next to the address.')
          : code === 'unsupported'
            ? t('این مرورگر ضبط صدا را پشتیبانی نمی‌کند.', 'This browser cannot record audio.')
            : t('میکروفن در دسترس نیست.', 'The microphone is not available.'),
      );
    }
  };

  const stopRec = async () => {
    if (!rec) return;
    const blob = await rec.stop();
    setRec(null);
    setAudio({ blob, url: URL.createObjectURL(blob), name: 'recording', duration: elapsed, source: 'recording' });
  };

  const onFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setError(null);
    const kind = await sniff(f);
    if (kind.family !== 'audio' && kind.family !== 'av') return setError(t('این فایل صوتی شناخته‌شده نیست. MP3، M4A، WAV یا WebM بارگذاری کنید.', 'Not a recognised audio file. Upload MP3, M4A, WAV or WebM.'));
    if (f.size > LIMITS.transcriptionBytes) return setError(t('حجم فایل بیشتر از {max} است.', 'The file is larger than {max}.', { max: bytes(LIMITS.transcriptionBytes) }));
    const d = await blobDuration(f, 'audio');
    if (d !== null && d > LIMITS.transcriptionSeconds) return setError(t('فایل بیشتر از ۱۰ دقیقه است. بخش کوتاه‌تری بارگذاری کنید.', 'The file is longer than 10 minutes. Upload a shorter part.'));
    setAudio({ blob: f, url: URL.createObjectURL(f), name: f.name, duration: d, source: 'file' });
  };

  const transcribe = async () => {
    if (!audio) return;
    const provider = status.transcription.provider ?? '';
    const consent = await db.consents.get(`transcription:${provider}`);
    if (!consent) {
      setConsentOpen(true);
      return;
    }
    setBusy(true);
    setError(null);
    const c = new AbortController();
    ctl.current = c;
    try {
      const out = await transcribeAudio(audio.blob, { language: mod.inputLanguage === 'fa-IR' ? 'fa' : 'en', durationSec: audio.duration ?? 60, filename: audio.name, signal: c.signal });
      setText((cur) => (cur.trim() ? `${cur.trim()}\n\n${out.text}` : out.text));
      if (!title) setTitle(audio.source === 'file' ? audio.name.replace(/\.[a-z0-9]+$/i, '') : t('ضبط {d}', 'Recording {d}', { d: new Date().toLocaleTimeString() }));
      toast({ kind: 'success', text: t('متن آماده است؛ بررسی و ذخیره کنید.', 'Text is ready; review and save.') });
      if (!keepAudio) setAudio(null);
    } catch (e) {
      if (!(e instanceof AiError && e.code === 'CANCELLED')) setError(errorText(e, t));
    } finally {
      setBusy(false);
      ctl.current = null;
    }
  };

  const save = async () => {
    if (!text.trim()) return;
    let assetId: string | null = null;
    if (keepAudio && audio) {
      try {
        assetId = (await saveAsset({ moduleId: mod.id, kind: 'recording', blob: audio.blob, name: audio.name, maxBytes: LIMITS.transcriptionBytes })).id;
      } catch (e) {
        toast({ kind: 'warning', text: errorText(e, t) });
      }
    }
    const ts = nowIso();
    if (editingId) await db.transcripts.update(editingId, { title: title.trim() || t('بدون عنوان', 'Untitled'), text, updatedAt: ts });
    else
      await db.transcripts.add({
        id: uid(),
        moduleId: mod.id,
        title: (title.trim() || t('بدون عنوان', 'Untitled')).slice(0, 120),
        text: text.slice(0, 100_000),
        language: mod.inputLanguage,
        source: audio?.source === 'file' ? 'file' : audio ? 'recording' : 'live',
        assetId,
        createdAt: ts,
        updatedAt: ts,
      });
    toast({ kind: 'success', text: t('متن ذخیره شد.', 'Text saved.') });
    setText('');
    setTitle('');
    setEditingId(null);
    setAudio(null);
  };

  const removeTranscript = async (tr: Transcript) => {
    const ok = await askConfirm({ title: t('حذف «{n}»؟', 'Delete “{n}”?', { n: tr.title }), confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (!ok) return;
    await db.transaction('rw', db.transcripts, db.assets, async () => {
      if (tr.assetId) await db.assets.delete(tr.assetId);
      await db.transcripts.delete(tr.id);
    });
  };

  const sttReason =
    status.transcription.available || status.transcription.reason === 'checking'
      ? null
      : status.transcription.reason === 'mobile_unavailable'
        ? t('تبدیل فایل صوتی به متن در نسخه گوشی فعال نیست (به سرور نیاز دارد). از دیکته زنده با دکمه میکروفن یا میکروفن صفحه‌کلید استفاده کنید.', 'Audio-file transcription is not available in the phone app (it needs a server). Use live dictation with the microphone button or the keyboard microphone.')
      : status.transcription.reason === 'preview_unavailable'
        ? t('تبدیل فایل صوتی در پیش‌نمایش claude.ai در دسترس نیست. تایپ کنید یا نسخه قابل اجرا را با کلید سرویس اجرا کنید.', 'Audio-file transcription is not available in the claude.ai preview. Type, or run the app with a service key.')
        : status.transcription.reason === 'server_missing'
          ? t('سرور محلی همیار در دسترس نیست؛ برای تبدیل فایل، برنامه را با «npm start» اجرا کنید.', 'Hamyar’s local server is unreachable; run the app with “npm start” to transcribe files.')
          : status.transcription.reason === 'offline'
            ? t('اینترنت در دسترس نیست.', 'You are offline.')
            : t('تبدیل فایل صوتی به متن هنوز برای این نسخه راه‌اندازی نشده است (کلید سرویس در ‎.env سرور).', 'Audio-file transcription has not been set up for this copy yet (service key in the server’s .env).');

  if (!transcripts) return <div className="mod-loading" />;

  return (
    <div className="stack">
      <div className="recorder">
        {rec ? (
          <div className="listening">
            <div className="wave" aria-hidden="true" style={{ ['--lvl' as string]: String(level || 0.3) }}>
              <span />
              <span />
              <span />
              <span />
              <span />
            </div>
            <div className="listening-text grow">
              <div className="listening-label">
                {t('در حال ضبط', 'Recording')} <span className="num">{duration(elapsed)}</span> / <span className="num">{duration(LIMITS.transcriptionSeconds)}</span>
              </div>
            </div>
            <Button size="sm" variant="accent" icon={<Square size={14} />} onClick={() => void stopRec()}>
              {t('پایان', 'Stop')}
            </Button>
            <IconButton
              label={t('لغو ضبط', 'Cancel recording')}
              size="sm"
              onClick={() => {
                rec.cancel();
                setRec(null);
              }}
            >
              <X size={16} />
            </IconButton>
          </div>
        ) : audio ? (
          <div className="audio-pending">
            <audio src={audio.url} controls preload="metadata" className="audio-el" />
            <div className="row-flex wrap">
              <span className="subtle small">
                {audio.source === 'file' ? audio.name : t('ضبط', 'Recording')} · {bytes(audio.blob.size)}
                {audio.duration ? ` · ${duration(audio.duration)}` : ''}
              </span>
              <span className="grow" />
              {busy ? (
                <Button size="sm" variant="ghost" icon={<X size={14} />} onClick={() => ctl.current?.abort()}>
                  {t('لغو', 'Cancel')}
                </Button>
              ) : (
                <IconButton label={t('کنار گذاشتن صدا', 'Discard audio')} size="sm" onClick={() => setAudio(null)}>
                  <TrashIcon size={15} />
                </IconButton>
              )}
              <Button size="sm" variant="accent" icon={<Wand2Icon size={14} />} busy={busy} disabled={!status.transcription.available} onClick={() => void transcribe()}>
                {t('تبدیل به متن', 'Transcribe')}
              </Button>
            </div>
            {busy && <Progress value={0.5} max={1} label={t('در حال تبدیل', 'Transcribing')} />}
          </div>
        ) : (
          <div className="row-flex wrap">
            <Button variant="accent" icon={<Mic size={16} />} onClick={() => void startRec()} disabled={!canRecord}>
              {t('ضبط صدا', 'Record')}
            </Button>
            <span className="subtle small">{t('یا', 'or')}</span>
            <div className="grow">
              <FileDrop accept="audio/*,.mp3,.m4a,.wav,.webm,.ogg" onFiles={(f) => void onFile(f)} title={t('بارگذاری فایل صوتی', 'Upload an audio file')} hint={t('تا ۱۰ دقیقه و {max}', 'Up to 10 min and {max}', { max: bytes(LIMITS.transcriptionBytes) })} />
            </div>
          </div>
        )}
      </div>
      {sttReason && (
        <Notice tone="neutral" icon={<Info size={16} />}>
          {sttReason}
        </Notice>
      )}
      {error && (
        <Notice tone="danger" icon={<TriangleAlert size={16} />}>
          {error}
        </Notice>
      )}
      <div className="stack-sm">
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t('عنوان متن', 'Title')} aria-label={t('عنوان متن', 'Title')} maxLength={120} />
        <VoiceInput
          value={text}
          onChange={setText}
          lang={mod.inputLanguage}
          ownerId={`stt-live-${mod.id}-${variant}`}
          inputLabel={t('متن', 'Text')}
          multiline
          continuous
          rows={variant === 'full' ? 10 : 4}
          maxLength={100_000}
          placeholder={t('متن اینجا می‌آید. با میکروفن کنار کادر می‌توانید زنده هم دیکته کنید.', 'Text appears here. Use the microphone beside the box for live dictation.')}
        />
        <div className="row-flex wrap">
          <Button variant="accent" size="sm" icon={<Save size={14} />} disabled={!text.trim()} onClick={() => void save()}>
            {editingId ? t('ذخیره تغییرات', 'Save changes') : t('ذخیره متن', 'Save text')}
          </Button>
          <Button size="sm" variant="soft" icon={<Copy size={14} />} disabled={!text.trim()} onClick={async () => {
            const ok = await copyText(text);
            toast({ kind: ok ? 'success' : 'warning', text: ok ? t('کپی شد.', 'Copied.') : t('کپی ممکن نشد؛ متن را انتخاب کنید.', 'Copy failed; select the text instead.') });
          }}>
            {t('کپی', 'Copy')}
          </Button>
          <Button
            size="sm"
            variant="soft"
            icon={<Download size={14} />}
            disabled={!text.trim()}
            onClick={async () => {
              const r = await saveFile(`${(title || 'transcript').replace(/[\\/:*?"<>|]/g, '-')}.txt`, text, 'text/plain');
              if (r === 'unavailable') toast({ kind: 'warning', text: t('دریافت فایل در این نمایش ممکن نیست؛ از «کپی» استفاده کنید.', 'Downloads are not available here; use Copy.') });
            }}
          >
            {t('دریافت ‎.txt', 'Download .txt')}
          </Button>
          {editingId && (
            <Button size="sm" variant="ghost" onClick={() => (setEditingId(null), setText(''), setTitle(''))}>
              {t('متن جدید', 'New text')}
            </Button>
          )}
        </div>
      </div>
      {variant === 'full' && (
        <>
          <h3 className="sec-title-plain">{t('متن‌های ذخیره‌شده', 'Saved texts')}</h3>
          {transcripts.length === 0 ? (
            <EmptyState icon={<AudioLines size={22} />} title={t('هنوز متنی ذخیره نشده', 'No saved texts yet')} />
          ) : (
            <ul className="rows">
              {transcripts.map((tr) => (
                <li key={tr.id} className={`row${editingId === tr.id ? ' is-selected' : ''}`}>
                  <button
                    type="button"
                    className="row-main"
                    onClick={() => {
                      setEditingId(tr.id);
                      setTitle(tr.title);
                      setText(tr.text);
                    }}
                  >
                    <span className="row-title auto-dir" dir={bidi(tr.title)}>{tr.title}</span>
                    <span className="row-meta">
                      <span>{relDay(todayISO(tz, Date.parse(tr.updatedAt)))}</span>
                      <span className="ellipsis auto-dir" dir={bidi(tr.text.slice(0, 60))}>{tr.text.slice(0, 60)}</span>
                    </span>
                  </button>
                  <IconButton label={t('حذف', 'Delete')} size="sm" onClick={() => void removeTranscript(tr)}>
                    <TrashIcon size={15} />
                  </IconButton>
                </li>
              ))}
            </ul>
          )}
        </>
      )}
      {variant === 'card' && transcripts.length > 0 && (
        <a className="more-link" href={`#/m/${mod.id}`}>
          {t('{n} متن ذخیره‌شده', '{n} saved texts', { n: transcripts.length })}
        </a>
      )}
      <Modal
        open={consentOpen}
        onClose={() => setConsentOpen(false)}
        title={t('ارسال صدا برای تبدیل به متن', 'Send audio for transcription')}
        closeLabel={t('بستن', 'Close')}
        size="sm"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConsentOpen(false)}>
              {t('انصراف', 'Cancel')}
            </Button>
            <Button
              variant="accent"
              icon={<ShieldCheck size={16} />}
              onClick={async () => {
                const provider = status.transcription.provider ?? '';
                await db.consents.put({ id: `transcription:${provider}`, feature: 'transcription', provider, grantedAt: nowIso(), version: 1 });
                setConsentOpen(false);
                await transcribe();
              }}
            >
              {t('موافقم، ارسال شود', 'I agree, send it')}
            </Button>
          </>
        }
      >
        <div className="stack-sm">
          <p>{t('این صدا از سرور محلی همیار به «{p}» فرستاده می‌شود تا به متن تبدیل شود.', 'This audio is sent from Hamyar’s local server to “{p}” to be transcribed.', { p: status.transcription.provider ?? '' })}</p>
          <p className="muted small">
            {keepAudio
              ? t('طبق تنظیم این بخش، فایل صوتی پس از تبدیل همراه متن نگه داشته می‌شود.', 'As set for this section, the audio is kept with the text.')
              : t('پس از تبدیل فقط متن نگه داشته می‌شود و صدای موقت پاک می‌شود. نگهداری نزد ارائه‌دهنده تابع سیاست همان سرویس است.', 'After transcription only the text is kept and the temporary audio is discarded. Retention at the provider follows that service’s policy.')}
          </p>
        </div>
      </Modal>
    </div>
  );
}
