import { useApp } from '../../shell/AppContext';
import type { ModuleSettingsProps } from '../registry';
import { Switch } from '../../ui/primitives';

export default function TranscriptionSettings({ config, onChange }: ModuleSettingsProps) {
  const { t } = useApp();
  return (
    <Switch
      checked={config.keepAudio === true}
      onChange={(keepAudio) => onChange({ keepAudio })}
      label={t('نگه داشتن فایل صوتی بعد از تبدیل', 'Keep the audio after transcribing')}
      description={t('پیش‌فرض خاموش: فقط متن نگه داشته می‌شود و صدای موقت پاک می‌شود.', 'Off by default: only the text is kept and the temporary audio is discarded.')}
    />
  );
}
