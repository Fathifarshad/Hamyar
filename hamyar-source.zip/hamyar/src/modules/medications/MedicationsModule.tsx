import { useEffect, useMemo, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { Medication, ModuleInstance } from '../../domain/types';
import { createMed, deleteMed, inputFromMed, listDoses, recordDose, setMedActive, updateMed, validateMedInput, type DoseItem, type MedInput } from './data';
import { Button, EmptyState, Field, IconButton, Input, Modal, Notice, Segmented, Switch, Tabs, Chip } from '../../ui/primitives';
import { VoiceInput } from '../../ui/VoiceInput';
import { DatePicker } from '../../ui/DatePicker';
import { CalendarPlus, Check, CircleX, Info, Pill, Plus, ShieldCheck, TrashIcon, X, Pencil } from '../../ui/icons';
import { medicationCalendarEvents, saveCalendar } from '../../lib/ics';
import { IS_ARTIFACT, IS_NATIVE } from '../../lib/platform';
import { addDaysISO, listTimeZones } from '../../domain/time';
import { WEEKDAYS_EN, WEEKDAYS_FA } from '../../domain/jalali';
import { askConfirm, toast } from '../../lib/ui-store';
import { errorText } from '../../i18n/errors';
import { SectionTitle } from '../shared';
import { currentRule } from '../../domain/recurrence';

function emptyMed(tz: string, today: string): MedInput {
  return { name: '', dosageText: '', unitText: '', notes: '', times: ['08:00'], freq: 'daily', weekdays: [], startDate: today, endDate: null, timezone: tz, reminderEnabled: true, showNameInNotification: false };
}

function MedForm({ mod, med, open, onClose }: { mod: ModuleInstance; med: Medication | null; open: boolean; onClose: () => void }) {
  const { t, tz, today, locale } = useApp();
  const base = useMemo(() => (med ? inputFromMed(med) : emptyMed(tz, today)), [med, tz, today]);
  const [v, setV] = useState(base);
  const [tried, setTried] = useState(false);
  const [busy, setBusy] = useState(false);
  const idem = useMemo(() => uid(), [open]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (open) {
      setV(base);
      setTried(false);
    }
  }, [open, base]);
  const set = (p: Partial<MedInput>) => setV((x) => ({ ...x, ...p }));
  const errors = validateMedInput(v);
  const err = (k: string) =>
    tried && errors[k]
      ? k === 'name'
        ? t('نام دارو را بنویسید.', 'Enter the medication name.')
        : k === 'dosageText'
          ? t('مقدار مصرف را همان‌طور که در نسخه آمده بنویسید.', 'Enter the dose as written on your prescription.')
          : k === 'times'
            ? t('حداقل یک ساعت معتبر لازم است.', 'At least one valid time is needed.')
            : k === 'weekdays'
              ? t('حداقل یک روز را انتخاب کنید.', 'Pick at least one day.')
              : t('پایان نمی‌تواند قبل از شروع باشد.', 'End cannot be before the start.')
      : undefined;
  const days = locale === 'fa' ? [6, 0, 1, 2, 3, 4, 5] : [0, 1, 2, 3, 4, 5, 6];
  const names = locale === 'fa' ? WEEKDAYS_FA : WEEKDAYS_EN;
  const zones = useMemo(() => listTimeZones(), []);
  const dirty = JSON.stringify(v) !== JSON.stringify(base);

  const close = async () => {
    if (dirty) {
      const ok = await askConfirm({ title: t('تغییرات ذخیره نشده‌اند', 'Unsaved changes'), confirmText: t('بستن بدون ذخیره', 'Discard'), cancelText: t('ادامه ویرایش', 'Keep editing') });
      if (!ok) return;
    }
    onClose();
  };

  const save = async () => {
    setTried(true);
    if (Object.keys(errors).length) return;
    if (med) {
      const ok = await askConfirm({
        title: t('ذخیره تغییر برنامه دارو؟', 'Save the schedule change?'),
        body: t('تغییر فقط روی نوبت‌های آینده اثر دارد. نوبت‌های ثبت‌شده گذشته با همان ساعت و مقدار قبلی در سابقه می‌مانند.', 'The change applies to future doses only. Past recorded doses keep their original time and amount in the history.'),
        confirmText: t('ذخیره', 'Save'),
        cancelText: t('انصراف', 'Cancel'),
      });
      if (!ok) return;
    }
    setBusy(true);
    try {
      if (med) await updateMed(med.id, v);
      else await createMed(mod.id, v, idem);
      toast({ kind: 'success', text: t('برنامه دارو ذخیره شد.', 'Medication schedule saved.') });
      onClose();
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!med) return;
    const ok = await askConfirm({
      title: t('حذف «{name}» و سابقه آن؟', 'Delete “{name}” and its history?', { name: med.name }),
      body: t('برنامه، یادآوری‌های آینده و سابقه مصرف این دارو حذف می‌شود. برای نگه داشتن سابقه، به‌جای حذف آن را «متوقف» کنید.', 'The schedule, future reminders and dose history are deleted. To keep the history, pause it instead.'),
      confirmText: t('حذف', 'Delete'),
      cancelText: t('انصراف', 'Cancel'),
      danger: true,
    });
    if (!ok) return;
    await deleteMed(med.id);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={() => void close()}
      title={med ? t('ویرایش برنامه دارو', 'Edit medication') : t('افزودن دارو', 'Add medication')}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          {med && (
            <Button variant="danger" icon={<TrashIcon size={15} />} onClick={() => void remove()} className="me-auto">
              {t('حذف', 'Delete')}
            </Button>
          )}
          <Button variant="ghost" onClick={() => void close()}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" busy={busy} onClick={() => void save()}>
            {t('ذخیره', 'Save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" data-accent={mod.appearance.accent}>
        <Notice tone="neutral" icon={<ShieldCheck size={16} />}>
          {t('همیار فقط برنامه‌ای را که خودتان از روی نسخه وارد می‌کنید نگه می‌دارد و هیچ توصیه پزشکی، دوز یا تداخلی پیشنهاد نمی‌دهد.', 'Hamyar only keeps the schedule you enter from your prescription. It gives no medical advice, doses or interaction checks.')}
        </Notice>
        <Field label={t('نام دارو', 'Medication name')} error={err('name')}>
          <VoiceInput value={v.name} onChange={(name) => set({ name })} lang={mod.inputLanguage} ownerId={`med-name-${mod.id}`} inputLabel={t('نام دارو', 'Medication name')} maxLength={120} />
        </Field>
        <div className="form-row">
          <Field label={t('مقدار مصرف (طبق نسخه)', 'Dose (as prescribed)')} error={err('dosageText')}>
            <VoiceInput
              value={v.dosageText}
              onChange={(dosageText) => set({ dosageText })}
              lang={mod.inputLanguage}
              ownerId={`med-dose-${mod.id}`}
              inputLabel={t('مقدار مصرف', 'Dose')}
              placeholder={t('مثلاً ۱ قرص', 'e.g. 1 tablet')}
              maxLength={200}
            />
          </Field>
          <Field label={t('واحد (اختیاری)', 'Unit (optional)')}>
            <Input value={v.unitText} onChange={(e) => set({ unitText: e.target.value })} placeholder={t('مثلاً میلی‌گرم', 'e.g. mg')} maxLength={60} />
          </Field>
        </div>
        <Field label={t('ساعت‌های مصرف', 'Dose times')} error={err('times')}>
          <div className="time-list">
            {v.times.map((tm, i) => (
              <div key={i} className="row-flex">
                <input
                  type="time"
                  className="input"
                  value={tm}
                  aria-label={t('ساعت نوبت {n}', 'Time for dose {n}', { n: i + 1 })}
                  onChange={(e) => set({ times: v.times.map((x, j) => (j === i ? e.target.value : x)) })}
                />
                {v.times.length > 1 && (
                  <IconButton label={t('حذف این ساعت', 'Remove this time')} size="sm" onClick={() => set({ times: v.times.filter((_, j) => j !== i) })}>
                    <X size={16} />
                  </IconButton>
                )}
              </div>
            ))}
            {v.times.length < 8 && (
              <Button size="sm" variant="soft" icon={<Plus size={14} />} onClick={() => set({ times: [...v.times, ''] })}>
                {t('ساعت دیگر', 'Add time')}
              </Button>
            )}
          </div>
        </Field>
        <Field label={t('روزهای مصرف', 'Days')}>
          <Segmented
            label={t('روزهای مصرف', 'Days')}
            value={v.freq}
            onChange={(freq) => set({ freq })}
            options={[
              { value: 'daily', label: t('هر روز', 'Every day') },
              { value: 'weekly', label: t('روزهای منتخب', 'Selected days') },
              { value: 'once', label: t('یک‌بار', 'Once') },
            ]}
          />
        </Field>
        {v.freq === 'weekly' && (
          <Field label={t('روزها', 'Days')} error={err('weekdays')}>
            <div className="day-chips">
              {days.map((d) => (
                <button key={d} type="button" className={`day-chip${v.weekdays.includes(d) ? ' is-on' : ''}`} aria-pressed={v.weekdays.includes(d)} onClick={() => set({ weekdays: v.weekdays.includes(d) ? v.weekdays.filter((x) => x !== d) : [...v.weekdays, d] })}>
                  {names[d]}
                </button>
              ))}
            </div>
          </Field>
        )}
        <div className="form-row">
          <Field label={v.freq === 'once' ? t('تاریخ', 'Date') : t('شروع', 'Start')}>
            <DatePicker value={v.startDate} onChange={(d) => d && set({ startDate: d })} label={t('شروع', 'Start')} />
          </Field>
          {v.freq !== 'once' && (
            <Field label={t('پایان (اختیاری)', 'End (optional)')} error={err('endDate')}>
              <DatePicker value={v.endDate} onChange={(d) => set({ endDate: d })} label={t('پایان', 'End')} allowClear placeholder={t('بدون پایان', 'No end')} />
            </Field>
          )}
        </div>
        <Field label={t('نکات شخصی (اختیاری)', 'Personal notes (optional)')} hint={t('فقط آنچه خودتان می‌نویسید؛ مثلاً «طبق دستور نسخه همراه غذا».', 'Only what you write, e.g. “with food, as prescribed”.')}>
          <VoiceInput value={v.notes} onChange={(notes) => set({ notes })} lang={mod.inputLanguage} ownerId={`med-notes-${mod.id}`} inputLabel={t('نکات', 'Notes')} multiline rows={2} maxLength={2000} />
        </Field>
        <Field label={t('منطقه زمانی', 'Time zone')}>
          <select className="input select ltr" value={v.timezone} onChange={(e) => set({ timezone: e.target.value })}>
            {zones.map((z) => (
              <option key={z} value={z}>
                {z}
              </option>
            ))}
          </select>
        </Field>
        <Switch checked={v.reminderEnabled} onChange={(reminderEnabled) => set({ reminderEnabled })} label={t('یادآوری در زمان نوبت', 'Remind me at dose time')} />
        {v.reminderEnabled && (
          <Notice tone="warn" icon={<Info size={16} />}>
            {t(
              'در این نسخه یادآوری فقط وقتی همیار در مرورگر باز است (حتی در تب پس‌زمینه) نمایش داده می‌شود. اعلان وب جای زنگ هشدار گوشی را نمی‌گیرد؛ برای داروهای حیاتی، زنگ گوشی را هم تنظیم کنید.',
              'In this version reminders appear only while Hamyar is open in the browser (a background tab is fine). Web notifications do not replace a phone alarm; for critical doses also set an alarm.',
            )}
          </Notice>
        )}
        <Switch
          checked={v.showNameInNotification}
          onChange={(showNameInNotification) => set({ showNameInNotification })}
          label={t('نمایش نام دارو در اعلان', 'Show the name in notifications')}
          description={t('خاموش: متن اعلان عمومی است («یادآوری دارو»)، تا روی صفحه قفل دیده نشود.', 'Off: the notification says only “Medication reminder”, so it is private on a lock screen.')}
        />
      </div>
    </Modal>
  );
}

function DoseDialog({ item, action, onClose }: { item: DoseItem | null; action: 'taken' | 'skipped' | 'cleared'; onClose: () => void }) {
  const { t, time, date, bidi } = useApp();
  const [takenAt, setTakenAt] = useState('');
  const [busy, setBusy] = useState(false);
  // one idempotency key per opened dialog: a double click cannot record a dose twice
  const idem = useMemo(() => `${item?.key ?? 'none'}|${action}|${uid()}`, [item, action]);
  useEffect(() => {
    const d = new Date();
    setTakenAt(`${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`);
  }, [item]);
  if (!item) return null;
  const confirm = async () => {
    setBusy(true);
    try {
      let actual: string | null = null;
      if (action === 'taken' && takenAt) {
        const [h, m] = takenAt.split(':').map(Number);
        const d = new Date();
        d.setHours(h!, m!, 0, 0);
        actual = d.toISOString();
      }
      await recordDose({ med: item.med, occ: item.occ, action, actualTakenAt: actual, idempotencyKey: idem });
      toast({ kind: 'success', text: action === 'taken' ? t('ثبت شد: مصرف شد.', 'Recorded: taken.') : action === 'skipped' ? t('ثبت شد: رد شد.', 'Recorded: skipped.') : t('ثبت پاک شد؛ سابقه حفظ شد.', 'Cleared; history kept.') });
      onClose();
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };
  const title = action === 'taken' ? t('ثبت «مصرف شد»', 'Record “taken”') : action === 'skipped' ? t('ثبت «رد شد»', 'Record “skipped”') : t('پاک کردن ثبت این نوبت', 'Clear this dose record');
  return (
    <Modal
      open
      onClose={onClose}
      title={title}
      size="sm"
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant={action === 'taken' ? 'accent' : 'outline'} busy={busy} onClick={() => void confirm()}>
            {t('تأیید', 'Confirm')}
          </Button>
        </>
      }
    >
      <div className="stack-sm">
        <div className="dose-detail">
          <div className="dose-name auto-dir" dir={bidi(item.med.name)}>{item.med.name}</div>
          <div className="muted">
            {item.med.dosageText} {item.med.unitText}
          </div>
          <div className="small">
            {t('نوبت', 'Dose')}: {date(item.occ.date, 'long')} · <span className="num">{time(item.occ.time!)}</span>
          </div>
          {item.med.notes && <div className="small muted para-dir pre-wrap">{item.med.notes}</div>}
        </div>
        {action === 'taken' && (
          <Field label={t('ساعت واقعی مصرف', 'Actual time taken')}>
            <input type="time" className="input" value={takenAt} onChange={(e) => setTakenAt(e.target.value)} />
          </Field>
        )}
        {item.event && <p className="subtle xsmall">{t('ثبت قبلی این نوبت در سابقه باقی می‌ماند.', 'The previous record for this dose stays in the history.')}</p>}
      </div>
    </Modal>
  );
}

function DoseRow({ item, onAction, highlight }: { item: DoseItem; onAction: (i: DoseItem, a: 'taken' | 'skipped' | 'cleared') => void; highlight?: boolean }) {
  const { t, time, now, bidi } = useApp();
  const ref = useRef<HTMLLIElement>(null);
  useEffect(() => {
    if (highlight) ref.current?.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }, [highlight]);
  const due = item.occ.at! <= now;
  return (
    <li ref={ref} className={`row dose-row state-${item.state}${highlight ? ' is-highlight' : ''}`}>
      <span className="dose-time num">{time(item.occ.time!)}</span>
      <div className="row-main is-static">
        <span className="row-title auto-dir" dir={bidi(item.med.name)}>{item.med.name}</span>
        <span className="row-meta">
          <span className="auto-dir" dir={bidi(`${item.med.dosageText} ${item.med.unitText}`)}>
            {item.med.dosageText} {item.med.unitText}
          </span>
          {item.state === 'taken' && <Chip tone="ok" icon={<Check size={12} />}>{t('مصرف شد', 'Taken')}</Chip>}
          {item.state === 'skipped' && <Chip tone="warn" icon={<CircleX size={12} />}>{t('رد شد', 'Skipped')}</Chip>}
          {item.state === 'pending' && due && <Chip tone="danger">{t('هنوز ثبت نشده', 'Not recorded')}</Chip>}
        </span>
      </div>
      <div className="row-actions">
        {item.state === 'pending' ? (
          <>
            <Button size="sm" variant="accent" onClick={() => onAction(item, 'taken')} icon={<Check size={14} />}>
              {t('مصرف شد', 'Taken')}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => onAction(item, 'skipped')}>
              {t('رد شد', 'Skip')}
            </Button>
          </>
        ) : (
          <Button size="sm" variant="ghost" onClick={() => onAction(item, item.state === 'taken' ? 'skipped' : 'taken')} icon={<Pencil size={13} />}>
            {t('اصلاح', 'Correct')}
          </Button>
        )}
      </div>
    </li>
  );
}

export default function MedicationsModule({ mod, variant, focus }: ModuleViewProps) {
  const { t, today, date, time, bidi, locale } = useApp();
  const meds = useLiveQuery(() => db.medications.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const events = useLiveQuery(() => db.medEvents.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const [form, setForm] = useState<{ open: boolean; med: Medication | null }>({ open: false, med: null });
  const [dose, setDose] = useState<{ item: DoseItem; action: 'taken' | 'skipped' | 'cleared' } | null>(null);
  const [tab, setTab] = useState<'today' | 'meds' | 'history'>('today');
  const todayDoses = useMemo(() => listDoses(meds ?? [], events ?? [], today, today), [meds, events, today]);
  const focusedOnce = useRef(false);

  useEffect(() => {
    if (!focus || focusedOnce.current || !todayDoses.length) return;
    const target = todayDoses.find((d) => d.key === focus);
    if (target && target.state === 'pending') {
      focusedOnce.current = true;
      setDose({ item: target, action: 'taken' });
    }
  }, [focus, todayDoses]);

  if (!meds || !events) return <div className="mod-loading" />;
  const pending = todayDoses.filter((d) => d.state === 'pending').length;
  const doseList = (list: DoseItem[]) => (
    <ul className="rows">
      {list.map((d) => (
        <DoseRow key={d.key} item={d} onAction={(item, action) => setDose({ item, action })} highlight={focus === d.key} />
      ))}
    </ul>
  );

  const dialogs = (
    <>
      <MedForm mod={mod} med={form.med} open={form.open} onClose={() => setForm({ open: false, med: null })} />
      {dose && <DoseDialog item={dose.item} action={dose.action} onClose={() => setDose(null)} />}
    </>
  );

  if (meds.length === 0) {
    return (
      <div className="stack">
        <EmptyState
          icon={<Pill size={22} />}
          title={t('هنوز دارویی ثبت نشده', 'No medications yet')}
          text={t('برنامه‌ای را که پزشک داده وارد کنید تا نوبت‌ها و ثبت «مصرف شد» را اینجا ببینید.', 'Enter the schedule from your prescription to see doses and record them here.')}
          action={
            <Button variant="accent" icon={<Plus size={16} />} onClick={() => setForm({ open: true, med: null })}>
              {t('افزودن دارو', 'Add medication')}
            </Button>
          }
        />
        {dialogs}
      </div>
    );
  }

  if (variant === 'card') {
    return (
      <div className="stack">
        <SectionTitle
          count={pending}
          action={
            <Button size="sm" variant="soft" icon={<Plus size={14} />} onClick={() => setForm({ open: true, med: null })}>
              {t('دارو', 'Add')}
            </Button>
          }
        >
          {t('نوبت‌های امروز', 'Today’s doses')}
        </SectionTitle>
        {todayDoses.length === 0 ? <p className="subtle small">{t('امروز نوبتی ندارید.', 'No doses today.')}</p> : doseList(todayDoses.slice(0, mod.appearance.density === 'compact' ? 6 : 4))}
        {todayDoses.length > 4 && (
          <a className="more-link" href={`#/m/${mod.id}`}>
            {t('همه نوبت‌ها', 'All doses')}
          </a>
        )}
        <p className="subtle xsmall">{t('فقط برنامه واردشده توسط شما؛ توصیه پزشکی نیست.', 'Only the schedule you entered; not medical advice.')}</p>
        {dialogs}
      </div>
    );
  }

  const history = [...events].sort((a, b) => (a.recordedAt < b.recordedAt ? 1 : -1)).slice(0, 120);
  const superseded = new Set(events.map((e) => e.supersedesId).filter(Boolean));
  const missed = listDoses(meds, events, addDaysISO(today, -7), addDaysISO(today, -1)).filter((d) => d.state === 'pending');

  return (
    <div className="stack">
      <div className="full-toolbar">
        <Tabs
          label={t('نمای داروها', 'Medication views')}
          value={tab}
          onChange={setTab}
          tabs={[
            { value: 'today', label: t('امروز', 'Today'), count: pending },
            { value: 'meds', label: t('داروها', 'Medications'), count: meds.length },
            { value: 'history', label: t('سابقه', 'History') },
          ]}
        />
        <div className="row-flex wrap">
          {!IS_NATIVE && !IS_ARTIFACT && (
            <Button
              variant="soft"
              icon={<CalendarPlus size={16} />}
              onClick={async () => {
                const events = meds.filter((m) => m.active).flatMap((m) => medicationCalendarEvents(m, today, locale === 'fa'));
                const r = await saveCalendar('hamyar-medications.ics', events);
                toast({
                  kind: r === 'saved' ? 'success' : 'warning',
                  text:
                    r === 'empty'
                      ? t('داروی فعالی برای افزودن نیست.', 'There is no active medication to add.')
                      : r === 'saved'
                        ? t('فایل تقویم آماده شد. آن را باز کنید و «افزودن همه» را بزنید؛ تقویم گوشی سر هر نوبت هشدار می‌دهد.', 'Calendar file ready. Open it and choose “Add all”; the phone calendar will alert you at each dose.')
                        : t('فایل تقویم ساخته نشد.', 'The calendar file could not be created.'),
                });
              }}
            >
              {t('افزودن به تقویم گوشی', 'Add to phone calendar')}
            </Button>
          )}
          <Button variant="accent" icon={<Plus size={16} />} onClick={() => setForm({ open: true, med: null })}>
            {t('افزودن دارو', 'Add medication')}
          </Button>
        </div>
      </div>
      {tab === 'today' && (todayDoses.length ? doseList(todayDoses) : <EmptyState icon={<Pill size={22} />} title={t('امروز نوبتی ندارید.', 'No doses today.')} />)}
      {tab === 'today' && missed.length > 0 && (
        <Notice tone="neutral" icon={<Info size={16} />} title={t('نوبت‌های ثبت‌نشده ۷ روز گذشته: {n}', 'Unrecorded doses in the last 7 days: {n}', { n: missed.length })}>
          {t('همیار نوبت جبرانی پیشنهاد نمی‌کند. برای نوبت فراموش‌شده طبق دستور پزشک عمل کنید.', 'Hamyar does not suggest catch-up doses. Follow your prescriber’s instructions for missed doses.')}
        </Notice>
      )}
      {tab === 'meds' && (
        <ul className="rows">
          {meds.map((m) => {
            const r = currentRule(m.revisions)!;
            return (
              <li key={m.id} className={`row${m.active ? '' : ' is-muted'}`}>
                <button type="button" className="row-main" onClick={() => setForm({ open: true, med: m })}>
                  <span className="row-title auto-dir" dir={bidi(m.name)}>{m.name}</span>
                  <span className="row-meta">
                    <span className="auto-dir" dir={bidi(`${m.dosageText} ${m.unitText}`)}>
                      {m.dosageText} {m.unitText}
                    </span>
                    <span className="num">{r.times.map((x) => time(x)).join('، ')}</span>
                    <span>{r.freq === 'daily' ? t('هر روز', 'daily') : r.freq === 'weekly' ? t('روزهای منتخب', 'selected days') : date(r.startDate, 'short')}</span>
                    {!m.reminderEnabled && <span>{t('بدون یادآوری', 'no reminder')}</span>}
                  </span>
                </button>
                <Switch checked={m.active} onChange={(a) => void setMedActive(m.id, a)} label={<span className="visually-hidden">{t('فعال', 'Active')}</span>} />
              </li>
            );
          })}
        </ul>
      )}
      {tab === 'history' &&
        (history.length === 0 ? (
          <EmptyState icon={<Pill size={22} />} title={t('هنوز چیزی ثبت نشده.', 'Nothing recorded yet.')} />
        ) : (
          <ul className="rows">
            {history.map((e) => (
              <li key={e.id} className={`row${superseded.has(e.id) ? ' is-muted' : ''}`}>
                <div className="row-main is-static">
                  <span className="row-title auto-dir" dir={bidi(e.snapshot.name)}>
                    {e.snapshot.name} · {e.snapshot.dosageText} {e.snapshot.unitText}
                  </span>
                  <span className="row-meta">
                    <span>
                      {date(e.snapshot.localDate, 'short')} <span className="num">{time(e.snapshot.localTime)}</span>
                    </span>
                    {e.action === 'taken' && <Chip tone="ok">{t('مصرف شد', 'Taken')}</Chip>}
                    {e.action === 'skipped' && <Chip tone="warn">{t('رد شد', 'Skipped')}</Chip>}
                    {e.action === 'cleared' && <Chip>{t('پاک شد', 'Cleared')}</Chip>}
                    {superseded.has(e.id) && <span>{t('اصلاح شده', 'corrected')}</span>}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        ))}
      {dialogs}
    </div>
  );
}
