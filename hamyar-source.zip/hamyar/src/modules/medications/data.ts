import Dexie from 'dexie';
import { db, nowIso, uid } from '../../data/db';
import { DST_POLICY, DomainError, type MedAction, type MedEvent, type Medication, type ScheduleRule } from '../../domain/types';
import { currentRule, expandByDates, reviseSchedule, validateRule, type Occurrence } from '../../domain/recurrence';

/**
 * Medication schedules hold only what the person entered. Nothing here suggests doses,
 * interactions or catch-up doses. Recording "taken"/"skipped" always targets one dose,
 * keeps a snapshot of that dose, and corrections supersede rather than overwrite.
 */

export interface MedInput {
  name: string;
  dosageText: string;
  unitText: string;
  notes: string;
  times: string[];
  freq: 'once' | 'daily' | 'weekly';
  weekdays: number[];
  startDate: string;
  endDate: string | null;
  timezone: string;
  reminderEnabled: boolean;
  showNameInNotification: boolean;
}

export function medRule(i: MedInput): ScheduleRule {
  return {
    freq: i.freq,
    startDate: i.startDate,
    endDate: i.freq === 'once' ? null : i.endDate,
    weekdays: i.freq === 'weekly' ? [...new Set(i.weekdays)].sort() : [],
    times: [...new Set(i.times.filter(Boolean))].sort(),
    timezone: i.timezone,
  };
}

export function validateMedInput(i: MedInput): Record<string, string> {
  const e: Record<string, string> = {};
  if (!i.name.trim()) e.name = 'required';
  if (!i.dosageText.trim()) e.dosageText = 'required';
  if (!i.times.filter(Boolean).length) e.times = 'required';
  if (i.freq === 'weekly' && !i.weekdays.length) e.weekdays = 'required';
  if (i.endDate && i.endDate < i.startDate) e.endDate = 'before_start';
  if (!Object.keys(e).length && validateRule(medRule(i)).length) e.times = 'invalid';
  return e;
}

export function inputFromMed(m: Medication): MedInput {
  const r = currentRule(m.revisions)!;
  return {
    name: m.name,
    dosageText: m.dosageText,
    unitText: m.unitText,
    notes: m.notes,
    times: r.times,
    freq: r.freq,
    weekdays: r.weekdays,
    startDate: r.startDate,
    endDate: r.endDate,
    timezone: r.timezone,
    reminderEnabled: m.reminderEnabled,
    showNameInNotification: m.showNameInNotification,
  };
}

export async function createMed(moduleId: string, i: MedInput, idem: string): Promise<Medication> {
  const errors = validateMedInput(i);
  if (Object.keys(errors).length) throw new DomainError('INVALID_INPUT', undefined, errors);
  return db.transaction('rw', db.medications, db.kv, async () => {
    const seen = await db.kv.get(`idem:med:${idem}`);
    if (seen) {
      const existing = await db.medications.get(String(seen.value));
      if (existing) return existing;
    }
    const ts = nowIso();
    const med: Medication = {
      id: uid(),
      moduleId,
      name: i.name.trim().slice(0, 120),
      dosageText: i.dosageText.trim().slice(0, 200),
      unitText: i.unitText.trim().slice(0, 60),
      notes: i.notes.trim().slice(0, 2000),
      revisions: [{ validFrom: 0, rule: medRule(i) }],
      active: true,
      reminderEnabled: i.reminderEnabled,
      showNameInNotification: i.showNameInNotification,
      dstPolicy: DST_POLICY,
      revision: 1,
      createdAt: ts,
      updatedAt: ts,
    };
    await db.medications.add(med);
    await db.kv.put({ key: `idem:med:${idem}`, value: med.id });
    return med;
  });
}

/** Changes apply to future doses only; recorded doses keep their own snapshot. */
export async function updateMed(id: string, i: MedInput, now = Date.now()): Promise<void> {
  const errors = validateMedInput(i);
  if (Object.keys(errors).length) throw new DomainError('INVALID_INPUT', undefined, errors);
  await db.transaction('rw', db.medications, async () => {
    const m = await db.medications.get(id);
    if (!m) throw new DomainError('NOT_FOUND');
    await db.medications.put({
      ...m,
      name: i.name.trim().slice(0, 120),
      dosageText: i.dosageText.trim().slice(0, 200),
      unitText: i.unitText.trim().slice(0, 60),
      notes: i.notes.trim().slice(0, 2000),
      revisions: reviseSchedule(m.revisions, medRule(i), now, { keepHistory: true }),
      reminderEnabled: i.reminderEnabled,
      showNameInNotification: i.showNameInNotification,
      revision: m.revision + 1,
      updatedAt: nowIso(),
    });
  });
}

export async function setMedActive(id: string, active: boolean): Promise<void> {
  await db.medications.update(id, { active, updatedAt: nowIso() });
}

/** Explicit delete removes the schedule and its history. */
export async function deleteMed(id: string): Promise<void> {
  await db.transaction('rw', db.medications, db.medEvents, db.reminders, async () => {
    await db.medEvents.where('medId').equals(id).delete();
    await db.reminders.where('sourceId').equals(id).delete();
    await db.medications.delete(id);
  });
}

export function occurrenceKey(medId: string, occ: Pick<Occurrence, 'date' | 'time'>): string {
  return `${medId}|${occ.date}|${occ.time ?? ''}`;
}

/** The latest event for each dose (events that nothing supersedes). */
export function currentEvents(events: MedEvent[]): Map<string, MedEvent> {
  const superseded = new Set(events.map((e) => e.supersedesId).filter(Boolean) as string[]);
  const map = new Map<string, MedEvent>();
  for (const e of events) {
    if (superseded.has(e.id)) continue;
    const prev = map.get(e.occurrenceKey);
    if (!prev || prev.recordedAt < e.recordedAt) map.set(e.occurrenceKey, e);
  }
  return map;
}

export interface RecordDoseInput {
  med: Medication;
  occ: Occurrence;
  action: MedAction;
  actualTakenAt: string | null;
  idempotencyKey: string;
}

/**
 * Records taken/skipped (or clears) for one dose. The same idempotency key never creates
 * a second record; a different decision supersedes the previous one and keeps it in history.
 */
export async function recordDose(input: RecordDoseInput): Promise<MedEvent> {
  const { med, occ } = input;
  if (occ.at === null || occ.time === null) throw new DomainError('INVALID_INPUT');
  const key = occurrenceKey(med.id, occ);
  try {
    return await db.transaction('rw', db.medEvents, async () => {
      const dup = await db.medEvents.where('idempotencyKey').equals(input.idempotencyKey).first();
      if (dup) return dup;
      const existing = await db.medEvents.where('occurrenceKey').equals(key).toArray();
      const current = currentEvents(existing).get(key) ?? null;
      const ev: MedEvent = {
        id: uid(),
        medId: med.id,
        moduleId: med.moduleId,
        occurrenceKey: key,
        scheduledAt: occ.at!,
        action: input.action,
        actualTakenAt: input.action === 'taken' ? input.actualTakenAt ?? nowIso() : null,
        recordedAt: nowIso(),
        snapshot: { name: med.name, dosageText: med.dosageText, unitText: med.unitText, localDate: occ.date, localTime: occ.time!, timezone: occ.timezone },
        supersedesId: current?.id ?? null,
        idempotencyKey: input.idempotencyKey,
      };
      await db.medEvents.add(ev);
      return ev;
    });
  } catch (e) {
    if (e instanceof Dexie.ConstraintError || (e as { name?: string })?.name === 'ConstraintError') {
      const dup = await db.medEvents.where('idempotencyKey').equals(input.idempotencyKey).first();
      if (dup) return dup;
    }
    throw e;
  }
}

export type DoseState = 'pending' | 'taken' | 'skipped';

export interface DoseItem {
  med: Medication;
  occ: Occurrence;
  key: string;
  state: DoseState;
  event: MedEvent | null;
}

export function listDoses(meds: Medication[], events: MedEvent[], fromDate: string, toDate: string): DoseItem[] {
  const cur = currentEvents(events);
  const out: DoseItem[] = [];
  for (const med of meds) {
    if (!med.active) continue;
    for (const occ of expandByDates(med.revisions, fromDate, toDate)) {
      if (occ.at === null) continue;
      const key = occurrenceKey(med.id, occ);
      const ev = cur.get(key) ?? null;
      const state: DoseState = !ev || ev.action === 'cleared' ? 'pending' : ev.action;
      out.push({ med, occ, key, state, event: ev && ev.action !== 'cleared' ? ev : null });
    }
  }
  return out.sort((a, b) => a.occ.at! - b.occ.at! || a.med.name.localeCompare(b.med.name));
}
