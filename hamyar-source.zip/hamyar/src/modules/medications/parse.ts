import { Scanner, WB_END as E, WB_START as S, normalizeKeepLength, stripFillers } from '../../domain/commands/scanner';
import { applyPeriod, extractDateTime } from '../../domain/commands/datetime';
import { NUMBER_RE, readNumber } from '../../domain/commands/numbers';
import { addDaysISO, pad2, todayISO } from '../../domain/time';
import { toPersianDigits } from '../../domain/normalize';
import { addMonthsInCalendar } from '../../domain/jalali';

/**
 * Reads one spoken or typed sentence about a medication — «استامینوفن ۵۰۰ میلی‌گرم، روزی سه
 * بار بعد از غذا، به مدت ۵ روز» — into the fields of the medication form. It only copies what
 * was said: it never suggests a dose, and times it had to place (for «روزی سه بار») are marked
 * so the form asks the person to set them as prescribed. Nothing is saved from here.
 */

export interface MedFill {
  name: string;
  dosageText: string;
  unitText: string;
  notes: string;
  times: string[];
  /** the times were placed by the app (only a count or an interval was said) */
  timesAssumed: boolean;
  /** hours said without morning/evening: each needs a choice */
  ambiguous: { said: string; options: string[] }[];
  freq: 'once' | 'daily' | 'weekly' | null;
  weekdays: number[];
  startDate: string | null;
  endDate: string | null;
  /** «یک روز در میان»: the form cannot repeat every other day, so the person must decide */
  everyOtherDay: boolean;
  /** «در صورت نیاز»: taken only when needed, so no reminders by default */
  asNeeded: boolean;
}

export interface MedParseContext {
  now: number;
  timezone: string;
  calendar: 'jalali' | 'gregorian';
}

const COUNT_UNITS: [string, string][] = [
  ['قاشق\\s*(?:چای\\s*خوری|چایخوری|غذا\\s*خوری|غذاخوری|مربا\\s*خوری|مرباخوری)', ''],
  ['قاشق', 'قاشق'],
  ['عدد', 'عدد'],
  ['قرص', 'قرص'],
  ['کپسول', 'کپسول'],
  ['قطره', 'قطره'],
  ['پاف', 'پاف'],
  ['سی\\s*سی', 'سی‌سی'],
  ['cc', 'cc'],
  ['میلی\\s*لیتر', 'میلی‌لیتر'],
  ['ml', 'ml'],
  ['واحد', 'واحد'],
  ['ساشه', 'ساشه'],
  ['شیاف', 'شیاف'],
  ['امپول', 'آمپول'],
  ['ویال', 'ویال'],
  ['برچسب', 'برچسب'],
  ['اسپری', 'اسپری'],
  ['puffs?', 'puff'],
  ['tablets?', 'tablet'],
  ['tabs?', 'tablet'],
  ['capsules?', 'capsule'],
  ['caps', 'capsule'],
  ['drops?', 'drop'],
  ['units?', 'unit'],
  ['teaspoons?', 'teaspoon'],
];
const STRENGTH_UNITS: [string, string][] = [
  ['میلی\\s*گرم', 'میلی‌گرم'],
  ['میلیگرم', 'میلی‌گرم'],
  ['میکرو\\s*گرم', 'میکروگرم'],
  ['گرم', 'گرم'],
  ['mg', 'mg'],
  ['mcg', 'mcg'],
  ['µg', 'µg'],
  ['g', 'g'],
  ['iu', 'IU'],
];

const HALF = '(?:نصف|نیم|یک\\s*و\\s*نیم|یه\\s*و\\s*نیم|half|one\\s*and\\s*a\\s*half)';
const DOSE_NUMBER = `(?:${HALF}|${NUMBER_RE}|\\d+\\s*/\\s*\\d+)`;

const NOTE_PHRASES: string[] = [
  'بعد\\s*از\\s*(?:غذا|صبحانه|ناهار|نهار|شام)',
  'قبل\\s*از\\s*(?:غذا|صبحانه|ناهار|نهار|شام)',
  'همراه\\s*(?:با\\s*)?غذا',
  'با\\s*غذا',
  'ناشتا',
  'با\\s*معده\\s*(?:ی\\s*)?خالی',
  'با\\s*(?:یک\\s*لیوان\\s*)?اب(?:\\s*فراوان)?',
  'زیر\\s*زبان(?:ی)?',
  'جویدنی',
  'در\\s*صورت\\s*(?:نیاز|درد|تب)',
  'هنگام\\s*(?:نیاز|درد)',
  'before\\s*(?:meals?|food|breakfast|bed)',
  'after\\s*(?:meals?|food|breakfast|dinner)',
  'with\\s*(?:food|meals?|water)',
  'on\\s*an\\s*empty\\s*stomach',
  'as\\s*needed',
];

const FA_WEEKDAY: [string, number][] = [
  ['یک\\s*شنبه', 0],
  ['دو\\s*شنبه', 1],
  ['سه\\s*شنبه', 2],
  ['چهار\\s*شنبه', 3],
  ['پنج\\s*شنبه', 4],
  ['جمعه', 5],
  ['شنبه', 6],
];
const EN_WEEKDAY = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

const hhmm = (h: number, m: number) => `${pad2(h)}:${pad2(m)}`;

/** Times spread over the waking day for «N times a day» (placed by the app, to be checked). */
export function spreadTimes(n: number): string[] {
  const table: Record<number, string[]> = { 1: ['08:00'], 2: ['08:00', '20:00'], 3: ['08:00', '14:00', '20:00'], 4: ['08:00', '12:00', '16:00', '20:00'] };
  if (table[n]) return table[n]!;
  const count = Math.min(8, Math.max(1, Math.round(n)));
  const out: string[] = [];
  for (let i = 0; i < count; i++) out.push(hhmm(Math.round(8 + (14 * i) / (count - 1)), 0));
  return [...new Set(out)];
}

/** Puts what was said into a medication form, leaving the fields that were not mentioned alone. */
export function applyFill<T extends { name: string; dosageText: string; unitText: string; notes: string; times: string[]; freq: 'once' | 'daily' | 'weekly'; weekdays: number[]; startDate: string; endDate: string | null; reminderEnabled: boolean }>(base: T, f: MedFill): T {
  const out = { ...base };
  if (f.name) out.name = f.name;
  if (f.dosageText) out.dosageText = f.dosageText;
  if (f.unitText) out.unitText = f.unitText;
  if (f.notes) out.notes = base.notes && !base.notes.includes(f.notes) ? `${base.notes}، ${f.notes}` : f.notes;
  if (f.times.length) out.times = [...f.times];
  if (f.freq) out.freq = f.freq;
  if (f.freq === 'weekly') out.weekdays = [...f.weekdays];
  if (f.startDate) out.startDate = f.startDate;
  if (f.endDate) out.endDate = f.endDate;
  if (f.asNeeded) out.reminderEnabled = false;
  return out;
}

/** Times every `h` hours, starting at `start` (08:00 when none was said). */
export function intervalTimes(h: number, start = 8): string[] {
  if (!(h >= 1 && h <= 24)) return [];
  const out: string[] = [];
  for (let t = 0; t < 24; t += h) out.push(hhmm((start + t) % 24, 0));
  return [...new Set(out)].sort();
}

function readHalf(s: string): number | null {
  const n = normalizeKeepLength(s).trim();
  if (/^(?:نصف|نیم|half)$/.test(n)) return 0.5;
  if (/^(?:یک|یه)\s*و\s*نیم$|^one\s*and\s*a\s*half$/.test(n)) return 1.5;
  const frac = n.match(/^(\d+)\s*\/\s*(\d+)$/);
  if (frac) return Number(frac[1]) / Number(frac[2]);
  return readNumber(n);
}

/** The amount as the person said it: digits as written, «نصف» as a word, «دو» as «۲». */
function doseText(said: string): string {
  const t = said.trim();
  const n = readHalf(t);
  if (n === null || /[\d۰-۹٠-٩]/.test(t)) return t.replace(/\s+/g, '');
  if (n === 0.5 || n === 1.5) return t;
  return /[\u0600-\u06ff]/.test(t) ? toPersianDigits(String(n)) : String(n);
}

export function parseMedicationCommand(raw: string, ctx: MedParseContext): MedFill {
  const today = todayISO(ctx.timezone, ctx.now);
  const sc = new Scanner(raw);
  const fill: MedFill = {
    name: '',
    dosageText: '',
    unitText: '',
    notes: '',
    times: [],
    timesAssumed: false,
    ambiguous: [],
    freq: null,
    weekdays: [],
    startDate: null,
    endDate: null,
    everyOtherDay: false,
    asNeeded: false,
  };
  const notes: string[] = [];
  const times = new Set<string>();
  let fasting = false;
  let fastingTime = false;

  // «یک روز در میان» first, so its «یک روز» is not read as a length of one day
  if (sc.take(new RegExp(`${S}(?:یک|یه)\\s*روز\\s*(?:در\\s*میان|درمیان)${E}|${S}every\\s*other\\s*day${E}`))) {
    fill.everyOtherDay = true;
    notes.push('یک روز در میان');
  }

  // ── how long: «به مدت ۵ روز», «برای دو هفته», «۱۰ روزه», «تا ۲۰ آبان»
  let span: { n: number; unit: 'day' | 'week' | 'month' } | null = null;
  let m = sc.take(new RegExp(`${S}(?:به\\s*مدت|برای|تا|for)?\\s*(${NUMBER_RE})\\s*(روز|هفته|ماه|days?|weeks?|months?)(?:ه)?${E}(?!\\s*(?:دیگه|دیگر|بعد))`));
  if (m) {
    const n = readNumber(m[1]!);
    const u = m[2]!;
    if (n !== null && n > 0) span = { n, unit: /^(?:روز|day)/.test(u) ? 'day' : /^(?:هفته|week)/.test(u) ? 'week' : 'month' };
  }
  let endFromDate: string | null = null;
  const until = sc.take(new RegExp(`${S}(?:تا|until|till)\\s+(?=\\d|(?:${FA_WEEKDAY.map((w) => w[0]).join('|')}))`));
  if (until) {
    const tail = new Scanner(raw.slice(until.index + until[0].length));
    const d = extractDateTime(tail, { now: ctx.now, timezone: ctx.timezone });
    if (d.date && !d.dateAssumed && !d.time) {
      endFromDate = d.date;
      // consume the same words in the main text
      const said = raw.slice(until.index + until[0].length).trim();
      const consumed = said.slice(0, said.length - tail.rest().length).trim();
      if (consumed) sc.take(new RegExp(normalizeKeepLength(consumed).trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s*')));
    }
  }

  // ── notes about how to take it
  for (const p of NOTE_PHRASES) {
    const hit = sc.take(new RegExp(`${S}(?:${p})${E}`));
    if (hit) {
      const said = raw.slice(hit.index, hit.index + hit[0].length).trim();
      notes.push(said);
      if (/صورت|هنگام|as\s*needed/.test(hit[0])) fill.asNeeded = true;
      if (/ناشتا|empty/.test(hit[0])) {
        times.add('07:00');
        fasting = true;
        fastingTime = true;
      }
    }
  }

  // ── how often
  let assumed = false;
  m = sc.take(new RegExp(`${S}هر\\s*(${NUMBER_RE})\\s*ساعت(?:\\s*(?:یک\\s*بار|یکبار|یکی|یک\\s*عدد))?${E}|${S}every\\s*(\\d+)\\s*h(?:ours?|rs?)?${E}`));
  let intervalH: number | null = null;
  if (m) intervalH = readNumber(m[1] ?? m[2] ?? '');
  m = sc.take(new RegExp(`${S}(?:روزی|روزانه|در\\s*روز)\\s*(${NUMBER_RE})\\s*(?:بار|نوبت|دفعه|مرتبه)${E}|${S}(${NUMBER_RE})\\s*(?:بار|نوبت|دفعه|مرتبه)\\s*(?:در\\s*روز|روزانه)${E}|${S}(once|twice|thrice|\\d+\\s*times)\\s*(?:a|per)\\s*day${E}`));
  let perDay: number | null = null;
  if (m) {
    const word = m[3];
    perDay = word ? (word === 'once' ? 1 : word === 'twice' ? 2 : word === 'thrice' ? 3 : Number(word.replace(/\D/g, ''))) : readNumber(m[1] ?? m[2] ?? '');
  }
  if (sc.take(new RegExp(`${S}(?:هفته\\s*ای|هر\\s*هفته)\\s*(?:یک|یه)\\s*(?:بار|نوبت|عدد)${E}|${S}once\\s*a\\s*week${E}`))) {
    fill.freq = 'weekly';
    fill.weekdays = [new Date(`${today}T12:00:00Z`).getUTCDay()];
    assumed = true;
  }

  // ── named days: «شنبه‌ها و چهارشنبه‌ها», «روزهای دوشنبه», «on mondays»
  const days = new Set<number>();
  for (const [w, d] of FA_WEEKDAY) {
    if (sc.take(new RegExp(`${S}(?:روزهای\\s*|روز\\s*های\\s*|هر\\s*)?${w}\\s*(?:ها)?${E}`))) days.add(d);
  }
  for (let d = 0; d < 7; d++) if (sc.take(new RegExp(`\\b(?:on\\s*|every\\s*)?${EN_WEEKDAY[d]}s?\\b`))) days.add(d);
  if (days.size) {
    fill.freq = 'weekly';
    fill.weekdays = [...days].sort();
  }

  // ── clock times: «ساعت ۸ صبح و ۸ شب», «ساعت ۸ و ۱۴ و ۲۰», «۹ شب», «8:30»
  const period = (w: string | undefined) => {
    if (!w) return null;
    const x = w.replace(/\s+/g, '');
    if (x === 'صبح' || x === 'قبلازظهر' || x === 'am' || x === 'a.m.' || x === 'morning') return 'am' as const;
    if (x === 'ظهر' || x === 'noon') return 'noon' as const;
    if (x === 'شب' || x === 'night') return 'night' as const;
    if (x === 'بامداد' || x === 'سحر') return 'early' as const;
    return 'pm' as const;
  };
  const PERIOD = '(صبح|قبل\\s*از\\s*ظهر|بعد\\s*از\\s*ظهر|بعدازظهر|ظهر|عصر|شب|بامداد|سحر|a\\.?m\\.?|p\\.?m\\.?|in\\s*the\\s*(?:morning|evening|afternoon)|at\\s*night)';
  const ONE = `(\\d{1,2}|یک|یه|دو|سه|چهار|پنج|شش|شیش|هفت|هشت|نه|ده|یازده|دوازده)(?:\\s*[:.]\\s*(\\d{2}))?(?:\\s*و\\s*(نیم|ربع))?`;
  const addTime = (hText: string, mText: string | undefined, half: string | undefined, per: string | undefined, said: string, clock24 = false) => {
    const h = readNumber(hText);
    if (h === null) return;
    const min = mText ? Number(mText) : half === 'نیم' ? 30 : half === 'ربع' ? 15 : 0;
    const p = per ? period(per.replace(/^in\s*the\s*|^at\s*/, '')) : clock24 && h < 12 ? 'am' : null;
    const r = applyPeriod(h, min, p, /[a-z]/.test(per ?? '') ? 'en' : 'fa');
    if (r.time) times.add(r.time);
    else if (r.ambiguity) {
      times.add(r.ambiguity.options[0]!);
      fill.ambiguous.push({ said: said.trim(), options: r.ambiguity.options });
    }
  };
  // «ساعت X ... و Y ... و Z»: a list after one «ساعت»
  let list: RegExpExecArray | null;
  const parts: RegExpExecArray[] = [];
  while ((list = sc.take(new RegExp(`${S}(?:ساعت|at)\\s*${ONE}(?:\\s*${PERIOD})?((?:\\s*(?:و|،|,|and)\\s*(?:ساعت\\s*)?${ONE.replace(/\((?!\?)/g, '(?:')}(?:\\s*${PERIOD.replace(/\((?!\?)/g, '(?:')})?)*)${E}`)))) {
    const whole = raw.slice(list.index, list.index + list[0].length);
    for (const part of normalizeKeepLength(whole)
      .replace(/^\s*(?:ساعت|at)\s*/, '')
      .split(/\s*(?:،|,|\band\b|(?<![\p{L}])و(?![\p{L}]))\s*/u)
      .map((p) => p.replace(/^ساعت\s*/, '').trim())
      .filter(Boolean)) {
      const one = new RegExp(`^${ONE}(?:\\s*${PERIOD})?$`, 'u').exec(part);
      if (one) parts.push(one);
    }
    // a list that uses 13–23 is on the 24-hour clock, so its small hours are mornings
    const clock24 = parts.some((p) => (readNumber(p[1]!) ?? 0) >= 13);
    for (const one of parts.splice(0)) addTime(one[1]!, one[2], one[3], one[4], one[0], clock24);
  }
  // bare «۹ شب», «8 am», «8:30»
  while ((m = sc.take(new RegExp(`${S}${ONE}\\s*${PERIOD}${E}`)))) addTime(m[1]!, m[2], m[3], m[4], m[0]);
  while ((m = sc.take(/(?<![\d/.:])(\d{1,2}):(\d{2})(?![\d:])/))) addTime(m[1]!, m[2], undefined, undefined, m[0]);

  // ── parts of the day without a clock time: «صبح و شب», «قبل از خواب»
  const dayParts: [string, string][] = [
    ['قبل\\s*از\\s*خواب|موقع\\s*خواب|before\\s*bed(?:time)?|at\\s*bedtime', '22:00'],
    ['صبح\\s*ها|صبح|morning', '08:00'],
    ['ظهر\\s*ها|ظهر|noon|midday', '13:00'],
    ['عصر\\s*ها|عصر|afternoon', '17:00'],
    ['شب\\s*ها|شب|evening|night', '20:00'],
  ];
  for (const [re, at] of dayParts) {
    const hit = sc.take(new RegExp(`${S}(?:${re})${E}`));
    if (hit) {
      if (fasting && at === '08:00') continue;
      times.add(at);
      assumed = true;
      if (at === '22:00') notes.push(raw.slice(hit.index, hit.index + hit[0].length).trim());
    }
  }

  if (!times.size && intervalH) {
    intervalTimes(intervalH).forEach((x) => times.add(x));
    assumed = true;
  } else if (!times.size && perDay) {
    spreadTimes(perDay).forEach((x) => times.add(x));
    assumed = true;
  } else if (times.size && perDay && times.size < perDay) assumed = true;

  // ── the amount: «یک قرص», «۲ عدد», «نصف قرص», «۵ سی‌سی» and the strength «۵۰۰ میلی‌گرم»
  let count: { text: string; unit: string } | null = null;
  for (const [re, label] of COUNT_UNITS) {
    const hit = sc.take(new RegExp(`${S}(?:روزی|هر\\s*بار|هر\\s*نوبت|هر\\s*دفعه)?\\s*(${DOSE_NUMBER})\\s*(?:تا\\s*)?(${re})${E}`));
    if (hit) {
      const said = raw.slice(hit.index, hit.index + hit[0].length);
      const unitSaid = said.slice(said.length - hit[2]!.length).trim();
      const numAt = hit.index + hit[0].indexOf(hit[1]!);
      count = { text: doseText(raw.slice(numAt, numAt + hit[1]!.length)), unit: label || unitSaid };
      if (/^\s*روزی/.test(hit[0]) && !perDay && !times.size && !intervalH) {
        times.add('08:00');
        assumed = true;
      }
      break;
    }
  }
  let strength: { text: string; unit: string; said: string } | null = null;
  for (const [re, label] of STRENGTH_UNITS) {
    const hit = sc.take(new RegExp(`${S}(${NUMBER_RE})\\s*(${re})${E}`));
    if (hit) {
      const numAt = hit.index + hit[0].indexOf(hit[1]!);
      strength = { text: raw.slice(numAt, numAt + hit[1]!.length).replace(/\s+/g, ' ').trim(), unit: label, said: raw.slice(hit.index, hit.index + hit[0].length).trim() };
      break;
    }
  }

  // ── when it starts: «از فردا», «از شنبه»
  const start = sc.take(new RegExp(`${S}(?:از|starting|from)\\s+(?=\\S)`));
  if (start) {
    const d = extractDateTime(sc, { now: ctx.now, timezone: ctx.timezone });
    if (d.date && !d.dateAssumed) fill.startDate = d.date;
  } else {
    const d = extractDateTime(sc, { now: ctx.now, timezone: ctx.timezone });
    if (d.date && !d.dateAssumed && !d.time) fill.startDate = d.date;
  }
  const startDate = fill.startDate ?? today;
  if (endFromDate) fill.endDate = endFromDate;
  else if (span) {
    fill.endDate =
      span.unit === 'month' ? addDaysISO(addMonthsInCalendar(startDate, Math.round(span.n), ctx.calendar), -1) : addDaysISO(startDate, Math.round(span.n * (span.unit === 'week' ? 7 : 1)) - 1);
  }

  // ── what is left is the name
  let name = stripFillers(
    sc.rest(),
    ['داروی?\\s*جدید', 'دارو(?:ی)?', 'اضافه\\s*کن', 'ثبت\\s*کن', 'بنویس', 'یادم\\s*بنداز', 'لطفا', 'نام', 'اسم', 'add', 'new', 'medication', 'medicine', 'please', 'take'],
    ['رو\\s*اضافه\\s*کن', 'اضافه\\s*کن', 'ثبت\\s*کن', 'بخورم', 'بخورد', 'مصرف\\s*کنم', 'مصرف\\s*شود', 'میخورم', 'می\\s*خورم', 'هر\\s*بار', 'هر', 'روزی', 'روزانه', 'و', 'با', 'را', 'رو', 'به', 'در'],
  )
    .replace(/[،,]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (count && strength) name = `${name} ${strength.said}`.trim();
  fill.name = name.slice(0, 120);
  if (count) {
    fill.dosageText = count.text;
    fill.unitText = count.unit;
  } else if (strength) {
    fill.dosageText = strength.text;
    fill.unitText = strength.unit;
  }

  if (fastingTime && times.size === 1) assumed = true;
  if (!times.size && !fill.asNeeded && (fill.freq || perDay || intervalH || span)) {
    times.add('08:00');
    assumed = true;
  }
  fill.times = [...times].sort().slice(0, 8);
  fill.timesAssumed = assumed;
  if (!fill.freq) fill.freq = span || endFromDate || fill.times.length || perDay || intervalH ? 'daily' : null;
  fill.notes = [...new Set(notes)].join('، ');
  return fill;
}
