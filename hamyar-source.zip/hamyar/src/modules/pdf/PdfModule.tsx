import { useEffect, useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { PdfDocument } from '../../domain/types';
import { Button, Chip, EmptyState, IconButton, Input, Progress, Notice } from '../../ui/primitives';
import { FileDrop } from '../../ui/FileDrop';
import { VoiceInput } from '../../ui/VoiceInput';
import { ArrowLeft, ArrowRight, FileText, Lock, RefreshCw, Search, TrashIcon, TriangleAlert, Info } from '../../ui/icons';
import { deleteDocument, extractionProgress, importPdf, runExtraction } from './data';
import { PdfViewer } from './PdfViewer';
import { SummaryPanel } from './SummaryPanel';
import { useStore } from '../../lib/store';
import { errorText } from '../../i18n/errors';
import { askConfirm, toast } from '../../lib/ui-store';
import { LIMITS } from '../../config/limits';
import { matchesQuery, normalizeForMatch } from '../../domain/normalize';
import { parseCommand } from '../../domain/commands/parse';
import { useGenericCommand, useVoiceMode, examplesFor } from '../shared';
import { moduleHref, navigate } from '../../shell/router';

function DocStatus({ doc }: { doc: PdfDocument }) {
  const { t } = useApp();
  const prog = useStore(extractionProgress)[doc.id];
  if (doc.extraction === 'running' || doc.extraction === 'pending')
    return prog ? (
      <span className="doc-progress">
        <Progress value={prog.done} max={prog.total} label={t('استخراج متن', 'Extracting text')} />
        <span className="subtle xsmall">{t('استخراج متن {a}/{b}', 'Extracting {a}/{b}', { a: prog.done, b: prog.total })}</span>
      </span>
    ) : (
      <Chip tone="info">{t('در صف استخراج', 'Queued')}</Chip>
    );
  if (doc.extraction === 'encrypted') return <Chip tone="warn" icon={<Lock size={11} />}>{t('رمزدار', 'Protected')}</Chip>;
  if (doc.extraction === 'failed') return <Chip tone="danger">{t('خطا در خواندن', 'Read error')}</Chip>;
  if (doc.textPageCount === 0) return <Chip tone="warn">{t('اسکن‌شده — بدون متن', 'Scanned — no text')}</Chip>;
  return (
    <span className="subtle xsmall">
      {t('{n} صفحه', '{n} pages', { n: doc.pageCount })}
      {doc.textPageCount < doc.pageCount ? ` · ${t('متن در {a} صفحه', 'text on {a}', { a: doc.textPageCount })}` : ''}
    </span>
  );
}

function SearchPanel({ doc, onGoto }: { doc: PdfDocument; onGoto: (n: number) => void }) {
  const { t, bidi } = useApp();
  const [q, setQ] = useState('');
  const pages = useLiveQuery(() => db.pages.where('docId').equals(doc.id).toArray(), [doc.id]);
  const results = useMemo(() => {
    const query = normalizeForMatch(q);
    if (query.length < 2 || !pages) return [];
    return pages
      .filter((p) => matchesQuery(p.text, q))
      .sort((a, b) => a.pageNumber - b.pageNumber)
      .slice(0, 40)
      .map((p) => {
        const norm = normalizeForMatch(p.text);
        const i = norm.indexOf(query);
        const start = Math.max(0, i - 40);
        return { n: p.pageNumber, snippet: `${start > 0 ? '…' : ''}${norm.slice(start, i + query.length + 60)}…` };
      });
  }, [q, pages]);
  return (
    <div className="stack-sm">
      <div className="search-box">
        <Search size={16} aria-hidden="true" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('جست‌وجو در متن سند', 'Search the document text')} aria-label={t('جست‌وجو در متن', 'Search text')} />
      </div>
      {q.length >= 2 && (
        <ul className="search-results">
          {results.length === 0 && <li className="subtle small">{t('پیدا نشد.', 'Not found.')}</li>}
          {results.map((r) => (
            <li key={r.n}>
              <button type="button" onClick={() => onGoto(r.n)}>
                <span className="page-chip">{t('ص {n}', 'p. {n}', { n: r.n })}</span>
                <span className="auto-dir small" dir={bidi(r.snippet)}>{r.snippet}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default function PdfModule({ mod, variant, focus }: ModuleViewProps) {
  const { t, bytes, tz, locale, date, bidi } = useApp();
  const docs = useLiveQuery(() => db.documents.where('moduleId').equals(mod.id).reverse().sortBy('createdAt'), [mod.id]);
  const [openId, setOpenId] = useState<string | null>(focus ?? null);
  const [page, setPage] = useState(1);
  const [busy, setBusy] = useState(false);
  const [voice, setVoice] = useState('');
  const [summaryKey, setSummaryKey] = useState(0);
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);
  const open = docs?.find((d) => d.id === openId) ?? null;

  useEffect(() => {
    if (focus) setOpenId(focus);
  }, [focus]);
  useEffect(() => {
    if (open) setPage(open.lastPage || 1);
  }, [open?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const upload = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setBusy(true);
    try {
      const doc = await importPdf(mod, f);
      toast({ kind: 'success', text: t('PDF ذخیره شد؛ استخراج متن در حال انجام است.', 'PDF saved; extracting text.') });
      if (variant === 'full') setOpenId(doc.id);
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  const remove = async (d: PdfDocument) => {
    const ok = await askConfirm({ title: t('حذف «{n}»؟', 'Delete “{n}”?', { n: d.name }), body: t('فایل، متن استخراج‌شده و خلاصه‌های آن حذف می‌شود.', 'The file, its extracted text and summaries are deleted.'), confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (!ok) return;
    if (openId === d.id) setOpenId(null);
    await deleteDocument(d.id);
  };

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'pdf', now: Date.now(), timezone: tz });
    if (d.kind === 'pdf_goto') {
      if (!open) return toast({ kind: 'warning', text: t('اول یک سند را باز کنید.', 'Open a document first.') });
      if (d.page < 1 || d.page > open.pageCount) return toast({ kind: 'warning', text: t('این سند {n} صفحه دارد.', 'This document has {n} pages.', { n: open.pageCount }) });
      setPage(d.page);
      return;
    }
    if (d.kind === 'pdf_summarize') {
      if (!open) return toast({ kind: 'warning', text: t('اول یک سند را باز کنید.', 'Open a document first.') });
      setSummaryKey((k) => k + 1);
      document.getElementById(`summary-${open.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      toast({ kind: 'info', text: t('برای خلاصه‌سازی، دکمه «خلاصه کن» را بزنید و ارسال را تأیید کنید.', 'Press “Summarise” and confirm sending to start.') });
      return;
    }
    await generic(d);
  };

  if (!docs) return <div className="mod-loading" />;

  const upload_ = (
    <FileDrop
      accept="application/pdf,.pdf"
      onFiles={(f) => void upload(f)}
      disabled={busy}
      title={busy ? t('در حال ذخیره…', 'Saving…') : t('انتخاب یا رها کردن PDF', 'Choose or drop a PDF')}
      hint={t('تا {max}؛ خلاصه برای اسناد تا {p} صفحه', 'Up to {max}; summaries for up to {p} pages', { max: bytes(LIMITS.pdfBytes), p: LIMITS.pdfSummaryMaxPages })}
    />
  );

  const renderList = (items: PdfDocument[]) => (
    <ul className="rows">
      {items.map((d) => (
        <li key={d.id} className={`row${openId === d.id ? ' is-selected' : ''}`}>
          <span className="doc-icon" aria-hidden="true">
            <FileText size={18} />
          </span>
          <button type="button" className="row-main" onClick={() => (variant === 'card' ? navigate(moduleHref(mod.id, d.id)) : setOpenId(d.id))}>
            <span className="row-title auto-dir" dir={bidi(d.name)}>{d.name}</span>
            <span className="row-meta">
              <DocStatus doc={d} />
              <span>{bytes(d.size)}</span>
              <span>{date(d.createdAt.slice(0, 10), 'short')}</span>
            </span>
          </button>
          {variant === 'full' && (
            <div className="row-actions">
              {(d.extraction === 'failed' || d.extraction === 'running') && (
                <IconButton label={t('استخراج دوباره', 'Extract again')} size="sm" onClick={() => void runExtraction(d.id)}>
                  <RefreshCw size={15} />
                </IconButton>
              )}
              <IconButton label={t('حذف', 'Delete')} size="sm" onClick={() => void remove(d)}>
                <TrashIcon size={15} />
              </IconButton>
            </div>
          )}
        </li>
      ))}
    </ul>
  );

  if (variant === 'card') {
    return (
      <div className="stack">
        {docs.length === 0 ? (
          <>
            <EmptyState icon={<FileText size={22} />} title={t('هنوز فایلی اضافه نکرده‌اید', 'No files yet')} text={t('اولین PDF را انتخاب کنید.', 'Choose your first PDF.')} />
            {upload_}
          </>
        ) : (
          <>
            {renderList(docs.slice(0, mod.appearance.density === 'compact' ? 5 : 3))}
            {docs.length > 3 && (
              <a className="more-link" href={moduleHref(mod.id)}>
                {t('همه اسناد ({n})', 'All documents ({n})', { n: docs.length })}
              </a>
            )}
            {upload_}
          </>
        )}
      </div>
    );
  }

  const Back = locale === 'fa' ? ArrowRight : ArrowLeft;
  return (
    <div className={`split pdf-split${open ? ' has-detail' : ''}`}>
      <div className="split-list stack">
        {upload_}
        {docs.length === 0 ? <EmptyState icon={<FileText size={22} />} title={t('هنوز فایلی اضافه نکرده‌اید', 'No files yet')} /> : renderList(docs)}
      </div>
      <div className="split-detail">
        {open ? (
          <div className="stack">
            <div className="row-flex spread wrap">
              <Button size="sm" variant="ghost" icon={<Back size={15} />} onClick={() => setOpenId(null)} className="split-back">
                {t('فهرست', 'List')}
              </Button>
              <h3 className="doc-title auto-dir grow" dir={bidi(open.name)}>{open.name}</h3>
            </div>
            {open.extraction === 'encrypted' ? (
              <Notice tone="warn" icon={<Lock size={16} />}>
                {t('این PDF رمز دارد و در این نسخه باز یا پردازش نمی‌شود. نسخه بدون رمز را بارگذاری کنید.', 'This PDF is password-protected and cannot be opened or processed in this version. Upload an unprotected copy.')}
              </Notice>
            ) : open.extraction === 'failed' ? (
              <Notice tone="danger" icon={<TriangleAlert size={16} />} action={<Button size="sm" variant="outline" onClick={() => void runExtraction(open.id)}>{t('تلاش دوباره', 'Retry')}</Button>}>
                {t('خواندن این PDF انجام نشد. ممکن است فایل آسیب‌دیده باشد؛ فایل حذف نشده است.', 'This PDF could not be read. The file may be damaged; it has not been deleted.')}
              </Notice>
            ) : (
              <>
                <VoiceInput
                  value={voice}
                  onChange={setVoice}
                  lang={mod.inputLanguage}
                  ownerId={`pdf-${mod.id}`}
                  inputLabel={t('فرمان سند', 'Document command')}
                  placeholder={t('«برو صفحه ۵» یا «خلاصه کن»', '“go to page 5” or “summarize”')}
                  mode={mode}
                  onModeChange={setMode}
                  onCommand={(s) => void onCommand(s)}
                  onSubmit={(s) => void onCommand(s)}
                  submitLabel={t('اجرا', 'Run')}
                  examples={examplesFor(mod, locale)}
                />
                <PdfViewer doc={open} page={page} onPage={setPage} />
                {open.extraction === 'done' && open.textPageCount > 0 && <SearchPanel doc={open} onGoto={setPage} />}
                {open.extraction === 'done' && open.textPageCount === 0 && (
                  <Notice tone="warn" icon={<Info size={16} />}>
                    {t('این سند تصویری یا اسکن‌شده است: نمایش داده می‌شود، اما جست‌وجو و خلاصه به OCR نیاز دارد که در این نسخه نیست.', 'This document is an image or scan: it can be viewed, but search and summaries need OCR, which this version does not have.')}
                  </Notice>
                )}
                <div id={`summary-${open.id}`}>
                  <SummaryPanel key={`${open.id}-${summaryKey}`} mod={mod} doc={open} onGoto={(n) => setPage(n)} />
                </div>
              </>
            )}
          </div>
        ) : (
          <EmptyState icon={<FileText size={22} />} title={t('یک سند را انتخاب کنید', 'Pick a document')} />
        )}
      </div>
    </div>
  );
}
