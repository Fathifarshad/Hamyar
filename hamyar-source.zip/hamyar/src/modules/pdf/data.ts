import { db, nowIso, uid } from '../../data/db';
import { saveAsset, sniff } from '../../data/assets';
import { LIMITS } from '../../config/limits';
import { DomainError, type ModuleInstance, type PdfDocument } from '../../domain/types';
import { extractPages, openPdf, PdfOpenError } from '../../lib/pdf';
import { sha256 } from '../../lib/hash';
import { createStore } from '../../lib/store';

/** Live extraction progress per document (UI only; the result is persisted). */
export const extractionProgress = createStore<Record<string, { done: number; total: number }>>({});

export async function importPdf(mod: ModuleInstance, file: File): Promise<PdfDocument> {
  const kind = await sniff(file);
  if (kind.family !== 'pdf') throw new DomainError('UNSUPPORTED_MEDIA');
  const asset = await saveAsset({ moduleId: mod.id, kind: 'pdf', blob: file, name: file.name, maxBytes: LIMITS.pdfBytes, mime: 'application/pdf' });
  const doc: PdfDocument = {
    id: uid(),
    moduleId: mod.id,
    assetId: asset.id,
    name: file.name.replace(/\.pdf$/i, '').slice(0, 160) || 'PDF',
    size: file.size,
    tags: [],
    pageCount: 0,
    textPageCount: 0,
    extraction: 'pending',
    extractionError: null,
    contentHash: null,
    lastPage: 1,
    createdAt: nowIso(),
  };
  await db.documents.add(doc);
  void runExtraction(doc.id);
  return doc;
}

/** Extracts text page by page. Failure never deletes the file. */
export async function runExtraction(docId: string): Promise<void> {
  const doc = await db.documents.get(docId);
  if (!doc || !doc.assetId) return;
  const asset = await db.assets.get(doc.assetId);
  if (!asset) {
    await db.documents.update(docId, { extraction: 'failed', extractionError: 'missing_file' });
    return;
  }
  await db.documents.update(docId, { extraction: 'running', extractionError: null });
  try {
    const pdf = await openPdf(await asset.blob.arrayBuffer());
    try {
      extractionProgress.set((p) => ({ ...p, [docId]: { done: 0, total: pdf.numPages } }));
      const pages = await extractPages(pdf, (done, total) => extractionProgress.set((p) => ({ ...p, [docId]: { done, total } })));
      const joined = pages.map((p) => `${p.n}\u0000${p.text}`).join('\u0001');
      const contentHash = await sha256(joined);
      await db.transaction('rw', db.pages, db.documents, async () => {
        await db.pages.where('docId').equals(docId).delete();
        await db.pages.bulkPut(pages.map((p) => ({ id: `${docId}|${p.n}`, docId, pageNumber: p.n, text: p.text, hasText: p.hasText })));
        await db.documents.update(docId, {
          pageCount: pdf.numPages,
          textPageCount: pages.filter((p) => p.hasText).length,
          contentHash,
          extraction: 'done',
          extractionError: null,
        });
      });
    } finally {
      void pdf.loadingTask.destroy();
    }
  } catch (e) {
    const code = e instanceof PdfOpenError ? e.code : 'failed';
    await db.documents.update(docId, { extraction: code === 'encrypted' ? 'encrypted' : 'failed', extractionError: code });
  } finally {
    extractionProgress.set((p) => {
      const next = { ...p };
      delete next[docId];
      return next;
    });
  }
}

export async function deleteDocument(docId: string): Promise<void> {
  await db.transaction('rw', db.documents, db.pages, db.summaries, db.assets, async () => {
    const doc = await db.documents.get(docId);
    await db.pages.where('docId').equals(docId).delete();
    await db.summaries.where('docId').equals(docId).delete();
    if (doc?.assetId) await db.assets.delete(doc.assetId);
    await db.documents.delete(docId);
  });
}
