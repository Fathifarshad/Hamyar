import { useEffect, useMemo, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleInstance, PdfDocument, PdfSummary } from '../../domain/types';
import { Button, Modal, Notice, Progress, Segmented } from '../../ui/primitives';
import { Copy, Download, Info, RefreshCw, Sparkles, TriangleAlert, ShieldCheck, X } from '../../ui/icons';
import { AiError, aiStatusStore, refreshAiStatus, summarizePages } from '../../lib/ai';
import { useStore } from '../../lib/store';
import { LIMITS } from '../../config/limits';
import { PROMPT_VERSION } from '../../../shared/summaryCore.mjs';
import { errorText } from '../../i18n/errors';
import { copyText, saveFile } from '../../lib/download';
import { toast } from '../../lib/ui-store';
import { updateModule } from '../../data/modules';
import { IS_ARTIFACT } from '../../lib/platform';

export function summaryMarkdown(doc: PdfDocument, s: PdfSummary, t: (fa: string, en: string, p?: Record<string, string | number>) => string): string {
  const fa = s.language === 'fa';
  const pages = (ns: number[]) => (fa ? `(ص. ${ns.join('، ')})` : `(p. ${ns.join(', ')})`);
  const lines = [
    `# ${fa ? 'خلاصه' : 'Summary'}: ${doc.name}`,
    '',
    `> ${fa ? 'خلاصه تولیدشده؛ برای جزئیات به سند مراجعه کنید.' : 'Generated summary; check the document for details.'}`,
    `> ${t('متن {a} صفحه از {b} صفحه پردازش شد.', 'Text from {a} of {b} pages was processed.', { a: s.coveredPages.length, b: s.totalPages })}`,
    '',
    s.overview,
    '',
    `## ${fa ? 'نکات کلیدی' : 'Key points'}`,
    ...s.highlights.map((h) => `- ${h.text} ${pages(h.pageNumbers)}`),
  ];
  if (s.actionItems.length) lines.push('', `## ${fa ? 'اقدامات ذکرشده در سند' : 'Actions stated in the document'}`, ...s.actionItems.map((h) => `- ${h.text} ${pages(h.pageNumbers)}`));
  if (s.caveats.length) lines.push('', `## ${fa ? 'محدودیت‌ها' : 'Caveats'}`, ...s.caveats.map((c) => `- ${c}`));
  return lines.join('\n');
}

function ConsentModal({ open, provider, pages, onAccept, onCancel }: { open: boolean; provider: string; pages: number; onAccept: () => void; onCancel: () => void }) {
  const { t } = useApp();
  return (
    <Modal
      open={open}
      onClose={onCancel}
      title={t('ارسال متن سند برای خلاصه‌سازی', 'Send document text for summarising')}
      closeLabel={t('بستن', 'Close')}
      size="sm"
      footer={
        <>
          <Button variant="ghost" onClick={onCancel}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" icon={<ShieldCheck size={16} />} onClick={onAccept}>
            {t('موافقم، ارسال شود', 'I agree, send it')}
          </Button>
        </>
      }
    >
      <div className="stack-sm">
        <p>
          {t('متن استخراج‌شده {n} صفحه از این PDF به «{p}» فرستاده می‌شود تا خلاصه ساخته شود.', 'The extracted text of {n} page(s) of this PDF is sent to “{p}” to create the summary.', { n: pages, p: provider })}
        </p>
        <ul className="bullets small muted">
          <li>{t('فقط متن همین سند ارسال می‌شود؛ فایل، داروها، یادداشت‌ها و بقیه داده‌ها نه.', 'Only this document’s text is sent — not the file, medications, notes or other data.')}</li>
          <li>
            {IS_ARTIFACT
              ? t('در پیش‌نمایش claude.ai این کار از حساب Claude خود شما انجام می‌شود.', 'In the claude.ai preview this uses your own Claude account.')
              : t('ارسال از سرور محلی همیار با کلیدی انجام می‌شود که خودتان تنظیم کرده‌اید.', 'It is sent from Hamyar’s local server with the key you configured.')}
          </li>
          <li>{t('این رضایت در «تنظیمات» قابل لغو است.', 'You can withdraw this consent in Settings.')}</li>
        </ul>
      </div>
    </Modal>
  );
}

export function SummaryPanel({ mod, doc, onGoto }: { mod: ModuleInstance; doc: PdfDocument; onGoto: (page: number) => void }) {
  const { t, num } = useApp();
  const status = useStore(aiStatusStore);
  const lang = (mod.config.summaryLanguage as 'fa' | 'en') ?? 'fa';
  const length = (mod.config.summaryLength as 'short' | 'medium') ?? 'short';
  const cacheKey = doc.contentHash ? `${doc.contentHash}|${lang}|${length}|${PROMPT_VERSION}` : null;
  const cached = useLiveQuery(() => (cacheKey ? db.summaries.where('cacheKey').equals(cacheKey).first() : undefined), [cacheKey]);
  const [ack, setAck] = useState(false);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [error, setError] = useState<{ text: string; retryable: boolean } | null>(null);
  const [consentOpen, setConsentOpen] = useState(false);
  const ctl = useRef<AbortController | null>(null);

  useEffect(() => {
    void refreshAiStatus();
  }, []);
  useEffect(() => () => ctl.current?.abort(), []);

  const provider = status.summary.provider ?? '';
  const partial = doc.textPageCount > 0 && doc.textPageCount < doc.pageCount;
  const tooMany = doc.pageCount > LIMITS.pdfSummaryMaxPages;
  const scanned = doc.extraction === 'done' && doc.textPageCount === 0;

  const blocker = useMemo(() => {
    if (doc.extraction === 'encrypted') return t('PDF رمزدار پردازش نمی‌شود؛ نسخه بدون رمز را بارگذاری کنید.', 'Password-protected PDFs are not processed; upload an unprotected copy.');
    if (doc.extraction !== 'done') return t('اول استخراج متن باید تمام شود.', 'Text extraction must finish first.');
    if (scanned) return t('این سند تصویری/اسکن‌شده است و متن قابل خواندن ندارد. خلاصه‌سازی به OCR نیاز دارد که در این نسخه نیست.', 'This document is scanned and has no readable text. Summarising needs OCR, which this version does not have.');
    if (tooMany) return t('سند بیش از {n} صفحه دارد؛ در این نسخه خلاصه نمی‌شود.', 'The document has more than {n} pages; it cannot be summarised in this version.', { n: LIMITS.pdfSummaryMaxPages });
    if (!status.summary.available) {
      switch (status.summary.reason) {
        case 'checking':
          return t('در حال بررسی سرویس…', 'Checking the service…');
        case 'offline':
          return t('اینترنت در دسترس نیست.', 'You are offline.');
        case 'server_missing':
          return t('سرور محلی همیار در دسترس نیست؛ خلاصه‌سازی فقط وقتی برنامه با «npm start» یا «npm run dev» اجرا شده کار می‌کند.', 'Hamyar’s local server is not reachable; summaries work only when the app runs with “npm start” or “npm run dev”.');
        case 'not_granted':
          return t('اجازه استفاده از Claude در این صفحه داده نشد.', 'Claude access was not allowed on this page.');
        case 'preview_unavailable':
          return t('خلاصه‌سازی در این نمایش در دسترس نیست.', 'Summaries are not available in this view.');
        case 'mobile_unavailable':
          return t('خلاصه‌سازی در نسخه گوشی فعال نیست، چون به سرور و کلید سرویس نیاز دارد. برای خلاصه، همین PDF را در نسخه کامپیوتر باز کنید. نمایش و جست‌وجوی متن اینجا کار می‌کند.', 'Summaries are not available in the phone app because they need a server and a service key. Open this PDF in the computer version to summarise it. Viewing and searching work here.');
        default:
          return t('خلاصه‌سازی هنوز برای این نسخه راه‌اندازی نشده است. (کلید و مدل را در فایل ‎.env سرور تنظیم کنید.)', 'Summarising has not been set up for this copy yet. (Set the key and model in the server’s .env file.)');
      }
    }
    return null;
  }, [doc, scanned, tooMany, status.summary, t]);

  const start = async () => {
    const consent = await db.consents.get(`summary:${provider}`);
    if (!consent) {
      setConsentOpen(true);
      return;
    }
    await run();
  };

  const run = async () => {
    setError(null);
    setRunning(true);
    setProgress(null);
    const c = new AbortController();
    ctl.current = c;
    try {
      const pages = (await db.pages.where('docId').equals(doc.id).toArray()).filter((p) => p.hasText).sort((a, b) => a.pageNumber - b.pageNumber);
      const { summary, provider: used } = await summarizePages({
        pages: pages.map((p) => ({ n: p.pageNumber, text: p.text })),
        totalPages: doc.pageCount,
        language: lang,
        length,
        signal: c.signal,
        onProgress: (done, total) => setProgress({ done, total }),
      });
      const coveredOk = summary.highlights.every((h) => h.pageNumbers.every((n) => pages.some((p) => p.pageNumber === n)));
      if (!coveredOk) throw new AiError('INVALID_OUTPUT', true);
      await db.summaries.put({ id: uid(), docId: doc.id, cacheKey: cacheKey!, language: lang, length, promptVersion: PROMPT_VERSION, provider: used, result: summary, createdAt: nowIso() });
    } catch (e) {
      if (!(e instanceof AiError && e.code === 'CANCELLED')) setError({ text: errorText(e, t), retryable: e instanceof AiError ? e.retryable || e.code === 'INVALID_OUTPUT' : true });
    } finally {
      setRunning(false);
      ctl.current = null;
    }
  };

  const s = cached?.result;
  return (
    <div className="summary">
      <div className="summary-head">
        <h3>
          <Sparkles size={16} aria-hidden="true" /> {t('خلاصه سند', 'Document summary')}
        </h3>
        <div className="row-flex wrap">
          <Segmented size="sm" label={t('زبان خلاصه', 'Summary language')} value={lang} onChange={(v) => void updateModule(mod.id, { config: { summaryLanguage: v } })} options={[{ value: 'fa', label: 'فارسی' }, { value: 'en', label: 'English' }]} />
          <Segmented
            size="sm"
            label={t('طول خلاصه', 'Summary length')}
            value={length}
            onChange={(v) => void updateModule(mod.id, { config: { summaryLength: v } })}
            options={[
              { value: 'short', label: t('کوتاه', 'Short') },
              { value: 'medium', label: t('متوسط', 'Medium') },
            ]}
          />
        </div>
      </div>
      {doc.extraction === 'done' && !scanned && (
        <p className="subtle small">{t('متن {a} صفحه از {b} صفحه قابل پردازش است.', 'Text from {a} of {b} pages can be processed.', { a: doc.textPageCount, b: doc.pageCount })}</p>
      )}
      {blocker && !s && (
        <Notice tone={scanned || tooMany || doc.extraction === 'encrypted' ? 'warn' : 'neutral'} icon={<Info size={16} />}>
          {blocker}
        </Notice>
      )}
      {!blocker && partial && !s && (
        <label className="ack">
          <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} />
          <span>{t('می‌دانم که فقط متن {a} صفحه از {b} صفحه خلاصه می‌شود و بقیه (تصویر/اسکن) نادیده گرفته می‌شود.', 'I understand only {a} of {b} pages have text; the rest (images/scans) are skipped.', { a: doc.textPageCount, b: doc.pageCount })}</span>
        </label>
      )}
      {running ? (
        <div className="stack-sm">
          <Progress value={progress?.done ?? 0} max={progress?.total ?? 1} label={t('پیشرفت خلاصه‌سازی', 'Summary progress')} />
          <div className="row-flex spread">
            <span className="subtle small">{progress && progress.total > 1 ? t('بخش {a} از {b}…', 'Part {a} of {b}…', { a: progress.done, b: progress.total }) : t('در حال خلاصه‌سازی…', 'Summarising…')}</span>
            <Button size="sm" variant="ghost" icon={<X size={14} />} onClick={() => ctl.current?.abort()}>
              {t('لغو', 'Cancel')}
            </Button>
          </div>
        </div>
      ) : (
        !s && (
          <Button variant="accent" icon={<Sparkles size={16} />} disabled={!!blocker || (partial && !ack)} onClick={() => void start()}>
            {t('خلاصه کن', 'Summarise')}
          </Button>
        )
      )}
      {error && (
        <Notice tone="danger" icon={<TriangleAlert size={16} />} action={error.retryable ? <Button size="sm" variant="outline" onClick={() => void run()}>{t('تلاش دوباره', 'Retry')}</Button> : undefined}>
          {error.text}
        </Notice>
      )}
      {s && (
        <article className="summary-body" lang={s.language} dir={s.language === 'fa' ? 'rtl' : 'ltr'}>
          <p className="summary-label">
            {s.language === 'fa' ? 'خلاصه تولیدشده؛ برای جزئیات به سند مراجعه کنید.' : 'Generated summary; check the document for details.'}{' '}
            <span className="subtle">({cached?.provider})</span>
          </p>
          <p className="summary-overview">{s.overview}</p>
          <h4>{s.language === 'fa' ? 'نکات کلیدی' : 'Key points'}</h4>
          <ul className="summary-list">
            {s.highlights.map((h, i) => (
              <li key={i}>
                <span>{h.text}</span>{' '}
                {h.pageNumbers.map((n) => (
                  <button key={n} type="button" className="page-chip" onClick={() => onGoto(n)} aria-label={t('رفتن به صفحه {n}', 'Go to page {n}', { n })}>
                    {s.language === 'fa' ? `ص ${num(n)}` : `p. ${n}`}
                  </button>
                ))}
              </li>
            ))}
          </ul>
          {s.actionItems.length > 0 && (
            <>
              <h4>{s.language === 'fa' ? 'اقدامات ذکرشده در سند' : 'Actions stated in the document'}</h4>
              <ul className="summary-list">
                {s.actionItems.map((h, i) => (
                  <li key={i}>
                    <span>{h.text}</span>{' '}
                    {h.pageNumbers.map((n) => (
                      <button key={n} type="button" className="page-chip" onClick={() => onGoto(n)}>
                        {s.language === 'fa' ? `ص ${num(n)}` : `p. ${n}`}
                      </button>
                    ))}
                  </li>
                ))}
              </ul>
            </>
          )}
          {s.caveats.length > 0 && (
            <ul className="summary-caveats">
              {s.caveats.map((c, i) => (
                <li key={i}>{c}</li>
              ))}
            </ul>
          )}
          <p className="subtle xsmall">{t('پوشش: متن {a} صفحه از {b} صفحه.', 'Coverage: text from {a} of {b} pages.', { a: s.coveredPages.length, b: s.totalPages })}</p>
          <div className="row-flex wrap">
            <Button size="sm" variant="soft" icon={<Copy size={14} />} onClick={async () => {
              const ok = await copyText(summaryMarkdown(doc, s, t));
              toast({ kind: ok ? 'success' : 'warning', text: ok ? t('کپی شد.', 'Copied.') : t('کپی ممکن نشد.', 'Copy failed.') });
            }}>
              {t('کپی', 'Copy')}
            </Button>
            <Button
              size="sm"
              variant="soft"
              icon={<Download size={14} />}
              onClick={async () => {
                const r = await saveFile(`${doc.name}-summary.md`, summaryMarkdown(doc, s, t), 'text/markdown');
                if (r === 'unavailable') toast({ kind: 'warning', text: t('دریافت فایل در این نمایش ممکن نیست؛ از «کپی» استفاده کنید.', 'Downloads are not available here; use Copy.') });
              }}
            >
              {t('دریافت ‎.md', 'Download .md')}
            </Button>
            <Button size="sm" variant="ghost" icon={<RefreshCw size={14} />} disabled={!!blocker || running} onClick={async () => {
              if (cached) await db.summaries.delete(cached.id);
              await start();
            }}>
              {t('ساخت دوباره', 'Regenerate')}
            </Button>
          </div>
        </article>
      )}
      <ConsentModal
        open={consentOpen}
        provider={provider}
        pages={doc.textPageCount}
        onCancel={() => setConsentOpen(false)}
        onAccept={async () => {
          await db.consents.put({ id: `summary:${provider}`, feature: 'summary', provider, grantedAt: nowIso(), version: 1 });
          setConsentOpen(false);
          await run();
        }}
      />
    </div>
  );
}
