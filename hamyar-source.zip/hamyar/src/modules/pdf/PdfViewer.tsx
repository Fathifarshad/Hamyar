import { useEffect, useRef, useState } from 'react';
import type { PDFDocumentProxy, RenderTask } from 'pdfjs-dist';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { PdfDocument } from '../../domain/types';
import { openPdf } from '../../lib/pdf';
import { IconButton, Spinner } from '../../ui/primitives';
import { ChevronLeft, ChevronRight, Type, ZoomIn, ZoomOut, TriangleAlert } from '../../ui/icons';

/** Canvas viewer for one PDF. `page` is controlled so search results and summary links can jump. */
export function PdfViewer({ doc, page, onPage }: { doc: PdfDocument; page: number; onPage: (n: number) => void }) {
  const { t, dig, locale, num } = useApp();
  const canvas = useRef<HTMLCanvasElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const [pdf, setPdf] = useState<PDFDocumentProxy | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [renderError, setRenderError] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [showText, setShowText] = useState(false);
  const [rendering, setRendering] = useState(false);
  const [pageInput, setPageInput] = useState(String(page));
  const pageText = useLiveQuery(() => db.pages.get(`${doc.id}|${page}`), [doc.id, page]);

  useEffect(() => setPageInput(String(page)), [page]);

  useEffect(() => {
    let alive = true;
    let loaded: PDFDocumentProxy | null = null;
    setPdf(null);
    setLoadError(null);
    (async () => {
      const asset = doc.assetId ? await db.assets.get(doc.assetId) : null;
      if (!asset) {
        setLoadError(t('فایل این سند در این مرورگر نیست.', 'This document’s file is not in this browser.'));
        return;
      }
      try {
        loaded = await openPdf(await asset.blob.arrayBuffer());
        if (alive) setPdf(loaded);
        else void loaded.loadingTask.destroy();
      } catch (e) {
        if (alive) setLoadError((e as { code?: string }).code === 'encrypted' ? t('این PDF رمز دارد و در این نسخه باز نمی‌شود. نسخه بدون رمز را بارگذاری کنید.', 'This PDF is password-protected and cannot be opened in this version. Upload an unprotected copy.') : t('این PDF باز نشد (فایل آسیب‌دیده است).', 'This PDF could not be opened (the file is damaged).'));
      }
    })();
    return () => {
      alive = false;
      void loaded?.loadingTask.destroy();
    };
  }, [doc.id, doc.assetId, t]);

  useEffect(() => {
    if (!pdf || !canvas.current || !wrap.current) return;
    let task: RenderTask | null = null;
    let cancelled = false;
    (async () => {
      setRendering(true);
      setRenderError(false);
      try {
        const p = await pdf.getPage(Math.min(Math.max(1, page), pdf.numPages));
        const base = p.getViewport({ scale: 1 });
        const avail = Math.max(240, wrap.current!.clientWidth - 2);
        const scale = (avail / base.width) * zoom;
        const viewport = p.getViewport({ scale });
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const c = canvas.current!;
        c.width = Math.floor(viewport.width * dpr);
        c.height = Math.floor(viewport.height * dpr);
        c.style.width = `${Math.floor(viewport.width)}px`;
        c.style.height = `${Math.floor(viewport.height)}px`;
        task = p.render({ canvas: c, viewport, transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined });
        await task.promise;
      } catch (e) {
        if (!cancelled && (e as { name?: string })?.name !== 'RenderingCancelledException') {
          // name/message only — never page content
          console.warn('PDF page render failed:', (e as Error)?.name, (e as Error)?.message);
          setRenderError(true);
        }
      } finally {
        if (!cancelled) setRendering(false);
      }
    })();
    void db.documents.update(doc.id, { lastPage: page });
    return () => {
      cancelled = true;
      task?.cancel();
    };
  }, [pdf, page, zoom, doc.id, t]);

  const total = pdf?.numPages ?? doc.pageCount;
  const go = (n: number) => {
    if (!total) return;
    onPage(Math.min(Math.max(1, n), total));
  };
  const Prev = locale === 'fa' ? ChevronRight : ChevronLeft;
  const Next = locale === 'fa' ? ChevronLeft : ChevronRight;

  return (
    <div
      className="pdf-viewer"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'ArrowRight') go(page + (locale === 'fa' ? -1 : 1));
        if (e.key === 'ArrowLeft') go(page + (locale === 'fa' ? 1 : -1));
      }}
      aria-label={t('نمایشگر PDF', 'PDF viewer')}
    >
      <div className="pdf-toolbar">
        <IconButton label={t('صفحه قبل', 'Previous page')} size="sm" onClick={() => go(page - 1)} disabled={page <= 1}>
          <Prev size={18} />
        </IconButton>
        <form
          className="pdf-page-form"
          onSubmit={(e) => {
            e.preventDefault();
            const n = Number(pageInput.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))));
            if (Number.isFinite(n)) go(n);
          }}
        >
          <input className="input pdf-page-input" value={dig(pageInput)} onChange={(e) => setPageInput(e.target.value)} inputMode="numeric" aria-label={t('شماره صفحه', 'Page number')} />
          <span className="subtle small">/ {num(total || 0)}</span>
        </form>
        <IconButton label={t('صفحه بعد', 'Next page')} size="sm" onClick={() => go(page + 1)} disabled={!!total && page >= total}>
          <Next size={18} />
        </IconButton>
        <span className="grow" />
        <IconButton label={t('کوچک‌نمایی', 'Zoom out')} size="sm" onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}>
          <ZoomOut size={17} />
        </IconButton>
        <IconButton label={t('بزرگ‌نمایی', 'Zoom in')} size="sm" onClick={() => setZoom((z) => Math.min(3, z + 0.25))}>
          <ZoomIn size={17} />
        </IconButton>
        <IconButton label={t('متن استخراج‌شده این صفحه', 'Extracted text of this page')} size="sm" pressed={showText} onClick={() => setShowText((v) => !v)}>
          <Type size={17} />
        </IconButton>
      </div>
      <div className="pdf-canvas-wrap" ref={wrap}>
        {loadError ? (
          <div className="video-overlay is-static">
            <TriangleAlert size={20} aria-hidden="true" />
            <p>{loadError}</p>
          </div>
        ) : (
          <>
            {(!pdf || rendering) && !renderError && (
              <div className="pdf-loading">
                <Spinner />
              </div>
            )}
            {renderError && (
              <div className="video-overlay is-static">
                <TriangleAlert size={20} aria-hidden="true" />
                <p>{t('نمایش این صفحه انجام نشد. متن استخراج‌شده آن را با دکمه «متن» ببینید.', 'This page could not be drawn. Use the “text” button to read its extracted text.')}</p>
              </div>
            )}
            {/* dir="ltr": canvas text inherits the page direction, and pdf.js positions glyphs
                assuming left-to-right anchoring — in an RTL page they would land mirrored. */}
            <canvas ref={canvas} className="pdf-canvas" dir="ltr" hidden={renderError} aria-label={t('صفحه {n}', 'Page {n}', { n: page })} />
          </>
        )}
      </div>
      {showText && (
        <div className="pdf-text para-dir">
          {pageText?.text ? pageText.text : <span className="subtle">{t('در این صفحه متنی قابل استخراج نیست (احتمالاً تصویر/اسکن است).', 'No extractable text on this page (probably an image or scan).')}</span>}
        </div>
      )}
    </div>
  );
}
