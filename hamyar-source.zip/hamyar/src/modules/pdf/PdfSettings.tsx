import { useApp } from '../../shell/AppContext';
import type { ModuleSettingsProps } from '../registry';
import { Field, Segmented } from '../../ui/primitives';

export default function PdfSettings({ config, onChange }: ModuleSettingsProps) {
  const { t } = useApp();
  return (
    <div className="form-row">
      <Field label={t('زبان پیش‌فرض خلاصه', 'Default summary language')}>
        <Segmented label={t('زبان', 'Language')} value={(config.summaryLanguage as 'fa' | 'en') ?? 'fa'} onChange={(v) => onChange({ summaryLanguage: v })} options={[{ value: 'fa', label: 'فارسی' }, { value: 'en', label: 'English' }]} />
      </Field>
      <Field label={t('طول خلاصه', 'Summary length')}>
        <Segmented
          label={t('طول', 'Length')}
          value={(config.summaryLength as 'short' | 'medium') ?? 'short'}
          onChange={(v) => onChange({ summaryLength: v })}
          options={[
            { value: 'short', label: t('کوتاه', 'Short') },
            { value: 'medium', label: t('متوسط', 'Medium') },
          ]}
        />
      </Field>
    </div>
  );
}
