import { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { Checklist, ChecklistItem } from '../../domain/types';
import { Button, EmptyState, IconButton, Input, Menu, MenuItem, MenuSeparator, Select } from '../../ui/primitives';
import { VoiceInput } from '../../ui/VoiceInput';
import { Archive, ArchiveRestore, ArrowDown, ArrowUp, Eraser, ListChecks, MoreIcon, Pencil, Plus, TrashIcon, X } from '../../ui/icons';
import { parseCommand } from '../../domain/commands/parse';
import { matchesQuery } from '../../domain/normalize';
import { useGenericCommand, useVoiceMode, examplesFor } from '../shared';
import { askConfirm, askText, toast } from '../../lib/ui-store';

async function addList(moduleId: string, name: string): Promise<Checklist> {
  const count = await db.checklists.where('moduleId').equals(moduleId).count();
  const list: Checklist = { id: uid(), moduleId, name: name.slice(0, 80), archived: false, order: count, createdAt: nowIso() };
  await db.checklists.add(list);
  return list;
}

async function addItem(list: Checklist, text: string) {
  const items = await db.checkItems.where('listId').equals(list.id).toArray();
  const order = items.reduce((m, i) => Math.max(m, i.order), -1) + 1;
  await db.checkItems.add({ id: uid(), listId: list.id, moduleId: list.moduleId, text: text.slice(0, 200), done: false, order, createdAt: nowIso() });
}

function ListView({ list, items, full, onRename }: { list: Checklist; items: ChecklistItem[]; full: boolean; onRename: (l: Checklist) => void }) {
  const { t, num, bidi } = useApp();
  const sorted = [...items].sort((a, b) => Number(a.done) - Number(b.done) || a.order - b.order);
  const doneCount = items.filter((i) => i.done).length;
  const move = async (item: ChecklistItem, dir: -1 | 1) => {
    const open = items.filter((i) => i.done === item.done).sort((a, b) => a.order - b.order);
    const idx = open.findIndex((i) => i.id === item.id);
    const other = open[idx + dir];
    if (!other) return;
    await db.transaction('rw', db.checkItems, async () => {
      await db.checkItems.update(item.id, { order: other.order });
      await db.checkItems.update(other.id, { order: item.order });
    });
  };
  return (
    <div className="checklist">
      {full && (
        <div className="checklist-head">
          <h3 className="auto-dir" dir={bidi(list.name)}>{list.name}</h3>
          <span className="subtle small">
            {num(doneCount)}/{num(items.length)}
          </span>
          <Menu
            label={t('گزینه‌های فهرست', 'List options')}
            trigger={(p) => (
              <IconButton label={t('گزینه‌های فهرست', 'List options')} size="sm" {...p}>
                <MoreIcon size={17} />
              </IconButton>
            )}
          >
            {(close) => (
              <>
                <MenuItem icon={<Pencil size={15} />} onSelect={() => (close(), onRename(list))}>
                  {t('تغییر نام', 'Rename')}
                </MenuItem>
                <MenuItem icon={<Eraser size={15} />} disabled={!doneCount} onSelect={() => (close(), void db.checkItems.where('listId').equals(list.id).filter((i) => i.done).delete())}>
                  {t('پاک کردن تیک‌خورده‌ها', 'Clear checked')}
                </MenuItem>
                <MenuItem icon={list.archived ? <ArchiveRestore size={15} /> : <Archive size={15} />} onSelect={() => (close(), void db.checklists.update(list.id, { archived: !list.archived }))}>
                  {list.archived ? t('خروج از بایگانی', 'Unarchive') : t('بایگانی فهرست', 'Archive list')}
                </MenuItem>
                <MenuSeparator />
                <MenuItem
                  icon={<TrashIcon size={15} />}
                  danger
                  onSelect={async () => {
                    close();
                    const ok = await askConfirm({ title: t('حذف فهرست «{n}»؟', 'Delete list “{n}”?', { n: list.name }), confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
                    if (!ok) return;
                    await db.transaction('rw', db.checklists, db.checkItems, async () => {
                      await db.checkItems.where('listId').equals(list.id).delete();
                      await db.checklists.delete(list.id);
                    });
                  }}
                >
                  {t('حذف فهرست', 'Delete list')}
                </MenuItem>
              </>
            )}
          </Menu>
        </div>
      )}
      {sorted.length === 0 ? (
        <p className="subtle small">{t('این فهرست خالی است.', 'This list is empty.')}</p>
      ) : (
        <ul className="rows">
          {sorted.map((it, i) => (
            <li key={it.id} className={`row check-row${it.done ? ' is-done' : ''}`}>
              <button type="button" className={`check${it.done ? ' is-on' : ''}`} role="checkbox" aria-checked={it.done} aria-label={it.text} onClick={() => void db.checkItems.update(it.id, { done: !it.done })}>
                <span />
              </button>
              <span className="row-title grow auto-dir" dir={bidi(it.text)}>{it.text}</span>
              {full && (
                <div className="row-actions">
                  <IconButton label={t('بالاتر', 'Move up')} size="sm" disabled={i === 0 || sorted[i - 1]?.done !== it.done} onClick={() => void move(it, -1)}>
                    <ArrowUp size={15} />
                  </IconButton>
                  <IconButton label={t('پایین‌تر', 'Move down')} size="sm" disabled={sorted[i + 1]?.done !== it.done} onClick={() => void move(it, 1)}>
                    <ArrowDown size={15} />
                  </IconButton>
                  <IconButton label={t('حذف', 'Remove')} size="sm" onClick={() => void db.checkItems.delete(it.id)}>
                    <X size={15} />
                  </IconButton>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default function ChecklistsModule({ mod, variant }: ModuleViewProps) {
  const { t, tz, locale } = useApp();
  const lists = useLiveQuery(() => db.checklists.where('moduleId').equals(mod.id).sortBy('order'), [mod.id]);
  const items = useLiveQuery(() => db.checkItems.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [newName, setNewName] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);
  const active = useMemo(() => (lists ?? []).filter((l) => !l.archived), [lists]);
  const current = active.find((l) => l.id === currentId) ?? active[0] ?? null;

  const rename = async (l: Checklist) => {
    const name = await askText({ title: t('تغییر نام فهرست', 'Rename list'), label: t('نام فهرست', 'List name'), initial: l.name, confirmText: t('ذخیره', 'Save'), cancelText: t('انصراف', 'Cancel'), maxLength: 80 });
    if (name && name.trim()) await db.checklists.update(l.id, { name: name.trim().slice(0, 80) });
  };

  const ensureList = async () => current ?? (await addList(mod.id, t('فهرست من', 'My list')));

  const add = async (value: string) => {
    const list = await ensureList();
    await addItem(list, value);
    setText('');
  };

  const onCommand = async (value: string) => {
    const d = parseCommand(value, { moduleType: 'checklists', now: Date.now(), timezone: tz });
    if (await generic(d)) return;
    const list = await ensureList();
    if (d.kind === 'add_item' && d.text) {
      const ok = await askConfirm({ title: t('افزودن «{x}» به «{l}»؟', 'Add “{x}” to “{l}”?', { x: d.text, l: list.name }), confirmText: t('افزودن', 'Add'), cancelText: t('انصراف', 'Cancel') });
      if (ok) {
        await addItem(list, d.text);
        setText('');
      }
    } else if (d.kind === 'check_item') {
      const hit = (items ?? []).find((i) => i.listId === list.id && !i.done && matchesQuery(i.text, d.query));
      if (!hit) {
        toast({ kind: 'warning', text: t('موردی با «{q}» در این فهرست نیست.', 'No item matches “{q}” in this list.', { q: d.query }) });
        return;
      }
      const ok = await askConfirm({ title: t('تیک زدن «{x}»؟', 'Check “{x}”?', { x: hit.text }), confirmText: t('تیک بزن', 'Check'), cancelText: t('انصراف', 'Cancel') });
      if (ok) await db.checkItems.update(hit.id, { done: true });
    }
  };

  if (!lists || !items) return <div className="mod-loading" />;

  const input = (
    <VoiceInput
      value={text}
      onChange={setText}
      lang={mod.inputLanguage}
      ownerId={`check-${mod.id}-${variant}`}
      inputLabel={t('افزودن مورد', 'Add item')}
      placeholder={current ? t('افزودن به «{l}»…', 'Add to “{l}”…', { l: current.name }) : t('اولین مورد را بنویسید…', 'Write the first item…')}
      onSubmit={(s) => void add(s)}
      mode={mode}
      onModeChange={setMode}
      onCommand={(s) => void onCommand(s)}
      examples={examplesFor(mod, locale)}
      maxLength={200}
    />
  );

  if (variant === 'card') {
    return (
      <div className="stack">
        {active.length > 1 && (
          <Select value={current?.id ?? ''} onChange={(e) => setCurrentId(e.target.value)} aria-label={t('انتخاب فهرست', 'Choose list')}>
            {active.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </Select>
        )}
        {input}
        {current ? (
          <ListView list={current} items={items.filter((i) => i.listId === current.id)} full={false} onRename={(l) => void rename(l)} />
        ) : (
          <EmptyState icon={<ListChecks size={22} />} title={t('فهرستی ندارید', 'No lists yet')} text={t('اولین مورد را بنویسید تا «فهرست من» ساخته شود.', 'Add an item and “My list” is created.')} />
        )}
      </div>
    );
  }

  const shownLists = showArchived ? lists : active;
  return (
    <div className="stack">
      <div className="full-toolbar">
        <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder={t('نام فهرست جدید، مثلاً «خرید»', 'New list name, e.g. “Groceries”')} aria-label={t('نام فهرست جدید', 'New list name')} className="grow" />
        <Button
          variant="accent"
          icon={<Plus size={16} />}
          disabled={!newName.trim()}
          onClick={async () => {
            const l = await addList(mod.id, newName.trim());
            setNewName('');
            setCurrentId(l.id);
          }}
        >
          {t('فهرست جدید', 'New list')}
        </Button>
      </div>
      {input}
      {shownLists.length === 0 ? (
        <EmptyState icon={<ListChecks size={22} />} title={t('فهرستی ندارید', 'No lists yet')} />
      ) : (
        <div className="checklist-grid">
          {shownLists.map((l) => (
            <div key={l.id} className={`checklist-card${current?.id === l.id ? ' is-current' : ''}${l.archived ? ' is-muted' : ''}`} onFocusCapture={() => !l.archived && setCurrentId(l.id)} onClickCapture={() => !l.archived && setCurrentId(l.id)}>
              <ListView list={l} items={items.filter((i) => i.listId === l.id)} full onRename={(x) => void rename(x)} />
            </div>
          ))}
        </div>
      )}
      {lists.some((l) => l.archived) && (
        <Button variant="ghost" size="sm" onClick={() => setShowArchived((v) => !v)}>
          {showArchived ? t('پنهان کردن بایگانی', 'Hide archived') : t('نمایش فهرست‌های بایگانی', 'Show archived lists')}
        </Button>
      )}
    </div>
  );
}
