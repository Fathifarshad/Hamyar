import { useEffect, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { MediaItem, ModuleInstance } from '../../domain/types';
import { Button, EmptyState, Field, IconButton, Input, Modal, Notice, Segmented } from '../../ui/primitives';
import { FileDrop } from '../../ui/FileDrop';
import { VoiceInput } from '../../ui/VoiceInput';
import { Clapperboard, ExternalLink, Film, Info, Play, Plus, TrashIcon, TriangleAlert } from '../../ui/icons';
import { saveAsset, sniff, deleteAsset } from '../../data/assets';
import { LIMITS } from '../../config/limits';
import { aparatEmbedUrl, aparatWatchUrl, checkLinkUrl, extractAparatHash, extractYouTubeId, hostOf, youTubeWatchUrl } from '../../domain/urls';
import { blobDuration, claimPlayback, coordinateElement, probeMediaUrl, registerMedia } from '../../lib/media';
import { errorText } from '../../i18n/errors';
import { askConfirm, toast } from '../../lib/ui-store';
import { parseCommand } from '../../domain/commands/parse';
import { matchesQuery } from '../../domain/normalize';
import { useGenericCommand, useVoiceMode, examplesFor } from '../shared';
import { IS_ARTIFACT } from '../../lib/platform';

// ───────── YouTube IFrame Player API (official), loaded only when a YouTube item is opened ─────────
interface YTPlayer {
  playVideo(): void;
  pauseVideo(): void;
  destroy(): void;
}
interface YTNamespace {
  Player: new (el: HTMLElement, opts: Record<string, unknown>) => YTPlayer;
}
let ytLoading: Promise<YTNamespace> | null = null;
function loadYouTubeApi(): Promise<YTNamespace> {
  const w = window as unknown as { YT?: YTNamespace & { loaded?: number }; onYouTubeIframeAPIReady?: () => void };
  if (w.YT?.Player) return Promise.resolve(w.YT);
  if (!ytLoading) {
    ytLoading = new Promise((resolve, reject) => {
      const prev = w.onYouTubeIframeAPIReady;
      w.onYouTubeIframeAPIReady = () => {
        prev?.();
        resolve(w.YT!);
      };
      const s = document.createElement('script');
      s.src = 'https://www.youtube.com/iframe_api';
      s.async = true;
      s.onerror = () => {
        ytLoading = null;
        reject(new Error('yt'));
      };
      document.head.appendChild(s);
      setTimeout(() => reject(new Error('timeout')), 15_000);
    });
  }
  return ytLoading;
}

export type VideoHandle = { play: () => void; pause: () => void };

function YouTubePlayer({ item, handleRef }: { item: MediaItem; handleRef: React.MutableRefObject<VideoHandle | null> }) {
  const { t } = useApp();
  const host = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let player: YTPlayer | null = null;
    let off: (() => void) | null = null;
    let cancelled = false;
    setError(null);
    loadYouTubeApi()
      .then((YT) => {
        if (cancelled || !host.current) return;
        const mount = document.createElement('div');
        host.current.replaceChildren(mount);
        player = new YT.Player(mount, {
          videoId: item.embedId,
          host: 'https://www.youtube-nocookie.com',
          playerVars: { playsinline: 1, rel: 0, origin: window.location.origin },
          events: {
            onStateChange: (e: { data: number }) => {
              if (e.data === 1) claimPlayback(`yt-${item.id}`);
            },
            onError: (e: { data: number }) => {
              setError(
                e.data === 101 || e.data === 150 || e.data === 153
                  ? t('صاحب این ویدئو پخش آن را در سایت‌های دیگر مجاز نکرده است.', 'The owner does not allow this video to play on other sites.')
                  : t('این ویدئو پخش نشد (حذف‌شده، خصوصی یا محدود).', 'This video could not play (removed, private or restricted).'),
              );
            },
          },
        });
        off = registerMedia(`yt-${item.id}`, { pause: () => player?.pauseVideo() });
        handleRef.current = { play: () => player?.playVideo(), pause: () => player?.pauseVideo() };
      })
      .catch(() => !cancelled && setError(t('پخش‌کننده YouTube بارگذاری نشد (اینترنت یا فیلترینگ).', 'The YouTube player did not load (internet or filtering).')));
    return () => {
      cancelled = true;
      off?.();
      player?.destroy();
      handleRef.current = null;
    };
  }, [item.id, item.embedId, handleRef, t]);
  return (
    <div className="video-frame">
      <div ref={host} className="video-embed" />
      {error && (
        <div className="video-overlay">
          <TriangleAlert size={20} aria-hidden="true" />
          <p>{error}</p>
          <a className="btn btn-soft btn-sm" href={youTubeWatchUrl(item.embedId!)} target="_blank" rel="noopener noreferrer">
            <ExternalLink size={14} /> {t('باز کردن در YouTube', 'Open on YouTube')}
          </a>
        </div>
      )}
    </div>
  );
}

function LocalPlayer({ item, handleRef }: { item: MediaItem; handleRef: React.MutableRefObject<VideoHandle | null> }) {
  const { t } = useApp();
  const ref = useRef<HTMLVideoElement>(null);
  const [src, setSrc] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let url: string | null = null;
    let alive = true;
    setError(null);
    (async () => {
      if (item.sourceType === 'file' && item.assetId) {
        const a = await db.assets.get(item.assetId);
        if (!a) {
          if (alive) setError(t('فایل این ویدئو در این مرورگر نیست؛ دوباره اضافه‌اش کنید.', 'This video’s file is not in this browser; add it again.'));
          return;
        }
        url = URL.createObjectURL(a.blob);
        if (alive) setSrc(url);
      } else if (item.url) setSrc(item.url);
    })();
    return () => {
      alive = false;
      if (url) URL.revokeObjectURL(url);
    };
  }, [item.id, item.assetId, item.url, item.sourceType, t]);
  useEffect(() => {
    const el = ref.current;
    if (!el || !src) return;
    const off = coordinateElement(`video-${item.id}`, el);
    handleRef.current = { play: () => void el.play().catch(() => undefined), pause: () => el.pause() };
    let last = 0;
    const save = () => void db.media.update(item.id, { position: el.currentTime, duration: Number.isFinite(el.duration) ? el.duration : item.duration });
    const onTime = () => {
      if (Math.abs(el.currentTime - last) > 5) {
        last = el.currentTime;
        save();
      }
    };
    const onMeta = () => {
      if (item.position > 3 && item.position < (el.duration || Infinity) - 3) el.currentTime = item.position;
    };
    const onErr = () => setError(el.error?.code === 4 ? t('قالب یا codec این ویدئو در این مرورگر پشتیبانی نمی‌شود. پسوند MP4 به‌تنهایی تضمین پخش نیست.', 'This video’s format or codec is not supported by this browser (an .mp4 name alone does not guarantee playback).') : t('منبع ویدئو در دسترس نیست.', 'The video source is unreachable.'));
    el.addEventListener('timeupdate', onTime);
    el.addEventListener('pause', save);
    el.addEventListener('loadedmetadata', onMeta);
    el.addEventListener('error', onErr);
    return () => {
      save();
      off();
      el.removeEventListener('timeupdate', onTime);
      el.removeEventListener('pause', save);
      el.removeEventListener('loadedmetadata', onMeta);
      el.removeEventListener('error', onErr);
      handleRef.current = null;
    };
  }, [src, item.id, item.position, item.duration, handleRef, t]);
  return (
    <div className="video-frame">
      {src && <video ref={ref} src={src} controls playsInline preload="metadata" className="video-el" />}
      {error && (
        <div className="video-overlay">
          <TriangleAlert size={20} aria-hidden="true" />
          <p>{error}</p>
          {item.url && (
            <a className="btn btn-soft btn-sm" href={item.url} target="_blank" rel="noopener noreferrer">
              <ExternalLink size={14} /> {t('باز کردن منبع', 'Open source')}
            </a>
          )}
        </div>
      )}
    </div>
  );
}

function VideoStage({ item, handleRef }: { item: MediaItem; handleRef: React.MutableRefObject<VideoHandle | null> }) {
  const { t } = useApp();
  if (item.sourceType === 'youtube' || item.sourceType === 'aparat') {
    const watch = item.sourceType === 'youtube' ? youTubeWatchUrl(item.embedId!) : aparatWatchUrl(item.embedId!);
    if (IS_ARTIFACT) {
      return (
        <div className="video-frame">
          <div className="video-overlay is-static">
            <Film size={22} aria-hidden="true" />
            <p>{t('پیش‌نمایش claude.ai اجازه جاسازی سایت‌های دیگر را نمی‌دهد. در نسخه قابل اجرا همین‌جا پخش می‌شود.', 'The claude.ai preview does not allow embedding other sites. In the runnable app it plays right here.')}</p>
            <a className="btn btn-soft btn-sm" href={watch} target="_blank" rel="noopener noreferrer">
              <ExternalLink size={14} /> {item.sourceType === 'youtube' ? t('باز کردن در YouTube', 'Open on YouTube') : t('باز کردن در آپارات', 'Open on Aparat')}
            </a>
          </div>
        </div>
      );
    }
    if (item.sourceType === 'youtube') return <YouTubePlayer key={item.id} item={item} handleRef={handleRef} />;
    return (
      <div className="stack-sm">
        <div className="video-frame">
          <iframe
            className="video-embed"
            src={aparatEmbedUrl(item.embedId!)}
            title={item.title}
            allow="autoplay; fullscreen; picture-in-picture"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
            sandbox="allow-scripts allow-same-origin allow-presentation"
          />
        </div>
        <p className="subtle xsmall">{t('کنترل صوتی برای آپارات در دسترس نیست؛ از دکمه‌های خود پخش‌کننده استفاده کنید.', 'Voice control is not available for Aparat; use the player’s own buttons.')}</p>
      </div>
    );
  }
  return <LocalPlayer key={item.id} item={item} handleRef={handleRef} />;
}

function AddVideoDialog({ mod, open, onClose, onAdded }: { mod: ModuleInstance; open: boolean; onClose: () => void; onAdded: (id: string) => void }) {
  const { t, bytes } = useApp();
  const [tab, setTab] = useState<'file' | 'link'>('file');
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    if (open) {
      setUrl('');
      setTitle('');
      setErr(null);
    }
  }, [open]);
  const order = async () => (await db.media.where('moduleId').equals(mod.id).toArray()).reduce((m, i) => Math.max(m, i.order), -1) + 1;
  const base = (): Omit<MediaItem, 'sourceType' | 'assetId' | 'url' | 'embedId' | 'title' | 'order'> => ({ id: uid(), moduleId: mod.id, kind: 'video', artist: '', favorite: false, position: 0, duration: null, missingFile: false, createdAt: nowIso() });

  const addFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setBusy(true);
    setErr(null);
    try {
      const kind = await sniff(f);
      if (kind.family !== 'video' && kind.family !== 'av') throw Object.assign(new Error(), { code: 'UNSUPPORTED_MEDIA' });
      const probe = document.createElement('video').canPlayType(f.type || kind.mime);
      const asset = await saveAsset({ moduleId: mod.id, kind: 'video', blob: f, name: f.name, maxBytes: LIMITS.videoBytes, mime: f.type || kind.mime });
      const duration = await blobDuration(f, 'video');
      const item: MediaItem = { ...base(), sourceType: 'file', assetId: asset.id, url: null, embedId: null, title: f.name.replace(/\.[a-z0-9]{2,5}$/i, '').slice(0, 120), order: await order(), duration };
      await db.media.add(item);
      if (duration === null || probe === '') toast({ kind: 'warning', text: t('ذخیره شد، اما ممکن است این مرورگر آن را پخش نکند.', 'Saved, but this browser may not be able to play it.') });
      onAdded(item.id);
      onClose();
    } catch (e) {
      setErr(errorText(e, t));
    } finally {
      setBusy(false);
    }
  };

  const addLink = async () => {
    setErr(null);
    const yt = extractYouTubeId(url);
    const ap = yt ? null : extractAparatHash(url);
    let item: MediaItem;
    if (yt) item = { ...base(), sourceType: 'youtube', assetId: null, url: youTubeWatchUrl(yt), embedId: yt, title: title.trim() || 'YouTube', order: await order() };
    else if (ap) item = { ...base(), sourceType: 'aparat', assetId: null, url: aparatWatchUrl(ap), embedId: ap, title: title.trim() || t('آپارات', 'Aparat'), order: await order() };
    else {
      const check = checkLinkUrl(url, { requireHttps: true });
      if (!check.ok) {
        setErr(check.reason === 'insecure' ? t('فقط نشانی https پذیرفته می‌شود.', 'Only https addresses are accepted.') : t('نشانی معتبر نیست. HTML یا کد جاسازی پذیرفته نمی‌شود؛ فقط نشانی.', 'Not a valid address. Embed code or HTML is not accepted, only an address.'));
        return;
      }
      setBusy(true);
      const probe = await probeMediaUrl(check.url, 'video');
      setBusy(false);
      if (!probe.ok) {
        setErr(t('این نشانی ویدئوی قابل پخش در مرورگر نیست. می‌توانید آن را در سایت اصلی باز کنید.', 'This address is not a video this browser can play. You can open it on its own site.'));
        return;
      }
      item = { ...base(), sourceType: 'url', assetId: null, url: check.url, embedId: null, title: (title.trim() || hostOf(check.url)).slice(0, 120), order: await order(), duration: probe.duration || null };
    }
    await db.media.add(item);
    onAdded(item.id);
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} title={t('افزودن ویدئو', 'Add video')} closeLabel={t('بستن', 'Close')}>
      <div className="stack" data-accent={mod.appearance.accent}>
        <Segmented
          label={t('منبع', 'Source')}
          value={tab}
          onChange={setTab}
          options={[
            { value: 'file', label: t('فایل من', 'My file') },
            { value: 'link', label: t('لینک (مستقیم، YouTube، آپارات)', 'Link (direct, YouTube, Aparat)') },
          ]}
        />
        {tab === 'file' ? (
          <FileDrop accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.m4v,.mov" onFiles={(f) => void addFile(f)} disabled={busy} title={t('انتخاب یا رها کردن ویدئو', 'Choose or drop a video')} hint={t('MP4 یا WebM تا {max}', 'MP4 or WebM up to {max}', { max: bytes(LIMITS.videoBytes) })} />
        ) : (
          <>
            <Field label={t('نشانی', 'Address')} hint={t('نشانی صفحه YouTube یا آپارات، یا نشانی مستقیم فایل ویدئو (https).', 'A YouTube or Aparat page address, or a direct video file address (https).')}>
              <Input value={url} onChange={(e) => setUrl(e.target.value)} dir="ltr" placeholder="https://" inputMode="url" />
            </Field>
            <Field label={t('عنوان (اختیاری)', 'Title (optional)')}>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
            </Field>
            <Button variant="accent" busy={busy} disabled={!url.trim()} onClick={() => void addLink()}>
              {t('افزودن', 'Add')}
            </Button>
          </>
        )}
        {err && (
          <Notice tone="danger" icon={<TriangleAlert size={16} />}>
            {err}
          </Notice>
        )}
        {IS_ARTIFACT && (
          <Notice tone="neutral" icon={<Info size={16} />}>
            {t('در پیش‌نمایش claude.ai فقط فایل‌های خودتان پخش می‌شوند؛ لینک‌ها ذخیره می‌شوند و در نسخه قابل اجرا پخش می‌شوند.', 'In the claude.ai preview only your own files play; links are saved and play in the runnable app.')}
          </Notice>
        )}
      </div>
    </Modal>
  );
}

export default function VideoModule({ mod, variant }: ModuleViewProps) {
  const { t, duration, tz, locale, bidi } = useApp();
  const items = useLiveQuery(() => db.media.where('moduleId').equals(mod.id).sortBy('order'), [mod.id]);
  const [selected, setSelected] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [voice, setVoice] = useState('');
  const handleRef = useRef<VideoHandle | null>(null);
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);
  if (!items) return <div className="mod-loading" />;
  const current = items.find((i) => i.id === selected) ?? null;

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'video', now: Date.now(), timezone: tz });
    if (d.kind === 'media') {
      if (!handleRef.current) {
        toast({ kind: 'warning', text: t('اول یک ویدئو را باز کنید.', 'Open a video first.') });
        return;
      }
      if (d.action === 'pause') handleRef.current.pause();
      else handleRef.current.play();
      return;
    }
    if (d.kind === 'media_search') {
      const hit = items.find((i) => matchesQuery(i.title, d.query));
      if (hit) setSelected(hit.id);
      else toast({ kind: 'warning', text: t('ویدئویی با «{q}» نیست.', 'No video matches “{q}”.', { q: d.query }) });
      return;
    }
    await generic(d);
  };

  const remove = async (i: MediaItem) => {
    const ok = await askConfirm({ title: t('حذف «{title}»؟', 'Remove “{title}”?', { title: i.title }), confirmText: t('حذف', 'Remove'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (!ok) return;
    if (selected === i.id) setSelected(null);
    await db.transaction('rw', db.media, db.assets, async () => {
      await deleteAsset(i.assetId);
      await db.media.delete(i.id);
    });
  };

  const sourceLabel = (i: MediaItem) => (i.sourceType === 'youtube' ? 'YouTube' : i.sourceType === 'aparat' ? t('آپارات', 'Aparat') : i.sourceType === 'file' ? t('فایل', 'File') : hostOf(i.url ?? ''));
  const max = variant === 'card' ? 4 : Infinity;

  return (
    <div className="stack">
      {current && <VideoStage item={current} handleRef={handleRef} />}
      {(variant === 'full' || mode === 'command') && items.length > 0 && (
        <VoiceInput
          value={voice}
          onChange={setVoice}
          lang={mod.inputLanguage}
          ownerId={`video-${mod.id}-${variant}`}
          inputLabel={t('فرمان ویدئو', 'Video command')}
          placeholder={t('«پخش» یا «توقف»', '“play” or “pause”')}
          mode={mode}
          onModeChange={setMode}
          onCommand={(s) => void onCommand(s)}
          onSubmit={(s) => void onCommand(s)}
          submitLabel={t('اجرا', 'Run')}
          examples={examplesFor(mod, locale)}
        />
      )}
      <div className="row-flex spread">
        <span className="subtle small">{items.length ? t('{n} ویدئو', '{n} videos', { n: items.length }) : ''}</span>
        <Button size="sm" variant="soft" icon={<Plus size={14} />} onClick={() => setAdding(true)}>
          {t('افزودن', 'Add')}
        </Button>
      </div>
      {items.length === 0 ? (
        <EmptyState icon={<Clapperboard size={22} />} title={t('هنوز ویدئویی اضافه نکرده‌اید', 'No videos yet')} text={t('فایل خودتان، لینک مستقیم، YouTube یا آپارات.', 'Your own file, a direct link, YouTube or Aparat.')} />
      ) : (
        <ul className="rows">
          {items.slice(0, max).map((i) => (
            <li key={i.id} className={`row media-row${selected === i.id ? ' is-current' : ''}`}>
              <IconButton label={t('نمایش «{title}»', 'Show “{title}”', { title: i.title })} variant={selected === i.id ? 'accent' : 'soft'} size="sm" onClick={() => setSelected(i.id)}>
                <Play size={15} />
              </IconButton>
              <button type="button" className="row-main" onClick={() => setSelected(i.id)}>
                <span className="row-title auto-dir" dir={bidi(i.title)}>{i.title}</span>
                <span className="row-meta">
                  <span className={i.sourceType === 'url' ? 'ltr' : ''}>{sourceLabel(i)}</span>
                  {i.duration ? <span className="num">{duration(i.duration)}</span> : null}
                  {i.position > 5 && i.duration ? <span>{t('ادامه از {p}', 'resume at {p}', { p: duration(i.position) })}</span> : null}
                </span>
              </button>
              {variant === 'full' && (
                <IconButton label={t('حذف', 'Remove')} size="sm" onClick={() => void remove(i)}>
                  <TrashIcon size={15} />
                </IconButton>
              )}
            </li>
          ))}
        </ul>
      )}
      <AddVideoDialog mod={mod} open={adding} onClose={() => setAdding(false)} onAdded={(id) => setSelected(id)} />
    </div>
  );
}
