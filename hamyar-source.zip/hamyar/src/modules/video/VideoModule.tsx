import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { MediaItem, ModuleInstance } from '../../domain/types';
import { Button, EmptyState, Field, IconButton, Input, Modal, Notice, Segmented, Switch } from '../../ui/primitives';
import { FileDrop } from '../../ui/FileDrop';
import { VoiceInput } from '../../ui/VoiceInput';
import { Clapperboard, ExternalLink, Film, HardDrive, Info, Maximize2, Minimize2, Play, Plus, Save, TrashIcon, TriangleAlert, Upload } from '../../ui/icons';
import { deleteAsset } from '../../data/assets';
import { LIMITS } from '../../config/limits';
import { aparatEmbedUrl, aparatWatchUrl, checkLinkUrl, extractAparatHash, extractYouTubeId, hostOf, youTubeWatchUrl } from '../../domain/urls';
import { claimPlayback, coordinateElement, probeMediaUrl, registerMedia } from '../../lib/media';
import { errorText } from '../../i18n/errors';
import { errorDetail } from '../../lib/errorDetail';
import { askConfirm, toast } from '../../lib/ui-store';
import { useStore } from '../../lib/store';
import { holdScreenOn, releaseScreenOn } from '../../lib/wakeLock';
import { parseCommand } from '../../domain/commands/parse';
import { matchesQuery } from '../../domain/normalize';
import { useGenericCommand, useVoiceMode, examplesFor } from '../shared';
import { IS_ARTIFACT, IS_NATIVE } from '../../lib/platform';
import { addPickedFile, attachPickedFile, canKeepCopy, keepCopy, mediaProblem, pickedVersion, playableBlob, saving, sessionFiles, storedBlob, type MediaProblem } from './files';

// ───────── YouTube IFrame Player API (official), loaded only when a YouTube item is opened ─────────
interface YTPlayer {
  playVideo(): void;
  pauseVideo(): void;
  destroy(): void;
}
interface YTNamespace {
  Player: new (el: HTMLElement, opts: Record<string, unknown>) => YTPlayer;
}
let ytLoading: Promise<YTNamespace> | null = null;
function loadYouTubeApi(): Promise<YTNamespace> {
  const w = window as unknown as { YT?: YTNamespace & { loaded?: number }; onYouTubeIframeAPIReady?: () => void };
  if (w.YT?.Player) return Promise.resolve(w.YT);
  if (!ytLoading) {
    ytLoading = new Promise((resolve, reject) => {
      const prev = w.onYouTubeIframeAPIReady;
      w.onYouTubeIframeAPIReady = () => {
        prev?.();
        resolve(w.YT!);
      };
      const s = document.createElement('script');
      s.src = 'https://www.youtube.com/iframe_api';
      s.async = true;
      s.onerror = () => {
        ytLoading = null;
        reject(new Error('yt'));
      };
      document.head.appendChild(s);
      setTimeout(() => reject(new Error('timeout')), 15_000);
    });
  }
  return ytLoading;
}

export type VideoHandle = { play: () => void; pause: () => void };
type HandleRef = React.MutableRefObject<VideoHandle | null>;
type Problem = { kind: MediaProblem; tag: string };

/** Small-print technical code under an error message (monospace, left-to-right, easy to screenshot). */
function Tag({ children }: { children: ReactNode }) {
  return (
    <code className="err-tag" dir="ltr">
      {children}
    </code>
  );
}

/** A compact "choose a file" button that opens the phone's file picker for videos. */
function PickFileButton({ onFiles, children }: { onFiles: (files: File[]) => void; children: ReactNode }) {
  const input = useRef<HTMLInputElement>(null);
  return (
    <>
      <Button size="sm" variant="soft" icon={<Upload size={14} />} onClick={() => input.current?.click()}>
        {children}
      </Button>
      <input
        ref={input}
        type="file"
        accept="video/*"
        hidden
        onChange={(e) => {
          const files = Array.from(e.target.files ?? []);
          e.target.value = '';
          if (files.length) onFiles(files);
        }}
      />
    </>
  );
}

function YouTubePlayer({ item, handleRef }: { item: MediaItem; handleRef: HandleRef }) {
  const { t } = useApp();
  const host = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<{ text: string; tag: string } | null>(null);
  useEffect(() => {
    let player: YTPlayer | null = null;
    let off: (() => void) | null = null;
    let cancelled = false;
    setError(null);
    loadYouTubeApi()
      .then((YT) => {
        if (cancelled || !host.current) return;
        const mount = document.createElement('div');
        host.current.replaceChildren(mount);
        player = new YT.Player(mount, {
          videoId: item.embedId,
          host: 'https://www.youtube-nocookie.com',
          playerVars: { playsinline: 1, rel: 0, origin: window.location.origin },
          events: {
            onStateChange: (e: { data: number }) => {
              if (e.data === 1) {
                claimPlayback(`yt-${item.id}`);
                holdScreenOn();
              } else if (e.data === 0 || e.data === 2) releaseScreenOn();
            },
            onError: (e: { data: number }) => {
              setError({
                text:
                  e.data === 101 || e.data === 150 || e.data === 153
                    ? t('صاحب این ویدئو پخش آن را در سایت‌های دیگر مجاز نکرده است (یا YouTube اجازه‌ی پخش داخل برنامه را نداده).', 'The owner does not allow this video to play on other sites (or YouTube does not allow playing it inside the app).')
                    : t('این ویدئو پخش نشد (حذف‌شده، خصوصی یا محدود).', 'This video could not play (removed, private or restricted).'),
                tag: `YOUTUBE_${e.data}`,
              });
            },
          },
        });
        off = registerMedia(`yt-${item.id}`, { pause: () => player?.pauseVideo() });
        handleRef.current = { play: () => player?.playVideo(), pause: () => player?.pauseVideo() };
      })
      .catch((e: Error) => !cancelled && setError({ text: t('پخش‌کننده YouTube بارگذاری نشد (اینترنت یا فیلترینگ).', 'The YouTube player did not load (internet or filtering).'), tag: e?.message === 'timeout' ? 'YOUTUBE_API_TIMEOUT' : 'YOUTUBE_API_BLOCKED' }));
    return () => {
      cancelled = true;
      off?.();
      releaseScreenOn();
      player?.destroy();
      handleRef.current = null;
    };
  }, [item.id, item.embedId, handleRef, t]);
  return (
    <div className={`video-frame${error ? ' has-overlay' : ''}`}>
      <div ref={host} className="video-embed" />
      {error && (
        <div className="video-overlay">
          <TriangleAlert size={20} aria-hidden="true" />
          <p>{error.text}</p>
          <Tag>{error.tag}</Tag>
          <a className="btn btn-soft btn-sm" href={youTubeWatchUrl(item.embedId!)} target="_blank" rel="noopener noreferrer">
            <ExternalLink size={14} /> {t('باز کردن در YouTube', 'Open on YouTube')}
          </a>
        </div>
      )}
    </div>
  );
}

/**
 * Plays a video from (in order): a direct link, the copy stored in the app, or the file picked
 * on the phone this session. A picked file is played straight from the phone's storage, so it
 * works for any size and nothing has to be copied or read into memory first.
 */
function LocalPlayer({ item, handleRef, onProblem }: { item: MediaItem; handleRef: HandleRef; onProblem?: (broken: boolean) => void }) {
  const { t } = useApp();
  useStore(pickedVersion);
  const pickVersion = sessionFiles.version(item.id);
  const ref = useRef<HTMLVideoElement>(null);
  const latest = useRef(item);
  useEffect(() => {
    latest.current = item; // the newest saved position/duration, for the effects below
  });
  const [phase, setPhase] = useState<'resolving' | 'ready' | 'missing'>('resolving');
  const [src, setSrc] = useState<string | null>(null);
  const [problem, setProblem] = useState<Problem | null>(null);
  const [noPicture, setNoPicture] = useState(false);

  // 1. find the bytes
  useEffect(() => {
    let url: string | null = null;
    let alive = true;
    setProblem(null);
    onProblem?.(false);
    setNoPicture(false);
    setSrc(null);
    setPhase('resolving');
    (async () => {
      const cur = latest.current;
      if (cur.sourceType === 'url' && cur.url) {
        if (alive) {
          setSrc(cur.url);
          setPhase('ready');
        }
        return;
      }
      let blob: Blob | null = null;
      if (cur.assetId) {
        const stored = await db.assets.get(cur.assetId).catch(() => undefined);
        if (stored) blob = storedBlob(stored);
      }
      if (!blob) {
        const p = sessionFiles.recall(cur.id);
        if (p) blob = playableBlob(p);
      }
      if (!alive) return;
      if (!blob) {
        setPhase('missing');
        return;
      }
      url = URL.createObjectURL(blob);
      setSrc(url);
      setPhase('ready');
    })();
    return () => {
      alive = false;
      if (url) URL.revokeObjectURL(url);
    };
  }, [item.id, item.sourceType, item.url, pickVersion, onProblem]);

  // 2. wire the <video>: resume position, remember progress, keep the screen on while playing
  useEffect(() => {
    const el = ref.current;
    if (!el || !src) return;
    const id = item.id;
    const off = coordinateElement(`video-${id}`, el);
    handleRef.current = { play: () => void el.play().catch(() => undefined), pause: () => el.pause() };
    let last = 0;
    let ready = false; // never overwrite a saved position before the video has loaded and resumed
    const save = () => {
      if (!ready) return;
      const patch: Partial<MediaItem> = { position: el.currentTime };
      if (Number.isFinite(el.duration)) patch.duration = el.duration;
      void db.media.update(id, patch);
    };
    const onTime = () => {
      if (Math.abs(el.currentTime - last) > 5) {
        last = el.currentTime;
        save();
      }
    };
    const onMeta = () => {
      const cur = latest.current;
      const d = el.duration;
      if (cur.position > 3 && Number.isFinite(d) && cur.position < d - 3) el.currentTime = cur.position;
      ready = true;
      if (el.videoWidth === 0 && el.videoHeight === 0) setNoPicture(true);
      if (Number.isFinite(d) && cur.duration !== d) void db.media.update(id, { duration: d });
    };
    const onErr = () => {
      setProblem(mediaProblem(el.error));
      onProblem?.(true);
    };
    const onPlay = () => holdScreenOn();
    const onStop = () => releaseScreenOn();
    const onPause = () => {
      save();
      releaseScreenOn();
    };
    el.addEventListener('timeupdate', onTime);
    el.addEventListener('pause', onPause);
    el.addEventListener('ended', onStop);
    el.addEventListener('play', onPlay);
    el.addEventListener('loadedmetadata', onMeta);
    el.addEventListener('error', onErr);
    return () => {
      save();
      releaseScreenOn();
      off();
      el.removeEventListener('timeupdate', onTime);
      el.removeEventListener('pause', onPause);
      el.removeEventListener('ended', onStop);
      el.removeEventListener('play', onPlay);
      el.removeEventListener('loadedmetadata', onMeta);
      el.removeEventListener('error', onErr);
      handleRef.current = null;
    };
  }, [src, item.id, handleRef, onProblem]);

  const repick = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    try {
      await attachPickedFile(item.id, f);
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t), detail: errorDetail(e), timeout: 9000 });
    }
  };

  const isFile = item.sourceType === 'file';
  const problemText = (p: Problem): string => {
    if (!isFile) return p.kind === 'format' ? t('این نشانی ویدئوی قابل پخش در این دستگاه نیست.', 'This address is not a video this device can play.') : t('منبع ویدئو در دسترس نیست.', 'The video source is unreachable.');
    switch (p.kind) {
      case 'format':
        return t('این دستگاه نتوانست این فایل را بخواند یا قالب/کدک آن را پشتیبانی نمی‌کند (مثلاً MKV، AVI یا HEVC). فایل MP4 با قالب H.264 را امتحان کنید.', 'This device could not read this file, or does not support its format/codec (e.g. MKV, AVI or HEVC). Try an MP4 file with H.264.');
      case 'decode':
        return t('پخش در میانه‌ی فایل ناموفق شد؛ فایل ممکن است ناقص یا خراب باشد.', 'Playback failed partway through; the file may be incomplete or damaged.');
      case 'network':
        return t('خواندن فایل قطع شد. دوباره انتخابش کنید.', 'Reading the file was interrupted. Pick it again.');
      default:
        return t('این ویدئو پخش نشد. دوباره انتخابش کنید.', 'This video did not play. Pick it again.');
    }
  };

  return (
    <>
      <div className={`video-frame${problem || phase === 'missing' ? ' has-overlay' : ''}`}>
        {src && <video key={src} ref={ref} src={src} controls playsInline preload="metadata" className="video-el" {...(IS_NATIVE ? { controlsList: 'nofullscreen' } : {})} />}
        {phase === 'missing' && (
          <div className="video-overlay">
            <Film size={22} aria-hidden="true" />
            <p>
              {item.assetId
                ? t('فایل این ویدئو در این برنامه نیست. برای دیدنش فایل را دوباره انتخاب کنید.', 'This video’s file is not in this app. Pick the file again to watch it.')
                : t('این ویدئو در برنامه ذخیره نشده است. برای دیدنش فایل را دوباره انتخاب کنید.', 'This video is not stored in the app. Pick the file again to watch it.')}
              {item.position > 5 ? ' ' + t('از همان‌جا که مانده بودید ادامه می‌دهد.', 'It resumes where you stopped.') : ''}
            </p>
            <PickFileButton onFiles={(f) => void repick(f)}>{t('انتخاب فایل', 'Choose file')}</PickFileButton>
          </div>
        )}
        {problem && (
          <div className="video-overlay">
            <TriangleAlert size={20} aria-hidden="true" />
            <p>{problemText(problem)}</p>
            <Tag>{problem.tag}</Tag>
            {isFile ? (
              <PickFileButton onFiles={(f) => void repick(f)}>{t('انتخاب دوباره‌ی فایل', 'Pick the file again')}</PickFileButton>
            ) : (
              item.url && (
                <a className="btn btn-soft btn-sm" href={item.url} target="_blank" rel="noopener noreferrer">
                  <ExternalLink size={14} /> {t('باز کردن منبع', 'Open source')}
                </a>
              )
            )}
          </div>
        )}
      </div>
      {noPicture && !problem && (
        <Notice tone="warn" icon={<TriangleAlert size={16} />}>
          {t('فقط صدا پخش می‌شود: این دستگاه تصویر این فایل را رمزگشایی نمی‌کند (معمولاً قالب HEVC یا H.265). فایل MP4 با قالب H.264 را امتحان کنید.', 'Only sound plays: this device cannot decode this file’s picture (usually HEVC / H.265). Try an MP4 with H.264.')}
        </Notice>
      )}
    </>
  );
}

/** Tells a picked-but-not-stored video's owner what will happen to it, and offers to keep a copy. */
function KeepNotice({ item }: { item: MediaItem }) {
  const { t, bytes } = useApp();
  useStore(pickedVersion);
  const busy = useStore(saving).includes(item.id);
  const [failed, setFailed] = useState<{ text: string; tag: string } | null>(null);
  const picked = sessionFiles.recall(item.id);
  if (item.sourceType !== 'file' || item.assetId || !picked) return null;
  const size = picked.file.size;
  const keep = async () => {
    setFailed(null);
    try {
      await keepCopy(item.id, picked.file, picked.mime);
      toast({ kind: 'success', text: t('نسخه‌ای از ویدئو در برنامه ذخیره شد.', 'A copy of the video was saved in the app.') });
    } catch (e) {
      setFailed({ text: errorText(e, t), tag: errorDetail(e) });
    }
  };
  if (busy)
    return (
      <Notice tone="neutral" icon={<HardDrive size={16} />}>
        {t('در حال ذخیره‌ی نسخه‌ای از ویدئو در برنامه…', 'Saving a copy of the video in the app…')}
      </Notice>
    );
  if (!canKeepCopy(size))
    return (
      <Notice tone="neutral" icon={<HardDrive size={16} />}>
        {t(
          'حجم این فایل ({size}) از سقف ذخیره در برنامه ({max}) بیشتر است. همین حالا پخش می‌شود و دفعه‌ی بعد کافی است دوباره انتخابش کنید؛ جای توقف یادتان می‌ماند.',
          'This file ({size}) is larger than the app can store ({max}). It plays now; next time just pick it again — your place is remembered.',
          { size: bytes(size), max: bytes(LIMITS.videoBytes) },
        )}
      </Notice>
    );
  return (
    <Notice
      tone="neutral"
      icon={<HardDrive size={16} />}
      action={
        <Button size="sm" variant="soft" icon={<Save size={14} />} onClick={() => void keep()}>
          {t('ذخیره در برنامه', 'Save in the app')}
        </Button>
      }
    >
      <div className="stack-sm">
        <span>{t('این ویدئو فقط تا بستن برنامه در دسترس است.', 'This video is only available until the app is closed.')}</span>
        {failed && (
          <>
            <span className="err-text">{failed.text}</span>
            <Tag>{failed.tag}</Tag>
          </>
        )}
      </div>
    </Notice>
  );
}

function VideoStage({ item, handleRef }: { item: MediaItem; handleRef: HandleRef }) {
  const { t } = useApp();
  const [theater, setTheater] = useState(false);
  const [broken, setBroken] = useState(false);

  // "Large view": the phone's own full-screen mode is unavailable inside the app, so the player
  // fills the screen itself. Back (Android) and Esc leave it.
  useEffect(() => {
    if (!theater) return;
    const onBack = (e: Event) => {
      e.preventDefault();
      setTheater(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setTheater(false);
    };
    window.addEventListener('hamyar:back', onBack);
    window.addEventListener('keydown', onKey);
    document.documentElement.classList.add('has-theater');
    return () => {
      window.removeEventListener('hamyar:back', onBack);
      window.removeEventListener('keydown', onKey);
      document.documentElement.classList.remove('has-theater');
    };
  }, [theater]);

  const watch = item.sourceType === 'youtube' ? youTubeWatchUrl(item.embedId!) : item.sourceType === 'aparat' ? aparatWatchUrl(item.embedId!) : null;
  let player: ReactNode;
  if (watch && IS_ARTIFACT) {
    player = (
      <div className="video-frame has-overlay">
        <div className="video-overlay is-static">
          <Film size={22} aria-hidden="true" />
          <p>{t('پیش‌نمایش claude.ai اجازه جاسازی سایت‌های دیگر را نمی‌دهد. در نسخه قابل اجرا همین‌جا پخش می‌شود.', 'The claude.ai preview does not allow embedding other sites. In the runnable app it plays right here.')}</p>
          <a className="btn btn-soft btn-sm" href={watch} target="_blank" rel="noopener noreferrer">
            <ExternalLink size={14} /> {item.sourceType === 'youtube' ? t('باز کردن در YouTube', 'Open on YouTube') : t('باز کردن در آپارات', 'Open on Aparat')}
          </a>
        </div>
      </div>
    );
  } else if (item.sourceType === 'youtube') player = <YouTubePlayer key={item.id} item={item} handleRef={handleRef} />;
  else if (item.sourceType === 'aparat')
    player = (
      <>
        <div className="video-frame">
          <iframe
            className="video-embed"
            src={aparatEmbedUrl(item.embedId!)}
            title={item.title}
            allow="autoplay; fullscreen; picture-in-picture"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
            sandbox="allow-scripts allow-same-origin allow-presentation"
          />
        </div>
        <p className="subtle xsmall video-note">{t('کنترل صوتی برای آپارات در دسترس نیست؛ از دکمه‌های خود پخش‌کننده استفاده کنید.', 'Voice control is not available for Aparat; use the player’s own buttons.')}</p>
      </>
    );
  else player = <LocalPlayer key={item.id} item={item} handleRef={handleRef} onProblem={setBroken} />;

  return (
    <div className={`video-stage${theater ? ' is-theater' : ''}`}>
      {player}
      {!(watch && IS_ARTIFACT) && (
        <div className="video-tools">
          <span className="video-rotate-hint">{t('برای تصویر بزرگ‌تر، گوشی را بچرخانید', 'Rotate the phone for a bigger picture')}</span>
          <Button size="sm" variant={theater ? 'primary' : 'soft'} icon={theater ? <Minimize2 size={14} /> : <Maximize2 size={14} />} onClick={() => setTheater((v) => !v)} aria-pressed={theater}>
            {theater ? t('بستن نمای بزرگ', 'Close large view') : t('نمای بزرگ', 'Large view')}
          </Button>
        </div>
      )}
      {!broken && <KeepNotice item={item} />}
    </div>
  );
}

function AddVideoDialog({ mod, open, onClose, onAdded }: { mod: ModuleInstance; open: boolean; onClose: () => void; onAdded: (id: string) => void }) {
  const { t, bytes } = useApp();
  const [tab, setTab] = useState<'file' | 'link'>('file');
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [keep, setKeep] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<{ text: string; tag: string } | null>(null);
  useEffect(() => {
    if (open) {
      setUrl('');
      setTitle('');
      setErr(null);
      setKeep(true);
    }
  }, [open]);
  const order = async () => (await db.media.where('moduleId').equals(mod.id).toArray()).reduce((m, i) => Math.max(m, i.order), -1) + 1;
  const base = (): Omit<MediaItem, 'sourceType' | 'assetId' | 'url' | 'embedId' | 'title' | 'order'> => ({ id: uid(), moduleId: mod.id, kind: 'video', artist: '', favorite: false, position: 0, duration: null, missingFile: false, createdAt: nowIso() });

  const fail = (e: unknown) => {
    const family = (e as { details?: { family?: string } })?.details?.family;
    setErr({
      text: (e as { code?: string })?.code === 'UNSUPPORTED_MEDIA' && family === 'audio' ? t('این فایل صوتی است؛ آن را در بخش «موسیقی» اضافه کنید.', 'This is an audio file; add it in the Music section.') : errorText(e, t),
      tag: errorDetail(e),
    });
  };

  const addFile = async (files: File[]) => {
    const f = files[0];
    if (!f) return;
    setBusy(true);
    setErr(null);
    try {
      const { item, saved } = await addPickedFile(mod.id, f, { keepCopy: keep });
      onAdded(item.id);
      onClose();
      void saved?.then((r) => {
        if (r.ok) toast({ kind: 'success', text: t('نسخه‌ای از ویدئو در برنامه ذخیره شد.', 'A copy of the video was saved in the app.') });
        else toast({ kind: 'warning', text: t('ویدئو پخش می‌شود، اما نسخه‌ای از آن در برنامه ذخیره نشد.', 'The video plays, but a copy could not be saved in the app.'), detail: `${errorText(r.error, t)} [${errorDetail(r.error)}]`, timeout: 10000 });
      });
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  };

  const addLink = async () => {
    setErr(null);
    const yt = extractYouTubeId(url);
    const ap = yt ? null : extractAparatHash(url);
    let item: MediaItem;
    if (yt) item = { ...base(), sourceType: 'youtube', assetId: null, url: youTubeWatchUrl(yt), embedId: yt, title: title.trim() || 'YouTube', order: await order() };
    else if (ap) item = { ...base(), sourceType: 'aparat', assetId: null, url: aparatWatchUrl(ap), embedId: ap, title: title.trim() || t('آپارات', 'Aparat'), order: await order() };
    else {
      const check = checkLinkUrl(url, { requireHttps: true });
      if (!check.ok) {
        setErr({ text: check.reason === 'insecure' ? t('فقط نشانی https پذیرفته می‌شود.', 'Only https addresses are accepted.') : t('نشانی معتبر نیست. HTML یا کد جاسازی پذیرفته نمی‌شود؛ فقط نشانی.', 'Not a valid address. Embed code or HTML is not accepted, only an address.'), tag: '' });
        return;
      }
      setBusy(true);
      const probe = await probeMediaUrl(check.url, 'video');
      setBusy(false);
      if (!probe.ok) {
        setErr({ text: t('این نشانی ویدئوی قابل پخش در مرورگر نیست. می‌توانید آن را در سایت اصلی باز کنید.', 'This address is not a video this browser can play. You can open it on its own site.'), tag: `PROBE_${probe.reason.toUpperCase()}` });
        return;
      }
      item = { ...base(), sourceType: 'url', assetId: null, url: check.url, embedId: null, title: (title.trim() || hostOf(check.url)).slice(0, 120), order: await order(), duration: probe.duration || null };
    }
    await db.media.add(item);
    onAdded(item.id);
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} title={t('افزودن ویدئو', 'Add video')} closeLabel={t('بستن', 'Close')}>
      <div className="stack" data-accent={mod.appearance.accent}>
        <Segmented
          label={t('منبع', 'Source')}
          value={tab}
          onChange={setTab}
          options={[
            { value: 'file', label: t('فایل من', 'My file') },
            { value: 'link', label: t('لینک (مستقیم، YouTube، آپارات)', 'Link (direct, YouTube, Aparat)') },
          ]}
        />
        {tab === 'file' ? (
          <>
            <FileDrop accept="video/*" onFiles={(f) => void addFile(f)} disabled={busy} title={t('انتخاب ویدئو از گوشی', 'Choose a video from the device')} hint={t('هر حجمی؛ بهترین قالب MP4 است', 'Any size; MP4 works best')} />
            <Switch
              checked={keep}
              onChange={setKeep}
              label={t('نسخه‌ای از فایل در برنامه ذخیره شود', 'Keep a copy of the file in the app')}
              description={t('تا دفعه‌ی بعد هم باشد (فقط تا {max}). فیلم‌های بزرگ‌تر بدون ذخیره پخش می‌شوند و دفعه‌ی بعد باید دوباره انتخابشان کنید.', 'So it is there next time (up to {max} only). Bigger films just play, and you pick them again next time.', { max: bytes(LIMITS.videoBytes) })}
            />
          </>
        ) : (
          <>
            <Field label={t('نشانی', 'Address')} hint={t('نشانی صفحه YouTube یا آپارات، یا نشانی مستقیم فایل ویدئو (https).', 'A YouTube or Aparat page address, or a direct video file address (https).')}>
              <Input value={url} onChange={(e) => setUrl(e.target.value)} dir="ltr" placeholder="https://" inputMode="url" />
            </Field>
            <Field label={t('عنوان (اختیاری)', 'Title (optional)')}>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
            </Field>
            <Button variant="accent" busy={busy} disabled={!url.trim()} onClick={() => void addLink()}>
              {t('افزودن', 'Add')}
            </Button>
          </>
        )}
        {err && (
          <Notice tone="danger" icon={<TriangleAlert size={16} />}>
            <div className="stack-sm">
              <span>{err.text}</span>
              {err.tag && <Tag>{err.tag}</Tag>}
            </div>
          </Notice>
        )}
        {IS_ARTIFACT && (
          <Notice tone="neutral" icon={<Info size={16} />}>
            {t('در پیش‌نمایش claude.ai فقط فایل‌های خودتان پخش می‌شوند؛ لینک‌ها ذخیره می‌شوند و در نسخه قابل اجرا پخش می‌شوند.', 'In the claude.ai preview only your own files play; links are saved and play in the runnable app.')}
          </Notice>
        )}
      </div>
    </Modal>
  );
}

export default function VideoModule({ mod, variant }: ModuleViewProps) {
  const { t, duration, tz, locale, bidi } = useApp();
  const items = useLiveQuery(() => db.media.where('moduleId').equals(mod.id).sortBy('order'), [mod.id]);
  const [selected, setSelected] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [voice, setVoice] = useState('');
  const handleRef = useRef<VideoHandle | null>(null);
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);
  useStore(pickedVersion);
  if (!items) return <div className="mod-loading" />;
  const current = items.find((i) => i.id === selected) ?? null;

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'video', now: Date.now(), timezone: tz });
    if (d.kind === 'media') {
      if (!handleRef.current) {
        toast({ kind: 'warning', text: t('اول یک ویدئو را باز کنید.', 'Open a video first.') });
        return;
      }
      if (d.action === 'pause') handleRef.current.pause();
      else handleRef.current.play();
      return;
    }
    if (d.kind === 'media_search') {
      const hit = items.find((i) => matchesQuery(i.title, d.query));
      if (hit) setSelected(hit.id);
      else toast({ kind: 'warning', text: t('ویدئویی با «{q}» نیست.', 'No video matches “{q}”.', { q: d.query }) });
      return;
    }
    await generic(d);
  };

  const remove = async (i: MediaItem) => {
    const ok = await askConfirm({ title: t('حذف «{title}»؟', 'Remove “{title}”?', { title: i.title }), confirmText: t('حذف', 'Remove'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (!ok) return;
    if (selected === i.id) setSelected(null);
    await db.transaction('rw', db.media, db.assets, async () => {
      await deleteAsset(i.assetId);
      await db.media.delete(i.id);
    });
    sessionFiles.forget(i.id);
  };

  const sourceLabel = (i: MediaItem) => (i.sourceType === 'youtube' ? 'YouTube' : i.sourceType === 'aparat' ? t('آپارات', 'Aparat') : i.sourceType === 'file' ? (i.assetId ? t('ذخیره در برنامه', 'Saved in the app') : t('فایل گوشی', 'Device file')) : hostOf(i.url ?? ''));
  const needsFile = (i: MediaItem) => i.sourceType === 'file' && !i.assetId && !sessionFiles.has(i.id);
  const max = variant === 'card' ? 4 : Infinity;

  return (
    <div className="stack">
      {current && <VideoStage item={current} handleRef={handleRef} />}
      {(variant === 'full' || mode === 'command') && items.length > 0 && (
        <VoiceInput
          value={voice}
          onChange={setVoice}
          lang={mod.inputLanguage}
          ownerId={`video-${mod.id}-${variant}`}
          inputLabel={t('فرمان ویدئو', 'Video command')}
          placeholder={t('«پخش» یا «توقف»', '“play” or “pause”')}
          mode={mode}
          onModeChange={setMode}
          onCommand={(s) => void onCommand(s)}
          onSubmit={(s) => void onCommand(s)}
          submitLabel={t('اجرا', 'Run')}
          examples={examplesFor(mod, locale)}
        />
      )}
      <div className="row-flex spread">
        <span className="subtle small">{items.length ? t('{n} ویدئو', '{n} videos', { n: items.length }) : ''}</span>
        <Button size="sm" variant="soft" icon={<Plus size={14} />} onClick={() => setAdding(true)}>
          {t('افزودن', 'Add')}
        </Button>
      </div>
      {items.length === 0 ? (
        <EmptyState icon={<Clapperboard size={22} />} title={t('هنوز ویدئویی اضافه نکرده‌اید', 'No videos yet')} text={t('فایل خودتان، لینک مستقیم، YouTube یا آپارات.', 'Your own file, a direct link, YouTube or Aparat.')} />
      ) : (
        <ul className="rows">
          {items.slice(0, max).map((i) => (
            <li key={i.id} className={`row media-row${selected === i.id ? ' is-current' : ''}`}>
              <IconButton label={t('نمایش «{title}»', 'Show “{title}”', { title: i.title })} variant={selected === i.id ? 'accent' : 'soft'} size="sm" onClick={() => setSelected(i.id)}>
                <Play size={15} />
              </IconButton>
              <button type="button" className="row-main" onClick={() => setSelected(i.id)}>
                <span className="row-title auto-dir" dir={bidi(i.title)}>{i.title}</span>
                <span className="row-meta">
                  <span className={i.sourceType === 'url' ? 'ltr' : ''}>{sourceLabel(i)}</span>
                  {i.duration ? <span className="num">{duration(i.duration)}</span> : null}
                  {i.position > 5 && i.duration ? <span>{t('ادامه از {p}', 'resume at {p}', { p: duration(i.position) })}</span> : null}
                  {needsFile(i) ? <span>{t('برای پخش، فایل را دوباره انتخاب کنید', 'pick the file again to play')}</span> : null}
                </span>
              </button>
              {variant === 'full' && (
                <IconButton label={t('حذف', 'Remove')} size="sm" onClick={() => void remove(i)}>
                  <TrashIcon size={15} />
                </IconButton>
              )}
            </li>
          ))}
        </ul>
      )}
      <AddVideoDialog mod={mod} open={adding} onClose={() => setAdding(false)} onAdded={(id) => setSelected(id)} />
    </div>
  );
}
