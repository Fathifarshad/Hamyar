import { DomainError } from '../../domain/types';
import { errorDetail } from '../../lib/errorDetail';
import { judge, probeFile, probeTag, type CanPlay, type FileProbe, type Verdict } from './probe';
import { prepareBlob, PREPARE_MAX_BYTES } from './prepare';
import type { MediaProblem } from './files';

/**
 * How a video file ends up on the screen, as a small state machine that knows nothing about React:
 *
 *   1. play the file the way the phone handed it over (instant, any size);
 *   2. if the phone's player cannot load it, look inside it (what container, which codecs, can the
 *      app read it at all) — a codec the phone cannot play is explained, not retried;
 *   3. otherwise read the whole file once into a plain copy and play that instead;
 *   4. if that fails too, give up with the real reason and a technical trail that fits a screenshot.
 *
 * It tells its owner what to show through `onView`, and learns from the owner what the <video>
 * element did through `videoLoaded` / `videoFailed`.
 */

export interface Origin {
  blob: Blob;
  mime: string;
  kind: 'stored' | 'picked';
}

export interface Failure {
  /** how the browser's player reported it; 'copy' when making the playable copy itself failed */
  kind: MediaProblem | 'copy';
  /** the technical code of the last failure, e.g. MEDIA_ERR_SRC_NOT_SUPPORTED · MEDIA_ELEMENT_ERROR: Format error */
  tag: string;
  /** more small print: the first failure, what the file is, what was tried */
  extra: string[];
  verdict: Verdict | null;
  /** the error behind a 'copy' failure */
  error: unknown;
}

export type Work = { step: 'checking' } | { step: 'copying'; done: number; total: number };

export interface View {
  /** what the <video> should load (null: no player is shown) */
  src: string | null;
  /** a progress message to show instead of the player */
  work: Work | null;
  failure: Failure | null;
}

export interface PlaybackOptions {
  origin: Origin;
  /** skip the direct try: on this device a copy is what plays */
  startWithCopy: boolean;
  canPlay: CanPlay;
  onView: (view: View) => void;
  /** a copy played where the direct try had failed */
  onCopyWorks?: () => void;
  /** a playable copy exists (the owner may keep it for saving into the app) */
  onPrepared?: (blob: Blob) => void;
  /** only for tests */
  makeUrl?: (blob: Blob) => string;
  revokeUrl?: (url: string) => void;
  maxCopyBytes?: number;
  loadWaitMs?: number;
}

export interface Playback {
  start(): void;
  /** the <video> reported an error, or never loaded */
  videoFailed(problem: { kind: MediaProblem; tag: string }): void;
  /** the <video> loaded the start of the file: this source works */
  videoLoaded(): void;
  /**
   * The browser chose not to load anything until play is pressed (low-power mode, data saver).
   * Nothing is wrong, so the app must not mistake the silence for a file that will not open;
   * a real failure later (when play is pressed) is still handled.
   */
  videoIdle(): void;
  cancelCopy(): void;
  dispose(): void;
}

/** How long the phone's player gets to open a file before the app steps in. */
export const LOAD_WAIT_MS = 12_000;

export function createPlayback(o: PlaybackOptions): Playback {
  const makeUrl = o.makeUrl ?? ((b: Blob) => URL.createObjectURL(b));
  const revokeUrl = o.revokeUrl ?? ((u: string) => URL.revokeObjectURL(u));
  const maxCopy = o.maxCopyBytes ?? PREPARE_MAX_BYTES;
  const wait = o.loadWaitMs ?? LOAD_WAIT_MS;
  const urls: string[] = [];
  const trail: string[] = [];
  let disposed = false;
  let stage: 'direct' | 'preparing' | 'prepared' = 'direct';
  let view: View = { src: null, work: null, failure: null };
  let first: { kind: MediaProblem; tag: string } | null = null;
  let probe: FileProbe | null = null;
  let abort: AbortController | null = null;
  let attempt: { loaded: boolean; failed: boolean; timer: ReturnType<typeof setTimeout> | null } | null = null;
  let reportedCopyWorks = false;

  const emit = (patch: Partial<View>) => {
    if (disposed) return;
    view = { ...view, ...patch };
    o.onView(view);
  };

  const stopWatch = () => {
    if (attempt?.timer) clearTimeout(attempt.timer);
  };

  const giveUp = (p: { kind: MediaProblem; tag: string }, why: { verdict?: Verdict; error?: unknown } = {}) => {
    const extra: string[] = [];
    if (first && first.tag !== p.tag) extra.push(`first: ${first.tag}`);
    if (probe) extra.push(probeTag(probe, o.canPlay));
    if (trail.length) extra.push(`tried: ${trail.join(' > ')}`);
    const copyFailed = why.error !== undefined && (why.error as { code?: string }).code !== 'CANCELLED';
    emit({ work: null, failure: { kind: copyFailed ? 'copy' : p.kind, tag: copyFailed ? errorDetail(why.error) || 'COPY_FAILED' : p.tag, extra: copyFailed ? [`player: ${p.tag}`, ...extra] : extra, verdict: why.verdict ?? null, error: why.error ?? null } });
  };

  const load = (blob: Blob) => {
    stopWatch();
    const url = makeUrl(blob);
    urls.push(url);
    const mine: NonNullable<typeof attempt> = { loaded: false, failed: false, timer: null };
    attempt = mine;
    mine.timer = setTimeout(() => {
      if (!mine.loaded && !mine.failed) fail({ kind: 'network', tag: 'LOAD_TIMEOUT' });
    }, stage === 'direct' ? wait : wait * 2);
    emit({ src: url, work: null, failure: null });
  };

  const copy = async () => {
    stage = 'preparing';
    abort = new AbortController();
    let lastEmit = 0;
    emit({ src: null, failure: null, work: { step: 'copying', done: 0, total: o.origin.blob.size } });
    try {
      const blob = await prepareBlob(o.origin.blob, {
        mime: o.origin.mime,
        signal: abort.signal,
        maxBytes: maxCopy,
        onProgress: (done, total) => {
          const now = Date.now();
          if (done >= total || now - lastEmit >= 250) {
            lastEmit = now;
            emit({ work: { step: 'copying', done, total } });
          }
        },
      });
      if (disposed) return;
      trail.push('copy:ok');
      stage = 'prepared';
      o.onPrepared?.(blob);
      load(blob);
    } catch (e) {
      if (disposed) return;
      trail.push((e as { code?: string })?.code === 'CANCELLED' ? 'copy:cancelled' : 'copy:fail');
      giveUp(first ?? { kind: 'unknown', tag: 'MEDIA_ERR' }, { error: e });
    }
  };

  const rescue = async (p: { kind: MediaProblem; tag: string }) => {
    first = p;
    emit({ src: null, failure: null, work: { step: 'checking' } });
    probe = await probeFile(o.origin.blob);
    if (disposed) return;
    const verdict = judge(probe, o.canPlay);
    trail.push(`probe:${verdict.kind}`);
    if (verdict.kind !== 'unknown') return giveUp(p, { verdict });
    if (o.origin.blob.size > maxCopy) {
      trail.push('copy:too-big');
      return giveUp(p, { error: new DomainError('TOO_BIG_TO_COPY', undefined, { max: maxCopy }) });
    }
    await copy();
  };

  /** The copy failed to play as well: look inside the file once more so the message can name the real cause. */
  const explain = async (p: { kind: MediaProblem; tag: string }) => {
    probe ??= await probeFile(o.origin.blob);
    if (disposed) return;
    const verdict = judge(probe, o.canPlay);
    giveUp(p, verdict.kind === 'unknown' ? {} : { verdict });
  };

  function fail(p: { kind: MediaProblem; tag: string }) {
    if (disposed || !attempt || attempt.failed) return;
    attempt.failed = true;
    stopWatch();
    const broke = attempt.loaded;
    trail.push(`${stage}:${broke ? 'broke' : 'fail'}`);
    if (stage === 'direct') {
      // Trouble in the middle of a file that opened fine is damage, not a way of reading to fix.
      if (broke && p.kind === 'decode') giveUp(p);
      else void rescue(p);
    } else void explain(p);
  }

  return {
    start() {
      if (o.startWithCopy && o.origin.kind === 'picked' && o.origin.blob.size <= maxCopy) void copy();
      else load(o.origin.blob);
    },
    videoFailed: fail,
    videoLoaded() {
      if (!attempt || attempt.failed) return;
      attempt.loaded = true;
      stopWatch();
      if (stage === 'prepared' && first && !reportedCopyWorks) {
        reportedCopyWorks = true;
        o.onCopyWorks?.();
      }
    },
    videoIdle() {
      if (!attempt || attempt.failed) return;
      stopWatch();
    },
    cancelCopy() {
      abort?.abort();
    },
    dispose() {
      disposed = true;
      abort?.abort();
      stopWatch();
      urls.splice(0).forEach(revokeUrl);
    },
  };
}
