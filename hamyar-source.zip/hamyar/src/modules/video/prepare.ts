import { errName } from '../../data/assets';
import { DomainError } from '../../domain/types';

/**
 * Makes a plain, self-contained copy of a picked file so it can be played from the browser's own
 * blob storage instead of from the phone's file.
 *
 * Some phones let the app read a picked file (a Gallery or Photo Picker item) but make the media
 * player fail when it streams the same file ("format error"). A copy made here is read once,
 * from the first byte to the last, in one pass (no seeking, which some pickers do not allow), and
 * is handed to the browser in pieces, so memory is not what holds it: browsers keep large blobs
 * on disk by themselves.
 */

const MiB = 1024 * 1024;
/** Bigger films are not copied this way: browsers cannot be trusted to hold them. */
export const PREPARE_MAX_BYTES = 1536 * MiB;
const PART_BYTES = 8 * MiB;
const CHECK_BYTES = 4096;

export interface PrepareOptions {
  /** MIME type the copy is given (the phone often reports none) */
  mime: string;
  onProgress?: (done: number, total: number) => void;
  signal?: AbortSignal;
  /** only for tests */
  maxBytes?: number;
}

/** Reads a blob from its first byte to its last, once, in order. */
async function* chunks(file: Blob, signal?: AbortSignal): AsyncGenerator<Uint8Array> {
  const stream = typeof file.stream === 'function' ? file.stream() : null;
  if (stream) {
    const reader = stream.getReader();
    const stop = () => void reader.cancel().catch(() => undefined);
    signal?.addEventListener('abort', stop, { once: true });
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) return;
        if (value?.byteLength) yield value;
      }
    } finally {
      signal?.removeEventListener('abort', stop);
      stop();
    }
  }
  // this browser has no Blob.stream(): read it piece by piece instead
  for (let at = 0; at < file.size; at += PART_BYTES) {
    if (signal?.aborted) return;
    yield new Uint8Array(await file.slice(at, Math.min(file.size, at + PART_BYTES)).arrayBuffer());
  }
}

/** The last `n` bytes seen so far, given the previous ones and the newest piece. */
function tailOf(prev: Uint8Array, piece: Uint8Array, n: number): Uint8Array {
  if (piece.byteLength >= n) return piece.slice(piece.byteLength - n);
  const out = new Uint8Array(Math.min(n, prev.byteLength + piece.byteLength));
  const keep = out.length - piece.byteLength;
  out.set(prev.subarray(prev.byteLength - keep), 0);
  out.set(piece, keep);
  return out;
}

const same = (a: Uint8Array, b: Uint8Array): boolean => a.length === b.length && a.every((x, i) => x === b[i]);

/**
 * Copies `file` into a new Blob. Throws FILE_UNREADABLE (with how far it got), TOO_BIG_TO_COPY,
 * CANCELLED, or STORE_FAILED when the browser did not keep the copy intact.
 */
export async function prepareBlob(file: Blob, opts: PrepareOptions): Promise<Blob> {
  const total = file.size;
  const max = opts.maxBytes ?? PREPARE_MAX_BYTES;
  if (total > max) throw new DomainError('TOO_BIG_TO_COPY', undefined, { max });
  const parts: Blob[] = [];
  let pending: Uint8Array[] = [];
  let pendingBytes = 0;
  let done = 0;
  let tail: Uint8Array = new Uint8Array(0);
  const flush = () => {
    if (pendingBytes) parts.push(new Blob(pending as BlobPart[]));
    pending = [];
    pendingBytes = 0;
  };
  try {
    for await (const piece of chunks(file, opts.signal)) {
      if (opts.signal?.aborted) throw new DomainError('CANCELLED');
      pending.push(piece);
      pendingBytes += piece.byteLength;
      done += piece.byteLength;
      tail = tailOf(tail, piece, CHECK_BYTES);
      if (pendingBytes >= PART_BYTES) flush();
      if (done > total) break;
      opts.onProgress?.(done, total);
    }
  } catch (e) {
    if (e instanceof DomainError) throw e;
    throw new DomainError('FILE_UNREADABLE', undefined, { stage: 'prepare', cause: errName(e), at: `${Math.round(done / MiB)}MiB` });
  }
  if (opts.signal?.aborted) throw new DomainError('CANCELLED');
  flush();
  if (done !== total) throw new DomainError('FILE_UNREADABLE', undefined, { stage: 'prepare', cause: 'short', at: `${Math.round(done / MiB)}/${Math.round(total / MiB)}MiB` });
  const copy = new Blob(parts, { type: opts.mime });
  // the browser may drop data it cannot keep without saying so: make sure both ends really come back
  try {
    const head = new Uint8Array(await copy.slice(0, Math.min(total, CHECK_BYTES)).arrayBuffer());
    const end = new Uint8Array(await copy.slice(Math.max(0, total - CHECK_BYTES)).arrayBuffer());
    if (head.length !== Math.min(total, CHECK_BYTES) || !same(end, tail)) throw new DomainError('STORE_FAILED', undefined, { stage: 'verify', cause: 'mismatch' });
  } catch (e) {
    if (e instanceof DomainError) throw e;
    throw new DomainError('STORE_FAILED', undefined, { stage: 'verify', cause: errName(e) });
  }
  return copy;
}
