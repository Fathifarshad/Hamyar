import { db, nowIso, uid } from '../../data/db';
import { deleteAsset, saveAsset, sniff } from '../../data/assets';
import { LIMITS } from '../../config/limits';
import { createStore } from '../../lib/store';
import { DomainError, type MediaItem } from '../../domain/types';

/**
 * Local video files, "play first": a file picked from the phone is played straight from where
 * it lives (the browser keeps reading it from storage), so a film of any size works without
 * being copied anywhere. Keeping a copy inside the app is a separate, optional step that only
 * small files can take.
 */

interface Picked {
  file: File;
  mime: string;
}

const picked = new Map<string, Picked>();
const versions = new Map<string, number>();

/** Bumps when a picked file is added or dropped, so lists and players re-render. */
export const pickedVersion = createStore(0);
/** Ids of videos whose copy is being written into the app right now. */
export const saving = createStore<readonly string[]>([]);

export const sessionFiles = {
  remember(id: string, file: File, mime: string = file.type) {
    picked.set(id, { file, mime });
    versions.set(id, (versions.get(id) ?? 0) + 1);
    pickedVersion.set((v) => v + 1);
  },
  recall(id: string): Picked | undefined {
    return picked.get(id);
  },
  has(id: string): boolean {
    return picked.has(id);
  },
  /** How many files were attached to this video this session (0 = none); changes when it is re-picked. */
  version(id: string): number {
    return versions.get(id) ?? 0;
  },
  forget(id: string) {
    versions.delete(id);
    if (picked.delete(id)) pickedVersion.set((v) => v + 1);
  },
};

/** The picked file as the media element should see it: with a type, even when the phone gave none. */
export function playableBlob(p: { file: Blob; mime: string }): Blob {
  return p.file.type || !p.mime ? p.file : p.file.slice(0, p.file.size, p.mime);
}

/** A stored copy as the media element should see it. */
export function storedBlob(a: { blob: Blob; mime: string; size: number }): Blob {
  return a.blob.type || !a.mime ? a.blob : a.blob.slice(0, a.size, a.mime);
}

/** Only files up to the section's limit can be copied into the app (and only if they are not empty). */
export function canKeepCopy(size: number): boolean {
  return size > 0 && size <= LIMITS.videoBytes;
}

export function titleFromFileName(name: string): string {
  const base = name.replace(/\.[a-z0-9]{2,5}$/i, '').trim();
  return (base || name).slice(0, 120);
}

export type MediaProblem = 'aborted' | 'network' | 'decode' | 'format' | 'unknown';

const PROBLEMS: Record<number, [MediaProblem, string]> = {
  1: ['aborted', 'MEDIA_ERR_ABORTED'],
  2: ['network', 'MEDIA_ERR_NETWORK'],
  3: ['decode', 'MEDIA_ERR_DECODE'],
  4: ['format', 'MEDIA_ERR_SRC_NOT_SUPPORTED'],
};

/** Classifies a <video> error and builds the technical tag shown in small print. */
export function mediaProblem(err: { code?: number; message?: string } | null | undefined): { kind: MediaProblem; tag: string } {
  const [kind, name] = PROBLEMS[err?.code ?? 0] ?? ['unknown' as MediaProblem, 'MEDIA_ERR'];
  const message = (err?.message ?? '').replace(/\s+/g, ' ').trim().slice(0, 80);
  return { kind, tag: message ? `${name} · ${message}` : name };
}

/**
 * Checks a picked file really is (or may be) a video. Throws a DomainError for an empty file, a
 * PDF or audio. If the first bytes simply cannot be read, the file is let through: the player
 * reads files by a different route and may still manage, and if it cannot, its own error
 * (with a technical code) says more than a guess made here would.
 */
async function inspect(file: File): Promise<{ mime: string }> {
  if (file.size === 0) throw new DomainError('EMPTY_FILE');
  let kind: Awaited<ReturnType<typeof sniff>>;
  try {
    kind = await sniff(file);
  } catch (e) {
    if (e instanceof DomainError && e.code === 'FILE_UNREADABLE') return { mime: file.type || 'video/mp4' };
    throw e;
  }
  const audioByType = kind.family === 'unknown' && file.type.startsWith('audio/');
  if (kind.family === 'pdf' || kind.family === 'audio' || audioByType) {
    throw new DomainError('UNSUPPORTED_MEDIA', undefined, { family: kind.family === 'pdf' ? 'pdf' : 'audio' });
  }
  // MKV, AVI, MPEG-TS… are not recognised by their first bytes; the player decides.
  return { mime: kind.family === 'unknown' ? file.type || 'video/mp4' : kind.mime };
}

export type SaveOutcome = { ok: true } | { ok: false; error: unknown };

/** Copies a picked file into the app and links it to its list entry. Safe to call twice. */
export async function keepCopy(itemId: string, file: File, mime?: string): Promise<void> {
  if (saving.get().includes(itemId)) return;
  saving.set((s) => [...s, itemId]);
  try {
    const item = await db.media.get(itemId);
    if (!item || item.assetId) return;
    const asset = await saveAsset({ moduleId: item.moduleId, kind: 'video', blob: file, name: file.name, maxBytes: LIMITS.videoBytes, mime: mime || file.type || 'video/mp4' });
    const linked = await db.media.update(itemId, { assetId: asset.id, missingFile: false });
    if (!linked) await deleteAsset(asset.id); // the video was removed while its copy was being written
  } finally {
    saving.set((s) => s.filter((x) => x !== itemId));
  }
}

export interface PickedResult {
  item: MediaItem;
  /** Present when a copy is being written into the app; resolves when that finishes. */
  saved: Promise<SaveOutcome> | null;
}

/**
 * Adds a video chosen on the phone to a Video section. The list entry exists and the file is
 * playable as soon as this resolves; the optional copy into the app continues in the background.
 */
export async function addPickedFile(moduleId: string, file: File, opts: { keepCopy: boolean }): Promise<PickedResult> {
  const { mime } = await inspect(file);
  const order = (await db.media.where('moduleId').equals(moduleId).toArray()).reduce((m, i) => Math.max(m, i.order), -1) + 1;
  const item: MediaItem = {
    id: uid(),
    moduleId,
    kind: 'video',
    sourceType: 'file',
    assetId: null,
    url: null,
    embedId: null,
    title: titleFromFileName(file.name),
    artist: '',
    favorite: false,
    order,
    position: 0,
    duration: null,
    missingFile: false,
    createdAt: nowIso(),
  };
  sessionFiles.remember(item.id, file, mime);
  try {
    await db.media.add(item);
  } catch (e) {
    sessionFiles.forget(item.id);
    throw e;
  }
  const saved = opts.keepCopy && canKeepCopy(file.size) ? keepCopy(item.id, file, mime).then((): SaveOutcome => ({ ok: true }), (error: unknown): SaveOutcome => ({ ok: false, error })) : null;
  return { item, saved };
}

/** Attaches a file picked again (after a restart) to an existing list entry. */
export async function attachPickedFile(itemId: string, file: File): Promise<void> {
  const { mime } = await inspect(file);
  sessionFiles.remember(itemId, file, mime);
}
