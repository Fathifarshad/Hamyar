import { errName } from '../../data/assets';

/**
 * Looks inside a video file (without playing it) to find out what it is: the container
 * (MP4, Matroska, AVI…), the picture and sound codecs, the size of the picture, and whether the
 * phone lets the app read the file at all. It reads a few kilobytes from the start, the middle and
 * the end, never the whole file, and never throws: whatever cannot be read is reported instead.
 *
 * Why: when a phone's browser engine says "format error" it does not say whether the file is
 * unreadable or the codec is unsupported (HEVC, for example, is common on phones). This tells the
 * two apart so the person gets the real reason, and the app picks the right fallback.
 */

export type Container = 'mp4' | 'webm' | 'mkv' | 'avi' | 'ts' | 'unknown';

export interface TrackInfo {
  /** what a browser is asked about: avc1.640028, hvc1.1.6.L93.B0, mp4a.40.2 … */
  codec: string;
  /** short name for people: H.264, HEVC (H.265), AAC … */
  label: string;
}

export interface FileProbe {
  size: number;
  /** MIME type the phone reported ('' when it gave none) */
  type: string;
  container: Container;
  /** MP4 major brand (isom, mp42, qt …), '' when not MP4 */
  brand: string;
  video: (TrackInfo & { width: number; height: number }) | null;
  audio: TrackInfo | null;
  seconds: number | null;
  /** 'ok', or the name of the error that reading ended with */
  read: { head: string; mid: string; tail: string };
}

/** What `canPlayType` says for one codec string: '' (no), 'maybe' or 'probably'. */
export type CanPlay = (codec: string) => string;

const KiB = 1024;
const HEAD_BYTES = 128 * KiB;
const SAMPLE_BYTES = 4 * KiB;
/** An MP4 "movie" index bigger than this is not worth reading just to look at it. */
const MOOV_MAX = 24 * 1024 * KiB;

const u8 = async (blob: Blob, start: number, end: number): Promise<Uint8Array> => new Uint8Array(await blob.slice(start, end).arrayBuffer());

async function tryRead(blob: Blob, start: number): Promise<string> {
  try {
    await u8(blob, start, Math.min(blob.size, start + SAMPLE_BYTES));
    return 'ok';
  } catch (e) {
    return errName(e);
  }
}

const cc = (b: Uint8Array, o: number): string => String.fromCharCode(b[o] ?? 0, b[o + 1] ?? 0, b[o + 2] ?? 0, b[o + 3] ?? 0);
const hex = (n: number, digits = 2): string => n.toString(16).toUpperCase().padStart(digits, '0');
const dv = (b: Uint8Array): DataView => new DataView(b.buffer, b.byteOffset, b.byteLength);
const latin1 = (b: Uint8Array): string => {
  let s = '';
  for (let i = 0; i < b.length; i += 8192) s += String.fromCharCode(...b.subarray(i, Math.min(b.length, i + 8192)));
  return s;
};
const hasText = (b: Uint8Array, s: string): boolean => latin1(b).includes(s);

interface Box {
  type: string;
  start: number;
  body: number;
  end: number;
}

/** The boxes (MP4 "atoms") stored one after another between two offsets of a buffer. */
function boxes(b: Uint8Array, from: number, to: number): Box[] {
  const out: Box[] = [];
  const v = dv(b);
  let o = from;
  while (o + 8 <= to && out.length < 4096) {
    let size = v.getUint32(o);
    const type = cc(b, o + 4);
    let body = o + 8;
    if (size === 1) {
      if (o + 16 > to) break;
      size = v.getUint32(o + 8) * 2 ** 32 + v.getUint32(o + 12);
      body = o + 16;
    } else if (size === 0) size = to - o;
    if (size < body - o) break;
    out.push({ type, start: o, body, end: Math.min(o + size, to) });
    o += size;
  }
  return out;
}

const child = (b: Uint8Array, parent: Box, type: string): Box | undefined => boxes(b, parent.body, parent.end).find((x) => x.type === type);

/** Position of a box tag inside a buffer, and the bytes of its payload (a cheap way to find avcC, hvcC, esds…). */
function payloadOf(b: Uint8Array, tag: string, from: number, to: number): Uint8Array | null {
  const t = [...tag].map((c) => c.charCodeAt(0));
  for (let i = from + 4; i + 4 <= to; i++) {
    if (b[i] === t[0] && b[i + 1] === t[1] && b[i + 2] === t[2] && b[i + 3] === t[3]) {
      const size = dv(b).getUint32(i - 4);
      if (size >= 8 && i - 4 + size <= to) return b.subarray(i + 4, i - 4 + size);
    }
  }
  return null;
}

function videoTrack(m: Uint8Array, entry: Box, width: number, height: number): FileProbe['video'] {
  const f = entry.type;
  const pay = (tag: string) => payloadOf(m, tag, entry.start, entry.end);
  const dims = { width, height };
  if (f === 'avc1' || f === 'avc3') {
    const c = pay('avcC');
    return { codec: c && c.length >= 4 ? `${f}.${hex(c[1]!)}${hex(c[2]!)}${hex(c[3]!)}` : `${f}.640028`, label: 'H.264', ...dims };
  }
  if (f === 'hvc1' || f === 'hev1') {
    const c = pay('hvcC');
    if (c && c.length >= 13) {
      const b1 = c[1]!;
      const space = ['', 'A', 'B', 'C'][b1 >> 6]!;
      const tier = b1 & 0x20 ? 'H' : 'L';
      let compat = 0;
      for (let i = 0; i < 32; i++) if ((dv(c).getUint32(2) >>> i) & 1) compat |= 1 << (31 - i);
      const constraints = Array.from(c.subarray(6, 12));
      while (constraints.length > 1 && constraints[constraints.length - 1] === 0) constraints.pop();
      return { codec: `${f}.${space}${b1 & 0x1f}.${(compat >>> 0).toString(16).toUpperCase()}.${tier}${c[12]}.${constraints.map((x) => hex(x)).join('.')}`, label: 'HEVC (H.265)', ...dims };
    }
    return { codec: `${f}.1.6.L93.B0`, label: 'HEVC (H.265)', ...dims };
  }
  if (f === 'dvh1' || f === 'dvhe' || f === 'dva1' || f === 'dvav') return { codec: `${f}.08.06`, label: 'Dolby Vision', ...dims };
  if (f === 'av01') {
    const c = pay('av1C');
    if (c && c.length >= 4) {
      const profile = c[1]! >> 5;
      const level = c[1]! & 0x1f;
      const bits = c[2]! & 0x40 ? (c[2]! & 0x20 ? 12 : 10) : 8;
      return { codec: `av01.${profile}.${String(level).padStart(2, '0')}${c[2]! & 0x80 ? 'H' : 'M'}.${String(bits).padStart(2, '0')}`, label: 'AV1', ...dims };
    }
    return { codec: 'av01.0.05M.08', label: 'AV1', ...dims };
  }
  if (f === 'vp09') {
    const c = pay('vpcC');
    if (c && c.length >= 8) return { codec: `vp09.${String(c[4]).padStart(2, '0')}.${String(c[5]).padStart(2, '0')}.${String(c[6]! >> 4).padStart(2, '0')}`, label: 'VP9', ...dims };
    return { codec: 'vp09.00.10.08', label: 'VP9', ...dims };
  }
  if (f === 'mp4v') return { codec: 'mp4v.20.9', label: 'MPEG-4 Visual', ...dims };
  if (f === 's263' || f === 'h263') return { codec: f, label: 'H.263', ...dims };
  return { codec: f.trim(), label: f.trim(), ...dims };
}

/** Size of one MPEG-4 descriptor length (1–4 bytes of 7 bits each). */
function descLen(b: Uint8Array, at: number): { len: number; next: number } {
  let len = 0;
  let i = at;
  for (let n = 0; n < 4 && i < b.length; n++, i++) {
    len = (len << 7) | (b[i]! & 0x7f);
    if (!(b[i]! & 0x80)) {
      i++;
      break;
    }
  }
  return { len, next: i };
}

function audioTrack(m: Uint8Array, entry: Box): TrackInfo {
  const f = entry.type;
  if (f === 'mp4a') {
    const esds = payloadOf(m, 'esds', entry.start, entry.end);
    if (esds && esds.length > 12 && esds[4] === 0x03) {
      let { next } = descLen(esds, 5);
      next += 2; // ES_ID
      const flags = esds[next++] ?? 0;
      if (flags & 0x80) next += 2;
      if (flags & 0x40) next += 1 + (esds[next] ?? 0);
      if (flags & 0x20) next += 2;
      if (esds[next] === 0x04) {
        const d = descLen(esds, next + 1);
        const oti = esds[d.next] ?? 0;
        if (oti === 0x40) {
          let aot = 2;
          let at = d.next + 13; // objectType, streamType, buffer(3), max(4), avg(4)
          if (esds[at] === 0x05) {
            at = descLen(esds, at + 1).next;
            aot = (esds[at] ?? 0) >> 3;
          }
          return { codec: `mp4a.40.${aot}`, label: aot === 2 ? 'AAC' : aot === 5 || aot === 29 ? 'HE-AAC' : 'AAC' };
        }
        if (oti === 0x6b || oti === 0x69) return { codec: 'mp3', label: 'MP3' };
        if (oti === 0xa5) return { codec: 'ac-3', label: 'AC-3 (Dolby Digital)' };
        if (oti === 0xa6) return { codec: 'ec-3', label: 'E-AC-3 (Dolby Digital Plus)' };
        if (oti >= 0xa9 && oti <= 0xac) return { codec: 'dtsc', label: 'DTS' };
      }
    }
    return { codec: 'mp4a.40.2', label: 'AAC' };
  }
  if (f === 'ac-3') return { codec: 'ac-3', label: 'AC-3 (Dolby Digital)' };
  if (f === 'ec-3') return { codec: 'ec-3', label: 'E-AC-3 (Dolby Digital Plus)' };
  if (f === 'Opus') return { codec: 'opus', label: 'Opus' };
  if (f === 'fLaC') return { codec: 'flac', label: 'FLAC' };
  if (f === '.mp3') return { codec: 'mp3', label: 'MP3' };
  if (f === 'alac') return { codec: 'alac', label: 'ALAC' };
  if (f === 'samr' || f === 'sawb') return { codec: f, label: 'AMR' };
  if (f === 'dtsc' || f === 'dtse' || f === 'dtsh' || f === 'dtsl') return { codec: 'dtsc', label: 'DTS' };
  return { codec: f.trim(), label: f.trim() };
}

interface Parsed {
  seconds: number | null;
  video: FileProbe['video'];
  audio: TrackInfo | null;
}

/** Reads the tracks out of an MP4 "moov" box (given with its own header). */
function parseMoov(m: Uint8Array): Parsed {
  const out: Parsed = { seconds: null, video: null, audio: null };
  const moov = boxes(m, 0, m.length).find((x) => x.type === 'moov');
  if (!moov) return out;
  const v = dv(m);
  const mvhd = child(m, moov, 'mvhd');
  if (mvhd) {
    const o = mvhd.body + 4;
    const ver = m[mvhd.body];
    const scale = ver === 1 ? v.getUint32(o + 16) : v.getUint32(o + 8);
    const dur = ver === 1 ? v.getUint32(o + 20) * 2 ** 32 + v.getUint32(o + 24) : v.getUint32(o + 12);
    if (scale > 0 && dur > 0) out.seconds = dur / scale;
  }
  for (const trak of boxes(m, moov.body, moov.end).filter((x) => x.type === 'trak')) {
    const mdia = child(m, trak, 'mdia');
    const hdlr = mdia && child(m, mdia, 'hdlr');
    const minf = mdia && child(m, mdia, 'minf');
    const stbl = minf && child(m, minf, 'stbl');
    const stsd = stbl && child(m, stbl, 'stsd');
    if (!hdlr || !stsd) continue;
    const kind = cc(m, hdlr.body + 8);
    const entry = boxes(m, stsd.body + 8, stsd.end)[0];
    if (!entry) continue;
    if (kind === 'vide' && !out.video) {
      const tkhd = child(m, trak, 'tkhd');
      let w = 0;
      let h = 0;
      if (tkhd && tkhd.end - 8 > tkhd.body) {
        w = Math.round(v.getUint32(tkhd.end - 8) / 65536);
        h = Math.round(v.getUint32(tkhd.end - 4) / 65536);
      }
      if (!w && entry.body + 28 <= entry.end) {
        w = v.getUint16(entry.body + 24);
        h = v.getUint16(entry.body + 26);
      }
      out.video = videoTrack(m, entry, w, h);
    } else if (kind === 'soun' && !out.audio) out.audio = audioTrack(m, entry);
  }
  return out;
}

/** Finds the "moov" box of an MP4: usually right after "ftyp", but cameras often write it after the (huge) media data. */
async function readMoov(file: Blob, head: Uint8Array): Promise<Uint8Array | null> {
  let o = 0;
  for (let guard = 0; guard < 64 && o + 8 <= file.size; guard++) {
    const h = o === 0 ? head : await u8(file, o, Math.min(file.size, o + 16));
    if (h.length < 8) return null;
    const v = dv(h);
    let size = v.getUint32(0);
    let header = 8;
    if (size === 1) {
      if (h.length < 16) return null;
      size = v.getUint32(8) * 2 ** 32 + v.getUint32(12);
      header = 16;
    } else if (size === 0) size = file.size - o;
    if (size < header) return null;
    if (cc(h, 4) === 'moov') return size > MOOV_MAX ? null : u8(file, o, Math.min(file.size, o + size));
    o += size;
  }
  return null;
}

/** MKV / WebM: the codec names are plain text near the start of the file. */
function parseEbml(head: Uint8Array): { container: 'webm' | 'mkv'; video: FileProbe['video']; audio: TrackInfo | null } {
  const text = latin1(head);
  // the DocType element (id 0x4282, then a one-byte length) holds the word "matroska" or "webm"
  const doc = /\u0042\u0082[\u0084-\u008f](matroska|webm)/.exec(text)?.[1];
  const vid = /V_(MPEG4\/ISO\/AVC|MPEGH\/ISO\/HEVC|VP8|VP9|AV1|MPEG4\/ISO\/ASP|MPEG2|MS\/VFW\/FOURCC)/.exec(text)?.[1];
  const aud = /A_(AAC|AC3|EAC3|DTS|OPUS|VORBIS|FLAC|MPEG\/L3|TRUEHD|PCM\/[A-Z/]+)/.exec(text)?.[1];
  const videoMap: Record<string, [string, string]> = {
    'MPEG4/ISO/AVC': ['avc1.640028', 'H.264'],
    'MPEGH/ISO/HEVC': ['hvc1.1.6.L120.B0', 'HEVC (H.265)'],
    VP8: ['vp8', 'VP8'],
    VP9: ['vp09.00.10.08', 'VP9'],
    AV1: ['av01.0.05M.08', 'AV1'],
    'MPEG4/ISO/ASP': ['mp4v.20.9', 'MPEG-4 Visual (Xvid/DivX)'],
    MPEG2: ['mpeg2', 'MPEG-2'],
    'MS/VFW/FOURCC': ['vfw', 'VfW (Xvid/DivX…)'],
  };
  const audioMap: Record<string, [string, string]> = {
    AAC: ['mp4a.40.2', 'AAC'],
    AC3: ['ac-3', 'AC-3 (Dolby Digital)'],
    EAC3: ['ec-3', 'E-AC-3 (Dolby Digital Plus)'],
    DTS: ['dtsc', 'DTS'],
    OPUS: ['opus', 'Opus'],
    VORBIS: ['vorbis', 'Vorbis'],
    FLAC: ['flac', 'FLAC'],
    'MPEG/L3': ['mp3', 'MP3'],
    TRUEHD: ['mlpa', 'TrueHD'],
  };
  const v = vid ? videoMap[vid] : undefined;
  const a = aud ? (audioMap[aud] ?? [aud.toLowerCase(), aud]) : undefined;
  return {
    container: doc === 'webm' ? 'webm' : 'mkv',
    video: v ? { codec: v[0], label: v[1], width: 0, height: 0 } : null,
    audio: a ? { codec: a[0], label: a[1] } : null,
  };
}

function parseAvi(head: Uint8Array): FileProbe['video'] {
  const text = latin1(head.subarray(0, 8192));
  const at = text.indexOf('vids');
  if (at < 0) return null;
  const handler = text.slice(at + 4, at + 8).replace(/[^\x20-\x7e]/g, '').trim();
  return { codec: handler || 'avi', label: handler || 'AVI', width: 0, height: 0 };
}

/** Looks inside a file. Never throws. */
export async function probeFile(file: Blob): Promise<FileProbe> {
  const probe: FileProbe = { size: file.size, type: file.type, container: 'unknown', brand: '', video: null, audio: null, seconds: null, read: { head: 'ok', mid: 'ok', tail: 'ok' } };
  let head: Uint8Array = new Uint8Array(0);
  try {
    head = await u8(file, 0, Math.min(file.size, HEAD_BYTES));
  } catch (e) {
    probe.read.head = errName(e);
  }
  probe.read.mid = await tryRead(file, Math.max(0, Math.floor(file.size / 2)));
  probe.read.tail = await tryRead(file, Math.max(0, file.size - SAMPLE_BYTES));
  if (head.length < 12) return probe;

  try {
    if (cc(head, 4) === 'ftyp') {
      probe.container = 'mp4';
      probe.brand = cc(head, 8).trim();
      const moov = await readMoov(file, head);
      if (moov) Object.assign(probe, parseMoov(moov));
    } else if (head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3) {
      Object.assign(probe, parseEbml(head));
    } else if (cc(head, 0) === 'RIFF' && cc(head, 8) === 'AVI ') {
      probe.container = 'avi';
      probe.video = parseAvi(head);
    } else if (head[0] === 0x47 && head[188] === 0x47 && head[376] === 0x47) {
      probe.container = 'ts';
    } else if (head[4] === 0x47 && head[196] === 0x47 && head[388] === 0x47) {
      probe.container = 'ts'; // M2TS (Blu-ray style, 4 extra bytes per packet)
    } else if (hasText(head.subarray(0, 4096), 'ftyp')) {
      probe.container = 'mp4';
    }
  } catch {
    // a damaged file: what was found so far is still useful
  }
  return probe;
}

export type Verdict =
  | { kind: 'unknown' }
  | { kind: 'unreadable' }
  | { kind: 'unsupported-container'; label: string }
  | { kind: 'unsupported-video'; label: string; codec: string };

/**
 * What the probe says about why a file would not play. 'unknown' means nothing in the file
 * explains it, so a different way of reading it is worth trying.
 */
export function judge(p: FileProbe, canPlay: CanPlay): Verdict {
  if (p.read.head !== 'ok') return { kind: 'unreadable' };
  if (p.container === 'avi') return { kind: 'unsupported-container', label: 'AVI' };
  if (p.container === 'ts') return { kind: 'unsupported-container', label: 'MPEG-TS' };
  // H.264 is never ruled out from here: a "no" for one H.264 profile string is not proof, and copying the file may still work.
  if (p.video && p.video.label !== 'H.264' && !canPlay(p.video.codec)) return { kind: 'unsupported-video', label: p.video.label, codec: p.video.codec };
  return { kind: 'unknown' };
}

/** `canPlayType` as a codec question: the codec is asked about inside MP4 and WebM. */
export function browserCanPlay(): CanPlay {
  const el = document.createElement('video');
  return (codec) => el.canPlayType(`video/mp4; codecs="${codec}"`) || el.canPlayType(`video/webm; codecs="${codec}"`);
}

const mb = (n: number): string => `${n >= 10 * 1024 * 1024 ? Math.round(n / 1048576) : (n / 1048576).toFixed(1)}MB`;

/** One line of small print for a screenshot: what the file is and what the browser thinks of it. */
export function probeTag(p: FileProbe, canPlay?: CanPlay): string {
  const bits = [`${p.container}${p.brand ? '/' + p.brand : ''}`];
  bits.push(p.video ? `V ${p.video.codec}${p.video.width ? ` ${p.video.width}x${p.video.height}` : ''}` : 'V -');
  bits.push(p.audio ? `A ${p.audio.codec}` : 'A -');
  bits.push(mb(p.size));
  if (p.seconds) bits.push(`${Math.round(p.seconds)}s`);
  const bad = (
    [
      ['head', p.read.head],
      ['mid', p.read.mid],
      ['tail', p.read.tail],
    ] as const
  ).filter(([, v]) => v !== 'ok');
  bits.push(bad.length ? `read ${bad.map(([k, v]) => `${k}:${v}`).join(' ')}` : 'read ok');
  if (canPlay) bits.push(`can V:${p.video ? (canPlay(p.video.codec) ? 'y' : 'n') : '-'} A:${p.audio ? (canPlay(p.audio.codec) ? 'y' : 'n') : '-'}`);
  return bits.join(' · ');
}
