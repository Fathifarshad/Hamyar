import type { ReactNode } from 'react';
import { useApp } from '../shell/AppContext';
import type { CommandDraft } from '../domain/commands/parse';
import { db } from '../data/db';
import { matchesQuery } from '../domain/normalize';
import { moduleHref, navigate } from '../shell/router';
import { toast } from '../lib/ui-store';
import { updateModule } from '../data/modules';
import type { ModuleInstance, VoiceMode } from '../domain/types';
import { MODULE_TEXT } from './registry';

/** Handles drafts every module shares (open a section, unsupported phrases). Returns true if handled. */
export function useGenericCommand() {
  const { t, locale } = useApp();
  return async (draft: CommandDraft): Promise<boolean> => {
    if (draft.kind === 'open_module') {
      const all = await db.modules.toArray();
      const target = all.find((m) => !m.archivedAt && (matchesQuery(m.title, draft.query) || matchesQuery(MODULE_TEXT[m.type].name[locale === 'fa' ? 0 : 1], draft.query)));
      if (target) {
        navigate(moduleHref(target.id));
        toast({ kind: 'success', text: t('«{title}» باز شد.', 'Opened “{title}”.', { title: target.title }) });
      } else toast({ kind: 'warning', text: t('بخشی با نام «{q}» پیدا نشد.', 'No section named “{q}”.', { q: draft.query }) });
      return true;
    }
    if (draft.kind === 'unsupported') {
      toast({
        kind: 'warning',
        text:
          draft.reason === 'empty'
            ? t('متنی دریافت نشد.', 'Nothing was heard.')
            : draft.reason === 'not_allowed_here'
              ? t('این بخش فقط دیکته متن را می‌پذیرد.', 'This section accepts dictation only.')
              : t('این فرمان پشتیبانی نمی‌شود. متن شما در کادر باقی ماند.', 'That command is not supported. Your text is kept in the box.'),
      });
      return true;
    }
    return false;
  };
}

export function useVoiceMode(mod: ModuleInstance) {
  return {
    mode: mod.voiceMode,
    setMode: (m: VoiceMode) => void updateModule(mod.id, { voiceMode: m }),
  };
}

export function examplesFor(mod: ModuleInstance, locale: 'fa' | 'en'): string[] {
  const ex = MODULE_TEXT[mod.type].examples;
  if (!ex) return [];
  return mod.inputLanguage === 'fa-IR' ? ex.fa : ex.en.length ? ex.en : locale === 'fa' ? ex.fa : ex.en;
}

export function SectionTitle({ children, action, count }: { children: ReactNode; action?: ReactNode; count?: number }) {
  const { num } = useApp();
  return (
    <div className="sec-title">
      <h3>
        {children}
        {count !== undefined && <span className="sec-count">{num(count)}</span>}
      </h3>
      {action}
    </div>
  );
}

export function MoreLink({ mod, count }: { mod: ModuleInstance; count: number }) {
  const { t } = useApp();
  if (count <= 0) return null;
  return (
    <a className="more-link" href={moduleHref(mod.id)}>
      {t('{n} مورد دیگر در نمای کامل', '{n} more in full view', { n: count })}
    </a>
  );
}
