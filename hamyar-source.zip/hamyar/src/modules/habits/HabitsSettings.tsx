import { useApp } from '../../shell/AppContext';
import type { ModuleSettingsProps } from '../registry';
import { Field, Input, Switch } from '../../ui/primitives';

export default function HabitsSettings({ config, onChange }: ModuleSettingsProps) {
  const { t } = useApp();
  return (
    <div className="stack-sm">
      <Switch checked={config.showWater !== false} onChange={(showWater) => onChange({ showWater })} label={t('نمایش شمارنده آب', 'Show the water counter')} />
      <Field label={t('هدف روزانه آب (لیوان)', 'Daily water goal (glasses)')}>
        <Input type="number" min={1} max={30} value={Number(config.waterGoal ?? 8)} onChange={(e) => onChange({ waterGoal: Number(e.target.value) })} />
      </Field>
    </div>
  );
}
