import { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { Habit, HabitLog, WaterLog } from '../../domain/types';
import { Button, EmptyState, IconButton, Input } from '../../ui/primitives';
import { VoiceInput } from '../../ui/VoiceInput';
import { Archive, Droplet, Flame, Minus, Pencil, Plus, TrashIcon, Sparkles } from '../../ui/icons';
import { addDaysISO } from '../../domain/time';
import { parseCommand } from '../../domain/commands/parse';
import { matchesQuery } from '../../domain/normalize';
import { useGenericCommand, useVoiceMode, examplesFor } from '../shared';
import { askConfirm, askText, toast } from '../../lib/ui-store';

export async function addWater(moduleId: string, date: string, delta: number) {
  await db.transaction('rw', db.water, async () => {
    const id = `${moduleId}|${date}`;
    const cur = await db.water.get(id);
    const count = Math.max(0, Math.min(40, (cur?.count ?? 0) + delta));
    await db.water.put({ id, moduleId, date, count });
  });
}

export function streakFor(habitId: string, logs: Set<string>, today: string): number {
  let d = logs.has(`${habitId}|${today}`) ? today : addDaysISO(today, -1);
  let n = 0;
  while (logs.has(`${habitId}|${d}`) && n < 3650) {
    n++;
    d = addDaysISO(d, -1);
  }
  return n;
}

function WaterPanel({ moduleId, goal, water, days, compact }: { moduleId: string; goal: number; water: WaterLog[]; days: string[]; compact: boolean }) {
  const { t, today, num, date } = useApp();
  const byDate = new Map(water.map((w) => [w.date, w.count]));
  const count = byDate.get(today) ?? 0;
  const max = Math.max(goal, ...days.map((d) => byDate.get(d) ?? 0), 1);
  const pct = Math.min(1, count / goal);
  return (
    <div className="water">
      <div className="water-top">
        <div className="water-meter" role="meter" aria-valuemin={0} aria-valuemax={goal} aria-valuenow={count} aria-label={t('لیوان آب امروز', 'Glasses of water today')}>
          <div className="water-fill" style={{ blockSize: `${pct * 100}%` }} />
          <Droplet size={18} aria-hidden="true" className="water-icon" />
        </div>
        <div className="grow">
          <div className="water-count">
            <span className="num">{num(count)}</span>
            <span className="subtle"> / {num(goal)}</span>
          </div>
          <div className="subtle small">{count >= goal ? t('هدف امروز کامل شد', 'Today’s goal reached') : t('لیوان آب امروز', 'glasses of water today')}</div>
        </div>
        <IconButton label={t('یک لیوان کمتر', 'One glass less')} variant="soft" onClick={() => void addWater(moduleId, today, -1)} disabled={count === 0}>
          <Minus size={17} />
        </IconButton>
        <IconButton label={t('یک لیوان آب', 'One glass of water')} variant="accent" onClick={() => void addWater(moduleId, today, 1)}>
          <Plus size={18} />
        </IconButton>
      </div>
      {!compact && (
        <div className="mini-cols" role="img" aria-label={t('آب ۷ روز گذشته', 'Water over the last 7 days')}>
          {days.map((d) => {
            const v = byDate.get(d) ?? 0;
            return (
              <div key={d} className={`mini-col${d === today ? ' is-today' : ''}`} title={`${date(d, 'short')}: ${num(v)}`}>
                <div className="mini-col-track">
                  <div className="mini-col-bar" style={{ blockSize: `${(v / max) * 100}%` }} />
                </div>
                <span className="mini-col-label">{date(d, 'weekday').slice(0, 1)}</span>
              </div>
            );
          })}
          <ul className="visually-hidden">
            {days.map((d) => (
              <li key={d}>
                {date(d, 'short')}: {num(byDate.get(d) ?? 0)}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default function HabitsModule({ mod, variant }: ModuleViewProps) {
  const { t, today, tz, num, date, locale, bidi } = useApp();
  const habits = useLiveQuery(() => db.habits.where('moduleId').equals(mod.id).sortBy('order'), [mod.id]);
  const logs = useLiveQuery(() => db.habitLogs.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const water = useLiveQuery(() => db.water.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const [name, setName] = useState('');
  const [voice, setVoice] = useState('');
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);
  const days = useMemo(() => Array.from({ length: 7 }, (_, i) => addDaysISO(today, i - 6)), [today]);
  const logSet = useMemo(() => new Set((logs ?? []).map((l: HabitLog) => l.id)), [logs]);
  const goal = Number(mod.config.waterGoal ?? 8);
  const showWater = mod.config.showWater !== false;

  const toggle = async (h: Habit, d: string) => {
    const id = `${h.id}|${d}`;
    if (logSet.has(id)) await db.habitLogs.delete(id);
    else await db.habitLogs.put({ id, habitId: h.id, moduleId: mod.id, date: d });
  };

  const addHabit = async (n: string) => {
    if (!n.trim()) return;
    const order = (habits ?? []).length;
    await db.habits.add({ id: uid(), moduleId: mod.id, name: n.trim().slice(0, 60), order, archived: false, createdAt: nowIso() });
    setName('');
  };

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'habits', now: Date.now(), timezone: tz });
    if (d.kind === 'water_add') {
      await addWater(mod.id, today, d.count);
      toast({ kind: 'success', text: t('{n} لیوان آب ثبت شد.', '{n} glass(es) of water added.', { n: d.count }) });
      return;
    }
    if (d.kind === 'habit_check') {
      const h = (habits ?? []).find((x) => !x.archived && matchesQuery(x.name, d.query));
      if (!h) return void toast({ kind: 'warning', text: t('عادتی با «{q}» پیدا نشد.', 'No habit matches “{q}”.', { q: d.query }) });
      const ok = await askConfirm({ title: t('ثبت «{n}» برای امروز؟', 'Mark “{n}” done today?', { n: h.name }), confirmText: t('ثبت', 'Mark'), cancelText: t('انصراف', 'Cancel') });
      if (ok && !logSet.has(`${h.id}|${today}`)) await toggle(h, today);
      return;
    }
    await generic(d);
  };

  if (!habits || !logs || !water) return <div className="mod-loading" />;
  const active = habits.filter((h) => !h.archived);
  const compact = variant === 'card' && mod.appearance.density === 'compact';

  return (
    <div className="stack">
      {showWater && <WaterPanel moduleId={mod.id} goal={goal} water={water} days={days} compact={compact} />}
      {(variant === 'full' || mode === 'command') && (
        <VoiceInput
          value={voice}
          onChange={setVoice}
          lang={mod.inputLanguage}
          ownerId={`habits-${mod.id}-${variant}`}
          inputLabel={t('فرمان', 'Command')}
          placeholder={t('«یک لیوان آب» یا «ورزش انجام شد»', '“one glass of water” or “exercise done”')}
          mode={mode}
          onModeChange={setMode}
          onCommand={(s) => void onCommand(s)}
          onSubmit={(s) => void onCommand(s)}
          submitLabel={t('اجرا', 'Run')}
          examples={examplesFor(mod, locale)}
        />
      )}
      {active.length === 0 ? (
        <EmptyState icon={<Sparkles size={22} />} title={t('عادتی تعریف نشده', 'No habits yet')} text={t('مثلاً «ورزش»، «مطالعه ۲۰ دقیقه» یا «پیاده‌روی».', 'For example “Exercise”, “Read 20 minutes” or “Walk”.')} />
      ) : (
        <ul className="habit-list">
          {active.map((h) => {
            const streak = streakFor(h.id, logSet, today);
            const doneToday = logSet.has(`${h.id}|${today}`);
            return (
              <li key={h.id} className="habit">
                <button type="button" className={`check${doneToday ? ' is-on' : ''}`} role="checkbox" aria-checked={doneToday} aria-label={t('امروز: {n}', 'Today: {n}', { n: h.name })} onClick={() => void toggle(h, today)}>
                  <span />
                </button>
                <div className="habit-main">
                  <span className="row-title auto-dir" dir={bidi(h.name)}>{h.name}</span>
                  {streak > 0 && (
                    <span className="streak" title={t('روزهای پشت‌سرهم', 'Days in a row')}>
                      <Flame size={12} aria-hidden="true" /> {num(streak)}
                    </span>
                  )}
                </div>
                <div className="habit-days" aria-label={t('۷ روز اخیر', 'Last 7 days')}>
                  {days.map((d) => (
                    <button
                      key={d}
                      type="button"
                      className={`habit-day${logSet.has(`${h.id}|${d}`) ? ' is-on' : ''}${d === today ? ' is-today' : ''}`}
                      aria-pressed={logSet.has(`${h.id}|${d}`)}
                      aria-label={`${h.name} — ${date(d, 'short')}`}
                      title={date(d, 'short')}
                      onClick={() => void toggle(h, d)}
                    />
                  ))}
                </div>
                {variant === 'full' && (
                  <div className="row-actions">
                    <IconButton
                      label={t('تغییر نام', 'Rename')}
                      size="sm"
                      onClick={async () => {
                        const v = await askText({ title: t('نام عادت', 'Habit name'), label: t('نام', 'Name'), initial: h.name, confirmText: t('ذخیره', 'Save'), cancelText: t('انصراف', 'Cancel'), maxLength: 60 });
                        if (v?.trim()) await db.habits.update(h.id, { name: v.trim() });
                      }}
                    >
                      <Pencil size={15} />
                    </IconButton>
                    <IconButton label={t('بایگانی', 'Archive')} size="sm" onClick={() => void db.habits.update(h.id, { archived: true })}>
                      <Archive size={15} />
                    </IconButton>
                    <IconButton
                      label={t('حذف', 'Delete')}
                      size="sm"
                      onClick={async () => {
                        const ok = await askConfirm({ title: t('حذف «{n}» و سابقه‌اش؟', 'Delete “{n}” and its history?', { n: h.name }), confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
                        if (!ok) return;
                        await db.transaction('rw', db.habits, db.habitLogs, async () => {
                          await db.habitLogs.where('habitId').equals(h.id).delete();
                          await db.habits.delete(h.id);
                        });
                      }}
                    >
                      <TrashIcon size={15} />
                    </IconButton>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
      <form
        className="row-flex"
        onSubmit={(e) => {
          e.preventDefault();
          void addHabit(name);
        }}
      >
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={t('عادت جدید…', 'New habit…')} aria-label={t('عادت جدید', 'New habit')} maxLength={60} />
        <Button type="submit" variant="soft" icon={<Plus size={15} />} disabled={!name.trim()}>
          {t('افزودن', 'Add')}
        </Button>
      </form>
      {variant === 'full' && habits.some((h) => h.archived) && (
        <div className="stack-sm">
          <h3 className="sec-title-plain">{t('بایگانی', 'Archived')}</h3>
          {habits
            .filter((h) => h.archived)
            .map((h) => (
              <div key={h.id} className="row-flex">
                <span className="grow auto-dir" dir={bidi(h.name)}>{h.name}</span>
                <Button size="sm" variant="ghost" onClick={() => void db.habits.update(h.id, { archived: false })}>
                  {t('بازگردانی', 'Restore')}
                </Button>
              </div>
            ))}
        </div>
      )}
    </div>
  );
}
