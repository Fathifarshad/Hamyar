import { useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import { buildTaskViews, setCompleted, weekOccurrences, type TaskOcc } from './data';
import { TaskForm, emptyTaskInput } from './TaskForm';
import { TaskPreview } from './TaskPreview';
import { VoiceInput } from '../../ui/VoiceInput';
import { parseCommand, type CommandDraft } from '../../domain/commands/parse';
import { useGenericCommand, useVoiceMode, examplesFor, SectionTitle, MoreLink } from '../shared';
import { Button, EmptyState, IconButton, Tabs } from '../../ui/primitives';
import { Bell, CalendarCheck2, ChevronLeft, ChevronRight, Plus, Repeat, TriangleAlert } from '../../ui/icons';
import type { Task } from '../../domain/types';
import { addDaysISO, weekdayOfISO } from '../../domain/time';
import { currentRule } from '../../domain/recurrence';

type Tab = 'today' | 'upcoming' | 'overdue' | 'undated' | 'done' | 'week';

function TaskRow({ item, onEdit, compact }: { item: TaskOcc; onEdit: (t: Task) => void; compact?: boolean }) {
  const { t, time, relDay, today, bidi } = useApp();
  const { task, occ, done, late } = item;
  const rule = currentRule(task.revisions);
  const recurring = rule && rule.freq !== 'once';
  const label = done ? t('بازگشایی «{title}»', 'Reopen “{title}”', { title: task.title }) : t('انجام شد: «{title}»', 'Mark “{title}” done', { title: task.title });
  return (
    <li className={`row task-row${done ? ' is-done' : ''}${late ? ' is-late' : ''} prio-${task.priority}`}>
      <button type="button" className={`check${done ? ' is-on' : ''}`} role="checkbox" aria-checked={done} aria-label={label} onClick={() => void setCompleted(task, item.key, !done)}>
        <span />
      </button>
      <button type="button" className="row-main" onClick={() => onEdit(task)}>
        <span className="row-title auto-dir" dir={bidi(task.title)}>{task.title}</span>
        <span className="row-meta">
          {occ && occ.date !== today && <span>{relDay(occ.date)}</span>}
          {occ?.time && <span className="num">{time(occ.time)}</span>}
          {task.kind === 'event' && <span className="tag">{t('قرار', 'Appt')}</span>}
          {recurring && <Repeat size={13} aria-label={t('تکرارشونده', 'Repeats')} />}
          {task.reminderOffset !== null && occ?.time && !compact && <Bell size={13} aria-label={t('یادآوری دارد', 'Has reminder')} />}
          {late && (
            <span className="late-tag">
              <TriangleAlert size={12} aria-hidden="true" />
              {t('گذشته', 'Overdue')}
            </span>
          )}
        </span>
      </button>
    </li>
  );
}

function WeekView({ tasks, completions, onEdit }: { tasks: Task[]; completions: Parameters<typeof weekOccurrences>[1]; onEdit: (t: Task) => void }) {
  const { today, now, locale, t, date, dig, bidi } = useApp();
  const weekStart = locale === 'fa' ? 6 : 1;
  const [offset, setOffset] = useState(0);
  const start = addDaysISO(today, -((weekdayOfISO(today) - weekStart + 7) % 7) + offset * 7);
  const map = useMemo(() => weekOccurrences(tasks, completions, start, now), [tasks, completions, start, now]);
  const Prev = locale === 'fa' ? ChevronRight : ChevronLeft;
  const Next = locale === 'fa' ? ChevronLeft : ChevronRight;
  return (
    <div className="week">
      <div className="week-head">
        <IconButton label={t('هفته قبل', 'Previous week')} size="sm" onClick={() => setOffset((o) => o - 1)}>
          <Prev size={18} />
        </IconButton>
        <span className="week-range">
          {date(start, 'short')} – {date(addDaysISO(start, 6), 'short')}
        </span>
        <IconButton label={t('هفته بعد', 'Next week')} size="sm" onClick={() => setOffset((o) => o + 1)}>
          <Next size={18} />
        </IconButton>
        {offset !== 0 && (
          <Button size="sm" variant="ghost" onClick={() => setOffset(0)}>
            {t('این هفته', 'This week')}
          </Button>
        )}
      </div>
      <div className="week-grid">
        {[...map.entries()].map(([iso, items]) => (
          <div key={iso} className={`week-day${iso === today ? ' is-today' : ''}`}>
            <div className="week-day-head">
              <span>{date(iso, 'weekday')}</span>
              <span className="num">{dig(date(iso, 'short').split(' ')[0] ?? '')}</span>
            </div>
            <ul className="week-items">
              {items.length === 0 && <li className="subtle xsmall">—</li>}
              {items.map((it) => (
                <li key={`${it.task.id}|${it.key}`}>
                  <button type="button" className={`week-item${it.done ? ' is-done' : ''}`} onClick={() => onEdit(it.task)}>
                    {it.occ?.time && <span className="num">{dig(it.occ.time)}</span>}
                    <span className="auto-dir" dir={bidi(it.task.title)}>{it.task.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function TasksModule({ mod, variant }: ModuleViewProps) {
  const { t, today, now, tz, locale } = useApp();
  const tasks = useLiveQuery(() => db.tasks.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const completions = useLiveQuery(() => db.taskCompletions.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const views = useMemo(() => buildTaskViews(tasks ?? [], completions ?? [], { today, now }), [tasks, completions, today, now]);
  const [text, setText] = useState('');
  const [draft, setDraft] = useState<Extract<CommandDraft, { kind: 'create_task' }> | null>(null);
  const [form, setForm] = useState<{ open: boolean; task: Task | null; initial?: Partial<ReturnType<typeof emptyTaskInput>> }>({ open: false, task: null });
  const [tab, setTab] = useState<Tab>((mod.config.view as Tab) ?? 'today');
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);

  const handle = async (input: string) => {
    const d = parseCommand(input, { moduleType: 'tasks', now: Date.now(), timezone: tz });
    if (await generic(d)) return;
    if (d.kind === 'create_task') setDraft(d);
  };

  const edit = (task: Task) => setForm({ open: true, task });

  if (!tasks || !completions) return <div className="mod-loading" />;

  const quickAdd = (
    <VoiceInput
      value={text}
      onChange={setText}
      lang={mod.inputLanguage}
      ownerId={`tasks-${mod.id}-${variant}`}
      inputLabel={t('افزودن کار یا قرار', 'Add a task or appointment')}
      placeholder={t('کار یا قرار… مثلاً «فردا ساعت ۹ صبح جلسه تیم»', 'Task or appointment… e.g. “tomorrow at 9am team meeting”')}
      mode={mode}
      onModeChange={setMode}
      onCommand={(s) => void handle(s)}
      onSubmit={(s) => void handle(s)}
      submitLabel={t('بررسی و ثبت', 'Review and save')}
      examples={examplesFor(mod, locale)}
      maxLength={300}
    />
  );

  const dialogs = (
    <>
      <TaskPreview
        mod={mod}
        draft={draft}
        onClose={() => setDraft(null)}
        onDone={() => {
          setDraft(null);
          setText('');
        }}
        onEditFull={(d) => {
          setDraft(null);
          setForm({ open: true, task: null, initial: { title: d.title, date: d.date, time: d.time, kind: d.time ? 'event' : 'task' } });
        }}
      />
      <TaskForm mod={mod} open={form.open} task={form.task} initial={form.initial} onClose={() => setForm({ open: false, task: null })} />
    </>
  );

  if (variant === 'card') {
    const max = mod.appearance.density === 'compact' ? 6 : 4;
    const todayItems = views.today;
    const shown = todayItems.slice(0, max);
    const nextUp = views.upcoming.slice(0, 2);
    const total = (tasks ?? []).length;
    return (
      <div className="stack">
        {quickAdd}
        {views.overdue.length > 0 && (
          <a className="overdue-pill" href={`#/m/${mod.id}`}>
            <TriangleAlert size={14} aria-hidden="true" />
            {t('{n} کار عقب‌افتاده', '{n} overdue', { n: views.overdue.length })}
          </a>
        )}
        {total === 0 ? (
          <EmptyState
            icon={<CalendarCheck2 size={22} />}
            title={t('هنوز کاری ثبت نشده', 'No tasks yet')}
            text={t('بنویسید یا با میکروفن بگویید؛ پیش از ثبت، تاریخ و ساعت را می‌بینید.', 'Type or say it; you’ll see the date and time before saving.')}
          />
        ) : (
          <>
            <SectionTitle count={todayItems.length}>{t('امروز', 'Today')}</SectionTitle>
            {todayItems.length === 0 ? (
              <p className="subtle small">{t('برای امروز کاری نیست.', 'Nothing for today.')}</p>
            ) : (
              <ul className="rows">
                {shown.map((it) => (
                  <TaskRow key={`${it.task.id}|${it.key}`} item={it} onEdit={edit} compact />
                ))}
              </ul>
            )}
            <MoreLink mod={mod} count={todayItems.length - shown.length} />
            {nextUp.length > 0 && (
              <>
                <SectionTitle>{t('بعدی', 'Next')}</SectionTitle>
                <ul className="rows">
                  {nextUp.map((it) => (
                    <TaskRow key={`${it.task.id}|${it.key}`} item={it} onEdit={edit} compact />
                  ))}
                </ul>
              </>
            )}
          </>
        )}
        {dialogs}
      </div>
    );
  }

  const lists: Record<Exclude<Tab, 'week'>, TaskOcc[]> = {
    today: views.today,
    upcoming: views.upcoming,
    overdue: views.overdue,
    undated: views.undated,
    done: views.done,
  };
  const emptyText: Record<Exclude<Tab, 'week'>, string> = {
    today: t('برای امروز کاری نیست.', 'Nothing for today.'),
    upcoming: t('در ۷ روز آینده کاری نیست.', 'Nothing in the next 7 days.'),
    overdue: t('کار عقب‌افتاده‌ای ندارید.', 'Nothing overdue.'),
    undated: t('کار بدون تاریخ ندارید.', 'No undated tasks.'),
    done: t('در ۷ روز گذشته کاری انجام نشده.', 'Nothing completed in the last 7 days.'),
  };
  return (
    <div className="stack">
      <div className="full-toolbar">
        <div className="grow">{quickAdd}</div>
        <Button variant="accent" icon={<Plus size={16} />} onClick={() => setForm({ open: true, task: null, initial: { date: today } })}>
          {t('فرم کامل', 'Full form')}
        </Button>
      </div>
      <Tabs
        label={t('نمای کارها', 'Task views')}
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'today', label: t('امروز', 'Today'), count: views.today.filter((x) => !x.done).length },
          { value: 'upcoming', label: t('آینده', 'Upcoming'), count: views.upcoming.length },
          { value: 'overdue', label: t('عقب‌افتاده', 'Overdue'), count: views.overdue.length },
          { value: 'undated', label: t('بدون تاریخ', 'No date'), count: views.undated.length },
          { value: 'done', label: t('انجام‌شده', 'Done') },
          { value: 'week', label: t('هفته', 'Week') },
        ]}
      />
      {tab === 'week' ? (
        <WeekView tasks={tasks} completions={completions} onEdit={edit} />
      ) : lists[tab].length === 0 ? (
        <EmptyState icon={<CalendarCheck2 size={22} />} title={emptyText[tab]} />
      ) : (
        <ul className="rows">
          {lists[tab].map((it) => (
            <TaskRow key={`${it.task.id}|${it.key}|${tab}`} item={it} onEdit={edit} />
          ))}
        </ul>
      )}
      {tab === 'overdue' && views.overdue.length > 0 && (
        <p className="subtle xsmall">{t('عقب‌افتاده یعنی موعد گذشته و هنوز انجام نشده؛ هیچ کاری خودکار «انجام‌شده» نمی‌شود.', 'Overdue means the time passed and it is not done; nothing is marked done automatically.')}</p>
      )}
      {dialogs}
    </div>
  );
}
