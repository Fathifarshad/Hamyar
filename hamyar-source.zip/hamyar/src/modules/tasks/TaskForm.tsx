import { useEffect, useMemo, useState } from 'react';
import { useApp } from '../../shell/AppContext';
import { Button, Field, Modal, Notice, Segmented, Select } from '../../ui/primitives';
import { DatePicker } from '../../ui/DatePicker';
import { VoiceInput } from '../../ui/VoiceInput';
import { createTask, deleteTask, inputFromTask, updateTask, validateTaskInput, type TaskInput } from './data';
import type { ModuleInstance, Task } from '../../domain/types';
import { uid } from '../../data/db';
import { askConfirm, toast } from '../../lib/ui-store';
import { errorText } from '../../i18n/errors';
import { CalendarPlus, Info, TrashIcon, TriangleAlert } from '../../ui/icons';
import { saveCalendar, taskCalendarEvents } from '../../lib/ics';
import { IS_ARTIFACT, IS_NATIVE } from '../../lib/platform';
import { WEEKDAYS_FA, WEEKDAYS_EN } from '../../domain/jalali';
import { listTimeZones, resolveZoned } from '../../domain/time';

export function emptyTaskInput(tz: string, date: string | null = null): TaskInput {
  return { title: '', notes: '', kind: 'task', priority: 'normal', date, time: null, timezone: tz, repeat: 'once', weekdays: [], until: null, reminderOffset: 0 };
}

export const REMINDER_OPTIONS = [null, 0, 5, 15, 30, 60] as const;

export function reminderLabel(v: number | null, t: (fa: string, en: string, p?: Record<string, number>) => string): string {
  if (v === null) return t('بدون یادآوری', 'No reminder');
  if (v === 0) return t('در زمان موعد', 'At the time');
  return t('{n} دقیقه قبل', '{n} min before', { n: v });
}

export function TaskForm({
  mod,
  open,
  onClose,
  task,
  initial,
}: {
  mod: ModuleInstance;
  open: boolean;
  onClose: () => void;
  task?: Task | null;
  initial?: Partial<TaskInput>;
}) {
  const { t, tz, locale, time, today } = useApp();
  const base = useMemo(() => (task ? inputFromTask(task, tz) : { ...emptyTaskInput(tz), ...initial }), [task, tz, initial]);
  const [v, setV] = useState<TaskInput>(base);
  const [busy, setBusy] = useState(false);
  const [tried, setTried] = useState(false);
  const idem = useMemo(() => uid(), [open]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (open) {
      setV(base);
      setTried(false);
    }
  }, [open, base]);
  const errors = validateTaskInput(v);
  const set = (patch: Partial<TaskInput>) => setV((x) => ({ ...x, ...patch }));
  const dirty = JSON.stringify(v) !== JSON.stringify(base);
  const weekdays = locale === 'fa' ? [6, 0, 1, 2, 3, 4, 5] : [0, 1, 2, 3, 4, 5, 6];
  const names = locale === 'fa' ? WEEKDAYS_FA : WEEKDAYS_EN;
  const dstNote = v.date && v.time ? resolveZoned(v.date, v.time, v.timezone) : null;
  const isPast = v.repeat === 'once' && dstNote ? dstNote.utc < Date.now() : false;
  const zones = useMemo(() => listTimeZones(), []);

  const close = async () => {
    if (dirty && !busy) {
      const ok = await askConfirm({
        title: t('تغییرات ذخیره نشده‌اند', 'Unsaved changes'),
        body: t('اگر ببندید، تغییرات این فرم از بین می‌رود.', 'If you close, the changes in this form are lost.'),
        confirmText: t('بستن بدون ذخیره', 'Discard'),
        cancelText: t('ادامه ویرایش', 'Keep editing'),
      });
      if (!ok) return;
    }
    onClose();
  };

  const save = async () => {
    setTried(true);
    if (Object.keys(errors).length) return;
    setBusy(true);
    try {
      if (task) await updateTask(task.id, v);
      else await createTask(mod.id, v, idem);
      toast({ kind: 'success', text: task ? t('تغییرات ذخیره شد.', 'Changes saved.') : t('ثبت شد.', 'Saved.') });
      onClose();
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!task) return;
    const ok = await askConfirm({
      title: t('حذف «{title}»؟', 'Delete “{title}”?', { title: task.title }),
      body: t('این کار و یادآوری‌های آینده‌اش حذف می‌شود.', 'This task and its future reminders will be deleted.'),
      confirmText: t('حذف', 'Delete'),
      cancelText: t('انصراف', 'Cancel'),
      danger: true,
    });
    if (!ok) return;
    await deleteTask(task.id);
    toast({ kind: 'success', text: t('حذف شد.', 'Deleted.') });
    onClose();
  };

  const err = (k: string) => (tried && errors[k] ? errorFor(k, errors[k]!, t) : undefined);

  return (
    <Modal
      open={open}
      onClose={() => void close()}
      title={task ? t('ویرایش کار', 'Edit task') : t('کار یا قرار جدید', 'New task or appointment')}
      closeLabel={t('بستن', 'Close')}
      footer={
        <>
          {task && (
            <Button variant="danger" icon={<TrashIcon size={15} />} onClick={() => void remove()} className="me-auto">
              {t('حذف', 'Delete')}
            </Button>
          )}
          {task && task.revisions && !IS_NATIVE && !IS_ARTIFACT && (
            <Button
              variant="ghost"
              icon={<CalendarPlus size={15} />}
              onClick={async () => {
                const r = await saveCalendar('hamyar-task.ics', taskCalendarEvents(task, today, locale === 'fa'));
                toast({
                  kind: r === 'saved' ? 'success' : 'warning',
                  text: r === 'saved' ? t('فایل تقویم آماده شد؛ آن را باز کنید تا به تقویم گوشی اضافه شود.', 'Calendar file ready; open it to add this to the phone calendar.') : t('فایل تقویم ساخته نشد.', 'The calendar file could not be created.'),
                });
              }}
            >
              {t('به تقویم گوشی', 'To phone calendar')}
            </Button>
          )}
          <Button variant="ghost" onClick={() => void close()}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" busy={busy} onClick={() => void save()}>
            {task ? t('ذخیره تغییرات', 'Save changes') : t('ثبت', 'Save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" data-accent={mod.appearance.accent}>
        <Field label={t('عنوان', 'Title')} error={err('title')}>
          <VoiceInput
            value={v.title}
            onChange={(title) => set({ title })}
            lang={mod.inputLanguage}
            ownerId={`task-form-title-${mod.id}`}
            inputLabel={t('عنوان', 'Title')}
            placeholder={t('مثلاً تماس با دندانپزشک', 'e.g. Call the dentist')}
            maxLength={200}
          />
        </Field>
        <Segmented
          label={t('نوع', 'Type')}
          value={v.kind}
          onChange={(kind) => set({ kind })}
          options={[
            { value: 'task', label: t('کار با موعد', 'Task with due time') },
            { value: 'event', label: t('قرار با زمان شروع', 'Appointment') },
          ]}
        />
        <div className="form-row">
          <Field label={t('تاریخ', 'Date')} error={err('date')}>
            <DatePicker value={v.date} onChange={(date) => set({ date, ...(date ? {} : { time: null, repeat: 'once' }) })} label={t('تاریخ', 'Date')} allowClear />
          </Field>
          <Field label={t('ساعت', 'Time')} error={err('time')} hint={!v.time ? t('بدون ساعت: یادآوری زمان‌دار ندارد', 'No time: no timed reminder') : undefined}>
            <div className="row-flex">
              <input
                type="time"
                className="input"
                value={v.time ?? ''}
                onChange={(e) => set({ time: e.target.value || null })}
                disabled={!v.date}
                aria-label={t('ساعت', 'Time')}
              />
              {v.time && (
                <Button size="sm" variant="ghost" onClick={() => set({ time: null })}>
                  {t('بدون ساعت', 'No time')}
                </Button>
              )}
            </div>
          </Field>
        </div>
        {isPast && (
          <Notice tone="warn" icon={<TriangleAlert size={16} />}>
            {t('این زمان گذشته است. اگر اشتباه است، تاریخ یا ساعت را اصلاح کنید.', 'This time has already passed. Fix the date or time if that is a mistake.')}
          </Notice>
        )}
        {v.date && (
          <>
            <Field label={t('تکرار', 'Repeat')}>
              <Segmented
                label={t('تکرار', 'Repeat')}
                value={v.repeat}
                onChange={(repeat) => set({ repeat, weekdays: repeat === 'weekly' && !v.weekdays.length && v.date ? [new Date(`${v.date}T12:00:00Z`).getUTCDay()] : v.weekdays })}
                options={[
                  { value: 'once', label: t('یک‌بار', 'Once') },
                  { value: 'daily', label: t('هر روز', 'Daily') },
                  { value: 'weekly', label: t('روزهای هفته', 'Weekdays') },
                ]}
              />
            </Field>
            {v.repeat === 'weekly' && (
              <Field label={t('روزها', 'Days')} error={err('weekdays')}>
                <div className="day-chips">
                  {weekdays.map((d) => (
                    <button
                      key={d}
                      type="button"
                      className={`day-chip${v.weekdays.includes(d) ? ' is-on' : ''}`}
                      aria-pressed={v.weekdays.includes(d)}
                      onClick={() => set({ weekdays: v.weekdays.includes(d) ? v.weekdays.filter((x) => x !== d) : [...v.weekdays, d] })}
                    >
                      {names[d]}
                    </button>
                  ))}
                </div>
              </Field>
            )}
            {v.repeat !== 'once' && (
              <Field label={t('پایان تکرار (اختیاری)', 'End repeat (optional)')} error={err('until')}>
                <DatePicker value={v.until} onChange={(until) => set({ until })} label={t('پایان تکرار', 'End repeat')} allowClear placeholder={t('بدون پایان', 'Never')} />
              </Field>
            )}
          </>
        )}
        {v.time && (
          <div className="form-row">
            <Field label={t('یادآوری', 'Reminder')}>
              <Select value={v.reminderOffset === null ? 'none' : String(v.reminderOffset)} onChange={(e) => set({ reminderOffset: e.target.value === 'none' ? null : Number(e.target.value) })}>
                {REMINDER_OPTIONS.map((o) => (
                  <option key={String(o)} value={o === null ? 'none' : String(o)}>
                    {reminderLabel(o, t)}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label={t('منطقه زمانی', 'Time zone')}>
              <Select value={v.timezone} onChange={(e) => set({ timezone: e.target.value })} className="ltr">
                {zones.map((z) => (
                  <option key={z} value={z}>
                    {z}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
        )}
        {v.time && v.repeat !== 'once' && (
          <Notice tone="neutral" icon={<Info size={16} />}>
            {t(
              'اگر به‌خاطر ساعت تابستانی این زمان در روزی وجود نداشته باشد، اولین زمان معتبر بعد از آن استفاده می‌شود و اگر دو بار تکرار شود، فقط بار اول.',
              'If daylight saving skips this time on a day, the first valid time after it is used; if it repeats, only the first one counts.',
            )}
          </Notice>
        )}
        {dstNote?.shifted && (
          <Notice tone="warn" icon={<Info size={16} />}>
            {t('این ساعت در آن روز به‌خاطر تغییر ساعت وجود ندارد؛ زمان {time} ثبت می‌شود.', 'That time does not exist that day because of a clock change; {time} will be used.', {
              time: time(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZone: v.timezone }).format(new Date(dstNote.utc))),
            })}
          </Notice>
        )}
        <Field label={t('اولویت', 'Priority')}>
          <Segmented
            label={t('اولویت', 'Priority')}
            value={v.priority}
            onChange={(priority) => set({ priority })}
            size="sm"
            options={[
              { value: 'low', label: t('کم', 'Low') },
              { value: 'normal', label: t('معمولی', 'Normal') },
              { value: 'high', label: t('زیاد', 'High') },
            ]}
          />
        </Field>
        <Field label={t('توضیح (اختیاری)', 'Notes (optional)')}>
          <VoiceInput
            value={v.notes}
            onChange={(notes) => set({ notes })}
            lang={mod.inputLanguage}
            ownerId={`task-form-notes-${mod.id}`}
            inputLabel={t('توضیح', 'Notes')}
            multiline
            rows={2}
            maxLength={4000}
          />
        </Field>
        {v.time && v.reminderOffset !== null && mod.remindersPaused && (
          <Notice tone="warn" icon={<Info size={16} />}>
            {t('یادآوری‌های این بخش متوقف است؛ تا ادامه دادن آن‌ها، اعلانی نمایش داده نمی‌شود.', 'Reminders for this section are paused; nothing will be shown until you resume them.')}
          </Notice>
        )}
      </div>
    </Modal>
  );
}

function errorFor(field: string, code: string, t: (fa: string, en: string) => string): string {
  if (field === 'title') return t('عنوان را بنویسید.', 'Enter a title.');
  if (field === 'date' && code === 'required_with_time') return t('برای ساعت، تاریخ هم لازم است.', 'A time needs a date.');
  if (field === 'weekdays') return t('حداقل یک روز را انتخاب کنید.', 'Pick at least one day.');
  if (field === 'until') return t('پایان نمی‌تواند قبل از شروع باشد.', 'End cannot be before the start.');
  return t('مقدار معتبر نیست.', 'Invalid value.');
}
