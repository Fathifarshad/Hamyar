import { db, nowIso, uid } from '../../data/db';
import { DST_POLICY, DomainError, type ScheduleRule, type Task, type TaskCompletion } from '../../domain/types';
import { currentRule, expandByDates, reviseSchedule, validateRule, type Occurrence } from '../../domain/recurrence';
import { addDaysISO, isValidISODate, isValidTime } from '../../domain/time';

export interface TaskInput {
  title: string;
  notes: string;
  kind: 'task' | 'event';
  priority: Task['priority'];
  date: string | null;
  time: string | null;
  timezone: string;
  repeat: 'once' | 'daily' | 'weekly';
  weekdays: number[];
  until: string | null;
  reminderOffset: number | null;
}

export const UNDATED_KEY = 'undated';

export function ruleFromInput(i: TaskInput): ScheduleRule | null {
  if (!i.date) return null;
  return {
    freq: i.repeat,
    startDate: i.date,
    endDate: i.repeat === 'once' ? null : i.until,
    weekdays: i.repeat === 'weekly' ? [...new Set(i.weekdays)].sort() : [],
    times: i.time ? [i.time] : [],
    timezone: i.timezone,
  };
}

export function inputFromTask(task: Task, fallbackTz: string): TaskInput {
  const r = currentRule(task.revisions);
  return {
    title: task.title,
    notes: task.notes,
    kind: task.kind,
    priority: task.priority,
    date: r?.startDate ?? null,
    time: r?.times[0] ?? null,
    timezone: r?.timezone ?? fallbackTz,
    repeat: r?.freq ?? 'once',
    weekdays: r?.weekdays ?? [],
    until: r?.endDate ?? null,
    reminderOffset: task.reminderOffset,
  };
}

export function validateTaskInput(i: TaskInput): Record<string, string> {
  const errors: Record<string, string> = {};
  if (!i.title.trim()) errors.title = 'required';
  if (i.time && !i.date) errors.date = 'required_with_time';
  if (i.date && !isValidISODate(i.date)) errors.date = 'invalid';
  if (i.time && !isValidTime(i.time)) errors.time = 'invalid';
  if (i.repeat === 'weekly' && !i.weekdays.length) errors.weekdays = 'required';
  if (i.until && i.date && i.until < i.date) errors.until = 'before_start';
  const rule = ruleFromInput(i);
  if (rule && validateRule(rule).length && !Object.keys(errors).length) errors.date = 'invalid';
  return errors;
}

/** Creates a task. The idempotency key makes a double submit produce one task. */
export async function createTask(moduleId: string, i: TaskInput, idempotencyKey: string): Promise<Task> {
  const errors = validateTaskInput(i);
  if (Object.keys(errors).length) throw new DomainError('INVALID_INPUT', undefined, errors);
  return db.transaction('rw', db.tasks, db.kv, async () => {
    const seen = await db.kv.get(`idem:task:${idempotencyKey}`);
    if (seen) {
      const existing = await db.tasks.get(String(seen.value));
      if (existing) return existing;
    }
    const rule = ruleFromInput(i);
    const ts = nowIso();
    const task: Task = {
      id: uid(),
      moduleId,
      kind: i.kind,
      title: i.title.trim().slice(0, 200),
      notes: i.notes.trim().slice(0, 4000),
      priority: i.priority,
      revisions: rule ? [{ validFrom: 0, rule }] : null,
      reminderOffset: rule && rule.times.length ? i.reminderOffset : null,
      dstPolicy: DST_POLICY,
      revision: 1,
      createdAt: ts,
      updatedAt: ts,
    };
    await db.tasks.add(task);
    await db.kv.put({ key: `idem:task:${idempotencyKey}`, value: task.id });
    return task;
  });
}

/** Edits a task. Recurring schedules change from now on; past occurrences keep their times. */
export async function updateTask(id: string, i: TaskInput, now = Date.now()): Promise<void> {
  const errors = validateTaskInput(i);
  if (Object.keys(errors).length) throw new DomainError('INVALID_INPUT', undefined, errors);
  await db.transaction('rw', db.tasks, async () => {
    const task = await db.tasks.get(id);
    if (!task) throw new DomainError('NOT_FOUND');
    const rule = ruleFromInput(i);
    const revisions = rule ? reviseSchedule(task.revisions, rule, now, { keepHistory: true }) : null;
    await db.tasks.put({
      ...task,
      kind: i.kind,
      title: i.title.trim().slice(0, 200),
      notes: i.notes.trim().slice(0, 4000),
      priority: i.priority,
      revisions,
      reminderOffset: rule && rule.times.length ? i.reminderOffset : null,
      revision: task.revision + 1,
      updatedAt: nowIso(),
    });
  });
}

export async function deleteTask(id: string): Promise<void> {
  await db.transaction('rw', db.tasks, db.taskCompletions, db.reminders, async () => {
    await db.taskCompletions.where('taskId').equals(id).delete();
    await db.reminders.where('sourceId').equals(id).delete();
    await db.tasks.delete(id);
  });
}

/** Marks one occurrence done/undone. Completing one occurrence never completes the series. */
export async function setCompleted(task: Task, occurrenceKey: string, done: boolean): Promise<void> {
  const id = `${task.id}|${occurrenceKey}`;
  if (done) {
    const rec: TaskCompletion = { id, taskId: task.id, moduleId: task.moduleId, occurrence: occurrenceKey, completedAt: nowIso() };
    await db.taskCompletions.put(rec);
  } else await db.taskCompletions.delete(id);
}

export interface TaskOcc {
  task: Task;
  occ: Occurrence | null;
  key: string;
  done: boolean;
  /** due instant passed and not done */
  late: boolean;
}

export interface TaskViews {
  overdue: TaskOcc[];
  today: TaskOcc[];
  upcoming: TaskOcc[];
  undated: TaskOcc[];
  done: TaskOcc[];
}

/** Builds the Today / Upcoming / Overdue / Undated / Done lists. Overdue never means done. */
export function buildTaskViews(tasks: Task[], completions: TaskCompletion[], ctx: { today: string; now: number }, upcomingDays = 7): TaskViews {
  const doneIds = new Map(completions.map((c) => [c.id, c]));
  const views: TaskViews = { overdue: [], today: [], upcoming: [], undated: [], done: [] };
  const from = addDaysISO(ctx.today, -14);
  const to = addDaysISO(ctx.today, upcomingDays);
  for (const task of tasks) {
    if (!task.revisions) {
      const key = UNDATED_KEY;
      const done = doneIds.has(`${task.id}|${key}`);
      const item: TaskOcc = { task, occ: null, key, done, late: false };
      (done ? views.done : views.undated).push(item);
      continue;
    }
    const occs = expandByDates(task.revisions, from, to);
    const seenUpcoming = new Set<string>();
    for (const occ of occs) {
      const done = doneIds.has(`${task.id}|${occ.key}`);
      const late = !done && occ.at !== null && occ.at < ctx.now;
      const item: TaskOcc = { task, occ, key: occ.key, done, late };
      if (occ.date < ctx.today) {
        if (done) {
          if (occ.date >= addDaysISO(ctx.today, -7)) views.done.push(item);
        } else views.overdue.push(item);
      } else if (occ.date === ctx.today) {
        views.today.push(item);
        if (done) views.done.push(item);
      } else {
        // a daily series shows only its next occurrence in Upcoming
        const series = currentRule(task.revisions)?.freq !== 'once';
        if (series && seenUpcoming.has(task.id)) continue;
        seenUpcoming.add(task.id);
        if (!done) views.upcoming.push(item);
      }
    }
  }
  const byTime = (a: TaskOcc, b: TaskOcc) => {
    const da = a.occ?.date ?? '9999';
    const dbb = b.occ?.date ?? '9999';
    if (da !== dbb) return da < dbb ? -1 : 1;
    const ta = a.occ?.at ?? 0;
    const tb = b.occ?.at ?? 0;
    if (ta !== tb) return ta - tb;
    const pr = { high: 0, normal: 1, low: 2 };
    return pr[a.task.priority] - pr[b.task.priority];
  };
  views.overdue.sort(byTime);
  views.today.sort((a, b) => Number(a.done) - Number(b.done) || byTime(a, b));
  views.upcoming.sort(byTime);
  views.undated.sort((a, b) => (a.task.createdAt < b.task.createdAt ? 1 : -1));
  views.done.sort((a, b) => (a.key < b.key ? 1 : -1));
  return views;
}

/** Occurrences for a calendar week (both dated views share the same expansion). */
export function weekOccurrences(tasks: Task[], completions: TaskCompletion[], startDate: string, now: number): Map<string, TaskOcc[]> {
  const doneIds = new Set(completions.map((c) => c.id));
  const end = addDaysISO(startDate, 6);
  const map = new Map<string, TaskOcc[]>();
  for (let i = 0; i < 7; i++) map.set(addDaysISO(startDate, i), []);
  for (const task of tasks) {
    for (const occ of expandByDates(task.revisions, startDate, end)) {
      const done = doneIds.has(`${task.id}|${occ.key}`);
      map.get(occ.date)?.push({ task, occ, key: occ.key, done, late: !done && occ.at !== null && occ.at < now });
    }
  }
  for (const list of map.values()) list.sort((a, b) => (a.occ?.at ?? 0) - (b.occ?.at ?? 0));
  return map;
}
