import { useEffect, useMemo, useState } from 'react';
import { useApp } from '../../shell/AppContext';
import { Button, Field, Input, Modal, Notice } from '../../ui/primitives';
import { DatePicker } from '../../ui/DatePicker';
import { CalendarClock, Info, TriangleAlert } from '../../ui/icons';
import type { CommandDraft } from '../../domain/commands/parse';
import type { ModuleInstance } from '../../domain/types';
import { resolveZoned } from '../../domain/time';
import { createTask } from './data';
import { emptyTaskInput, reminderLabel } from './TaskForm';
import { uid } from '../../data/db';
import { toast } from '../../lib/ui-store';
import { errorText } from '../../i18n/errors';

type Draft = Extract<CommandDraft, { kind: 'create_task' }>;

/** Shows what a spoken or typed command will create; nothing is saved until confirmed. */
export function TaskPreview({ mod, draft, onClose, onDone, onEditFull }: { mod: ModuleInstance; draft: Draft | null; onClose: () => void; onDone: () => void; onEditFull: (d: { title: string; date: string | null; time: string | null }) => void }) {
  const { t, time, date, now } = useApp();
  const [title, setTitle] = useState('');
  const [d, setD] = useState<string | null>(null);
  const [tm, setTm] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  // one idempotency key per preview: a double click cannot save the task twice
  const idem = useMemo(() => (draft ? uid() : ''), [draft]);
  useEffect(() => {
    if (!draft) return;
    setTitle(draft.title);
    setD(draft.date);
    setTm(draft.time);
  }, [draft]);
  if (!draft) return null;
  const tz = draft.timezone;
  const resolved = d && tm ? resolveZoned(d, tm, tz) : null;
  const past = resolved ? resolved.utc < now : false;
  const needsTime = !!draft.ambiguity && !tm;
  const defaultReminder = (mod.config.defaultReminder as number | null | undefined) ?? 0;
  const canSave = !!title.trim() && !past && !needsTime && (!!d || !tm);

  const save = async () => {
    setBusy(true);
    try {
      await createTask(mod.id, { ...emptyTaskInput(tz, d), title, time: tm, kind: tm ? 'event' : 'task', reminderOffset: tm ? defaultReminder : null }, idem);
      toast({ kind: 'success', text: t('«{title}» ثبت شد.', '“{title}” saved.', { title }) });
      onDone();
    } catch (e) {
      toast({ kind: 'error', text: errorText(e, t) });
    } finally {
      setBusy(false);
    }
  };

  const periodLabel = (hhmm: string) => {
    const h = Number(hhmm.slice(0, 2));
    if (h < 5) return t('بامداد', 'early morning');
    if (h < 12) return t('صبح', 'morning');
    if (h < 17) return t('بعدازظهر', 'afternoon');
    return t('شب', 'evening');
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={t('بررسی پیش از ثبت', 'Check before saving')}
      closeLabel={t('بستن', 'Close')}
      size="sm"
      footer={
        <>
          <Button variant="ghost" onClick={() => onEditFull({ title, date: d, time: tm })}>
            {t('فرم کامل', 'Full form')}
          </Button>
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" busy={busy} disabled={!canSave} onClick={() => void save()} icon={<CalendarClock size={16} />}>
            {tm ? t('ثبت قرار', 'Save appointment') : t('ثبت کار', 'Save task')}
          </Button>
        </>
      }
    >
      <div className="stack" data-accent={mod.appearance.accent}>
        <p className="muted small">{t('متن را بررسی کنید و سپس قرار را ثبت کنید.', 'Check the text, then save.')}</p>
        <Field label={t('عنوان', 'Title')} error={!title.trim() ? t('عنوان را بنویسید.', 'Enter a title.') : undefined}>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={200} />
        </Field>
        <div className="form-row">
          <Field label={t('تاریخ', 'Date')}>
            <DatePicker value={d} onChange={setD} label={t('تاریخ', 'Date')} allowClear />
          </Field>
          <Field label={t('ساعت', 'Time')}>
            <input type="time" className="input" value={tm ?? ''} onChange={(e) => setTm(e.target.value || null)} disabled={!d} aria-label={t('ساعت', 'Time')} />
          </Field>
        </div>
        {draft.ambiguity && (
          <Notice tone="warn" icon={<Info size={16} />} title={t('صبح یا شب؟', 'Morning or evening?')}>
            <div className="stack-sm">
              <span>{t('ساعت گفته‌شده دو معنی دارد. یکی را انتخاب کنید:', 'The time you said is ambiguous. Pick one:')}</span>
              <div className="row-flex wrap">
                {draft.ambiguity.options.map((o) => (
                  <Button key={o} size="sm" variant={tm === o ? 'accent' : 'outline'} onClick={() => setTm(o)} aria-pressed={tm === o}>
                    {time(o)} · {periodLabel(o)}
                  </Button>
                ))}
              </div>
            </div>
          </Notice>
        )}
        {draft.dateAssumed && (
          <Notice tone="neutral" icon={<Info size={16} />}>
            {t('تاریخی گفته نشد؛ امروز در نظر گرفته شد. در صورت نیاز تغییرش دهید.', 'No date was said, so today was used. Change it if needed.')}
          </Notice>
        )}
        {past && (
          <Notice tone="danger" icon={<TriangleAlert size={16} />}>
            {t('این زمان گذشته است. تاریخ یا ساعت را اصلاح کنید؛ خودکار به فردا منتقل نمی‌شود.', 'That time has passed. Fix the date or time; it is not moved to tomorrow automatically.')}
          </Notice>
        )}
        {resolved?.shifted && (
          <Notice tone="warn" icon={<Info size={16} />}>
            {t('این ساعت به‌خاطر تغییر ساعت رسمی وجود ندارد و اولین زمان معتبر بعد از آن ثبت می‌شود.', 'This time does not exist because of a clock change; the first valid time after it will be used.')}
          </Notice>
        )}
        {d && (
          <div className="preview-line">
            <CalendarClock size={16} aria-hidden="true" />
            <span>
              {date(d, 'long')}
              {tm ? ` · ${time(tm)}` : ` · ${t('بدون ساعت', 'no time')}`}
{' '}
              <span className="subtle ltr">({tz})</span>
            </span>
          </div>
        )}
        {tm && <div className="subtle small">{t('یادآوری: {r}', 'Reminder: {r}', { r: reminderLabel(defaultReminder, t) })}</div>}
      </div>
    </Modal>
  );
}
