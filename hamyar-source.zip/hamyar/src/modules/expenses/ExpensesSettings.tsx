import { useState } from 'react';
import { useApp } from '../../shell/AppContext';
import type { ModuleSettingsProps } from '../registry';
import { Field, Select, Textarea } from '../../ui/primitives';
import { CURRENCY_CODES } from '../../domain/catalog';
import { currencyLabel } from '../../lib/format';

export default function ExpensesSettings({ config, onChange }: ModuleSettingsProps) {
  const { t, locale } = useApp();
  const [cats, setCats] = useState(((config.categories as string[]) ?? []).join('\n'));
  return (
    <div className="stack-sm">
      <Field label={t('واحد پول پیش‌فرض', 'Default currency')}>
        <Select value={(config.currency as string) ?? 'IRT'} onChange={(e) => onChange({ currency: e.target.value })}>
          {CURRENCY_CODES.map((c) => (
            <option key={c} value={c}>
              {currencyLabel(c, locale)}
            </option>
          ))}
        </Select>
      </Field>
      <Field label={t('دسته‌ها (هر خط یک دسته)', 'Categories (one per line)')}>
        <Textarea
          rows={5}
          value={cats}
          onChange={(e) => {
            setCats(e.target.value);
            onChange({ categories: e.target.value.split('\n').map((x) => x.trim()).filter(Boolean) });
          }}
        />
      </Field>
    </div>
  );
}
