import { useEffect, useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, nowIso, uid } from '../../data/db';
import { useApp } from '../../shell/AppContext';
import type { ModuleViewProps } from '../registry';
import type { Expense, ModuleInstance } from '../../domain/types';
import { Button, EmptyState, Field, IconButton, Input, Modal, Select } from '../../ui/primitives';
import { DatePicker } from '../../ui/DatePicker';
import { VoiceInput } from '../../ui/VoiceInput';
import { Pencil, Plus, TrashIcon, Wallet } from '../../ui/icons';
import { parseLocaleNumber } from '../../domain/normalize';
import { parseCommand } from '../../domain/commands/parse';
import { useGenericCommand, useVoiceMode, examplesFor } from '../shared';
import { askConfirm, toast } from '../../lib/ui-store';
import { isoToJalali, jalaliToISO } from '../../domain/jalali';
import { currencyLabel } from '../../lib/format';

function monthStart(today: string, calendar: 'jalali' | 'gregorian'): string {
  if (calendar === 'jalali') {
    const j = isoToJalali(today);
    return jalaliToISO(j.jy, j.jm, 1);
  }
  return `${today.slice(0, 8)}01`;
}

interface Draft {
  id?: string;
  amount: string;
  currency: string;
  category: string;
  note: string;
  date: string;
}

function ExpenseForm({ mod, draft, onClose }: { mod: ModuleInstance; draft: Draft | null; onClose: () => void }) {
  const { t, locale } = useApp();
  const [v, setV] = useState<Draft | null>(draft);
  const [tried, setTried] = useState(false);
  useEffect(() => {
    setV(draft);
    setTried(false);
  }, [draft]);
  if (!v) return null;
  const categories = (mod.config.categories as string[]) ?? [];
  const amount = parseLocaleNumber(v.amount);
  const valid = amount !== null && amount > 0;
  const save = async () => {
    setTried(true);
    if (!valid) return;
    if (v.id) await db.expenses.update(v.id, { amount: amount!, currency: v.currency, category: v.category, note: v.note.trim().slice(0, 200), date: v.date });
    else await db.expenses.add({ id: uid(), moduleId: mod.id, amount: amount!, currency: v.currency, category: v.category, note: v.note.trim().slice(0, 200), date: v.date, createdAt: nowIso() });
    toast({ kind: 'success', text: t('هزینه ثبت شد.', 'Expense saved.') });
    onClose();
  };
  return (
    <Modal
      open
      onClose={onClose}
      title={v.id ? t('ویرایش هزینه', 'Edit expense') : t('ثبت هزینه', 'Add expense')}
      closeLabel={t('بستن', 'Close')}
      size="sm"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('انصراف', 'Cancel')}
          </Button>
          <Button variant="accent" onClick={() => void save()}>
            {t('ثبت', 'Save')}
          </Button>
        </>
      }
    >
      <div className="form-grid" data-accent={mod.appearance.accent}>
        <div className="form-row">
          <Field label={t('مبلغ', 'Amount')} error={tried && !valid ? t('مبلغ معتبر وارد کنید.', 'Enter a valid amount.') : undefined}>
            <Input value={v.amount} onChange={(e) => setV({ ...v, amount: e.target.value })} inputMode="decimal" dir="ltr" autoFocus />
          </Field>
          <Field label={t('واحد پول', 'Currency')}>
            <Select value={v.currency} onChange={(e) => setV({ ...v, currency: e.target.value })}>
              {['IRT', 'IRR', 'USD', 'EUR', 'GBP', 'CAD', 'AUD', 'TRY', 'AED', 'CLP', 'AFN'].map((c) => (
                <option key={c} value={c}>
                  {currencyLabel(c, locale)}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label={t('دسته', 'Category')}>
          <Select value={v.category} onChange={(e) => setV({ ...v, category: e.target.value })}>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </Select>
        </Field>
        <Field label={t('شرح', 'Note')}>
          <VoiceInput value={v.note} onChange={(note) => setV({ ...v, note })} lang={mod.inputLanguage} ownerId={`exp-note-${mod.id}`} inputLabel={t('شرح', 'Note')} maxLength={200} />
        </Field>
        <Field label={t('تاریخ', 'Date')}>
          <DatePicker value={v.date} onChange={(d) => d && setV({ ...v, date: d })} label={t('تاریخ', 'Date')} />
        </Field>
      </div>
    </Modal>
  );
}

export default function ExpensesModule({ mod, variant }: ModuleViewProps) {
  const { t, today, profile, money, tz, date, relDay, locale, num, bidi } = useApp();
  const expenses = useLiveQuery(() => db.expenses.where('moduleId').equals(mod.id).toArray(), [mod.id]);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [voice, setVoice] = useState('');
  const generic = useGenericCommand();
  const { mode, setMode } = useVoiceMode(mod);
  const currency = (mod.config.currency as string) ?? 'IRT';
  const categories = (mod.config.categories as string[]) ?? [];
  const start = monthStart(today, profile.calendar);

  const stats = useMemo(() => {
    const list = (expenses ?? []).filter((e) => e.currency === currency);
    const day = list.filter((e) => e.date === today).reduce((a, e) => a + e.amount, 0);
    const month = list.filter((e) => e.date >= start && e.date <= today);
    const monthTotal = month.reduce((a, e) => a + e.amount, 0);
    const byCat = new Map<string, number>();
    for (const e of month) byCat.set(e.category, (byCat.get(e.category) ?? 0) + e.amount);
    const cats = [...byCat.entries()].sort((a, b) => b[1] - a[1]);
    const other = new Set((expenses ?? []).filter((e) => e.currency !== currency).map((e) => e.currency));
    return { day, monthTotal, cats, other };
  }, [expenses, currency, today, start]);

  const newDraft = (p: Partial<Draft> = {}): Draft => ({ amount: '', currency, category: categories[0] ?? '', note: '', date: today, ...p });

  const onCommand = async (text: string) => {
    const d = parseCommand(text, { moduleType: 'expenses', now: Date.now(), timezone: tz });
    if (d.kind === 'create_expense') {
      const cat = categories.find((c) => d.note && d.note.includes(c)) ?? categories[0] ?? '';
      setDraft(newDraft({ amount: d.amount !== null ? String(d.amount) : '', currency: d.currency ?? currency, note: d.note, category: cat }));
      return;
    }
    await generic(d);
  };

  if (!expenses) return <div className="mod-loading" />;
  const recent = [...expenses].sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : a.createdAt < b.createdAt ? 1 : -1));
  const shown = variant === 'card' ? recent.slice(0, mod.appearance.density === 'compact' ? 5 : 3) : recent.slice(0, 200);
  const maxCat = stats.cats[0]?.[1] ?? 1;

  const remove = async (e: Expense) => {
    const ok = await askConfirm({ title: t('حذف این هزینه؟', 'Delete this expense?'), body: `${money(e.amount, e.currency)} · ${e.note || e.category}`, confirmText: t('حذف', 'Delete'), cancelText: t('انصراف', 'Cancel'), danger: true });
    if (ok) await db.expenses.delete(e.id);
  };

  return (
    <div className="stack">
      <div className="stat-pair">
        <div className="stat">
          <div className="stat-label">{t('امروز', 'Today')}</div>
          <div className="stat-value num">{money(stats.day, currency)}</div>
        </div>
        <div className="stat">
          <div className="stat-label">{profile.calendar === 'jalali' ? t('این ماه ({m})', 'This month ({m})', { m: date(start, 'short').split(' ').slice(1).join(' ') }) : t('این ماه', 'This month')}</div>
          <div className="stat-value num">{money(stats.monthTotal, currency)}</div>
        </div>
      </div>
      <VoiceInput
        value={voice}
        onChange={setVoice}
        lang={mod.inputLanguage}
        ownerId={`exp-${mod.id}-${variant}`}
        inputLabel={t('ثبت سریع هزینه', 'Quick expense')}
        placeholder={t('مثلاً «۵۰ هزار تومان نان»', 'e.g. “12 dollars coffee”')}
        mode={mode}
        onModeChange={setMode}
        onCommand={(s) => void onCommand(s)}
        onSubmit={(s) => void onCommand(s)}
        submitLabel={t('بررسی و ثبت', 'Review and save')}
        examples={examplesFor(mod, locale)}
      />
      {variant === 'full' && stats.cats.length > 0 && (
        <div className="cat-bars" role="list" aria-label={t('هزینه این ماه بر اساس دسته', 'This month by category')}>
          {stats.cats.map(([c, v]) => (
            <div key={c} className="cat-bar" role="listitem" title={`${c}: ${money(v, currency)}`}>
              <span className="cat-name auto-dir" dir={bidi(c)}>{c}</span>
              <span className="cat-track">
                <span className="cat-fill" style={{ inlineSize: `${(v / maxCat) * 100}%` }} />
              </span>
              <span className="cat-val num">{money(v, currency)}</span>
            </div>
          ))}
        </div>
      )}
      {stats.other.size > 0 && <p className="subtle xsmall">{t('هزینه‌های ارزهای دیگر ({c}) در جمع بالا حساب نشده‌اند.', 'Expenses in other currencies ({c}) are not included above.', { c: [...stats.other].map((c) => currencyLabel(c, locale)).join('، ') })}</p>}
      {expenses.length === 0 ? (
        <EmptyState icon={<Wallet size={22} />} title={t('هنوز هزینه‌ای ثبت نشده', 'No expenses yet')} />
      ) : (
        <ul className="rows">
          {shown.map((e) => (
            <li key={e.id} className="row">
              <button type="button" className="row-main" onClick={() => setDraft({ id: e.id, amount: String(e.amount), currency: e.currency, category: e.category, note: e.note, date: e.date })}>
                <span className="row-title auto-dir" dir={bidi(e.note || e.category)}>{e.note || e.category}</span>
                <span className="row-meta">
                  <span>{relDay(e.date)}</span>
                  <span className="tag">{e.category}</span>
                </span>
              </button>
              <span className="amount num">{money(e.amount, e.currency)}</span>
              {variant === 'full' && (
                <div className="row-actions">
                  <IconButton label={t('ویرایش', 'Edit')} size="sm" onClick={() => setDraft({ id: e.id, amount: String(e.amount), currency: e.currency, category: e.category, note: e.note, date: e.date })}>
                    <Pencil size={15} />
                  </IconButton>
                  <IconButton label={t('حذف', 'Delete')} size="sm" onClick={() => void remove(e)}>
                    <TrashIcon size={15} />
                  </IconButton>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
      <div className="row-flex spread">
        {variant === 'card' && expenses.length > shown.length ? (
          <a className="more-link" href={`#/m/${mod.id}`}>
            {t('همه ({n})', 'All ({n})', { n: num(expenses.length) })}
          </a>
        ) : (
          <span />
        )}
        <Button size="sm" variant="soft" icon={<Plus size={14} />} onClick={() => setDraft(newDraft())}>
          {t('هزینه', 'Expense')}
        </Button>
      </div>
      <ExpenseForm mod={mod} draft={draft} onClose={() => setDraft(null)} />
    </div>
  );
}
