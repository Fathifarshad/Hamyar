export class ProviderError extends Error {
  constructor(code, retryable, status) {
    super(code);
    this.code = code;
    this.retryable = retryable;
    this.status = status;
  }
}

export function errorFromStatus(status) {
  if (status === 401 || status === 403) return new ProviderError('PROVIDER_AUTH', false, status);
  if (status === 429) return new ProviderError('RATE_LIMITED', true, status);
  if (status === 413) return new ProviderError('TOO_LARGE', false, status);
  if (status >= 500) return new ProviderError('PROVIDER_ERROR', true, status);
  return new ProviderError('PROVIDER_REJECTED', false, status);
}

/** fetch with a hard timeout that also respects the job's cancel signal. */
export async function fetchWithTimeout(url, init, timeoutMs, signal) {
  const ctl = new AbortController();
  const onAbort = () => ctl.abort(new Error('cancelled'));
  if (signal) {
    if (signal.aborted) throw new ProviderError('CANCELLED', false);
    signal.addEventListener('abort', onAbort, { once: true });
  }
  const timer = setTimeout(() => ctl.abort(new Error('timeout')), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: ctl.signal });
  } catch {
    if (signal?.aborted) throw new ProviderError('CANCELLED', false);
    if (ctl.signal.aborted) throw new ProviderError('TIMEOUT', true);
    throw new ProviderError('NETWORK', true);
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', onAbort);
  }
}

/** Up to three attempts with exponential backoff for retryable failures. */
export async function withRetry(fn, signal, attempts = 3) {
  let last;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (e) {
      last = e;
      if (!(e instanceof ProviderError) || !e.retryable || signal?.aborted || i === attempts - 1) throw e;
      await new Promise((r) => setTimeout(r, 1500 * 2 ** i + Math.random() * 400));
    }
  }
  throw last;
}
