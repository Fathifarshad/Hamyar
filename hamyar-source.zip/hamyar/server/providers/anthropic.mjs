import { errorFromStatus, fetchWithTimeout, ProviderError } from './common.mjs';

export function anthropicText({ key, model }) {
  const call = async (body, signal) =>
    fetchWithTimeout(
      'https://api.anthropic.com/v1/messages',
      { method: 'POST', headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' }, body: JSON.stringify(body) },
      150_000,
      signal,
    );
  let structured = true;
  return {
    label: 'Claude (Anthropic)',
    async complete({ system, user, schema, signal }) {
      const base = { model, max_tokens: 4096, system, messages: [{ role: 'user', content: user }] };
      let res = await call(structured ? { ...base, output_config: { format: { type: 'json_schema', schema } } } : base, signal);
      if (res.status === 400 && structured) {
        // Older models do not support structured outputs: ask for JSON in the prompt instead.
        structured = false;
        res = await call(base, signal);
      }
      if (!res.ok) throw errorFromStatus(res.status);
      const j = await res.json();
      const text = (j.content ?? [])
        .filter((b) => b.type === 'text')
        .map((b) => b.text)
        .join('');
      if (!text) throw new ProviderError('INVALID_OUTPUT', true);
      return text;
    },
  };
}
