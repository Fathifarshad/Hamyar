import { errorFromStatus, fetchWithTimeout, ProviderError } from './common.mjs';

// Transcription models documented to accept the singular ISO-639-1 `language` hint
// (checked against the API reference, Oct 2026). For any other model name the language
// is left to automatic detection rather than sending a parameter it may reject.
const LANGUAGE_PARAM_MODELS = /^(whisper-1|gpt-transcribe|gpt-4o-transcribe|gpt-4o-mini-transcribe)/;

export function openaiText({ key, model }) {
  return {
    label: 'OpenAI',
    async complete({ system, user, schema, signal }) {
      const res = await fetchWithTimeout(
        'https://api.openai.com/v1/responses',
        {
          method: 'POST',
          headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' },
          body: JSON.stringify({
            model,
            input: [
              { role: 'system', content: system },
              { role: 'user', content: user },
            ],
            text: { format: { type: 'json_schema', name: 'pdf_summary', schema, strict: true } },
          }),
        },
        150_000,
        signal,
      );
      if (!res.ok) throw errorFromStatus(res.status);
      const j = await res.json();
      if (typeof j.output_text === 'string') return j.output_text;
      const text = (j.output ?? [])
        .flatMap((o) => o.content ?? [])
        .filter((c) => c.type === 'output_text' && typeof c.text === 'string')
        .map((c) => c.text)
        .join('');
      if (!text) throw new ProviderError('INVALID_OUTPUT', true);
      return text;
    },
  };
}

export function openaiTranscription({ key, model }) {
  return {
    label: 'OpenAI',
    async transcribe({ buffer, mime, filename, language, signal }) {
      const form = new FormData();
      form.append('file', new Blob([buffer], { type: mime }), filename);
      form.append('model', model);
      form.append('response_format', 'json');
      if (LANGUAGE_PARAM_MODELS.test(model)) form.append('language', language);
      const res = await fetchWithTimeout('https://api.openai.com/v1/audio/transcriptions', { method: 'POST', headers: { authorization: `Bearer ${key}` }, body: form }, 240_000, signal);
      if (!res.ok) throw errorFromStatus(res.status);
      const j = await res.json();
      if (typeof j.text !== 'string') throw new ProviderError('INVALID_OUTPUT', true);
      return { text: j.text.trim() };
    },
  };
}
