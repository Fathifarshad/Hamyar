import { randomUUID } from 'node:crypto';

/**
 * In-memory job queue for AI work (local single-user server).
 * States: queued → processing → succeeded | failed | cancelled.
 * A restart loses queued jobs; the client then reports JOB_EXPIRED and offers a retry.
 */
export class JobQueue {
  constructor({ concurrency = 2, ttlMs = 60 * 60_000 } = {}) {
    this.concurrency = concurrency;
    this.ttlMs = ttlMs;
    this.jobs = new Map();
    this.waiting = [];
    this.running = 0;
    setInterval(() => this.sweep(), 5 * 60_000).unref?.();
  }

  create(kind, run) {
    const job = { id: randomUUID(), kind, state: 'queued', createdAt: Date.now(), progress: null, result: null, error: null, ctl: new AbortController(), run, payload: null };
    this.jobs.set(job.id, job);
    this.waiting.push(job);
    this.pump();
    return job;
  }

  pump() {
    while (this.running < this.concurrency && this.waiting.length) {
      const job = this.waiting.shift();
      if (job.state !== 'queued') continue;
      this.running++;
      job.state = 'processing';
      job.startedAt = Date.now();
      Promise.resolve()
        .then(() => job.run({ signal: job.ctl.signal, progress: (done, total) => (job.progress = { done, total }) }))
        .then((result) => {
          if (job.state === 'processing') {
            job.state = 'succeeded';
            job.result = result;
          }
        })
        .catch((e) => {
          if (job.state === 'cancelled') return;
          job.state = e?.code === 'CANCELLED' ? 'cancelled' : 'failed';
          job.error = { code: e?.code || 'FAILED', retryable: !!e?.retryable };
        })
        .finally(() => {
          job.run = null; // drop references to request data (e.g. temporary audio)
          job.finishedAt = Date.now();
          this.running--;
          this.pump();
        });
    }
  }

  get(id) {
    return this.jobs.get(id) || null;
  }

  cancel(id) {
    const job = this.jobs.get(id);
    if (!job) return null;
    if (job.state === 'queued' || job.state === 'processing') {
      job.state = 'cancelled';
      job.ctl.abort();
    }
    return job;
  }

  activeCount() {
    let n = 0;
    for (const j of this.jobs.values()) if (j.state === 'queued' || j.state === 'processing') n++;
    return n;
  }

  sweep() {
    const cutoff = Date.now() - this.ttlMs;
    for (const [id, j] of this.jobs) if ((j.finishedAt ?? j.createdAt) < cutoff && j.state !== 'processing') this.jobs.delete(id);
  }

  view(job) {
    return { id: job.id, kind: job.kind, state: job.state, progress: job.progress, result: job.state === 'succeeded' ? job.result : undefined, error: job.error ?? undefined };
  }
}
