import { randomUUID } from 'node:crypto';
import { readConfig } from './config.mjs';
import { JobQueue } from './jobs.mjs';
import { openaiText, openaiTranscription } from './providers/openai.mjs';
import { anthropicText } from './providers/anthropic.mjs';
import { withRetry, ProviderError } from './providers/common.mjs';
import { summarizeDocument } from '../shared/summaryCore.mjs';

/**
 * Local API for the two AI features. Document text and audio are untrusted data:
 * they are only ever sent as data to the configured provider, never executed,
 * and nothing about them is logged.
 */
const MAX_JSON = 3 * 1024 * 1024;
const MAX_AUDIO = 20 * 1024 * 1024;
const MAX_PAGES = 100;
const MAX_PAGE_CHARS = 30_000;
const MAX_TOTAL_CHARS = 600_000;

function send(res, status, body, extra = {}) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...extra });
  res.end(JSON.stringify(body));
}

function fail(res, status, code, retryable, requestId) {
  send(res, status, { error: { code, retryable, requestId } });
}

function readBody(req, max) {
  return new Promise((resolve, reject) => {
    const declared = Number(req.headers['content-length'] || 0);
    if (declared > max) return reject(Object.assign(new Error('too_large'), { status: 413 }));
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > max) {
        req.destroy();
        reject(Object.assign(new Error('too_large'), { status: 413 }));
      } else chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true; // non-browser client on this machine
  try {
    return new URL(origin).host === req.headers.host;
  } catch {
    return false;
  }
}

/** Real file signature check — the declared content type is not trusted. */
function sniffAudio(buf) {
  const s = (o, t) => buf.length >= o + t.length && buf.subarray(o, o + t.length).toString('latin1') === t;
  if (s(0, 'ID3') || (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0)) return 'audio/mpeg';
  if (s(0, 'RIFF') && s(8, 'WAVE')) return 'audio/wav';
  if (s(0, 'OggS')) return 'audio/ogg';
  if (s(0, 'fLaC')) return 'audio/flac';
  if (s(4, 'ftyp')) return 'audio/mp4';
  if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return 'audio/webm';
  return null;
}

const EXT = { 'audio/mpeg': 'mp3', 'audio/wav': 'wav', 'audio/ogg': 'ogg', 'audio/flac': 'flac', 'audio/mp4': 'm4a', 'audio/webm': 'webm' };

class RateLimiter {
  constructor(limit, windowMs) {
    this.limit = limit;
    this.windowMs = windowMs;
    this.hits = new Map();
  }
  allow(key) {
    const now = Date.now();
    const list = (this.hits.get(key) || []).filter((t) => now - t < this.windowMs);
    if (list.length >= this.limit) {
      this.hits.set(key, list);
      return false;
    }
    list.push(now);
    this.hits.set(key, list);
    return true;
  }
}

function log(entry) {
  console.log(JSON.stringify({ t: new Date().toISOString(), ...entry }));
}

export function createApiHandler({ env }) {
  const cfg = readConfig(env);
  const jobs = new JobQueue({ concurrency: 2 });
  const summaryLimiter = new RateLimiter(20, 60 * 60_000);
  const sttLimiter = new RateLimiter(30, 60 * 60_000);
  const usage = { day: '', summaries: 0, transcriptionSec: 0 };
  const today = () => new Date().toISOString().slice(0, 10);
  const roll = () => {
    if (usage.day !== today()) Object.assign(usage, { day: today(), summaries: 0, transcriptionSec: 0 });
  };
  const textProvider = cfg.summary ? (cfg.summary.provider === 'openai' ? openaiText(cfg.summary) : anthropicText(cfg.summary)) : null;
  const sttProvider = cfg.transcription ? openaiTranscription(cfg.transcription) : null;
  if (cfg.reasons.length) log({ level: 'info', msg: 'ai features not configured', details: cfg.reasons });

  return async function handle(req, res) {
    const started = Date.now();
    const requestId = randomUUID().slice(0, 8);
    const url = new URL(req.url, 'http://localhost');
    const path = url.pathname.replace(/^.*?\/api\//, '/api/');
    let status = 200;
    const reply = (s, body, extra) => {
      status = s;
      send(res, s, body, extra);
    };
    const error = (s, code, retryable = false) => {
      status = s;
      fail(res, s, code, retryable, requestId);
    };
    try {
      if (req.method === 'GET' && path === '/api/health') {
        return reply(200, {
          ok: true,
          summary: { available: !!textProvider, provider: textProvider?.label ?? null },
          transcription: { available: !!sttProvider, provider: sttProvider?.label ?? null },
          limits: { dailySummaries: cfg.dailySummaryLimit, dailyTranscriptionMinutes: cfg.dailyTranscriptionMinutes },
        });
      }
      if (req.method === 'POST' && !sameOrigin(req)) return error(403, 'FORBIDDEN_ORIGIN');
      const ip = req.socket.remoteAddress || 'local';

      if (req.method === 'POST' && path === '/api/summaries') {
        if (!textProvider) return error(503, 'NOT_CONFIGURED');
        if (!summaryLimiter.allow(ip)) return error(429, 'RATE_LIMITED', true);
        roll();
        if (usage.summaries >= cfg.dailySummaryLimit) return error(429, 'QUOTA_EXCEEDED');
        if (jobs.activeCount() >= 4) return error(429, 'RATE_LIMITED', true);
        let body;
        try {
          body = JSON.parse((await readBody(req, MAX_JSON)).toString('utf8'));
        } catch (e) {
          return error(e?.status === 413 ? 413 : 400, e?.status === 413 ? 'TOO_LARGE' : 'INVALID_INPUT');
        }
        const pages = Array.isArray(body?.pages) ? body.pages : null;
        const totalPages = Number(body?.totalPages);
        const language = body?.language === 'en' ? 'en' : body?.language === 'fa' ? 'fa' : null;
        const length = body?.length === 'medium' ? 'medium' : body?.length === 'short' ? 'short' : null;
        if (!pages || !pages.length || !language || !length || !Number.isInteger(totalPages) || totalPages < 1 || totalPages > MAX_PAGES) return error(422, 'INVALID_INPUT');
        let total = 0;
        const seen = new Set();
        const clean = [];
        for (const p of pages) {
          const n = Number(p?.n);
          const text = typeof p?.text === 'string' ? p.text : null;
          if (!Number.isInteger(n) || n < 1 || n > totalPages || text === null || seen.has(n)) return error(422, 'INVALID_INPUT');
          seen.add(n);
          const tx = text.slice(0, MAX_PAGE_CHARS);
          total += tx.length;
          clean.push({ n, text: tx });
        }
        if (total > MAX_TOTAL_CHARS) return error(413, 'TOO_LARGE');
        usage.summaries++;
        const job = jobs.create('summary', async ({ signal, progress }) => {
          const summary = await summarizeDocument({
            pages: clean,
            totalPages,
            language,
            length,
            maxChars: 24_000,
            signal,
            onProgress: progress,
            complete: (prompt) => withRetry(() => textProvider.complete(prompt), signal),
          });
          return { summary, provider: textProvider.label };
        });
        return reply(202, { jobId: job.id });
      }

      if (req.method === 'POST' && path === '/api/transcriptions') {
        if (!sttProvider) return error(503, 'NOT_CONFIGURED');
        if (!sttLimiter.allow(ip)) return error(429, 'RATE_LIMITED', true);
        roll();
        const duration = Math.max(1, Math.min(600, Number(url.searchParams.get('duration')) || 60));
        if (usage.transcriptionSec + duration > cfg.dailyTranscriptionMinutes * 60) return error(429, 'QUOTA_EXCEEDED');
        const language = url.searchParams.get('lang') === 'en' ? 'en' : 'fa';
        let buf;
        try {
          buf = await readBody(req, MAX_AUDIO);
        } catch (e) {
          return error(e?.status === 413 ? 413 : 400, e?.status === 413 ? 'TOO_LARGE' : 'INVALID_INPUT');
        }
        const mime = sniffAudio(buf);
        if (!mime) return error(415, 'UNSUPPORTED_AUDIO');
        usage.transcriptionSec += duration;
        let audio = buf;
        const job = jobs.create('transcription', async ({ signal }) => {
          try {
            const out = await withRetry(() => sttProvider.transcribe({ buffer: audio, mime, filename: `audio.${EXT[mime]}`, language, signal }), signal);
            return { text: out.text, provider: sttProvider.label };
          } finally {
            audio = null; // temporary audio is released as soon as the job ends
          }
        });
        return reply(202, { jobId: job.id });
      }

      const m = path.match(/^\/api\/jobs\/([0-9a-f-]{36})(\/cancel)?$/);
      if (m) {
        if (m[2] && req.method === 'POST') {
          const job = jobs.cancel(m[1]);
          return job ? reply(200, jobs.view(job)) : error(404, 'NOT_FOUND');
        }
        if (!m[2] && req.method === 'GET') {
          const job = jobs.get(m[1]);
          return job ? reply(200, jobs.view(job)) : error(404, 'NOT_FOUND');
        }
      }
      return error(404, 'NOT_FOUND');
    } catch (e) {
      log({ level: 'error', requestId, path, code: e instanceof ProviderError ? e.code : 'INTERNAL' });
      if (!res.headersSent) error(500, 'INTERNAL', true);
    } finally {
      log({ requestId, method: req.method, path, status, ms: Date.now() - started });
    }
  };
}
