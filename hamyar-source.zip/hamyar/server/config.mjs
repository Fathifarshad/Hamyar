// Reads provider settings from the environment. Secrets never leave the server.
export function readConfig(env) {
  const text = (env.TEXT_PROVIDER || 'none').trim().toLowerCase();
  const stt = (env.TRANSCRIPTION_PROVIDER || 'none').trim().toLowerCase();
  const textModel = (env.TEXT_MODEL || '').trim();
  const sttModel = (env.TRANSCRIPTION_MODEL || '').trim();
  const openaiKey = (env.OPENAI_API_KEY || '').trim();
  const anthropicKey = (env.ANTHROPIC_API_KEY || '').trim();
  const summary =
    text === 'openai' && openaiKey && textModel
      ? { provider: 'openai', label: 'OpenAI', key: openaiKey, model: textModel }
      : text === 'anthropic' && anthropicKey && textModel
        ? { provider: 'anthropic', label: 'Claude (Anthropic)', key: anthropicKey, model: textModel }
        : null;
  const transcription = stt === 'openai' && openaiKey && sttModel ? { provider: 'openai', label: 'OpenAI', key: openaiKey, model: sttModel } : null;
  const reasons = [];
  if (!summary) reasons.push(text === 'none' ? 'TEXT_PROVIDER=none' : !textModel ? 'TEXT_MODEL is empty' : 'API key for TEXT_PROVIDER is empty');
  if (!transcription) reasons.push(stt === 'none' ? 'TRANSCRIPTION_PROVIDER=none' : !sttModel ? 'TRANSCRIPTION_MODEL is empty' : 'OPENAI_API_KEY is empty');
  return {
    summary,
    transcription,
    reasons,
    dailySummaryLimit: Number(env.DAILY_SUMMARY_LIMIT || 10),
    dailyTranscriptionMinutes: Number(env.DAILY_TRANSCRIPTION_MINUTES || 30),
  };
}
