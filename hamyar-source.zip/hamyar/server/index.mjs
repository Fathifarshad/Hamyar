#!/usr/bin/env node
// Hamyar local server: serves the built app (dist/) and the /api routes for AI features.
// Zero dependencies — Node 20.12+.
import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { createReadStream, existsSync, statSync } from 'node:fs';
import { extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApiHandler } from './api.mjs';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
try {
  if (existsSync(join(root, '.env'))) process.loadEnvFile(join(root, '.env'));
} catch (e) {
  console.warn('Could not read .env:', e.message);
}

const dist = join(root, 'dist');
const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || '127.0.0.1';

if (!existsSync(join(dist, 'index.html'))) {
  console.error('\n  dist/ was not found. Build the app first:\n\n    npm install\n    npm run build\n\n  (or use "npm run dev" for development)\n');
  process.exit(1);
}

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ttf': 'font/ttf',
  '.pfb': 'application/octet-stream',
  '.bcmap': 'application/octet-stream',
  '.wasm': 'application/wasm',
  '.pdf': 'application/pdf',
  '.txt': 'text/plain; charset=utf-8',
};

const CSP = [
  "default-src 'self'",
  "script-src 'self' 'wasm-unsafe-eval' https://www.youtube.com https://s.ytimg.com",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob: https://i.ytimg.com",
  "media-src 'self' blob: https:",
  "font-src 'self' data:",
  "connect-src 'self' https://api.open-meteo.com https://geocoding-api.open-meteo.com",
  'frame-src https://www.youtube-nocookie.com https://www.youtube.com https://www.aparat.com',
  "worker-src 'self' blob:",
  "manifest-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "frame-ancestors 'self'",
].join('; ');

const SECURITY = {
  'content-security-policy': CSP,
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'strict-origin-when-cross-origin',
  'permissions-policy': 'microphone=(self), camera=(), geolocation=()',
  'cross-origin-opener-policy': 'same-origin',
};

const api = createApiHandler({ env: process.env });

function serveFile(res, file, status = 200) {
  const ext = extname(file).toLowerCase();
  const immutable = file.includes(`${sep}assets${sep}`);
  res.writeHead(status, {
    'content-type': TYPES[ext] || 'application/octet-stream',
    'cache-control': immutable ? 'public, max-age=31536000, immutable' : ext === '.html' || file.endsWith('sw.js') ? 'no-cache' : 'public, max-age=3600',
    ...SECURITY,
  });
  createReadStream(file).pipe(res);
}

const server = createServer((req, res) => {
  const url = new URL(req.url || '/', 'http://localhost');
  if (url.pathname.startsWith('/api/')) return void api(req, res);
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, SECURITY);
    return res.end();
  }
  let path;
  try {
    path = decodeURIComponent(url.pathname);
  } catch {
    res.writeHead(400, SECURITY);
    return res.end();
  }
  const file = normalize(join(dist, path));
  // must stay inside dist/ (a bare prefix check would also allow siblings like dist-artifact/)
  if (file !== dist && !file.startsWith(dist + sep)) {
    res.writeHead(403, SECURITY);
    return res.end();
  }
  if (existsSync(file) && statSync(file).isFile()) return serveFile(res, file);
  if (!extname(path)) return serveFile(res, join(dist, 'index.html'));
  res.writeHead(404, SECURITY);
  res.end();
});

const appUrl = `http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`;
const wantsBrowser = process.argv.includes('--open');

/** Opens the default browser (used by the double-click launchers). Failure is harmless. */
function openBrowser(url) {
  const [cmd, args] =
    process.platform === 'win32' ? ['rundll32', ['url.dll,FileProtocolHandler', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  try {
    const child = spawn(cmd, args, { stdio: 'ignore', detached: true, windowsHide: true });
    child.on('error', () => console.log(`  Open this address in your browser: ${url}`));
    child.unref();
  } catch {
    console.log(`  Open this address in your browser: ${url}`);
  }
}

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`\n  Port ${PORT} is already in use. Hamyar may already be running: open ${appUrl}`);
    console.error('  To use another port, put a line like PORT=4180 in the .env file.\n');
    if (wantsBrowser) openBrowser(appUrl);
  } else {
    console.error(`\n  The server could not start: ${e.message}\n`);
  }
  process.exitCode = 1;
});

server.listen(PORT, HOST, () => {
  console.log(`\n  همیار / Hamyar is running:  ${appUrl}`);
  console.log('  Keep this window open while you use Hamyar. Press Ctrl+C to stop.\n');
  if (wantsBrowser) openBrowser(appUrl);
});
