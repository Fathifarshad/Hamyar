/** Builds tiny MP4 files out of boxes, so the video code can be tested without real films. */
export const enc = (s: string) => Array.from(s).map((c) => c.charCodeAt(0));
export const u32 = (n: number) => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
export const u16 = (n: number) => [(n >> 8) & 255, n & 255];
export const zeros = (n: number) => new Array<number>(n).fill(0);
export type Part = number[] | Uint8Array;

export const box = (type: string, ...payload: Part[]): Uint8Array<ArrayBuffer> => {
  const body = payload.flatMap((p) => Array.from(p));
  return new Uint8Array([...u32(8 + body.length), ...enc(type), ...body]);
};
export const cat = (...parts: Part[]): Uint8Array<ArrayBuffer> => new Uint8Array(parts.flatMap((p) => Array.from(p)));

export const ftyp = (brand = 'isom') => box('ftyp', enc(brand), u32(512), enc('isom'), enc('mp42'));
export const mvhd = (scale: number, duration: number) => box('mvhd', [0, 0, 0, 0], u32(0), u32(0), u32(scale), u32(duration), zeros(80));
export const tkhd = (w: number, h: number) => box('tkhd', [0, 0, 0, 3], zeros(68), u32(w * 65536), u32(h * 65536));
export const hdlr = (kind: string) => box('hdlr', [0, 0, 0, 0], u32(0), enc(kind), zeros(12), [0]);
export const visual = (fourcc: string, w: number, h: number, config: Uint8Array) =>
  box(fourcc, zeros(6), u16(1), zeros(16), u16(w), u16(h), u32(0x480000), u32(0x480000), u32(0), u16(1), zeros(32), u16(24), u16(0xffff), config);
export const avc1 = (w: number, h: number) => visual('avc1', w, h, box('avcC', [1, 100, 0, 40, 0xff, 0xe1, 0, 0]));
export const hvc1 = (w: number, h: number) => visual('hvc1', w, h, box('hvcC', [1, 0x01, 0x60, 0, 0, 0, 0xb0, 0, 0, 0, 0, 0, 93, 0, 0, 0]));
export const mp4aAac = () =>
  box('mp4a', zeros(6), u16(1), zeros(8), u16(2), u16(16), zeros(4), u32(48000 * 65536), box('esds', [0, 0, 0, 0, 0x03, 0x16, 0, 1, 0, 0x04, 0x11, 0x40, 0x15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x05, 0x02, 0x12, 0x10]));
export const track = (kind: string, entry: Uint8Array, w = 0, h = 0) => box('trak', tkhd(w, h), box('mdia', hdlr(kind), box('minf', box('stbl', box('stsd', [0, 0, 0, 0], u32(1), entry)))));
export const moov = (video: Uint8Array, audio?: Uint8Array, w = 1920, h = 1080) => box('moov', mvhd(1000, 62000), track('vide', video, w, h), ...(audio ? [track('soun', audio)] : []));
