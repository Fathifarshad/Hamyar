import { describe, expect, it } from 'vitest';
import { dirOf } from '../../src/lib/bidi';

describe('dirOf', () => {
  it('keeps Persian text that starts with a Latin word right-to-left in a Persian UI', () => {
    expect(dirOf('PDF و خلاصه', 'rtl')).toBe('rtl');
    expect(dirOf('PDF ها', 'rtl')).toBe('rtl');
  });

  it('gives pure English text its own direction inside a Persian UI', () => {
    expect(dirOf('3 apples', 'rtl')).toBe('ltr');
    expect(dirOf('Call Bob!', 'rtl')).toBe('ltr');
  });

  it('gives pure Persian text its own direction inside an English UI', () => {
    expect(dirOf('خرید نان', 'ltr')).toBe('rtl');
  });

  it('lets a clearly dominant script win over the UI direction', () => {
    expect(dirOf('Meeting with the design team about علی', 'rtl')).toBe('ltr');
    expect(dirOf('جلسه با John', 'ltr')).toBe('ltr');
    expect(dirOf('جلسه هفتگی تیم طراحی با John', 'ltr')).toBe('rtl');
  });

  it('falls back to the UI direction for text without letters', () => {
    expect(dirOf('', 'rtl')).toBe('rtl');
    expect(dirOf('12:30', 'ltr')).toBe('ltr');
    expect(dirOf(null, 'rtl')).toBe('rtl');
  });
});
