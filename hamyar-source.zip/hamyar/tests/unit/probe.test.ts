import { describe, expect, it } from 'vitest';
import { judge, probeFile, probeTag, type CanPlay } from '../../src/modules/video/probe';
import { avc1, box, cat, enc, ftyp, hvc1, moov, mp4aAac, u32, visual, zeros } from './helpers/mp4';

const file = (bytes: Uint8Array<ArrayBuffer>, type = 'video/mp4') => new File([bytes], 'x.mp4', { type });
const readable = (n = 0) => ({ arrayBuffer: () => (n ? Promise.resolve(new ArrayBuffer(n)) : Promise.reject(Object.assign(new Error('x'), { name: 'NotReadableError' }))) });
/** A blob that fails to read from some offset on, the way a phone's file can. */
const flaky = (b: Blob, failFrom: number): Blob => ({ size: b.size, type: b.type, slice: (s: number, e: number) => (s >= failFrom ? readable() : b.slice(s, e)) }) as unknown as Blob;

describe('probeFile — MP4', () => {
  it('reads codecs, size and length from a "fast start" file (index first)', async () => {
    const p = await probeFile(file(cat(ftyp(), moov(avc1(1920, 1080), mp4aAac()), box('mdat', zeros(2000)))));
    expect(p).toMatchObject({ container: 'mp4', brand: 'isom', seconds: 62, read: { head: 'ok', mid: 'ok', tail: 'ok' } });
    expect(p.video).toEqual({ codec: 'avc1.640028', label: 'H.264', width: 1920, height: 1080 });
    expect(p.audio).toEqual({ codec: 'mp4a.40.2', label: 'AAC' });
  });

  it('finds the index at the end of the file, after the media data (how phone cameras write it)', async () => {
    const mdat = cat(u32(8 + 300_000), enc('mdat'), zeros(300_000));
    const p = await probeFile(new File([ftyp('mp42'), mdat, moov(hvc1(3840, 2160), mp4aAac(), 3840, 2160)], 'cam.mp4', { type: 'video/mp4' }));
    expect(p.brand).toBe('mp42');
    expect(p.video).toEqual({ codec: 'hvc1.1.6.L93.B0', label: 'HEVC (H.265)', width: 3840, height: 2160 });
    expect(p.audio?.codec).toBe('mp4a.40.2');
  });

  it('names Dolby Vision, AV1 and VP9 tracks', async () => {
    const dv = await probeFile(file(cat(ftyp(), moov(visual('dvh1', 3840, 2160, box('dvcC', zeros(24)))))));
    expect(dv.video).toMatchObject({ label: 'Dolby Vision', codec: 'dvh1.08.06' });
    const av1 = await probeFile(file(cat(ftyp(), moov(visual('av01', 1920, 1080, box('av1C', [0x81, 0x08, 0x4c, 0]))))));
    expect(av1.video).toMatchObject({ label: 'AV1', codec: 'av01.0.08M.10' });
    const vp9 = await probeFile(file(cat(ftyp(), moov(visual('vp09', 1280, 720, box('vpcC', [1, 0, 0, 0, 0, 31, 0x80, 0]))))));
    expect(vp9.video).toMatchObject({ label: 'VP9', codec: 'vp09.00.31.08' });
  });

  it('knows other sound codecs by name', async () => {
    const ac3 = await probeFile(file(cat(ftyp(), moov(avc1(640, 360), box('ac-3', zeros(28))))));
    expect(ac3.audio).toEqual({ codec: 'ac-3', label: 'AC-3 (Dolby Digital)' });
  });

  it('still says "mp4" when the index cannot be read or is missing', async () => {
    const p = await probeFile(file(cat(ftyp(), box('mdat', zeros(500)))));
    expect(p).toMatchObject({ container: 'mp4', brand: 'isom', video: null, audio: null });
  });

  it('does not choke on a damaged index', async () => {
    const bad = cat(ftyp(), u32(5000), enc('moov'), zeros(100));
    const p = await probeFile(file(bad));
    expect(p.container).toBe('mp4');
    expect(p.video).toBeNull();
  });
});

describe('probeFile — other containers', () => {
  it('recognises Matroska by its codec names', async () => {
    const mkv = cat([0x1a, 0x45, 0xdf, 0xa3, 0x9f], [0x42, 0x82, 0x88], enc('matroska'), [0x42, 0x87, 0x81, 4], [0x86, 0x8f], enc('V_MPEGH/ISO/HEVC'), [0x86, 0x85], enc('A_AC3'), zeros(200));
    const p = await probeFile(file(mkv, 'video/x-matroska'));
    expect(p.container).toBe('mkv');
    expect(p.video).toMatchObject({ codec: 'hvc1.1.6.L120.B0', label: 'HEVC (H.265)' });
    expect(p.audio).toEqual({ codec: 'ac-3', label: 'AC-3 (Dolby Digital)' });
  });

  it('recognises WebM', async () => {
    const webm = cat([0x1a, 0x45, 0xdf, 0xa3, 0x9f], [0x42, 0x82, 0x84], enc('webm'), [0x86, 0x85], enc('V_VP9'), [0x86, 0x86], enc('A_OPUS'), zeros(100));
    const p = await probeFile(file(webm, 'video/webm'));
    expect(p).toMatchObject({ container: 'webm', video: { codec: 'vp09.00.10.08' }, audio: { codec: 'opus' } });
  });

  it('recognises AVI and names its video codec', async () => {
    const avi = cat(enc('RIFF'), u32(5000), enc('AVI '), enc('LIST'), u32(300), enc('hdrl'), enc('avih'), u32(56), zeros(56), enc('LIST'), u32(100), enc('strl'), enc('strh'), u32(56), enc('vids'), enc('XVID'), zeros(60));
    const p = await probeFile(file(avi, 'video/x-msvideo'));
    expect(p.container).toBe('avi');
    expect(p.video?.codec).toBe('XVID');
  });

  it('recognises MPEG transport streams', async () => {
    const ts = new Uint8Array(1000);
    for (const at of [0, 188, 376, 564]) ts[at] = 0x47;
    expect((await probeFile(file(ts, 'video/mp2t'))).container).toBe('ts');
  });

  it('says "unknown" for anything else', async () => {
    expect((await probeFile(file(new Uint8Array(200).fill(7)))).container).toBe('unknown');
    expect((await probeFile(new File([], 'e.mp4'))).container).toBe('unknown');
  });
});

describe('probeFile — a phone that will not let the app read', () => {
  const mp4 = cat(ftyp(), moov(avc1(1280, 720), mp4aAac()), box('mdat', zeros(60_000)));

  it('reports that nothing can be read, with the browser’s error name', async () => {
    const dead = { size: 5000, type: 'video/mp4', slice: () => readable() } as unknown as Blob;
    const p = await probeFile(dead);
    expect(p.read).toEqual({ head: 'NotReadableError', mid: 'NotReadableError', tail: 'NotReadableError' });
    expect(p.container).toBe('unknown');
  });

  it('reports a file that can be read from the start but not from the middle or the end (a source that cannot be seeked)', async () => {
    const p = await probeFile(flaky(new File([mp4], 'x.mp4', { type: 'video/mp4' }), 20_000));
    expect(p.read).toEqual({ head: 'ok', mid: 'NotReadableError', tail: 'NotReadableError' });
    expect(p.container).toBe('mp4');
  });
});

describe('judge', () => {
  const canPlay: CanPlay = (codec) => (codec.startsWith('avc1') || codec.startsWith('mp4a') || codec.startsWith('vp09') ? 'probably' : '');
  const probeOf = async (b: Uint8Array<ArrayBuffer>) => probeFile(file(b));

  it('explains a codec the phone cannot play (HEVC) instead of retrying', async () => {
    const p = await probeOf(cat(ftyp(), moov(hvc1(3840, 2160), mp4aAac())));
    expect(judge(p, canPlay)).toEqual({ kind: 'unsupported-video', label: 'HEVC (H.265)', codec: 'hvc1.1.6.L93.B0' });
  });

  it('never rules out H.264 on the strength of one "no" — copying the file may still work', async () => {
    const p = await probeOf(cat(ftyp(), moov(avc1(1920, 1080), mp4aAac())));
    expect(judge(p, () => '')).toEqual({ kind: 'unknown' });
    expect(judge(p, canPlay)).toEqual({ kind: 'unknown' });
  });

  it('explains containers browsers do not play at all', async () => {
    const ts = new Uint8Array(1000);
    for (const at of [0, 188, 376]) ts[at] = 0x47;
    expect(judge(await probeOf(ts), canPlay)).toEqual({ kind: 'unsupported-container', label: 'MPEG-TS' });
  });

  it('reports an unreadable file', async () => {
    const p = await probeFile({ size: 10, type: '', slice: () => readable() } as unknown as Blob);
    expect(judge(p, canPlay)).toEqual({ kind: 'unreadable' });
  });
});

describe('probeTag', () => {
  it('fits what matters on one line of small print', async () => {
    const p = await probeFile(file(cat(ftyp(), moov(avc1(1920, 1080), mp4aAac()), box('mdat', zeros(2000)))));
    const tag = probeTag(p, () => 'probably');
    expect(tag).toContain('mp4/isom');
    expect(tag).toContain('V avc1.640028 1920x1080');
    expect(tag).toContain('A mp4a.40.2');
    expect(tag).toContain('62s');
    expect(tag).toContain('read ok');
    expect(tag).toContain('can V:y A:y');
    expect(tag.length).toBeLessThan(140);
    expect(probeTag(p, () => '')).toContain('can V:n A:n');
  });

  it('shows which reads failed', async () => {
    const p = await probeFile(flaky(new File([cat(ftyp(), box('mdat', zeros(50_000)))], 'x.mp4'), 10_000));
    expect(probeTag(p)).toContain('read mid:NotReadableError tail:NotReadableError');
  });
});
