import { beforeEach, describe, expect, it } from 'vitest';
import { openDatabase } from '../../src/data/db';
import { applyPreset, createModule, planPreset, setActive, countActive, deleteModule } from '../../src/data/modules';

let n = 0;
beforeEach(() => {
  openDatabase(`test-modules-${++n}`);
});

const make = (active = true) => createModule({ type: 'notes', title: 'n', active, inputLanguage: 'fa-IR' });

describe('active module cap', () => {
  it('allows ten active modules and rejects the eleventh without losing data', async () => {
    for (let i = 0; i < 10; i++) await make();
    await expect(make()).rejects.toMatchObject({ code: 'MODULE_LIMIT_REACHED' });
    const hidden = await make(false);
    expect(hidden.active).toBe(0);
    await expect(setActive(hidden.id, true)).rejects.toMatchObject({ code: 'MODULE_LIMIT_REACHED' });
    expect(await countActive()).toBe(10);
  });

  it('two concurrent activations with nine active: exactly one wins', async () => {
    for (let i = 0; i < 9; i++) await make();
    const a = await make(false);
    const b = await make(false);
    const results = await Promise.allSettled([setActive(a.id, true), setActive(b.id, true)]);
    expect(results.filter((r) => r.status === 'fulfilled')).toHaveLength(1);
    expect(await countActive()).toBe(10);
  });

  it('presets respect the cap and never delete', async () => {
    for (let i = 0; i < 8; i++) await make();
    const plan = await planPreset('daily', 'add');
    expect(plan.activeAfter).toBe(10);
    await applyPreset(plan, (t) => t, 'fa-IR', 'fa');
    expect(await countActive()).toBe(10);
    const sw = await planPreset('health', 'switch');
    await applyPreset(sw, (t) => t, 'fa-IR', 'fa');
    expect(await countActive()).toBeLessThanOrEqual(10);
  });

  it('delete removes the module', async () => {
    const m = await make();
    await deleteModule(m.id);
    expect(await countActive()).toBe(0);
  });
});
