import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { db, openDatabase } from '../../src/data/db';
import { copyBlob, errName, fingerprint, saveAsset, sniff } from '../../src/data/assets';
import { DomainError } from '../../src/domain/types';
import { LIMITS } from '../../src/config/limits';
import { sha256 } from '../../src/lib/hash';

let n = 0;
beforeEach(() => {
  openDatabase(`test-assets-${++n}`);
});
afterEach(() => {
  vi.restoreAllMocks();
});

const enc = (s: string) => Array.from(s).map((c) => c.charCodeAt(0));
/** A minimal MP4-family header: box size, 'ftyp', major brand, padding. */
const mp4 = (brand: string) => new Blob([new Uint8Array([0, 0, 0, 0x18, ...enc('ftyp'), ...enc(brand), 0, 0, 0, 0, ...enc('isom'), ...enc('mp42')])]);
const withType = (b: Blob, type: string) => new Blob([b], { type });
const notReadable = () => Object.assign(new Error('The requested file could not be read'), { name: 'NotReadableError' });
const MiB = 1024 * 1024;

describe('sniff — the real file family comes from the first bytes', () => {
  it('treats an mp4 declared as video as a video', async () => {
    expect((await sniff(withType(mp4('isom'), 'video/mp4'))).family).toBe('video');
  });

  it('keeps an mp4 with no declared type ambiguous instead of calling it audio (mp42 is mostly video)', async () => {
    expect((await sniff(mp4('mp42'))).family).toBe('av');
    expect((await sniff(mp4('isom'))).family).toBe('av');
    expect((await sniff(mp4('qt  '))).family).toBe('av');
  });

  it('still recognises audio-only brands and declared audio types', async () => {
    expect((await sniff(mp4('M4A '))).family).toBe('audio');
    expect((await sniff(mp4('M4B '))).family).toBe('audio');
    expect((await sniff(withType(mp4('mp42'), 'audio/mp4'))).family).toBe('audio');
  });

  it('recognises WebM/Matroska, AVI, WAV, MP3 and PDF', async () => {
    const webm = new Blob([new Uint8Array([0x1a, 0x45, 0xdf, 0xa3, 1, 2, 3, 4])]);
    expect((await sniff(webm)).family).toBe('av');
    expect((await sniff(withType(webm, 'video/webm'))).family).toBe('video');
    const avi = new Blob([new Uint8Array([...enc('RIFF'), 0, 0, 0, 0, ...enc('AVI '), ...enc('LIST')])]);
    expect(await sniff(avi)).toEqual({ family: 'video', mime: 'video/x-msvideo' });
    const wav = new Blob([new Uint8Array([...enc('RIFF'), 0, 0, 0, 0, ...enc('WAVE'), ...enc('fmt ')])]);
    expect((await sniff(wav)).family).toBe('audio');
    expect((await sniff(new Blob([new Uint8Array([...enc('ID3'), 3, 0, 0, 0])]))).family).toBe('audio');
    expect((await sniff(new Blob(['%PDF-1.7\n']))).family).toBe('pdf');
  });

  it('does not guess for unknown content and keeps the declared type', async () => {
    expect(await sniff(withType(new Blob(['just some text']), 'video/x-matroska'))).toEqual({ family: 'unknown', mime: 'video/x-matroska' });
    expect(await sniff(new Blob(['x']))).toEqual({ family: 'unknown', mime: 'application/octet-stream' });
  });

  it('reports an unreadable file as FILE_UNREADABLE with the browser error name', async () => {
    const unreadable = { size: 10, type: '', slice: () => ({ arrayBuffer: () => Promise.reject(notReadable()) }) } as unknown as Blob;
    const e = await sniff(unreadable).catch((x: unknown) => x);
    expect(e).toBeInstanceOf(DomainError);
    expect((e as DomainError).code).toBe('FILE_UNREADABLE');
    expect((e as DomainError).details).toMatchObject({ cause: 'NotReadableError', stage: 'sniff' });
  });
});

describe('fingerprint — never reads a whole film', () => {
  it('is a plain SHA-256 for small files', async () => {
    const small = new Blob(['hello film']);
    expect(await fingerprint(small)).toBe(await sha256(small));
  });

  it('identifies a large file by size plus three small samples', async () => {
    const data = new Uint8Array(9 * MiB);
    data.fill(7);
    const big = new Blob([data]);
    const read: [number, number][] = [];
    const spy = {
      size: big.size,
      slice: (a: number, b: number = big.size) => {
        read.push([a, b]);
        return big.slice(a, b);
      },
    } as unknown as Blob;
    const fp = await fingerprint(spy);
    expect(fp).toMatch(/^s9437184-[0-9a-f]{64}$/);
    const total = read.reduce((sum, [a, b]) => sum + (b - a), 0);
    expect(total).toBeLessThanOrEqual(3 * 256 * 1024);
    expect(await fingerprint(new Blob([data]))).toBe(fp);
    const changed = new Uint8Array(data);
    changed[0] = 8;
    expect(await fingerprint(new Blob([changed]))).not.toBe(fp);
  });

  it('turns a read failure into FILE_UNREADABLE', async () => {
    const unreadable = { size: 100, arrayBuffer: () => Promise.reject(notReadable()) } as unknown as Blob;
    const e = (await fingerprint(unreadable).catch((x: unknown) => x)) as DomainError;
    expect(e.code).toBe('FILE_UNREADABLE');
    expect(e.details).toMatchObject({ cause: 'NotReadableError', stage: 'fingerprint' });
  });
});

describe('copyBlob', () => {
  it('copies a file larger than one chunk byte for byte and keeps its type', async () => {
    const data = new Uint8Array(9 * MiB + 123);
    for (let i = 0; i < data.length; i += 4099) data[i] = i % 251;
    const src = new Blob([data], { type: 'video/mp4' });
    const copy = await copyBlob(src);
    expect(copy.size).toBe(src.size);
    expect(copy.type).toBe('video/mp4');
    expect(await sha256(copy)).toBe(await sha256(src));
  });
});

describe('errName', () => {
  it('prefers the original browser error wrapped by Dexie', () => {
    expect(errName({ name: 'AbortError', inner: { name: 'QuotaExceededError' } })).toBe('QuotaExceededError');
    expect(errName({ name: 'UnknownError' })).toBe('UnknownError');
    expect(errName(null)).toBe('Error');
  });
});

describe('saveAsset', () => {
  const input = (blob: Blob, extra: Partial<Parameters<typeof saveAsset>[0]> = {}) => ({ moduleId: 'm1', kind: 'video' as const, blob, name: 'clip.mp4', maxBytes: LIMITS.videoBytes, ...extra });

  it('stores a small file with its SHA-256 and the real bytes', async () => {
    const blob = withType(new Blob(['abcdef']), 'video/mp4');
    const a = await saveAsset(input(blob));
    expect(a.hash).toBe(await sha256(blob));
    expect(a.size).toBe(6);
    const stored = await db.assets.get(a.id);
    expect(stored?.mime).toBe('video/mp4');
    expect(await sha256(stored!.blob)).toBe(a.hash);
  });

  it('refuses empty and oversized files and a full account', async () => {
    await expect(saveAsset(input(new Blob([])))).rejects.toMatchObject({ code: 'EMPTY_FILE' });
    await expect(saveAsset(input(new Blob(['12345']), { maxBytes: 4 }))).rejects.toMatchObject({ code: 'FILE_TOO_LARGE' });
    await db.assets.add({ id: 'big', moduleId: 'm0', kind: 'video', name: 'x', mime: 'video/mp4', size: LIMITS.accountStorageBytes, hash: 'h', blob: new Blob(['x']), createdAt: '2026-01-01T00:00:00Z' });
    await expect(saveAsset(input(new Blob(['12345'])))).rejects.toMatchObject({ code: 'QUOTA_EXCEEDED' });
  });

  it('uses the cheap fingerprint for a big file instead of hashing all of it', async () => {
    const a = await saveAsset(input(new Blob([new Uint8Array(9 * MiB)]), { maxBytes: 20 * MiB }));
    expect(a.hash).toMatch(/^s9437184-/);
  });

  it('retries with a plain copy when the browser rejects the picked file itself', async () => {
    const original = db.assets.add.bind(db.assets);
    const add = vi.spyOn(db.assets, 'add').mockRejectedValueOnce(Object.assign(new Error('boom'), { name: 'UnknownError' })).mockImplementation(original);
    const a = await saveAsset(input(withType(new Blob(['0123456789']), 'video/mp4')));
    expect(add).toHaveBeenCalledTimes(2);
    expect(await db.assets.count()).toBe(1);
    expect((await db.assets.get(a.id))!.blob.size).toBe(10);
  });

  it('reports STORE_FAILED with both causes when the copy cannot be stored either', async () => {
    vi.spyOn(db.assets, 'add').mockRejectedValue(Object.assign(new Error('boom'), { name: 'UnknownError' }));
    const e = (await saveAsset(input(new Blob(['0123456789']))).catch((x: unknown) => x)) as DomainError;
    expect(e).toBeInstanceOf(DomainError);
    expect(e.code).toBe('STORE_FAILED');
    expect(e.details).toMatchObject({ cause: 'UnknownError', first: 'UnknownError' });
    expect(await db.assets.count()).toBe(0);
  });

  it('does not retry a full browser store — it says so', async () => {
    const add = vi.spyOn(db.assets, 'add').mockRejectedValue(Object.assign(new Error('full'), { name: 'QuotaExceededError' }));
    await expect(saveAsset(input(new Blob(['0123456789'])))).rejects.toMatchObject({ code: 'BROWSER_STORAGE_FULL' });
    expect(add).toHaveBeenCalledTimes(1);
  });

  it('reports FILE_UNREADABLE when the copy cannot read the file either', async () => {
    vi.spyOn(db.assets, 'add').mockRejectedValue(Object.assign(new Error('boom'), { name: 'DataCloneError' }));
    const real = new Blob(['0123456789']);
    const flaky = { size: real.size, type: '', arrayBuffer: () => real.arrayBuffer(), slice: () => ({ arrayBuffer: () => Promise.reject(notReadable()) }) } as unknown as Blob;
    const e = (await saveAsset(input(flaky)).catch((x: unknown) => x)) as DomainError;
    expect(e.code).toBe('FILE_UNREADABLE');
    expect(e.details).toMatchObject({ cause: 'NotReadableError', stage: 'copy', first: 'DataCloneError' });
  });
});
