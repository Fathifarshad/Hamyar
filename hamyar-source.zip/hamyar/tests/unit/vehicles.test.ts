import { beforeEach, describe, expect, it } from 'vitest';
import { db, openDatabase } from '../../src/data/db';
import { createModule } from '../../src/data/modules';
import { parseVehicleCommand } from '../../src/modules/vehicles/parse';
import { addRecord, createVehicle, deleteRecord, deleteVehicle, emptyRecord, emptyVehicle, normalizeVin, setOdometer, updateRecord, validateRecord, vinProblem } from '../../src/modules/vehicles/data';
import { attention, costTotals, dueItems, latestByKind, vehicleReminders } from '../../src/modules/vehicles/due';
import { planNotifications } from '../../src/lib/reminderPlan';
import { buildExport, commitImport, validateImport } from '../../src/data/transfer';
import { readNumber } from '../../src/domain/commands/numbers';
import { addMonthsInCalendar } from '../../src/domain/jalali';
import { zonedToUtc } from '../../src/domain/time';
import type { ModuleInstance, Vehicle, VehicleRecord } from '../../src/domain/types';

const TZ = 'America/Santiago';
const now = zonedToUtc('2026-11-13', '09:00', TZ);
const today = '2026-11-13';

let n = 0;
beforeEach(() => {
  openDatabase(`test-vehicles-${++n}`);
});

const car = (p: Partial<Vehicle> = {}): Vehicle => ({ id: 'v1', moduleId: 'm', name: 'پژو سفید', make: 'ایران‌خودرو', model: 'پژو ۲۰۶', year: '1398', color: '', plate: '', vin: '', engineNo: '', odometer: 85000, odometerDate: today, notes: '', order: 0, createdAt: '', updatedAt: '', ...p });
const rec = (p: Partial<VehicleRecord>): VehicleRecord => ({ id: 'r', vehicleId: 'v1', moduleId: 'm', kind: 'oil', title: '', date: today, validUntil: null, odometer: null, nextDueKm: null, nextDueDate: null, cost: null, currency: 'IRT', provider: '', reference: '', items: [], notes: '', remind: true, createdAt: '2026-11-13T12:00:00Z', updatedAt: '', ...p });
const mod = (p: Partial<ModuleInstance> = {}): ModuleInstance => ({ id: 'm', type: 'vehicles', title: 'خودروها', active: 1, archivedAt: null, order: 0, inputLanguage: 'fa-IR', voiceMode: 'command', remindersPaused: false, appearance: { preset: 'default', accent: 'indigo', icon: 'car', width: 'normal', density: 'comfortable' }, config: { remindDays: [30, 7, 1, 0], remindTime: '10:00' }, configVersion: 1, version: 1, createdAt: '', updatedAt: '', ...p });

describe('reading a sentence about a car', () => {
  const vehicles = [car(), car({ id: 'v2', name: 'تویوتا', make: 'Toyota', model: 'Corolla', odometer: null })];
  const parse = (s: string) => parseVehicleCommand(s, { now, timezone: TZ, calendar: 'jalali', vehicles });

  it('an oil change with the odometer, the next one «5 thousand km from now» and the cost', () => {
    expect(parse('پژو تعویض روغن امروز کیلومتر ۸۶ هزار بعدی ۵ هزار کیلومتر دیگه هزینه ۲ میلیون تومان')).toEqual({
      vehicleId: 'v1',
      kind: 'oil',
      title: '',
      date: today,
      validUntil: null,
      odometer: 86000,
      nextDueKm: 91000,
      nextDueDate: null,
      cost: 2_000_000,
      currency: 'IRT',
      odometerOnly: false,
    });
  });

  it('a policy «until 20 Esfand 1405» with its premium', () => {
    expect(parse('بیمه ثالث تویوتا تا ۲۰ اسفند ۱۴۰۵ حق بیمه ۸ میلیون')).toMatchObject({ vehicleId: 'v2', kind: 'insurance_third', validUntil: '2027-03-11', cost: 8_000_000, title: '' });
  });

  it('«one-year» body insurance ends on the same Jalali date next year', () => {
    expect(parse('بیمه بدنه پژو از امروز یک ساله')).toMatchObject({ vehicleId: 'v1', kind: 'insurance_body', validUntil: '2027-11-13' });
    expect(parse('بیمه ثالث پژو ۱۰ روز دیگه تموم میشه')).toMatchObject({ kind: 'insurance_third', validUntil: '2026-11-23', title: '' });
  });

  it('only a new odometer reading, with the car’s name in between', () => {
    expect(parse('کیلومتر پژو ۸۷ هزار')).toMatchObject({ vehicleId: 'v1', kind: null, odometer: 87000, odometerOnly: true });
  });

  it('«تا» used as a counter («دو تا لاستیک») is not an end date', () => {
    expect(parse('دو تا لاستیک جلو پژو عوض کردم هزینه ۶ میلیون')).toMatchObject({ vehicleId: 'v1', kind: 'tires', title: 'دو تا جلو', cost: 6_000_000, validUntil: null });
  });

  it('a repair yesterday; English with thousands separators', () => {
    expect(parse('تعمیر کلاچ پژو دیروز ۴ میلیون تومان')).toMatchObject({ kind: 'repair', title: 'کلاچ', date: '2026-11-12', cost: 4_000_000, currency: 'IRT' });
    expect(parse('oil change toyota today 120,000 km next in 10000 km')).toMatchObject({ vehicleId: 'v2', kind: 'oil', odometer: 120000, nextDueKm: 130000 });
  });

  it('asks which car when there are two and none is named', () => {
    expect(parse('معاینه فنی تا ۱۵ خرداد')).toMatchObject({ vehicleId: null, kind: 'inspection', validUntil: '2027-06-05' });
  });
});

describe('numbers as said', () => {
  it('reads digits, separators and words', () => {
    expect(readNumber('85,000')).toBe(85000);
    expect(readNumber('85.000')).toBe(85000);
    expect(readNumber('85 000')).toBe(85000);
    expect(readNumber('2.5 میلیون')).toBe(2_500_000);
    expect(readNumber('هشتاد و پنج هزار')).toBe(85000);
    expect(readNumber('12k')).toBe(12000);
  });

  it('adds months in the Jalali or Gregorian calendar, keeping the day', () => {
    expect(addMonthsInCalendar('2026-11-13', 12, 'jalali')).toBe('2027-11-13');
    expect(addMonthsInCalendar('2027-01-31', 1, 'gregorian')).toBe('2027-02-28');
    expect(addMonthsInCalendar('2026-11-13', -12, 'gregorian')).toBe('2025-11-13');
  });
});

describe('what is due', () => {
  it('the latest record of a kind counts (a renewal replaces the old policy)', () => {
    const old = rec({ id: 'a', kind: 'insurance_third', date: '2025-11-01', validUntil: '2026-11-01' });
    const renewed = rec({ id: 'b', kind: 'insurance_third', date: '2026-11-01', validUntil: '2027-11-01' });
    expect(latestByKind([old, renewed]).get('insurance_third')?.id).toBe('b');
  });

  it('statuses by date and by odometer, with tracked kinds shown even when empty', () => {
    const items = dueItems(
      car({ odometer: 90500 }),
      [
        rec({ id: 'i', kind: 'insurance_third', validUntil: '2026-12-01' }),
        rec({ id: 'x', kind: 'inspection', validUntil: '2026-11-10' }),
        rec({ id: 'o', kind: 'oil', odometer: 86000, nextDueKm: 91000 }),
        rec({ id: 't', kind: 'tires', nextDueDate: '2028-01-01' }),
      ],
      today,
    );
    const by = Object.fromEntries(items.map((d) => [d.kind, d]));
    expect(by.inspection).toMatchObject({ status: 'overdue', daysLeft: -3 });
    expect(by.insurance_third).toMatchObject({ status: 'soon', daysLeft: 18 });
    expect(by.oil).toMatchObject({ status: 'soon', kmLeft: 500 });
    expect(by.insurance_body).toMatchObject({ status: 'none', record: null });
    expect(by.tires).toMatchObject({ status: 'ok' });
    expect(items[0]!.kind).toBe('inspection');
    expect(attention([car({ odometer: 90500 })], [rec({ id: 'o', kind: 'oil', odometer: 86000, nextDueKm: 90000 })], today)[0]).toMatchObject({ kind: 'oil', status: 'overdue', kmLeft: -500 });
  });

  it('reminds 30, 7 and 1 day before and on the day, at 10:00 local time, only for the latest record', () => {
    const records = [rec({ id: 'old', kind: 'insurance_third', date: '2025-01-01', validUntil: '2026-11-20' }), rec({ id: 'new', kind: 'insurance_third', date: '2026-11-01', validUntil: '2026-11-20' })];
    const list = vehicleReminders({ modules: [mod()], vehicles: [car()], records, timezone: TZ, locale: 'fa', formatDate: (iso) => iso, dig: (s) => s }, now, now + 30 * 86_400_000);
    expect(list.map((r) => r.key)).toEqual(['veh:new:2026-11-20:7', 'veh:new:2026-11-20:1', 'veh:new:2026-11-20:0']);
    expect(list[0]!.at).toBe(zonedToUtc('2026-11-13', '10:00', TZ));
    expect(list[0]).toMatchObject({ title: 'بیمه شخص ثالث · پژو سفید', url: '#/m/m?focus=v1' });
    expect(list[0]!.body).toContain('7 روز دیگر');
    expect(list[2]!.body).toContain('امروز');
  });

  it('no reminders when they are off, the section is paused or archived', () => {
    const r = [rec({ id: 'a', kind: 'inspection', validUntil: '2026-11-20' })];
    const input = (m: ModuleInstance, records = r) => ({ modules: [m], vehicles: [car()], records, timezone: TZ, locale: 'fa' as const, formatDate: (s: string) => s, dig: (s: string) => s });
    const span = [now, now + 30 * 86_400_000] as const;
    expect(vehicleReminders(input(mod()), ...span)).toHaveLength(3);
    expect(vehicleReminders(input(mod({ remindersPaused: true })), ...span)).toHaveLength(0);
    expect(vehicleReminders(input(mod({ archivedAt: '2026-01-01' })), ...span)).toHaveLength(0);
    expect(vehicleReminders(input(mod(), [{ ...r[0]!, remind: false }]), ...span)).toHaveLength(0);
  });

  it('the Android plan includes car reminders', () => {
    const plan = planNotifications(
      { profile: { locale: 'fa', timezone: TZ, calendar: 'jalali' }, modules: [mod()], tasks: [], completions: [], medications: [], medEvents: [], reminders: [], focus: [], vehicles: [car()], vehicleRecords: [rec({ id: 'a', kind: 'oil', nextDueDate: '2026-11-20' })] },
      now,
    );
    expect(plan.filter((p) => p.kind === 'vehicle').map((p) => p.title)).toEqual(['تعویض روغن · پژو سفید', 'تعویض روغن · پژو سفید', 'تعویض روغن · پژو سفید']);
  });

  it('adds up costs per currency', () => {
    const t = costTotals([rec({ cost: 100, currency: 'USD' }), rec({ cost: 50, currency: 'USD', date: '2020-01-01' }), rec({ cost: 2_000_000, currency: 'IRT' }), rec({ cost: null })], '2026-01-01');
    expect(Object.fromEntries(t)).toEqual({ USD: 100, IRT: 2_000_000 });
  });
});

describe('storing cars and records', () => {
  it('checks a VIN without blocking odd ones', () => {
    expect(normalizeVin(' vf3-2a ۵ ')).toBe('VF32A5');
    expect(vinProblem('VF32A5FX0EW123456')).toBeNull();
    expect(vinProblem('VF32A5')).toBe('length');
    expect(vinProblem('VF32A5FX0EW12345O')).toBe('chars');
    expect(vinProblem('')).toBeNull();
  });

  it('a record moves the odometer forward, never back; deleting a car removes its records and reminders', async () => {
    const m = await createModule({ type: 'vehicles', title: 'خودروها', active: true, inputLanguage: 'fa-IR' });
    const v = await createVehicle(m.id, { ...emptyVehicle(), name: 'پژو', vin: 'vf32a5fx0ew123456', odometer: 85000 }, today);
    expect(v.vin).toBe('VF32A5FX0EW123456');
    const r = await addRecord(v.id, { ...emptyRecord('oil', today, 'IRT'), odometer: 86000, nextDueKm: 91000 }, 'idem-1');
    expect((await db.vehicles.get(v.id))?.odometer).toBe(86000);
    // the same confirmation twice saves once
    expect((await addRecord(v.id, { ...emptyRecord('oil', today, 'IRT'), odometer: 86000 }, 'idem-1')).id).toBe(r.id);
    await addRecord(v.id, { ...emptyRecord('repair', '2026-01-01', 'IRT'), odometer: 70000 });
    expect((await db.vehicles.get(v.id))?.odometer).toBe(86000);
    await setOdometer(v.id, 86500, today);
    await updateRecord(r.id, { ...emptyRecord('oil', today, 'IRT'), odometer: 86000, nextDueKm: 92000 });
    expect((await db.vehicleRecords.get(r.id))?.nextDueKm).toBe(92000);
    await db.reminders.add({ id: 'x', kind: 'vehicle', sourceId: r.id, moduleId: m.id, occurrenceKey: v.id, dueAt: 0, firedAt: '', late: false, title: '', body: '', readAt: null, snoozedUntil: null, followUpOf: null, delivery: 'in_app' });
    await deleteVehicle(v.id);
    expect(await db.vehicleRecords.count()).toBe(0);
    expect(await db.reminders.count()).toBe(0);
  });

  it('validates records: a policy needs its end date after the start; the next service after this one', async () => {
    expect(validateRecord({ ...emptyRecord('insurance_third', today, 'IRT') })).toMatchObject({ validUntil: 'required' });
    expect(validateRecord({ ...emptyRecord('insurance_third', today, 'IRT'), validUntil: '2026-01-01' })).toMatchObject({ validUntil: 'before_start' });
    expect(validateRecord({ ...emptyRecord('oil', today, 'IRT'), odometer: 90000, nextDueKm: 85000 })).toMatchObject({ nextDueKm: 'not_after' });
    expect(validateRecord({ ...emptyRecord('other', today, 'IRT') })).toMatchObject({ title: 'required' });
    expect(Object.keys(validateRecord({ ...emptyRecord('oil', today, 'IRT'), odometer: 90000, nextDueKm: 95000 }))).toEqual([]);
    const m = await createModule({ type: 'vehicles', title: 'خودروها', active: true, inputLanguage: 'fa-IR' });
    const v = await createVehicle(m.id, { ...emptyVehicle(), name: 'پژو' }, today);
    await expect(addRecord(v.id, emptyRecord('inspection', today, 'IRT'))).rejects.toMatchObject({ code: 'INVALID_INPUT' });
    const r = await addRecord(v.id, { ...emptyRecord('inspection', today, 'IRT'), validUntil: '2027-11-13', nextDueKm: 5 });
    expect(r.nextDueKm).toBeNull(); // a validity record keeps no "next service"
    await deleteRecord(r.id);
    expect(await db.vehicleRecords.count()).toBe(0);
  });

  it('cars travel in the JSON backup with fresh ids, and old backups without cars still import', async () => {
    const m = await createModule({ type: 'vehicles', title: 'خودروها', active: true, inputLanguage: 'fa-IR' });
    const v = await createVehicle(m.id, { ...emptyVehicle(), name: 'پژو' }, today);
    await addRecord(v.id, { ...emptyRecord('insurance_third', today, 'IRT'), validUntil: '2027-11-13' });
    const file = await buildExport();
    expect(file.tables.vehicles).toHaveLength(1);
    openDatabase(`test-vehicles-import-${n}`);
    const plan = await validateImport(JSON.parse(JSON.stringify(file)));
    expect(plan.ok).toBe(true);
    await commitImport(plan, 'fa');
    const [car2] = await db.vehicles.toArray();
    const [rec2] = await db.vehicleRecords.toArray();
    expect(car2!.id).not.toBe(v.id);
    expect(rec2).toMatchObject({ vehicleId: car2!.id, moduleId: car2!.moduleId, validUntil: '2027-11-13' });
    const old = JSON.parse(JSON.stringify(file));
    delete old.tables.vehicles;
    delete old.tables.vehicleRecords;
    openDatabase(`test-vehicles-old-${n}`);
    const plan2 = await validateImport(old);
    expect(plan2.ok).toBe(true);
    await commitImport(plan2, 'fa');
    expect(await db.vehicles.count()).toBe(0);
  });
});

describe('upgrading an existing phone', () => {
  it('a version-1 database opens with the new tables and keeps everything', async () => {
    const { default: Dexie } = await import('dexie');
    const name = `test-upgrade-${n}`;
    const v1 = new Dexie(name);
    v1.version(1).stores({ kv: 'key', profile: 'id', modules: 'id, type, active, order', notes: 'id, moduleId, updatedAt' });
    await v1.open();
    await v1.table('notes').add({ id: 'n1', moduleId: 'm1', title: 'قدیمی', body: '', tags: [], pinned: false, createdAt: '', updatedAt: '' });
    v1.close();
    const upgraded = openDatabase(name);
    expect((await upgraded.notes.get('n1'))?.title).toBe('قدیمی');
    expect(await upgraded.vehicles.count()).toBe(0);
    expect(upgraded.verno).toBe(2);
  });
});
