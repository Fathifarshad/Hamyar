import { beforeEach, describe, expect, it } from 'vitest';
import { db, kvSet, openDatabase } from '../../src/data/db';
import { createModule } from '../../src/data/modules';
import { tick } from '../../src/lib/reminders';
import { defaultProfile } from '../../src/shell/AppContext';
import { DST_POLICY, type Medication, type Task } from '../../src/domain/types';
import { zonedToUtc } from '../../src/domain/time';
import { expandByDates } from '../../src/domain/recurrence';
import { recordDose, updateMed, inputFromMed } from '../../src/modules/medications/data';

// All times in UTC to keep the arithmetic obvious.
const TZ = 'UTC';
const DAY = '2026-10-05';
const T0 = zonedToUtc(DAY, '10:00', TZ);
const ts = new Date(0).toISOString();

let n = 0;
beforeEach(async () => {
  openDatabase(`test-reminders-${++n}`);
  await db.profile.put({ ...defaultProfile('fa'), timezone: TZ, onboarded: true, reminderSound: false, systemNotifications: false });
});

function task(moduleId: string, title: string, time: string, reminderOffset = 0): Task {
  return {
    id: `${moduleId}-${title}`,
    moduleId,
    kind: 'event',
    title,
    notes: '',
    priority: 'normal',
    revisions: [{ validFrom: 0, rule: { freq: 'once', startDate: DAY, endDate: null, weekdays: [], times: [time], timezone: TZ } }],
    reminderOffset,
    dstPolicy: DST_POLICY,
    revision: 1,
    createdAt: ts,
    updatedAt: ts,
  };
}

async function tasksModule(patch: Record<string, unknown> = {}) {
  const m = await createModule({ type: 'tasks', title: 'کارها', active: true, inputLanguage: 'fa-IR' });
  if (Object.keys(patch).length) await db.modules.update(m.id, patch);
  return m;
}

describe('in-app reminders', () => {
  it('fires for visible and hidden sections, but not archived or paused ones', async () => {
    const visible = await tasksModule();
    const hidden = await tasksModule({ active: 0 });
    const archived = await tasksModule({ active: 0, archivedAt: ts });
    const paused = await tasksModule({ remindersPaused: true });
    await db.tasks.bulkAdd([task(visible.id, 'visible', '10:00'), task(hidden.id, 'hidden', '10:00'), task(archived.id, 'archived', '10:00'), task(paused.id, 'paused', '10:00')]);
    await kvSet('reminders:lastTick', T0 - 60_000);
    await tick(T0 + 30_000);
    const titles = (await db.reminders.toArray()).map((r) => r.title).sort();
    expect(titles).toEqual(['hidden', 'visible']);
  });

  it('fires each reminder once, even when ticks repeat', async () => {
    const m = await tasksModule();
    await db.tasks.add(task(m.id, 'once', '10:00'));
    await kvSet('reminders:lastTick', T0 - 60_000);
    await tick(T0 + 10_000);
    await kvSet('reminders:lastTick', T0 - 60_000); // simulate a second tab replaying the same window
    await tick(T0 + 20_000);
    expect(await db.reminders.count()).toBe(1);
  });

  it('marks reminders more than 60 minutes late as inbox-only', async () => {
    const m = await tasksModule();
    await db.tasks.add(task(m.id, 'missed', '07:30'));
    await kvSet('reminders:lastTick', T0 - 5 * 3600_000);
    await tick(T0);
    const [r] = await db.reminders.toArray();
    expect(r?.late).toBe(true);
    expect(r?.delivery).toBe('none');
  });

  it('medication reminders never record a dose, and snoozing only re-notifies', async () => {
    const mods = await createModule({ type: 'medications', title: 'داروها', active: true, inputLanguage: 'fa-IR' });
    const med: Medication = {
      id: 'med-1',
      moduleId: mods.id,
      name: 'نمونه',
      dosageText: '۱ عدد',
      unitText: '',
      notes: '',
      revisions: [{ validFrom: 0, rule: { freq: 'daily', startDate: DAY, endDate: null, weekdays: [], times: ['10:00'], timezone: TZ } }],
      active: true,
      reminderEnabled: true,
      showNameInNotification: false,
      dstPolicy: DST_POLICY,
      revision: 1,
      createdAt: ts,
      updatedAt: ts,
    };
    await db.medications.add(med);
    await kvSet('reminders:lastTick', T0 - 60_000);
    await tick(T0 + 5_000);
    const [first] = await db.reminders.toArray();
    expect(first?.kind).toBe('medication');
    expect(first?.title).not.toContain('نمونه'); // generic text unless the name is allowed
    expect(await db.medEvents.count()).toBe(0);

    await db.reminders.update(first!.id, { snoozedUntil: T0 + 10 * 60_000 });
    await tick(T0 + 11 * 60_000);
    const all = await db.reminders.toArray();
    expect(all).toHaveLength(2);
    expect(all.find((r) => r.followUpOf === first!.id)).toBeTruthy();
    expect(await db.medEvents.count()).toBe(0);
  });

  it('a double confirmation records one dose, and later schedule edits keep the recorded snapshot', async () => {
    const mods = await createModule({ type: 'medications', title: 'داروها', active: true, inputLanguage: 'fa-IR' });
    const med: Medication = {
      id: 'med-2',
      moduleId: mods.id,
      name: 'دارو الف',
      dosageText: '۱ عدد',
      unitText: '',
      notes: '',
      revisions: [{ validFrom: 0, rule: { freq: 'daily', startDate: DAY, endDate: null, weekdays: [], times: ['10:00'], timezone: TZ } }],
      active: true,
      reminderEnabled: true,
      showNameInNotification: false,
      dstPolicy: DST_POLICY,
      revision: 1,
      createdAt: ts,
      updatedAt: ts,
    };
    await db.medications.add(med);
    const [occ] = expandByDates(med.revisions, DAY, DAY);
    const once = { med, occ: occ!, action: 'taken' as const, actualTakenAt: null, idempotencyKey: 'click-1' };
    await Promise.all([recordDose(once), recordDose(once)]);
    expect(await db.medEvents.count()).toBe(1);

    const input = inputFromMed(med);
    await updateMed(med.id, { ...input, name: 'دارو ب', times: ['21:00'] }, T0 + 3600_000);
    const [ev] = await db.medEvents.toArray();
    expect(ev?.snapshot.name).toBe('دارو الف');
    expect(ev?.snapshot.localTime).toBe('10:00');
  });
});
