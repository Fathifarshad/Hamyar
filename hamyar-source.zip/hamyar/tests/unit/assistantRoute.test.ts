import { describe, expect, it } from 'vitest';
import { routeUtterance, type RouteModule } from '../../src/assistant/route';
import { zonedToUtc } from '../../src/domain/time';

const now = zonedToUtc('2026-11-13', '09:00', 'America/Santiago');
const mods: RouteModule[] = [
  { id: 'meds', type: 'medications', title: 'داروها', active: 1, archivedAt: null, order: 0 },
  { id: 'car', type: 'vehicles', title: 'ماشین‌ها', active: 1, archivedAt: null, order: 1 },
  { id: 'mus', type: 'music', title: 'موسیقی', active: 1, archivedAt: null, order: 2 },
  { id: 'tsk', type: 'tasks', title: 'کارها', active: 1, archivedAt: null, order: 3 },
  { id: 'old', type: 'tasks', title: 'کارهای قدیمی', active: 0, archivedAt: '2026-01-01T00:00:00Z', order: 4 },
  { id: 'hid', type: 'notes', title: 'یادداشت پنهان', active: 0, archivedAt: null, order: 5 },
];
const route = (s: string) => routeUtterance(s, { modules: mods, now, timezone: 'America/Santiago' });

describe('the first word chooses the section', () => {
  it('medicine: «دارو» is dropped, the rest goes to the medications section', () => {
    expect(route('دارو استامینوفن ۵۰۰ هر ۸ ساعت')).toEqual({ kind: 'module', type: 'medications', moduleId: 'meds', text: 'استامینوفن ۵۰۰ هر ۸ ساعت' });
    expect(route('داروی جدید آموکسی سیلین')).toMatchObject({ type: 'medications', text: 'آموکسی سیلین' });
    // a form word stays, it is part of the name
    expect(route('قرص فشار ساعت ۸')).toMatchObject({ type: 'medications', text: 'قرص فشار ساعت ۸' });
  });

  it('cars: «ماشین» is dropped; insurance, oil and km words go there as they are', () => {
    expect(route('ماشین تعویض روغن امروز')).toMatchObject({ type: 'vehicles', moduleId: 'car', text: 'تعویض روغن امروز' });
    expect(route('بیمه ثالث تا ۲۰ اسفند')).toMatchObject({ type: 'vehicles', text: 'بیمه ثالث تا ۲۰ اسفند' });
    expect(route('معاینه فنی تا ۱۵ خرداد')).toMatchObject({ type: 'vehicles' });
    expect(route('کیلومتر ۸۷ هزار')).toMatchObject({ type: 'vehicles' });
  });

  it('music keeps the whole sentence (the music section reads «آهنگ‌های …» itself)', () => {
    expect(route('آهنگ‌های گوگوش')).toEqual({ kind: 'module', type: 'music', moduleId: 'mus', text: 'آهنگ‌های گوگوش' });
    expect(route('پخش آهنگ خلیج')).toMatchObject({ type: 'music', text: 'پخش آهنگ خلیج' });
    expect(route('پخش فیلم سفر')).toMatchObject({ type: 'video', text: 'سفر' });
  });

  it('tasks, lists, expenses, water, weather and the focus timer', () => {
    expect(route('یادم بنداز فردا ساعت ۹ جلسه')).toMatchObject({ type: 'tasks', moduleId: 'tsk', text: 'یادم بنداز فردا ساعت ۹ جلسه' });
    expect(route('خرید نان، شیر و تخم مرغ')).toMatchObject({ type: 'checklists', moduleId: null, text: 'نان، شیر و تخم مرغ' });
    expect(route('هزینه ۵۰ هزار تومان نان')).toMatchObject({ type: 'expenses', text: '۵۰ هزار تومان نان' });
    expect(route('یک لیوان آب')).toMatchObject({ type: 'habits' });
    expect(route('آب و هوا')).toMatchObject({ type: 'weather' });
    expect(route('تمرکز ۴۰ دقیقه')).toMatchObject({ type: 'focus', text: 'شروع ۴۰ دقیقه' });
    expect(route('تمرکز توقف')).toMatchObject({ type: 'focus', text: 'توقف' });
  });

  it('prefers a shown section, never an archived one, and uses a hidden one when it is the only one', () => {
    expect(route('کار خرید نان')).toMatchObject({ moduleId: 'tsk' });
    expect(route('یادداشت کتاب جدید بخرم')).toMatchObject({ type: 'notes', moduleId: 'hid', text: 'کتاب جدید بخرم' });
  });

  it('says when there is no section of that kind yet', () => {
    expect(route('هزینه ۲۰ دلار قهوه')).toMatchObject({ kind: 'module', type: 'expenses', moduleId: null });
  });
});

describe('without a section word', () => {
  it('an amount with a currency is an expense; a date or time is a task', () => {
    expect(route('۵۰ هزار تومان نان')).toMatchObject({ type: 'expenses' });
    expect(route('فردا ساعت ۵ دندانپزشکی')).toMatchObject({ type: 'tasks', text: 'فردا ساعت ۵ دندانپزشکی' });
  });

  it('anything else is not guessed', () => {
    expect(route('سلام خوبی')).toEqual({ kind: 'unknown', text: 'سلام خوبی' });
    expect(route('   ')).toMatchObject({ kind: 'unknown' });
  });

  it('opens a section by its name', () => {
    expect(route('باز کن داروها')).toEqual({ kind: 'open', moduleId: 'meds' });
    expect(route('برو به ماشین')).toEqual({ kind: 'open', moduleId: 'car' });
    expect(route('open music')).toEqual({ kind: 'open', moduleId: 'mus' });
  });
});
