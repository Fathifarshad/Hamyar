import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { db, openDatabase } from '../../src/data/db';
import { LIMITS } from '../../src/config/limits';
import { DomainError, type Asset } from '../../src/domain/types';
import { addPickedFile, attachPickedFile, canKeepCopy, keepCopy, mediaProblem, pickedVersion, playableBlob, saving, sessionFiles, storedBlob, titleFromFileName } from '../../src/modules/video/files';

let n = 0;
beforeEach(() => {
  openDatabase(`test-videofiles-${++n}`);
});
afterEach(() => {
  vi.restoreAllMocks();
});

const enc = (s: string) => Array.from(s).map((c) => c.charCodeAt(0));
const mp4Bytes = (extra = 64): Uint8Array<ArrayBuffer> => new Uint8Array([0, 0, 0, 0x18, ...enc('ftyp'), ...enc('isom'), 0, 0, 0, 0, ...enc('isom'), ...enc('mp42'), ...new Array(extra).fill(1)]);
const video = (name = 'trip.mp4', type = 'video/mp4', bytes: Uint8Array<ArrayBuffer> = mp4Bytes()) => new File([bytes], name, { type });

describe('small helpers', () => {
  it('builds a list title from the file name', () => {
    expect(titleFromFileName('My Film.mp4')).toBe('My Film');
    expect(titleFromFileName('trip.MKV')).toBe('trip');
    expect(titleFromFileName('no-extension')).toBe('no-extension');
    expect(titleFromFileName('.mp4')).toBe('.mp4');
    expect(titleFromFileName('x'.repeat(300) + '.mp4')).toHaveLength(120);
  });

  it('classifies <video> errors and keeps the browser message as a technical tag', () => {
    expect(mediaProblem({ code: 4, message: 'DEMUXER_ERROR_COULD_NOT_OPEN: FFmpegDemuxer: open context failed' })).toEqual({ kind: 'format', tag: 'MEDIA_ERR_SRC_NOT_SUPPORTED · DEMUXER_ERROR_COULD_NOT_OPEN: FFmpegDemuxer: open context failed' });
    expect(mediaProblem({ code: 3 })).toEqual({ kind: 'decode', tag: 'MEDIA_ERR_DECODE' });
    expect(mediaProblem({ code: 2, message: '  spaced \n out  ' })).toEqual({ kind: 'network', tag: 'MEDIA_ERR_NETWORK · spaced out' });
    expect(mediaProblem({ code: 1 }).kind).toBe('aborted');
    expect(mediaProblem(null)).toEqual({ kind: 'unknown', tag: 'MEDIA_ERR' });
    expect(mediaProblem({ code: 4, message: 'x'.repeat(500) }).tag.length).toBeLessThan(120);
  });

  it('only offers to keep a copy of files the app can store', () => {
    expect(canKeepCopy(0)).toBe(false);
    expect(canKeepCopy(1)).toBe(true);
    expect(canKeepCopy(LIMITS.videoBytes)).toBe(true);
    expect(canKeepCopy(LIMITS.videoBytes + 1)).toBe(false);
  });

  it('gives the player a typed blob even when the phone reported no type', () => {
    const untyped = new File([mp4Bytes()], 'a.mp4');
    expect(untyped.type).toBe('');
    expect(playableBlob({ file: untyped, mime: 'video/mp4' }).type).toBe('video/mp4');
    const typed = video();
    expect(playableBlob({ file: typed, mime: 'video/webm' })).toBe(typed);
    const stored = new Blob(['abc']);
    expect(storedBlob({ blob: stored, mime: 'video/mp4', size: 3 }).type).toBe('video/mp4');
  });
});

describe('sessionFiles', () => {
  it('remembers picked files, counts re-picks and tells the UI when anything changes', () => {
    const seen: number[] = [];
    const off = pickedVersion.subscribe(() => seen.push(pickedVersion.get()));
    const f = video();
    expect(sessionFiles.has('a')).toBe(false);
    expect(sessionFiles.version('a')).toBe(0);
    sessionFiles.remember('a', f, 'video/mp4');
    sessionFiles.remember('a', f, 'video/mp4');
    expect(sessionFiles.recall('a')).toEqual({ file: f, mime: 'video/mp4' });
    expect(sessionFiles.version('a')).toBe(2);
    sessionFiles.forget('a');
    expect(sessionFiles.has('a')).toBe(false);
    expect(sessionFiles.version('a')).toBe(0);
    expect(seen.length).toBe(3);
    off();
  });
});

describe('addPickedFile — play first, keep a copy second', () => {
  it('adds the list entry at once, playable from the picked file, and copies it in the background', async () => {
    const file = video();
    const { item, saved } = await addPickedFile('m1', file, { keepCopy: true });
    expect(item).toMatchObject({ moduleId: 'm1', kind: 'video', sourceType: 'file', assetId: null, title: 'trip', order: 0 });
    expect(sessionFiles.recall(item.id)?.file).toBe(file);
    expect(await db.media.get(item.id)).toMatchObject({ title: 'trip', assetId: null });
    expect(await saved).toEqual({ ok: true });
    const row = await db.media.get(item.id);
    expect(row?.assetId).toBeTruthy();
    const asset = await db.assets.get(row!.assetId!);
    expect(asset).toMatchObject({ kind: 'video', mime: 'video/mp4', size: file.size, moduleId: 'm1' });
    expect(saving.get()).toEqual([]);
  });

  it('numbers new entries after the existing ones', async () => {
    await addPickedFile('m1', video('one.mp4'), { keepCopy: false });
    const { item } = await addPickedFile('m1', video('two.mp4'), { keepCopy: false });
    expect(item.order).toBe(1);
  });

  it('does not copy anything when the person turned the copy off', async () => {
    const { item, saved } = await addPickedFile('m1', video(), { keepCopy: false });
    expect(saved).toBeNull();
    expect(await db.assets.count()).toBe(0);
    expect(sessionFiles.has(item.id)).toBe(true);
  });

  it('plays a file that is too big to store, without copying it', async () => {
    const mutable = LIMITS as { videoBytes: number };
    const original = mutable.videoBytes;
    mutable.videoBytes = 50;
    try {
      const { item, saved } = await addPickedFile('m1', video('film.mp4', 'video/mp4', mp4Bytes(200)), { keepCopy: true });
      expect(saved).toBeNull();
      expect(sessionFiles.has(item.id)).toBe(true);
      expect(await db.assets.count()).toBe(0);
    } finally {
      mutable.videoBytes = original;
    }
  });

  it('keeps the video playable when saving the copy fails, and says why', async () => {
    vi.spyOn(db.assets, 'add').mockRejectedValue(Object.assign(new Error('boom'), { name: 'UnknownError' }));
    const { item, saved } = await addPickedFile('m1', video(), { keepCopy: true });
    const outcome = await saved;
    expect(outcome?.ok).toBe(false);
    expect(((outcome as { error: DomainError }).error as DomainError).code).toBe('STORE_FAILED');
    expect(sessionFiles.has(item.id)).toBe(true);
    expect((await db.media.get(item.id))?.assetId).toBeNull();
    expect(saving.get()).toEqual([]);
  });

  it('drops the copy when the video was removed while it was being written', async () => {
    const original = db.assets.add.bind(db.assets);
    vi.spyOn(db.assets, 'add').mockImplementation(((a: Asset) => db.media.clear().then(() => original(a))) as typeof db.assets.add);
    const { saved } = await addPickedFile('m1', video(), { keepCopy: true });
    await saved;
    expect(await db.assets.count()).toBe(0);
  });

  it('accepts containers it cannot recognise by their first bytes (MKV, MPEG…) and lets the player decide', async () => {
    const { item } = await addPickedFile('m1', new File([new Uint8Array(40).fill(9)], 'old.mpg', { type: 'video/mpeg' }), { keepCopy: false });
    expect(item.title).toBe('old');
  });

  it('refuses empty files, PDFs and audio with a clear reason', async () => {
    await expect(addPickedFile('m1', new File([], 'e.mp4'), { keepCopy: false })).rejects.toMatchObject({ code: 'EMPTY_FILE' });
    await expect(addPickedFile('m1', new File(['%PDF-1.7 hi'], 'a.mp4'), { keepCopy: false })).rejects.toMatchObject({ code: 'UNSUPPORTED_MEDIA', details: { family: 'pdf' } });
    await expect(addPickedFile('m1', new File([new Uint8Array([...enc('ID3'), 3, 0, 0, 0, 0])], 'song.mp4', { type: 'audio/mpeg' }), { keepCopy: false })).rejects.toMatchObject({ code: 'UNSUPPORTED_MEDIA', details: { family: 'audio' } });
    expect(await db.media.count()).toBe(0);
  });

  it('still adds a file whose first bytes cannot be read, so the player gets to try; saving a copy then says why it failed', async () => {
    const f = video();
    const unreadable = () => Promise.reject(Object.assign(new Error('x'), { name: 'NotReadableError' }));
    vi.spyOn(f, 'slice').mockReturnValue({ arrayBuffer: unreadable } as unknown as Blob);
    vi.spyOn(f, 'arrayBuffer').mockImplementation(unreadable);
    const { item, saved } = await addPickedFile('m1', f, { keepCopy: true });
    expect(await db.media.count()).toBe(1);
    expect(sessionFiles.recall(item.id)).toEqual({ file: f, mime: 'video/mp4' });
    const outcome = await saved;
    expect(outcome?.ok).toBe(false);
    expect((outcome as { error: DomainError }).error.code).toBe('FILE_UNREADABLE');
    expect(await db.assets.count()).toBe(0);
  });
});

describe('keepCopy / attachPickedFile', () => {
  it('writes one copy even if asked twice at the same time', async () => {
    const { item } = await addPickedFile('m1', video(), { keepCopy: false });
    const file = sessionFiles.recall(item.id)!.file;
    await Promise.all([keepCopy(item.id, file), keepCopy(item.id, file)]);
    expect(await db.assets.count()).toBe(1);
    await keepCopy(item.id, file); // already stored: nothing more is written
    expect(await db.assets.count()).toBe(1);
  });

  it('re-attaches a file picked again after the app was restarted', async () => {
    const { item } = await addPickedFile('m1', video(), { keepCopy: false });
    sessionFiles.forget(item.id); // simulates a restart
    expect(sessionFiles.has(item.id)).toBe(false);
    await attachPickedFile(item.id, video('again.mp4'));
    expect(sessionFiles.recall(item.id)?.file.name).toBe('again.mp4');
    await expect(attachPickedFile(item.id, new File(['%PDF-1.7'], 'x.pdf'))).rejects.toMatchObject({ code: 'UNSUPPORTED_MEDIA' });
  });
});
