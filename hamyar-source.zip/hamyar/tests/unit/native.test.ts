import { beforeEach, describe, expect, it, vi } from 'vitest';

// Stand-ins for the Android plugins: record what Hamyar asks the phone to do.
const state = vi.hoisted(() => ({
  display: 'granted' as 'granted' | 'denied' | 'prompt',
  exact: 'granted' as 'granted' | 'denied',
  pending: [] as { id: number }[],
  scheduled: [] as Record<string, unknown>[],
  cancelled: [] as number[],
}));

vi.mock('@capacitor/local-notifications', () => ({
  LocalNotifications: {
    checkPermissions: async () => ({ display: state.display }),
    requestPermissions: async () => ({ display: state.display }),
    checkExactNotificationSetting: async () => ({ exact_alarm: state.exact }),
    changeExactNotificationSetting: async () => ({ exact_alarm: state.exact }),
    getPending: async () => ({ notifications: state.pending }),
    cancel: async (o: { notifications: { id: number }[] }) => {
      state.cancelled.push(...o.notifications.map((n) => n.id));
    },
    schedule: async (o: { notifications: Record<string, unknown>[] }) => {
      state.scheduled.push(...o.notifications);
      return { notifications: o.notifications.map((n) => ({ id: n.id })) };
    },
    createChannel: async () => undefined,
    addListener: async () => ({ remove: async () => undefined }),
  },
}));
vi.mock('@capacitor/app', () => ({ App: { addListener: async () => ({ remove: async () => undefined }), minimizeApp: async () => undefined } }));
vi.mock('@capacitor/core', () => ({ SystemBars: { setStyle: async () => undefined }, SystemBarsStyle: { Dark: 'DARK', Light: 'LIGHT' } }));

import { db, openDatabase } from '../../src/data/db';
import { createModule } from '../../src/data/modules';
import { defaultProfile } from '../../src/shell/AppContext';
import { addDaysISO, todayISO } from '../../src/domain/time';
import { DST_POLICY } from '../../src/domain/types';
import { syncNotifications } from '../../src/lib/native';

const TZ = 'UTC';
let n = 0;

async function setup(systemNotifications = true) {
  openDatabase(`test-native-${++n}`);
  await db.profile.put({ ...defaultProfile('fa'), timezone: TZ, onboarded: true, systemNotifications });
  const mod = await createModule({ type: 'tasks', title: 'کارها', active: true, inputLanguage: 'fa-IR' });
  const tomorrow = addDaysISO(todayISO(TZ, Date.now()), 1);
  const ts = new Date().toISOString();
  await db.tasks.add({
    id: 'call',
    moduleId: mod.id,
    kind: 'event',
    title: 'تماس با دکتر',
    notes: '',
    priority: 'normal',
    revisions: [{ validFrom: 0, rule: { freq: 'once', startDate: tomorrow, endDate: null, weekdays: [], times: ['09:00'], timezone: TZ } }],
    reminderOffset: 10,
    dstPolicy: DST_POLICY,
    revision: 1,
    createdAt: ts,
    updatedAt: ts,
  });
  return mod;
}

beforeEach(() => {
  state.display = 'granted';
  state.exact = 'granted';
  state.pending = [{ id: 7 }, { id: 4242 }];
  state.scheduled = [];
  state.cancelled = [];
});

describe('Android reminder sync', () => {
  it('replaces the old plan with exact, idle-proof alarms that open the right section', async () => {
    const mod = await setup();
    const count = await syncNotifications();
    expect(count).toBe(1);
    expect(state.cancelled).toEqual([4242]); // the test notification (id 7) is left alone
    const [first] = state.scheduled as { title: string; channelId: string; isExactNotification: boolean; schedule: { at: Date; allowWhileIdle: boolean }; extra: { url: string } }[];
    expect(first!.title).toBe('تماس با دکتر');
    expect(first!.channelId).toBe('hamyar-reminders');
    expect(first!.isExactNotification).toBe(true);
    expect(first!.schedule.allowWhileIdle).toBe(true);
    expect(first!.schedule.at.toISOString().endsWith('T08:50:00.000Z')).toBe(true); // 10 minutes early
    expect(first!.extra.url).toBe(`#/m/${encodeURIComponent(mod.id)}`);
  });

  it('never opens the exact-alarm settings screen from a background sync', async () => {
    await setup();
    state.exact = 'denied';
    await syncNotifications();
    expect((state.scheduled[0] as { isExactNotification: boolean }).isExactNotification).toBe(false);
  });

  it('schedules nothing without permission, or when phone reminders are switched off', async () => {
    await setup();
    state.display = 'denied';
    expect(await syncNotifications()).toBe(0);
    expect(state.scheduled).toHaveLength(0);
    expect(state.cancelled).toEqual([4242]);

    state.display = 'granted';
    state.cancelled = [];
    await setup(false);
    expect(await syncNotifications()).toBe(0);
    expect(state.scheduled).toHaveLength(0);
    expect(state.cancelled).toEqual([4242]);
  });
});
