import { describe, expect, it } from 'vitest';
import { applyFill, intervalTimes, parseMedicationCommand, spreadTimes } from '../../src/modules/medications/parse';
import { zonedToUtc } from '../../src/domain/time';

const now = zonedToUtc('2026-11-13', '09:00', 'America/Santiago');
const parse = (s: string) => parseMedicationCommand(s, { now, timezone: 'America/Santiago', calendar: 'jalali' });

describe('one sentence fills the medication form', () => {
  it('name, strength, every 8 hours, a note — times placed by the app are marked', () => {
    expect(parse('استامینوفن ۵۰۰ میلی گرم هر ۸ ساعت بعد از غذا')).toMatchObject({
      name: 'استامینوفن',
      dosageText: '۵۰۰',
      unitText: 'میلی‌گرم',
      notes: 'بعد از غذا',
      times: ['00:00', '08:00', '16:00'],
      timesAssumed: true,
      freq: 'daily',
    });
  });

  it('a count of tablets, clock times with morning/evening, nothing assumed', () => {
    expect(parse('قرص فشار لوزارتان یک عدد ساعت ۸ صبح و ۸ شب')).toMatchObject({ name: 'قرص فشار لوزارتان', dosageText: '۱', unitText: 'عدد', times: ['08:00', '20:00'], timesAssumed: false, ambiguous: [] });
  });

  it('keeps the strength in the name when a count is also said', () => {
    expect(parse('متفورمین ۵۰۰ میلی‌گرم یک قرص صبح و شب همراه غذا از فردا')).toMatchObject({ name: 'متفورمین ۵۰۰ میلی‌گرم', dosageText: '۱', unitText: 'قرص', times: ['08:00', '20:00'], startDate: '2026-11-14', notes: 'همراه غذا' });
  });

  it('«روزی سه بار به مدت ۷ روز»: three placed times and an end date; no dose is invented', () => {
    const f = parse('آموکسی سیلین ۵۰۰ روزی سه بار به مدت ۷ روز');
    expect(f).toMatchObject({ name: 'آموکسی سیلین ۵۰۰', dosageText: '', times: ['08:00', '14:00', '20:00'], timesAssumed: true, endDate: '2026-11-19' });
  });

  it('a list of hours on the 24-hour clock is not ambiguous', () => {
    expect(parse('شربت سرفه ۵ سی سی ساعت ۸ و ۱۴ و ۲۰')).toMatchObject({ name: 'شربت سرفه', dosageText: '۵', unitText: 'سی‌سی', times: ['08:00', '14:00', '20:00'], ambiguous: [] });
  });

  it('an hour without morning/evening asks', () => {
    const f = parse('قرص ب کمپلکس شنبه ها و چهارشنبه ها ساعت ۹');
    expect(f).toMatchObject({ freq: 'weekly', weekdays: [3, 6], times: ['09:00'] });
    expect(f.ambiguous[0]?.options).toEqual(['09:00', '21:00']);
  });

  it('half a tablet on an empty stomach', () => {
    expect(parse('لووتیروکسین نصف قرص صبح ناشتا')).toMatchObject({ name: 'لووتیروکسین', dosageText: 'نصف', unitText: 'قرص', notes: 'ناشتا', times: ['07:00'] });
  });

  it('«تا ۲۰ آذر» is the end date, not the start', () => {
    expect(parse('قطره چشم دو قطره هر ۶ ساعت تا ۲۰ آذر')).toMatchObject({ dosageText: '۲', unitText: 'قطره', startDate: null, endDate: '2026-12-11', times: ['02:00', '08:00', '14:00', '20:00'] });
  });

  it('«در صورت درد» is taken only when needed: no times, no reminder', () => {
    const f = parse('ایبوپروفن ۴۰۰ در صورت درد');
    expect(f).toMatchObject({ name: 'ایبوپروفن ۴۰۰', times: [], asNeeded: true, notes: 'در صورت درد' });
    const form = applyFill({ name: '', dosageText: '', unitText: '', notes: '', times: ['08:00'], freq: 'daily' as const, weekdays: [], startDate: '2026-11-13', endDate: null, reminderEnabled: true }, f);
    expect(form.reminderEnabled).toBe(false);
    expect(form.times).toEqual(['08:00']);
  });

  it('once a week without a day: today’s weekday, 08:00, both to check', () => {
    expect(parse('ویتامین د هفته ای یک بار')).toMatchObject({ freq: 'weekly', weekdays: [5], times: ['08:00'], timesAssumed: true });
  });

  it('every other day cannot be scheduled here and is said so', () => {
    expect(parse('فولیک اسید یک روز در میان')).toMatchObject({ everyOtherDay: true, notes: 'یک روز در میان' });
  });

  it('English works too', () => {
    expect(parse('Ibuprofen 400 mg twice a day after meals for 5 days')).toMatchObject({ name: 'Ibuprofen', dosageText: '400', unitText: 'mg', notes: 'after meals', times: ['08:00', '20:00'], endDate: '2026-11-17' });
  });
});

describe('helpers', () => {
  it('spreads N doses over the waking day and steps through the day every H hours', () => {
    expect(spreadTimes(2)).toEqual(['08:00', '20:00']);
    expect(spreadTimes(6)).toHaveLength(6);
    expect(intervalTimes(12)).toEqual(['08:00', '20:00']);
    expect(intervalTimes(6, 6)).toEqual(['00:00', '06:00', '12:00', '18:00']);
    expect(intervalTimes(0)).toEqual([]);
  });

  it('only fills the fields that were said', () => {
    const base = { name: 'قبلی', dosageText: '۱', unitText: 'قرص', notes: 'یادداشت', times: ['09:00'], freq: 'daily' as const, weekdays: [], startDate: '2026-11-13', endDate: null, reminderEnabled: true };
    const out = applyFill(base, parse('بعد از غذا'));
    expect(out).toMatchObject({ name: 'قبلی', dosageText: '۱', times: ['09:00'], notes: 'یادداشت، بعد از غذا' });
  });
});
