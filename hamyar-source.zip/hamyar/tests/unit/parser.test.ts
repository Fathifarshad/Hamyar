import { describe, expect, it } from 'vitest';
import { parseCommand } from '../../src/domain/commands/parse';
import { normalizeForMatch, parseLocaleNumber, parsePersianNumberWords, toAsciiDigits } from '../../src/domain/normalize';

// Fixed clock: Sunday 2026-10-04 10:00 in Tehran (06:30Z)
const NOW = Date.UTC(2026, 9, 4, 6, 30);
const ctx = (moduleType: Parameters<typeof parseCommand>[1]['moduleType'], timezone = 'Asia/Tehran') => ({ moduleType, timezone, now: NOW });

describe('normalization', () => {
  it('normalizes digits and letters', () => {
    expect(toAsciiDigits('ساعت ۹ و ٣٠')).toBe('ساعت 9 و 30');
    expect(normalizeForMatch('كتاب يك')).toBe('کتاب یک');
    expect(parseLocaleNumber('۱۲٬۵۰۰')).toBe(12500);
    expect(parsePersianNumberWords('دو میلیون و پانصد هزار')).toBe(2_500_000);
  });
});

describe('task commands', () => {
  it('«فردا ساعت ۹ صبح جلسه تیم دارم»', () => {
    const d = parseCommand('فردا ساعت ۹ صبح جلسه تیم دارم', ctx('tasks'));
    expect(d.kind).toBe('create_task');
    if (d.kind !== 'create_task') return;
    expect(d.date).toBe('2026-10-05');
    expect(d.time).toBe('09:00');
    expect(d.title).toBe('جلسه تیم');
    expect(d.ambiguity).toBeNull();
    expect(d.isPast).toBe(false);
  });

  it('«ساعت ۹» without morning/evening is ambiguous, not guessed', () => {
    const d = parseCommand('فردا ساعت ۹ جلسه', ctx('tasks'));
    if (d.kind !== 'create_task') throw new Error(d.kind);
    expect(d.time).toBeNull();
    expect(d.ambiguity?.options).toEqual(['09:00', '21:00']);
  });

  it('time without a date assumes today but flags it; past times are not moved', () => {
    const d = parseCommand('یادم بنداز ساعت ۸ صبح دارو بخورم', ctx('tasks'));
    if (d.kind !== 'create_task') throw new Error(d.kind);
    expect(d.dateAssumed).toBe(true);
    expect(d.date).toBe('2026-10-04');
    expect(d.isPast).toBe(true);
    expect(d.title).toBe('دارو بخورم');
  });

  it('afternoon words and half hours', () => {
    const d = parseCommand('پس فردا ساعت ۵ و نیم عصر خرید', ctx('tasks'));
    if (d.kind !== 'create_task') throw new Error(d.kind);
    expect(d.date).toBe('2026-10-06');
    expect(d.time).toBe('17:30');
    expect(d.title).toBe('خرید');
  });

  it('Jalali dates and weekdays', () => {
    const a = parseCommand('۲۰ مهر ساعت ۱۸ تولد سارا', ctx('tasks'));
    if (a.kind !== 'create_task') throw new Error(a.kind);
    expect(a.date).toBe('2026-10-12');
    expect(a.time).toBe('18:00');
    expect(a.title).toBe('تولد سارا');
    const b = parseCommand('سه‌شنبه ساعت ۱۰ صبح دندانپزشکی', ctx('tasks'));
    if (b.kind !== 'create_task') throw new Error(b.kind);
    expect(b.date).toBe('2026-10-06');
  });

  it('relative times', () => {
    const d = parseCommand('نیم ساعت دیگه زنگ بزنم به مامان', ctx('tasks'));
    if (d.kind !== 'create_task') throw new Error(d.kind);
    expect(d.time).toBe('10:30');
    expect(d.title).toBe('زنگ بزنم به مامان');
  });

  it('English commands', () => {
    const d = parseCommand('tomorrow at 9am team meeting', ctx('tasks', 'America/Santiago'));
    if (d.kind !== 'create_task') throw new Error(d.kind);
    expect(d.date).toBe('2026-10-05');
    expect(d.time).toBe('09:00');
    expect(d.title).toBe('team meeting');
    const e = parseCommand('remind me to call mom at 7', ctx('tasks', 'America/Santiago'));
    if (e.kind !== 'create_task') throw new Error(e.kind);
    expect(e.ambiguity?.options).toEqual(['07:00', '19:00']);
    expect(e.title).toBe('call mom');
  });
});

describe('other modules', () => {
  it('media controls', () => {
    expect(parseCommand('پخش', ctx('music'))).toMatchObject({ kind: 'media', action: 'play' });
    expect(parseCommand('بعدی', ctx('music'))).toMatchObject({ kind: 'media', action: 'next' });
    expect(parseCommand('pause', ctx('music'))).toMatchObject({ kind: 'media', action: 'pause' });
    expect(parseCommand('پخش کن باران', ctx('music'))).toMatchObject({ kind: 'media_search', query: 'باران' });
  });
  it('focus timer', () => {
    expect(parseCommand('شروع ۴۰ دقیقه', ctx('focus'))).toMatchObject({ kind: 'focus', action: 'start', minutes: 40 });
    expect(parseCommand('توقف', ctx('focus'))).toMatchObject({ kind: 'focus', action: 'pause' });
  });
  it('pdf page and summary', () => {
    expect(parseCommand('برو صفحه ۱۲', ctx('pdf'))).toMatchObject({ kind: 'pdf_goto', page: 12 });
    expect(parseCommand('خلاصه کن', ctx('pdf'))).toMatchObject({ kind: 'pdf_summarize' });
  });
  it('expenses', () => {
    expect(parseCommand('۵۰ هزار تومان نان', ctx('expenses'))).toMatchObject({ kind: 'create_expense', amount: 50000, currency: 'IRT', note: 'نان' });
    expect(parseCommand('پنجاه هزار تومن تاکسی', ctx('expenses'))).toMatchObject({ amount: 50000, currency: 'IRT', note: 'تاکسی' });
    expect(parseCommand('$12 coffee', ctx('expenses'))).toMatchObject({ amount: 12, currency: 'USD', note: 'coffee' });
  });
  it('checklist and water', () => {
    expect(parseCommand('شیر رو اضافه کن', ctx('checklists'))).toMatchObject({ kind: 'add_item', text: 'شیر' });
    expect(parseCommand('دو لیوان آب', ctx('habits'))).toMatchObject({ kind: 'water_add', count: 2 });
  });
  it('medications never interpret commands', () => {
    expect(parseCommand('ساعت ۸ قرص بخورم', ctx('medications'))).toMatchObject({ kind: 'unsupported', reason: 'not_allowed_here' });
  });
  it('unknown phrases are kept and reported', () => {
    expect(parseCommand('یک چیز نامفهوم', ctx('music'))).toMatchObject({ kind: 'unsupported', reason: 'not_understood' });
  });
});
