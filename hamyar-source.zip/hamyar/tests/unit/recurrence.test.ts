import { describe, expect, it } from 'vitest';
import { expandByDates, expandByInstants, nextOccurrence, reviseSchedule } from '../../src/domain/recurrence';
import type { ScheduleRule } from '../../src/domain/types';

const base: ScheduleRule = { freq: 'daily', startDate: '2026-03-06', endDate: null, weekdays: [], times: ['02:30'], timezone: 'America/New_York' };

describe('recurrence', () => {
  it('daily series across a DST gap keeps one occurrence per day', () => {
    const occ = expandByDates([{ validFrom: 0, rule: base }], '2026-03-06', '2026-03-10');
    expect(occ.map((o) => o.date)).toEqual(['2026-03-06', '2026-03-07', '2026-03-08', '2026-03-09', '2026-03-10']);
    const gap = occ.find((o) => o.date === '2026-03-08')!;
    expect(gap.shifted).toBe(true);
    expect(new Date(gap.at!).toISOString()).toBe('2026-03-08T07:00:00.000Z');
  });

  it('daily series across a fold does not produce two occurrences', () => {
    const rule: ScheduleRule = { ...base, startDate: '2026-10-31', times: ['01:30'] };
    const occ = expandByDates([{ validFrom: 0, rule }], '2026-10-31', '2026-11-02');
    expect(occ).toHaveLength(3);
  });

  it('weekly on selected weekdays with an end date', () => {
    const rule: ScheduleRule = { freq: 'weekly', startDate: '2026-10-01', endDate: '2026-10-20', weekdays: [1, 3], times: ['18:00'], timezone: 'Asia/Tehran' };
    const occ = expandByDates([{ validFrom: 0, rule }], '2026-10-01', '2026-10-31');
    expect(occ.map((o) => o.date)).toEqual(['2026-10-05', '2026-10-07', '2026-10-12', '2026-10-14', '2026-10-19']);
  });

  it('crossing midnight in UTC keeps the local date', () => {
    const rule: ScheduleRule = { freq: 'once', startDate: '2026-10-05', endDate: null, weekdays: [], times: ['23:30'], timezone: 'America/Santiago' };
    const occ = expandByInstants([{ validFrom: 0, rule }], Date.UTC(2026, 9, 5), Date.UTC(2026, 9, 7));
    expect(occ).toHaveLength(1);
    expect(occ[0]!.date).toBe('2026-10-05');
    expect(new Date(occ[0]!.at!).toISOString()).toBe('2026-10-06T02:30:00.000Z');
  });

  it('a revision applies only from its start; history stays', () => {
    const r1: ScheduleRule = { freq: 'daily', startDate: '2026-10-01', endDate: null, weekdays: [], times: ['08:00'], timezone: 'UTC' };
    const r2: ScheduleRule = { ...r1, times: ['20:00'] };
    const now = Date.UTC(2026, 9, 3, 12);
    const revs = reviseSchedule([{ validFrom: 0, rule: r1 }], r2, now, { keepHistory: true });
    const occ = expandByDates(revs, '2026-10-02', '2026-10-04');
    expect(occ.map((o) => o.key)).toEqual(['2026-10-02|08:00', '2026-10-03|08:00', '2026-10-03|20:00', '2026-10-04|20:00']);
    expect(nextOccurrence(revs, now)!.key).toBe('2026-10-03|20:00');
  });

  it('one-off edits replace the schedule', () => {
    const r1: ScheduleRule = { freq: 'once', startDate: '2026-10-01', endDate: null, weekdays: [], times: ['08:00'], timezone: 'UTC' };
    const r2: ScheduleRule = { ...r1, startDate: '2026-10-09' };
    const revs = reviseSchedule([{ validFrom: 0, rule: r1 }], r2, Date.UTC(2026, 9, 3), { keepHistory: true });
    expect(revs).toHaveLength(1);
    expect(expandByDates(revs, '2026-09-01', '2026-12-01').map((o) => o.date)).toEqual(['2026-10-09']);
  });
});
