import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { reconstructPageText, type RawTextItem } from '../../src/lib/pdfText';

describe('pdf text reconstruction', () => {
  it('orders glyph-per-item RTL text and normalizes presentation forms', () => {
    // «سلام دنیا» drawn right-to-left as separate glyphs (visual order = increasing x for later glyphs on the left)
    const glyphs = ['ﺳ', 'ﻼ', 'م', ' ', 'د', 'ﻧ', 'ﯿ', 'ﺎ'];
    const items: RawTextItem[] = glyphs
      .map((g, i) => ({ str: g, transform: [10, 0, 0, 10, 200 - i * 8, 700], width: 7 }))
      .filter((g) => g.str.trim());
    const text = reconstructPageText(items);
    expect(text).toBe('سلام دنیا');
  });

  it('keeps Latin words and numbers readable inside an RTL line', () => {
    const items: RawTextItem[] = [
      { str: 'ﺧ', transform: [10, 0, 0, 10, 300, 700], width: 7 },
      { str: 'ﻼ', transform: [10, 0, 0, 10, 293, 700], width: 7 },
      { str: 'ﺻ', transform: [10, 0, 0, 10, 286, 700], width: 7 },
      { str: 'ﻪ', transform: [10, 0, 0, 10, 279, 700], width: 7 },
      { str: 'PDF', transform: [10, 0, 0, 10, 240, 700], width: 22 },
      { str: '۲۵', transform: [10, 0, 0, 10, 200, 700], width: 12 },
    ];
    expect(reconstructPageText(items)).toBe('خلاصه PDF ۲۵');
  });

  it('leaves left-to-right lines in order', () => {
    const items: RawTextItem[] = [
      { str: 'Hello', transform: [10, 0, 0, 10, 50, 700], width: 30 },
      { str: 'world', transform: [10, 0, 0, 10, 85, 700], width: 30 },
      { str: 'Next line', transform: [10, 0, 0, 10, 50, 686], width: 50 },
    ];
    expect(reconstructPageText(items)).toBe('Hello world\nNext line');
  });

  it('extracts readable Persian from the bundled sample PDF', async () => {
    const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
    const data = new Uint8Array(readFileSync('public/samples/hamyar-sample-fa.pdf'));
    const doc = await pdfjs.getDocument({ data }).promise;
    const page = await doc.getPage(1);
    const content = await page.getTextContent();
    const text = reconstructPageText(content.items.filter((i) => 'str' in i) as RawTextItem[]);
    expect(text).toContain('مدیریت زمان با گام‌های کوچک'.replace(/‌/g, ''));
    expect(text).toContain('برنامه روزانه');
  });
});
