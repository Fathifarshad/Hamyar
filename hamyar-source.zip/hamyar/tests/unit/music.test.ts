import { describe, expect, it } from 'vitest';
import { nameScore, resolveMusicQuery, soundKey } from '../../src/modules/music/match';
import { decodeLegacy, describeTrack, parseId3v1, parseId3v2, parseMp4Tags, readAudioTags, splitArtistTitle, titleFromFileName } from '../../src/modules/music/tags';
import { parseCommand, splitItems } from '../../src/domain/commands/parse';

const enc = (s: string) => [...new TextEncoder().encode(s)];
const latin = (s: string) => [...s].map((c) => c.charCodeAt(0) & 255);
const be32 = (n: number) => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
const safe = (n: number) => [(n >> 21) & 127, (n >> 14) & 127, (n >> 7) & 127, n & 127];

/** An ID3v2 tag with text frames ([id, encoding byte, payload bytes]). */
function id3(major: 3 | 4, frames: [string, number, number[]][]): Uint8Array<ArrayBuffer> {
  const body = frames.flatMap(([id, e, data]) => {
    const payload = [e, ...data];
    return [...latin(id), ...(major === 4 ? safe(payload.length) : be32(payload.length)), 0, 0, ...payload];
  });
  return new Uint8Array([...latin('ID3'), major, 0, 0, ...safe(body.length + 10), ...body, ...new Array(10).fill(0)]);
}
const utf16 = (s: string) => {
  const out = [0xff, 0xfe];
  for (const c of s) {
    const code = c.charCodeAt(0);
    out.push(code & 255, code >> 8);
  }
  return out;
};

describe('reading tags', () => {
  it('ID3v2.3 Latin-1 and UTF-16, ID3v2.4 UTF-8', () => {
    expect(parseId3v2(id3(3, [['TIT2', 0, latin('Pol')], ['TPE1', 0, latin('Googoosh')]]))).toEqual({ title: 'Pol', artist: 'Googoosh' });
    expect(parseId3v2(id3(3, [['TIT2', 1, utf16('گل یخ')], ['TPE1', 1, utf16('سیاوش قمیشی')]]))).toEqual({ title: 'گل یخ', artist: 'سیاوش قمیشی' });
    expect(parseId3v2(id3(4, [['TPE2', 3, enc('Album Artist')], ['TPE1', 3, enc('ابی')], ['TIT2', 3, enc('خلیج')], ['TALB', 3, enc('Khalij')]]))).toEqual({ artist: 'ابی', title: 'خلیج', album: 'Khalij' });
  });

  it('Persian tags written in the Windows Arabic code page are read correctly', () => {
    const cp1256 = new Uint8Array([0xe3, 0xcd, 0xd3, 0xe4]); // «محسن»
    expect(decodeLegacy(cp1256)).toBe('محسن');
    expect(parseId3v2(id3(3, [['TPE1', 0, [...cp1256]]])).artist).toBe('محسن');
    expect(decodeLegacy(new Uint8Array(latin('Café')))).toBe('Café');
  });

  it('the old ID3v1 tag at the end of the file', () => {
    const tail = new Uint8Array(128);
    tail.set(latin('TAG'), 0);
    tail.set(latin('Khalij'), 3);
    tail.set(latin('Ebi'), 33);
    expect(parseId3v1(tail)).toEqual({ title: 'Khalij', artist: 'Ebi' });
  });

  it('M4A (iTunes) tags', () => {
    const box = (type: string, body: number[]) => [...be32(8 + body.length), ...latin(type), ...body];
    const data = (s: string) => box('data', [...be32(1), 0, 0, 0, 0, ...enc(s)]);
    const moov = new Uint8Array(box('moov', box('udta', box('meta', [0, 0, 0, 0, ...box('hdlr', new Array(25).fill(0)), ...box('ilst', [...box('©nam', data('Rolling')), ...box('©ART', data('Adele'))])]))));
    expect(parseMp4Tags(moov)).toEqual({ title: 'Rolling', artist: 'Adele' });
  });

  it('reads a whole file and never throws', async () => {
    const tag = id3(3, [['TIT2', 0, latin('Pol')], ['TPE1', 0, latin('Googoosh')]]);
    expect(await readAudioTags(new Blob([tag, new Uint8Array(2000)]))).toEqual({ title: 'Pol', artist: 'Googoosh' });
    expect(await readAudioTags(new Blob([new Uint8Array(50)]))).toEqual({});
    expect(await readAudioTags({ size: 100, slice: () => ({ arrayBuffer: () => Promise.reject(new Error('x')) }) } as unknown as Blob)).toEqual({});
  });

  it('falls back to «Artist - Title» file names and cleans download-site tags', () => {
    expect(titleFromFileName('Mohsen Yeganeh - Behet Ghol Midam [128] (Nex1Music).mp3')).toBe('Mohsen Yeganeh - Behet Ghol Midam');
    expect(splitArtistTitle('محسن یگانه - بهت قول میدم')).toEqual({ artist: 'محسن یگانه', title: 'بهت قول میدم' });
    expect(splitArtistTitle('Track-01')).toBeNull();
    expect(describeTrack('Ebi - Khalij (320).mp3', {})).toEqual({ title: 'Khalij', artist: 'Ebi' });
    expect(describeTrack('01 track.mp3', { title: 'Pol', artist: 'Googoosh' })).toEqual({ title: 'Pol', artist: 'Googoosh' });
    expect(describeTrack('song_name.mp3', {})).toEqual({ title: 'song name', artist: '' });
  });
});

describe('finding what was asked for', () => {
  const tracks = [
    { id: 'a', title: 'Pol', artist: 'Googoosh' },
    { id: 'b', title: 'Talaye Zard', artist: 'Googoosh' },
    { id: 'c', title: 'Khalij', artist: 'Ebi' },
    { id: 'd', title: 'محسن یگانه - بهت قول میدم', artist: '' },
    { id: 'f', title: 'سیاوش قمیشی - گل یخ', artist: '' },
  ];

  it('one sound key for Persian and Latin spellings', () => {
    expect(soundKey('محسن یگانه')).toBe(soundKey('Mohsen Yeganeh'));
    expect(soundKey('سیاوش قمیشی')).toBe(soundKey('Siavash Ghomayshi'));
    expect(soundKey('هایده')).toBe(soundKey('Hayedeh'));
    expect(soundKey('همایون شجریان')).toBe(soundKey('Homayoun Shajarian'));
    expect(soundKey('خلیج')).toBe(soundKey('Khalij'));
    expect(nameScore('گوگوش', 'Googoosh')).toBeGreaterThanOrEqual(0.6);
    expect(nameScore('داریوش', 'Googoosh')).toBeLessThan(0.6);
  });

  it('an artist said in Persian plays every song of the artist tagged in Latin letters', () => {
    expect(resolveMusicQuery(tracks, 'گوگوش', 'artist')).toEqual({ kind: 'artist', artist: 'Googoosh', ids: ['a', 'b'] });
    expect(resolveMusicQuery(tracks, 'ابی', 'artist')).toEqual({ kind: 'artist', artist: 'Ebi', ids: ['c'] });
    // no tag: the artist comes from «Artist - Title»; one word of the name is enough
    expect(resolveMusicQuery(tracks, 'یگانه', 'artist')).toMatchObject({ kind: 'artist', ids: ['d'] });
  });

  it('a song title plays only that song', () => {
    expect(resolveMusicQuery(tracks, 'خلیج', 'track')).toMatchObject({ kind: 'track', id: 'c', title: 'Khalij' });
    expect(resolveMusicQuery(tracks, 'طلای زرد', 'any')).toMatchObject({ kind: 'track', id: 'b' });
    expect(resolveMusicQuery(tracks, 'گل یخ', 'any')).toMatchObject({ kind: 'track', id: 'f', artist: 'سیاوش قمیشی' });
    expect(resolveMusicQuery(tracks, 'گوگوش', 'any')).toMatchObject({ kind: 'artist' });
  });

  it('says so, with the artists it knows, when nothing fits', () => {
    expect(resolveMusicQuery(tracks, 'داریوش', 'artist')).toMatchObject({ kind: 'none', suggestions: expect.arrayContaining(['Googoosh', 'Ebi']) });
  });
});

describe('music commands', () => {
  const ctx = { moduleType: 'music' as const, now: 0, timezone: 'UTC' };
  it('«آهنگ‌های X» asks for an artist, «آهنگ X» for one song, «پخش علاقه‌مندی‌ها» for favourites', () => {
    expect(parseCommand('آهنگ‌های گوگوش', ctx)).toMatchObject({ kind: 'media_search', query: 'گوگوش', target: 'artist' });
    expect(parseCommand('یه آهنگ از ابی بذار', ctx)).toMatchObject({ query: 'ابی', target: 'artist' });
    expect(parseCommand('گوگوش آهنگاش', ctx)).toMatchObject({ query: 'گوگوش', target: 'artist' });
    expect(parseCommand('songs by adele', ctx)).toMatchObject({ query: 'adele', target: 'artist' });
    expect(parseCommand('آهنگ خلیج', ctx)).toMatchObject({ query: 'خلیج', target: 'track' });
    expect(parseCommand('خلیج رو پخش کن', ctx)).toMatchObject({ query: 'خلیج', target: 'any' });
    expect(parseCommand('پخش علاقه مندی ها', ctx)).toMatchObject({ kind: 'media_favorites' });
    expect(parseCommand('آهنگ', ctx)).toMatchObject({ kind: 'media', action: 'play' });
  });

  it('a spoken shopping list becomes separate items', () => {
    expect(splitItems('نان، شیر و تخم مرغ')).toEqual(['نان', 'شیر', 'تخم مرغ']);
    expect(splitItems('نان و پنیر و سبزی')).toEqual(['نان', 'پنیر', 'سبزی']);
    expect(splitItems('یک کتاب برای کلاس زبان انگلیسی و دفتر')).toEqual(['یک کتاب برای کلاس زبان انگلیسی و دفتر']);
    expect(parseCommand('خرید نان، شیر', { moduleType: 'checklists', now: 0, timezone: 'UTC' })).toMatchObject({ kind: 'add_item', items: ['خرید نان', 'شیر'] });
  });
});
