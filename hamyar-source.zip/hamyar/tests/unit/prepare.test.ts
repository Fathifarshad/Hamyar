import { describe, expect, it } from 'vitest';
import { prepareBlob } from '../../src/modules/video/prepare';

const MiB = 1024 * 1024;
const pattern = (n: number): Uint8Array<ArrayBuffer> => {
  const b = new Uint8Array(n);
  for (let i = 0; i < n; i++) b[i] = (i * 31 + (i >> 8)) & 255;
  return b;
};
const bytesOf = async (b: Blob) => new Uint8Array(await b.arrayBuffer());
const nameError = (name: string) => Object.assign(new Error(name), { name });

/** A blob-like file whose stream hands out 64 KiB pieces and then does what the test says. */
function fakeFile(data: Uint8Array<ArrayBuffer>, after?: { at: number; error?: Error }): Blob {
  return {
    size: data.length,
    type: '',
    stream: () => {
      let at = 0;
      return new ReadableStream<Uint8Array>({
        pull(c) {
          if (after && at >= after.at) {
            if (after.error) c.error(after.error);
            else c.close();
            return;
          }
          if (at >= data.length) return c.close();
          c.enqueue(data.slice(at, Math.min(data.length, at + 65536)));
          at += 65536;
        },
      });
    },
    slice: (s: number, e: number) => new Blob([data]).slice(s, e),
  } as unknown as Blob;
}

describe('prepareBlob', () => {
  it('makes an exact copy of a multi-part file, with the type it is given', async () => {
    const data = pattern(20 * MiB + 123);
    const copy = await prepareBlob(new File([data], 'film.mp4'), { mime: 'video/mp4' });
    expect(copy.size).toBe(data.length);
    expect(copy.type).toBe('video/mp4');
    expect(Buffer.compare(await bytesOf(copy), data)).toBe(0);
  });

  it('reports progress that only goes forward and ends at the full size', async () => {
    const seen: number[] = [];
    await prepareBlob(fakeFile(pattern(5 * MiB)), { mime: 'video/mp4', onProgress: (done, total) => seen.push(done / total) });
    expect(seen.length).toBeGreaterThan(10);
    expect(seen.every((v, i) => i === 0 || v >= seen[i - 1]!)).toBe(true);
    expect(seen[seen.length - 1]).toBe(1);
  });

  it('copies a small file and an empty one', async () => {
    const small = pattern(100);
    expect(Buffer.compare(await bytesOf(await prepareBlob(new Blob([small]), { mime: 'video/webm' })), small)).toBe(0);
    expect((await prepareBlob(new Blob([]), { mime: 'video/mp4' })).size).toBe(0);
  });

  it('reads in order, from the first byte to the last, with no seeking (a picker may not allow it)', async () => {
    const data = pattern(3 * MiB);
    const calls: string[] = [];
    const f = fakeFile(data);
    (f as unknown as { slice: unknown }).slice = () => {
      calls.push('slice');
      throw new Error('seek');
    };
    const copy = await prepareBlob(f, { mime: 'video/mp4' });
    expect(Buffer.compare(await bytesOf(copy), data)).toBe(0);
    expect(calls).toEqual([]);
  });

  it('falls back to reading piece by piece when the browser has no Blob.stream()', async () => {
    const data = pattern(9 * MiB);
    const f = fakeFile(data) as unknown as { stream?: unknown };
    delete f.stream;
    const copy = await prepareBlob(f as Blob, { mime: 'video/mp4' });
    expect(Buffer.compare(await bytesOf(copy), data)).toBe(0);
  });

  it('says how far it got when the phone stops letting the app read', async () => {
    const f = fakeFile(pattern(5 * MiB), { at: 2 * MiB, error: nameError('NotReadableError') });
    await expect(prepareBlob(f, { mime: 'video/mp4' })).rejects.toMatchObject({ code: 'FILE_UNREADABLE', details: { stage: 'prepare', cause: 'NotReadableError', at: '2MiB' } });
  });

  it('notices a file that ends sooner than its size says', async () => {
    const f = fakeFile(pattern(5 * MiB), { at: 3 * MiB });
    await expect(prepareBlob(f, { mime: 'video/mp4' })).rejects.toMatchObject({ code: 'FILE_UNREADABLE', details: { cause: 'short', at: '3/5MiB' } });
  });

  it('refuses a film that is too big to hold, before reading anything', async () => {
    let read = false;
    const f = { size: 1000, type: '', stream: () => ((read = true), new ReadableStream()), slice: () => new Blob([]) } as unknown as Blob;
    await expect(prepareBlob(f, { mime: 'video/mp4', maxBytes: 999 })).rejects.toMatchObject({ code: 'TOO_BIG_TO_COPY' });
    expect(read).toBe(false);
  });

  it('can be cancelled', async () => {
    const ctl = new AbortController();
    const f = fakeFile(pattern(40 * MiB));
    await expect(prepareBlob(f, { mime: 'video/mp4', signal: ctl.signal, onProgress: (done) => done > MiB && ctl.abort() })).rejects.toMatchObject({ code: 'CANCELLED' });
  });

  it('is cancelled at once if the signal is already aborted', async () => {
    const ctl = new AbortController();
    ctl.abort();
    await expect(prepareBlob(fakeFile(pattern(MiB)), { mime: 'video/mp4', signal: ctl.signal })).rejects.toMatchObject({ code: 'CANCELLED' });
  });
});
