import { describe, expect, it } from 'vitest';
import { checkLinkUrl, extractAparatHash, extractYouTubeId, isExternalMusicPage } from '../../src/domain/urls';

describe('url rules', () => {
  it('rejects dangerous schemes and html', () => {
    expect(checkLinkUrl('javascript:alert(1)').ok).toBe(false);
    expect(checkLinkUrl('data:text/html,hi').ok).toBe(false);
    expect(checkLinkUrl('file:///etc/passwd').ok).toBe(false);
    expect(checkLinkUrl('<iframe src=x>').ok).toBe(false);
    expect(checkLinkUrl('http://example.com/a.mp3', { requireHttps: true })).toEqual({ ok: false, reason: 'insecure' });
    expect(checkLinkUrl('example.com')).toEqual({ ok: true, url: 'https://example.com/' });
  });
  it('extracts video ids', () => {
    expect(extractYouTubeId('https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=3')).toBe('dQw4w9WgXcQ');
    expect(extractYouTubeId('https://youtu.be/dQw4w9WgXcQ')).toBe('dQw4w9WgXcQ');
    expect(extractYouTubeId('https://www.youtube.com/shorts/dQw4w9WgXcQ')).toBe('dQw4w9WgXcQ');
    expect(extractYouTubeId('https://evil.com/watch?v=dQw4w9WgXcQ')).toBeNull();
    expect(extractAparatHash('https://www.aparat.com/v/abc12XY')).toBe('abc12XY');
    expect(isExternalMusicPage('https://open.spotify.com/track/123')).toBe(true);
  });
});
