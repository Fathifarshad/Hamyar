import { describe, expect, it } from 'vitest';
import { addDaysISO, getOffsetMinutes, resolveZoned, todayISO, weekdayOfISO, zonedToUtc } from '../../src/domain/time';
import { isoToJalali, jalaliToISO, parseFlexibleDate } from '../../src/domain/jalali';

describe('time zones', () => {
  it('converts ordinary wall times', () => {
    expect(new Date(zonedToUtc('2026-10-05', '09:00', 'Asia/Tehran')).toISOString()).toBe('2026-10-05T05:30:00.000Z');
    expect(new Date(zonedToUtc('2026-10-05', '09:00', 'America/Santiago')).toISOString()).toBe('2026-10-05T12:00:00.000Z');
    expect(getOffsetMinutes(Date.UTC(2026, 0, 1), 'Asia/Tehran')).toBe(210);
  });

  it('moves a time inside a spring-forward gap to the first valid instant', () => {
    // New York: 2026-03-08 02:00 → 03:00
    const r = resolveZoned('2026-03-08', '02:30', 'America/New_York');
    expect(r.shifted).toBe(true);
    expect(new Date(r.utc).toISOString()).toBe('2026-03-08T07:00:00.000Z');
  });

  it('uses the first occurrence of a repeated (fall-back) time', () => {
    // New York: 2026-11-01 02:00 EDT → 01:00 EST
    const r = resolveZoned('2026-11-01', '01:30', 'America/New_York');
    expect(r.ambiguous).toBe(true);
    expect(new Date(r.utc).toISOString()).toBe('2026-11-01T05:30:00.000Z');
  });

  it('handles Chile midnight DST gap', () => {
    // Santiago: 2026-09-06 00:00 → 01:00
    const r = resolveZoned('2026-09-06', '00:30', 'America/Santiago');
    expect(r.shifted).toBe(true);
    expect(new Date(r.utc).toISOString()).toBe('2026-09-06T04:00:00.000Z');
  });

  it('date helpers', () => {
    expect(addDaysISO('2026-12-31', 1)).toBe('2027-01-01');
    expect(weekdayOfISO('2026-10-04')).toBe(0);
    expect(todayISO('Asia/Tehran', Date.UTC(2026, 9, 4, 21, 0))).toBe('2026-10-05');
  });
});

describe('jalali calendar', () => {
  it('converts known dates', () => {
    expect(isoToJalali('2026-10-04')).toEqual({ jy: 1405, jm: 7, jd: 12 });
    expect(jalaliToISO(1405, 1, 1)).toBe('2026-03-21');
    expect(parseFlexibleDate('1405/07/12')).toBe('2026-10-04');
    expect(parseFlexibleDate('2026-10-04')).toBe('2026-10-04');
    expect(parseFlexibleDate('1404/12/30')).toBeNull();
    expect(parseFlexibleDate('1403/12/30')).toBe('2025-03-20');
  });
});
