import { describe, expect, it } from 'vitest';
import { buildIcs, foldLine, medicationCalendarEvents, taskCalendarEvents } from '../../src/lib/ics';
import { DST_POLICY, type Medication, type Task } from '../../src/domain/types';

const ts = new Date(0).toISOString();
const NOW = new Date(Date.UTC(2026, 9, 4, 12, 0, 0));

function unfold(ics: string): string[] {
  return ics.replace(/\r\n /g, '').split('\r\n');
}

describe('calendar export', () => {
  it('folds long Persian lines at 75 bytes without breaking characters', () => {
    const line = `SUMMARY:${'یادآوری دارو '.repeat(12)}`;
    const folded = foldLine(line);
    const enc = new TextEncoder();
    for (const part of folded.split('\r\n')) expect(enc.encode(part).length).toBeLessThanOrEqual(75);
    expect(folded.replace(/\r\n /g, '')).toBe(line);
  });

  it('writes a daily medication with an alert at the dose time', () => {
    const med: Medication = {
      id: 'm1',
      moduleId: 'mod',
      name: 'متفورمین',
      dosageText: '۱ عدد',
      unitText: '',
      notes: '',
      revisions: [{ validFrom: 0, rule: { freq: 'daily', startDate: '2026-09-01', endDate: null, weekdays: [], times: ['08:00', '20:00'], timezone: 'Asia/Tehran' } }],
      active: true,
      reminderEnabled: true,
      showNameInNotification: false,
      dstPolicy: DST_POLICY,
      revision: 1,
      createdAt: ts,
      updatedAt: ts,
    };
    const lines = unfold(buildIcs(medicationCalendarEvents(med, '2026-10-04', true), NOW));
    expect(lines.filter((l) => l === 'BEGIN:VEVENT')).toHaveLength(2);
    expect(lines).toContain('DTSTART:20261004T080000');
    expect(lines).toContain('DTSTART:20261004T200000');
    expect(lines).toContain('RRULE:FREQ=DAILY');
    expect(lines).toContain('TRIGGER:PT0M');
    expect(lines).toContain('SUMMARY:یادآوری دارو');
    expect(lines.join('\n')).not.toContain('متفورمین'); // name stays private unless allowed
    expect(lines).toContain('DTSTAMP:20261004T120000Z');
  });

  it('starts weekly events on a real occurrence and escapes text', () => {
    const task: Task = {
      id: 't1',
      moduleId: 'mod',
      kind: 'event',
      title: 'کلاس زبان, سطح ۲; گروه A',
      notes: 'خط اول\nخط دوم',
      priority: 'normal',
      revisions: [{ validFrom: 0, rule: { freq: 'weekly', startDate: '2026-10-04', endDate: '2026-12-31', weekdays: [1, 3], times: ['17:00'], timezone: 'UTC' } }],
      reminderOffset: 30,
      dstPolicy: DST_POLICY,
      revision: 1,
      createdAt: ts,
      updatedAt: ts,
    };
    const lines = unfold(buildIcs(taskCalendarEvents(task, '2026-10-04', true), NOW));
    expect(lines).toContain('DTSTART:20261005T170000'); // 4 Oct is a Sunday; first class is Monday
    expect(lines).toContain('RRULE:FREQ=WEEKLY;BYDAY=MO,WE;UNTIL=20261231T235959');
    expect(lines).toContain('TRIGGER:-PT30M');
    expect(lines).toContain('SUMMARY:کلاس زبان\\, سطح ۲\\; گروه A');
    expect(lines).toContain('DESCRIPTION:خط اول\\nخط دوم');
  });

  it('all-day tasks become date-only events', () => {
    const task: Task = {
      id: 't2',
      moduleId: 'mod',
      kind: 'task',
      title: 'خرید',
      notes: '',
      priority: 'normal',
      revisions: [{ validFrom: 0, rule: { freq: 'once', startDate: '2026-10-10', endDate: null, weekdays: [], times: [], timezone: 'UTC' } }],
      reminderOffset: null,
      dstPolicy: DST_POLICY,
      revision: 1,
      createdAt: ts,
      updatedAt: ts,
    };
    const lines = unfold(buildIcs(taskCalendarEvents(task, '2026-10-04', false), NOW));
    expect(lines).toContain('DTSTART;VALUE=DATE:20261010');
    expect(lines).toContain('DTEND;VALUE=DATE:20261011');
    expect(lines.some((l) => l.startsWith('RRULE'))).toBe(false);
    expect(lines).not.toContain('BEGIN:VALARM');
  });
});
