import { describe, expect, it } from 'vitest';
import { errorDetail } from '../../src/lib/errorDetail';
import { errorText } from '../../src/i18n/errors';
import { DomainError } from '../../src/domain/types';

const fa = (a: string) => a;
const en = (_a: string, b: string) => b;

describe('errorDetail — the small technical code shown under a message', () => {
  it('lists the domain code and every browser cause, once each', () => {
    expect(errorDetail(new DomainError('STORE_FAILED', undefined, { cause: 'UnknownError', first: 'DataCloneError' }))).toBe('STORE_FAILED · UnknownError · DataCloneError');
    expect(errorDetail(new DomainError('FILE_UNREADABLE', undefined, { cause: 'NotReadableError', stage: 'fingerprint' }))).toBe('FILE_UNREADABLE · fingerprint · NotReadableError');
    expect(errorDetail(new DomainError('EMPTY_FILE'))).toBe('EMPTY_FILE');
  });

  it('names browser errors, including the one Dexie wraps', () => {
    expect(errorDetail(Object.assign(new Error('x'), { name: 'NotReadableError' }))).toBe('NotReadableError');
    expect(errorDetail({ name: 'AbortError', inner: { name: 'QuotaExceededError' } })).toBe('QuotaExceededError · AbortError');
  });

  it('falls back to a short message, and copes with odd values', () => {
    expect(errorDetail(new Error('Array buffer allocation failed'))).toBe('Array buffer allocation failed');
    expect(errorDetail(new Error('y'.repeat(300))).length).toBeLessThanOrEqual(60);
    expect(errorDetail('plain text')).toBe('plain text');
    expect(errorDetail(null)).toBe('');
    expect(errorDetail(undefined)).toBe('');
    expect(errorDetail(42)).toBe('');
  });

  it('never exceeds 100 characters', () => {
    expect(errorDetail(new DomainError('A'.repeat(200)))).toHaveLength(100);
  });
});

describe('errorText — new file errors', () => {
  it('explains an unreadable file and a failed save in plain words', () => {
    expect(errorText(new DomainError('FILE_UNREADABLE'), fa)).toContain('نتوانست این فایل را');
    expect(errorText(new DomainError('FILE_UNREADABLE'), en)).toContain('could not read this file');
    expect(errorText(new DomainError('STORE_FAILED'), fa)).toContain('ذخیره‌ی این فایل');
    expect(errorText(new DomainError('STORE_FAILED'), en)).toContain('existing data is safe');
  });

  it('keeps the generic message only for unknown errors', () => {
    expect(errorText(new Error('whatever'), en)).toBe('That did not work. Please try again.');
  });
});
