import { describe, expect, it } from 'vitest';
import { notificationId, planNotifications, type PlanInput } from '../../src/lib/reminderPlan';
import { zonedToUtc } from '../../src/domain/time';
import { DST_POLICY, type Medication, type ModuleInstance, type Task } from '../../src/domain/types';

const TZ = 'UTC';
const ts = new Date(0).toISOString();
const NOW = zonedToUtc('2026-10-05', '07:00', TZ);

function mod(id: string, type: ModuleInstance['type'], patch: Partial<ModuleInstance> = {}): ModuleInstance {
  return {
    id,
    type,
    title: id,
    active: 1,
    archivedAt: null,
    order: 0,
    inputLanguage: 'fa-IR',
    voiceMode: 'command',
    remindersPaused: false,
    appearance: { preset: 'default', accent: 'teal', icon: 'calendar-clock', width: 'normal', density: 'comfortable' },
    config: {},
    version: 1,
    createdAt: ts,
    updatedAt: ts,
    ...patch,
  } as ModuleInstance;
}

function task(id: string, moduleId: string, freq: 'once' | 'daily', time: string, startDate = '2026-10-05', reminderOffset = 0): Task {
  return {
    id,
    moduleId,
    kind: 'event',
    title: id,
    notes: '',
    priority: 'normal',
    revisions: [{ validFrom: 0, rule: { freq, startDate, endDate: null, weekdays: [], times: [time], timezone: TZ } }],
    reminderOffset,
    dstPolicy: DST_POLICY,
    revision: 1,
    createdAt: ts,
    updatedAt: ts,
  };
}

function med(id: string, moduleId: string, times: string[], patch: Partial<Medication> = {}): Medication {
  return {
    id,
    moduleId,
    name: 'داروی الف',
    dosageText: '',
    unitText: '',
    notes: '',
    revisions: [{ validFrom: 0, rule: { freq: 'daily', startDate: '2026-10-01', endDate: null, weekdays: [], times, timezone: TZ } }],
    active: true,
    reminderEnabled: true,
    showNameInNotification: false,
    dstPolicy: DST_POLICY,
    revision: 1,
    createdAt: ts,
    updatedAt: ts,
    ...patch,
  };
}

function input(patch: Partial<PlanInput> = {}): PlanInput {
  return { profile: { locale: 'fa' }, modules: [], tasks: [], completions: [], medications: [], medEvents: [], reminders: [], focus: [], ...patch };
}

describe('phone reminder plan', () => {
  it('plans tasks in visible and hidden sections, never in archived or paused ones', () => {
    const plan = planNotifications(
      input({
        modules: [mod('a', 'tasks'), mod('h', 'tasks', { active: 0 }), mod('x', 'tasks', { archivedAt: ts }), mod('p', 'tasks', { remindersPaused: true })],
        tasks: [task('in-visible', 'a', 'once', '09:00'), task('in-hidden', 'h', 'once', '09:00'), task('in-archived', 'x', 'once', '09:00'), task('in-paused', 'p', 'once', '09:00')],
      }),
      NOW,
    );
    expect(plan.map((p) => p.title).sort()).toEqual(['in-hidden', 'in-visible']);
    expect(plan[0]!.at).toBe(zonedToUtc('2026-10-05', '09:00', TZ));
  });

  it('applies the reminder offset and skips past or completed occurrences', () => {
    const plan = planNotifications(
      input({
        modules: [mod('a', 'tasks')],
        tasks: [task('early', 'a', 'once', '09:00', '2026-10-05', 15), task('past', 'a', 'once', '06:00'), task('done', 'a', 'once', '10:00')],
        completions: [{ id: 'done|2026-10-05|10:00', taskId: 'done', moduleId: 'a', occurrenceKey: '2026-10-05|10:00', completedAt: ts } as never],
      }),
      NOW,
    );
    expect(plan.map((p) => p.title)).toEqual(['early']);
    expect(plan[0]!.at).toBe(zonedToUtc('2026-10-05', '08:45', TZ));
  });

  it('plans doses with a generic title and skips doses already recorded', () => {
    const m = med('m1', 'meds', ['08:00', '20:00']);
    const plan = planNotifications(
      input({
        modules: [mod('meds', 'medications')],
        medications: [m],
        medEvents: [{ id: 'e1', medId: 'm1', moduleId: 'meds', occurrenceKey: 'm1|2026-10-05|08:00', scheduledAt: 0, action: 'taken', actualTakenAt: ts, recordedAt: ts, snapshot: {} as never, supersedesId: null, idempotencyKey: 'k' }],
      }),
      NOW,
      { horizonDays: 2 },
    );
    const doses = plan.filter((p) => p.kind === 'medication');
    expect(doses[0]!.at).toBe(zonedToUtc('2026-10-05', '20:00', TZ)); // the 08:00 dose was taken early
    expect(doses).toHaveLength(3); // 20:00 today, 08:00 and 20:00 tomorrow (2-day horizon ends 07:00 on day 3)
    expect(doses.every((d) => d.title === 'یادآوری دارو')).toBe(true);
    expect(doses[0]!.url).toContain('focus=');
  });

  it('asks the person to open the app before the plan runs out and keeps ids unique', () => {
    const plan = planNotifications(input({ modules: [mod('meds', 'medications')], medications: [med('m1', 'meds', ['08:00', '14:00', '20:00'])] }), NOW, { horizonDays: 21, max: 300 });
    const notice = plan.find((p) => p.kind === 'notice');
    expect(notice).toBeTruthy();
    expect(notice!.at).toBeLessThan(NOW + 21 * 86_400_000);
    expect(new Set(plan.map((p) => p.id)).size).toBe(plan.length);
    expect(plan.every((p) => p.id > 0 && p.id < 2 ** 31)).toBe(true);
  });

  it('caps the number of scheduled alarms', () => {
    const plan = planNotifications(input({ modules: [mod('meds', 'medications')], medications: [med('m1', 'meds', ['06:00', '09:00', '12:00', '15:00', '18:00', '21:00'])] }), NOW, { horizonDays: 21, max: 50 });
    expect(plan.filter((p) => p.kind !== 'notice')).toHaveLength(50);
  });

  it('re-notifies snoozed reminders and focus timer ends', () => {
    const plan = planNotifications(
      input({
        modules: [mod('a', 'tasks'), mod('f', 'focus')],
        reminders: [{ id: 'r1', kind: 'task', sourceId: 't', moduleId: 'a', occurrenceKey: 'k', dueAt: NOW - 60_000, firedAt: ts, late: false, title: 'تماس', body: 'ساعت', readAt: ts, snoozedUntil: NOW + 600_000, followUpOf: null, delivery: 'in_app' }],
        focus: [{ id: 'f', phase: 'focus', status: 'running', endAt: NOW + 1_500_000, pausedRemainingMs: null, sessionsDate: '2026-10-05', sessionsCount: 0, updatedAt: ts }],
      }),
      NOW,
    );
    expect(plan.map((p) => p.kind)).toEqual(['task', 'focus']);
    expect(plan[1]!.title).toBe('زمان تمرکز تمام شد');
  });

  it('gives the same reminder the same id every time', () => {
    expect(notificationId('task:x:2026-10-05|09:00:0')).toBe(notificationId('task:x:2026-10-05|09:00:0'));
    expect(notificationId('a')).not.toBe(notificationId('b'));
  });
});
