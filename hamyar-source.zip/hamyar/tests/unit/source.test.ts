import { describe, expect, it, vi } from 'vitest';
import { createPlayback, type Origin, type PlaybackOptions, type View } from '../../src/modules/video/source';
import type { CanPlay } from '../../src/modules/video/probe';
import { box, cat, ftyp, hvc1, moov, mp4aAac, zeros } from './helpers/mp4';

const hevcFile = () => new File([cat(ftyp(), moov(hvc1(1920, 1080), mp4aAac()), box('mdat', zeros(1000)))], 'cam.mp4', { type: 'video/mp4' });
/** A file that is slow to read (a phone's storage), so a copy is still under way when the test looks. */
const slowFile = (n: number): Blob =>
  ({
    size: n,
    type: 'video/mp4',
    slice: (a: number, b: number) => new Blob([new Uint8Array(n)]).slice(a, b),
    stream: () => {
      let at = 0;
      return new ReadableStream<Uint8Array>({
        async pull(c) {
          await new Promise((r) => setTimeout(r, 3));
          if (at >= n) return c.close();
          c.enqueue(new Uint8Array(Math.min(65536, n - at)));
          at += 65536;
        },
      });
    },
  }) as unknown as Blob;
const plainFile = (n = 5000) => new File([new Uint8Array(n).fill(7)], 'a.mp4', { type: 'video/mp4' });

const FORMAT = { kind: 'format' as const, tag: 'MEDIA_ERR_SRC_NOT_SUPPORTED · MEDIA_ELEMENT_ERROR: Format error' };
const noHevc: CanPlay = (c) => (c.startsWith('hvc1') ? '' : 'probably');

/** Runs a playback and records every view it asks the screen to show. */
function run(blob: Blob, extra: Partial<PlaybackOptions> = {}, kind: Origin['kind'] = 'picked') {
  const views: View[] = [];
  const revoked: string[] = [];
  let n = 0;
  const sources = new Map<string, Blob>();
  const onCopyWorks = vi.fn();
  const onPrepared = vi.fn();
  const pb = createPlayback({
    origin: { blob, mime: 'video/mp4', kind },
    startWithCopy: false,
    canPlay: () => 'probably',
    onView: (v) => views.push(v),
    onCopyWorks,
    onPrepared,
    makeUrl: (b) => {
      const url = `blob:test/${++n}`;
      sources.set(url, b);
      return url;
    },
    revokeUrl: (u) => revoked.push(u),
    ...extra,
  });
  const last = () => views[views.length - 1]!;
  const until = async (ok: () => boolean) => {
    for (let i = 0; i < 400 && !ok(); i++) await new Promise((r) => setTimeout(r, 5));
    expect(ok()).toBe(true);
  };
  return { pb, views, last, until, revoked, sources, onCopyWorks, onPrepared };
}

describe('createPlayback', () => {
  it('plays the picked file as it is, and does nothing else when that works', () => {
    const r = run(plainFile());
    r.pb.start();
    expect(r.last()).toEqual({ src: 'blob:test/1', work: null, failure: null });
    expect(r.sources.get('blob:test/1')).toBe(r.sources.get('blob:test/1'));
    r.pb.videoLoaded();
    expect(r.views).toHaveLength(1);
    expect(r.onCopyWorks).not.toHaveBeenCalled();
    r.pb.dispose();
    expect(r.revoked).toEqual(['blob:test/1']);
  });

  it('when the phone’s player cannot load the file, looks at it and plays a plain copy instead', async () => {
    const file = plainFile();
    const r = run(file);
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    expect(r.last().work).toEqual({ step: 'checking' });
    expect(r.last().src).toBeNull();
    await r.until(() => r.last().src === 'blob:test/2');
    expect(r.last().failure).toBeNull();
    const copy = r.sources.get('blob:test/2')!;
    expect(copy).not.toBe(file);
    expect(copy.size).toBe(file.size);
    expect(r.onPrepared).toHaveBeenCalledWith(copy);
    expect(r.onCopyWorks).not.toHaveBeenCalled();
    r.pb.videoLoaded();
    expect(r.onCopyWorks).toHaveBeenCalledTimes(1);
    r.pb.videoLoaded();
    expect(r.onCopyWorks).toHaveBeenCalledTimes(1);
  });

  it('shows copy progress while it works', async () => {
    const r = run(slowFile(3 * 1024 * 1024));
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().src !== null);
    const copying = r.views.filter((v) => v.work?.step === 'copying');
    expect(copying.length).toBeGreaterThan(1);
    expect(copying[0]!.work).toMatchObject({ step: 'copying', done: 0, total: 3 * 1024 * 1024 });
    expect(copying[copying.length - 1]!.work).toMatchObject({ step: 'copying', done: 3 * 1024 * 1024 });
  });

  it('explains a codec the phone cannot play, without copying anything', async () => {
    const r = run(hevcFile(), { canPlay: noHevc });
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().failure !== null);
    const f = r.last().failure!;
    expect(f.verdict).toMatchObject({ kind: 'unsupported-video', label: 'HEVC (H.265)' });
    expect(f.tag).toBe(FORMAT.tag);
    expect(f.extra.join('\n')).toContain('V hvc1.1.6.L93.B0 1920x1080');
    expect(f.extra.join('\n')).toContain('tried: direct:fail > probe:unsupported-video');
    expect(r.onPrepared).not.toHaveBeenCalled();
    expect(r.last().work).toBeNull();
  });

  it('says so when the file cannot be read at all', async () => {
    const dead = { size: 5000, type: 'video/mp4', slice: () => ({ arrayBuffer: () => Promise.reject(Object.assign(new Error('x'), { name: 'NotReadableError' })) }), stream: () => { throw new Error('no'); } } as unknown as Blob;
    const r = run(dead);
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().failure !== null);
    expect(r.last().failure?.verdict).toEqual({ kind: 'unreadable' });
    expect(r.last().failure?.extra.join('\n')).toContain('read head:NotReadableError');
  });

  it('gives up with both failures on record when the copy does not play either', async () => {
    const r = run(plainFile());
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().src === 'blob:test/2');
    r.pb.videoFailed({ kind: 'format', tag: 'DEMUXER_ERROR_COULD_NOT_OPEN: FFmpegDemuxer: open context failed' });
    const f = r.last().failure!;
    expect(f.kind).toBe('format');
    expect(f.tag).toBe('DEMUXER_ERROR_COULD_NOT_OPEN: FFmpegDemuxer: open context failed');
    expect(f.extra[0]).toBe(`first: ${FORMAT.tag}`);
    expect(f.extra.join('\n')).toContain('tried: direct:fail > probe:unknown > copy:ok > prepared:fail');
    expect(r.last().src).toBe('blob:test/2'); // the failed element stays, hidden behind the message
  });

  it('does not try again after the copy failed to play', async () => {
    const r = run(plainFile());
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().src === 'blob:test/2');
    r.pb.videoFailed(FORMAT);
    const n = r.views.length;
    r.pb.videoFailed(FORMAT);
    await new Promise((res) => setTimeout(res, 30));
    expect(r.views).toHaveLength(n);
  });

  it('goes straight to a copy on a device where that is what worked before', async () => {
    const r = run(plainFile(), { startWithCopy: true });
    r.pb.start();
    expect(r.views[0]?.work?.step).toBe('copying');
    expect(r.views.some((v) => v.src === 'blob:test/1' && v.failure === null)).toBe(false);
    await r.until(() => r.last().src !== null);
    r.pb.videoLoaded();
    expect(r.onCopyWorks).not.toHaveBeenCalled(); // nothing was learned: there was no direct try
  });

  it('names the codec even when it went straight to a copy and the copy would not play', async () => {
    const r = run(hevcFile(), { startWithCopy: true, canPlay: noHevc });
    r.pb.start();
    await r.until(() => r.last().src !== null);
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().failure !== null);
    expect(r.last().failure?.verdict).toMatchObject({ kind: 'unsupported-video', label: 'HEVC (H.265)' });
    expect(r.last().failure?.extra.join('\n')).toContain('V hvc1.1.6.L93.B0');
  });

  it('plays a stored copy directly even on such a device', () => {
    const r = run(plainFile(), { startWithCopy: true }, 'stored');
    r.pb.start();
    expect(r.last().src).toBe('blob:test/1');
  });

  it('can be cancelled while it copies, and then shows the first failure', async () => {
    const r = run(slowFile(8 * 1024 * 1024));
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().work?.step === 'copying');
    r.pb.cancelCopy();
    await r.until(() => r.last().failure !== null);
    const f = r.last().failure!;
    expect(f.kind).toBe('format');
    expect(f.tag).toBe(FORMAT.tag);
    expect(f.extra.join('\n')).toContain('copy:cancelled');
  });

  it('does not copy a film that is too big, and says so', async () => {
    const r = run(plainFile(2000), { maxCopyBytes: 1000 });
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().failure !== null);
    expect(r.last().failure).toMatchObject({ kind: 'copy', tag: expect.stringContaining('TOO_BIG_TO_COPY') });
    expect(r.onPrepared).not.toHaveBeenCalled();
  });

  it('reports a failed copy with the reason and the player’s own code', async () => {
    const file = plainFile();
    const bad = {
      size: file.size,
      type: file.type,
      slice: file.slice.bind(file),
      stream: () =>
        new ReadableStream({
          start(c) {
            c.error(Object.assign(new Error('x'), { name: 'NotReadableError' }));
          },
        }),
    } as unknown as Blob;
    const r = run(bad);
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().failure !== null);
    const f = r.last().failure!;
    expect(f.kind).toBe('copy');
    expect(f.tag).toContain('FILE_UNREADABLE');
    expect(f.extra[0]).toBe(`player: ${FORMAT.tag}`);
  });

  it('steps in when the player neither loads nor fails', async () => {
    const r = run(plainFile(), { loadWaitMs: 40 });
    r.pb.start();
    await r.until(() => r.last().src === 'blob:test/2');
    expect(r.views.some((v) => v.work?.step === 'checking')).toBe(true);
  });

  it('does not step in once the file has loaded', async () => {
    const r = run(plainFile(), { loadWaitMs: 40 });
    r.pb.start();
    r.pb.videoLoaded();
    await new Promise((res) => setTimeout(res, 100));
    expect(r.views).toHaveLength(1);
  });

  it('does not step in when the browser holds off loading until play is pressed (low-power mode)', async () => {
    const r = run(plainFile(), { loadWaitMs: 40 });
    r.pb.start();
    r.pb.videoIdle();
    await new Promise((res) => setTimeout(res, 100));
    expect(r.views).toHaveLength(1);
    // …but a real failure once play is pressed is still looked into
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().src === 'blob:test/2');
  });

  it('leaves damage in the middle of a file that opened fine as damage (no copying)', async () => {
    const r = run(plainFile());
    r.pb.start();
    r.pb.videoLoaded();
    r.pb.videoFailed({ kind: 'decode', tag: 'MEDIA_ERR_DECODE' });
    expect(r.last().failure).toMatchObject({ kind: 'decode', tag: 'MEDIA_ERR_DECODE' });
    expect(r.views.some((v) => v.work !== null)).toBe(false);
  });

  it('still tries a copy when reading breaks off in the middle of a file that opened fine', async () => {
    const r = run(plainFile());
    r.pb.start();
    r.pb.videoLoaded();
    r.pb.videoFailed({ kind: 'network', tag: 'MEDIA_ERR_NETWORK' });
    await r.until(() => r.last().src === 'blob:test/2');
  });

  it('stops everything when it is disposed in the middle of work', async () => {
    const r = run(slowFile(8 * 1024 * 1024));
    r.pb.start();
    r.pb.videoFailed(FORMAT);
    await r.until(() => r.last().work?.step === 'copying');
    const n = r.views.length;
    r.pb.dispose();
    await new Promise((res) => setTimeout(res, 50));
    expect(r.views).toHaveLength(n);
    expect(r.revoked).toEqual(['blob:test/1']);
  });
});
