/* global document, window, indexedDB, getComputedStyle -- used inside page.evaluate callbacks, which run in the browser */
// Video section on a phone-sized screen (npm run build:mobile first): a picked file plays at once
// from the phone's storage (any size), a copy is kept only when it fits, nothing breaks after a
// restart, clear messages appear for bad files, and the "large view" fills the screen.
import { chromium } from 'playwright-core';
import http from 'node:http';
import { existsSync, mkdirSync, readFileSync, rmSync, statSync, truncateSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { extname, join, normalize } from 'node:path';
import { chromiumPath } from '../../scripts/chromium.mjs';

const ROOT = 'dist-mobile';
const PORT = Number(process.env.VIDEO_PORT || 4197);
const BASE = `http://127.0.0.1:${PORT}/Hamyar/`;
const OUT = 'test-results';
const FIX = 'tests/e2e/fixtures';
mkdirSync(OUT, { recursive: true });

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2', '.pdf': 'application/pdf', '.bcmap': 'application/octet-stream', '.wasm': 'application/wasm' };
const server = http
  .createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    if (!url.pathname.startsWith('/Hamyar/')) {
      res.writeHead(404);
      return res.end();
    }
    let file = normalize(join(ROOT, decodeURIComponent(url.pathname.slice('/Hamyar/'.length)) || 'index.html'));
    if (!file.startsWith(ROOT)) {
      res.writeHead(403);
      return res.end();
    }
    if (existsSync(file) && statSync(file).isDirectory()) file = join(file, 'index.html');
    if (!existsSync(file)) {
      res.writeHead(404);
      return res.end();
    }
    res.writeHead(200, { 'content-type': TYPES[extname(file)] || 'application/octet-stream' });
    res.end(readFileSync(file));
  })
  .listen(PORT, '127.0.0.1');

const results = [];
const check = (name, ok, detail = '') => {
  results.push(ok);
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`);
};

// A "film" bigger than the 100 MiB the app can store: the real clip padded with zeros after its end.
const MiB = 1024 * 1024;
const bigFile = join(tmpdir(), `hamyar-big-${process.pid}.webm`);
writeFileSync(bigFile, readFileSync(`${FIX}/tiny.webm`));
truncateSync(bigFile, 101 * MiB);

const browser = await chromium.launch({ executablePath: chromiumPath(), args: ['--autoplay-policy=no-user-gesture-required'] });
const androidUA = 'Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36';
const context = await browser.newContext({ viewport: { width: 412, height: 860 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: androidUA, locale: 'fa-IR', timezoneId: 'America/Santiago' });
const page = await context.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
page.on('console', (m) => {
  if (m.type() !== 'error') return;
  if (/youtube|open-meteo|ERR_INTERNET_DISCONNECTED|ERR_TUNNEL|Failed to load resource/.test(`${m.text()} ${m.location()?.url ?? ''}`)) return;
  errors.push(m.text().slice(0, 200));
});
await page.route(/youtube\.com|ytimg\.com/, (r) => r.abort());

const rows = () => page.locator('.media-row');
const dialog = page.locator('dialog[open]');
const videoInfo = () =>
  page.evaluate(async () => {
    const v = document.querySelector('video');
    if (!v) return null;
    if (v.readyState < 1 && !v.error) await new Promise((r) => (v.addEventListener('loadedmetadata', r, { once: true }), v.addEventListener('error', r, { once: true })));
    return { src: v.currentSrc.slice(0, 5), duration: Math.round(v.duration), w: v.videoWidth, h: v.videoHeight, error: v.error ? v.error.code : null, time: v.currentTime };
  });
const openAdd = async () => {
  await page.getByRole('button', { name: 'افزودن', exact: true }).first().click();
  await dialog.waitFor();
};
const pick = (file) => dialog.locator('input[type=file]').setInputFiles(file);
const storedAssets = () =>
  page.evaluate(async () => {
    const dbs = await indexedDB.databases();
    const name = dbs.map((d) => d.name).find((n) => /hamyar/i.test(n ?? ''));
    return await new Promise((resolve) => {
      const open = indexedDB.open(name);
      open.onsuccess = () => {
        const all = open.result.transaction('assets', 'readonly').objectStore('assets').getAll();
        all.onsuccess = () => resolve(all.result.map((a) => ({ kind: a.kind, size: a.size })));
      };
    });
  });
const toastText = async () => (await page.locator('.toast').allInnerTexts()).join(' | ').replace(/\s+/g, ' ');

try {
  await page.goto(BASE);
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('radio', { name: /شروع پیشنهادی/ }).click();
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('button', { name: 'ساخت داشبورد من' }).click();
  await page.locator('.dash-grid .mod').first().waitFor({ timeout: 20000 });
  await page.getByRole('link', { name: /بخش‌ها/ }).first().click();
  await page.getByRole('button', { name: 'افزودن بخش' }).first().click();
  await page.locator('.type-card', { hasText: 'ویدئو' }).first().click();
  await page.getByRole('button', { name: 'ساخت بخش' }).click();
  await page.getByRole('button', { name: 'باز کردن' }).click();
  await page.getByText('هنوز ویدئویی اضافه نکرده‌اید').waitFor();
  const sectionUrl = page.url();

  // ── 1. a small file: plays at once from the phone, and a copy is kept ──
  await openAdd();
  const keepSwitch = dialog.getByRole('switch');
  check('the "keep a copy" switch is on by default and explains the size limit', (await keepSwitch.getAttribute('aria-checked')) === 'true' && /۱۰۰/.test(await dialog.innerText()), (await dialog.innerText()).replace(/\s+/g, ' ').slice(0, 160));
  check('the file picker offers videos of any kind (accept="video/*")', (await dialog.locator('input[type=file]').getAttribute('accept')) === 'video/*');
  await page.screenshot({ path: `${OUT}/video-1-add-dialog.png` });
  await pick(`${FIX}/tiny.webm`);
  await rows().first().waitFor({ timeout: 10000 });
  await page.waitForSelector('video', { timeout: 10000 });
  const small = await videoInfo();
  check('the picked file plays right away from the phone (blob video, 20 s, 160×120)', small?.src === 'blob:' && small.duration === 20 && small.w === 160 && small.error === null, JSON.stringify(small));
  check('the list entry carries the file name', (await rows().first().innerText()).includes('tiny'), (await rows().first().innerText()).replace(/\s+/g, ' '));
  await page.getByText('نسخه‌ای از ویدئو در برنامه ذخیره شد').first().waitFor({ timeout: 10000 });
  check('a copy is saved in the app in the background and the list says so', (await rows().first().innerText()).includes('ذخیره در برنامه'), await toastText());
  check('no "only until the app is closed" warning for a saved video', (await page.getByText('فقط تا بستن برنامه').count()) === 0);
  await page.screenshot({ path: `${OUT}/video-2-small-playing.png`, fullPage: true });

  // ── 2. after closing and reopening the app, the saved copy still plays ──
  await page.reload();
  await rows().first().waitFor({ timeout: 15000 });
  await rows().first().locator('.row-main').click();
  await page.waitForSelector('video', { timeout: 10000 });
  const reopened = await videoInfo();
  check('after a restart the saved copy plays from the app’s own storage', reopened?.src === 'blob:' && reopened.duration === 20 && reopened.error === null, JSON.stringify(reopened));

  // ── 3. a film bigger than the app can store: plays, is not copied, asks for the file again next time ──
  await openAdd();
  await pick(bigFile);
  await page.waitForFunction(() => document.querySelectorAll('.media-row').length === 2, null, { timeout: 15000 });
  await page.locator('.video-stage .notice, .video-stage [class*=notice]').first().waitFor({ timeout: 10000 });
  const big = await videoInfo();
  check('a 101 MiB file plays too (nothing reads the whole file)', big?.src === 'blob:' && big.duration === 20 && big.error === null, JSON.stringify(big));
  const bigNotice = (await page.locator('.video-stage').innerText()).replace(/\s+/g, ' ');
  check('it explains that this file is bigger than the app stores and is remembered by its place', /بیشتر است/.test(bigNotice) && /جای توقف/.test(bigNotice), bigNotice.slice(0, 200));
  const bigRow = rows().nth(1);
  check('its list entry is marked as a file on the phone', (await bigRow.innerText()).includes('فایل گوشی'), (await bigRow.innerText()).replace(/\s+/g, ' '));
  await page.screenshot({ path: `${OUT}/video-3-big-playing.png`, fullPage: true });
  // watch a bit, pause at 8 s so the place is remembered
  await page.evaluate(async () => {
    const v = document.querySelector('video');
    v.muted = true;
    v.currentTime = 8;
    await v.play();
    await new Promise((r) => setTimeout(r, 600));
    v.pause();
  });
  await page.waitForTimeout(500);
  await page.reload();
  await rows().nth(1).waitFor({ timeout: 15000 });
  check('after a restart the list shows where the film stopped and that the file must be picked again', /ادامه از/.test(await rows().nth(1).innerText()) && /دوباره انتخاب/.test(await rows().nth(1).innerText()), (await rows().nth(1).innerText()).replace(/\s+/g, ' '));
  await rows().nth(1).locator('.row-main').click();
  const overlay = page.locator('.video-overlay');
  await overlay.waitFor({ timeout: 10000 });
  const overlayText = (await overlay.innerText()).replace(/\s+/g, ' ');
  check('opening it asks to pick the file again and promises to resume', overlayText.includes('دوباره انتخاب کنید') && overlayText.includes('ادامه می‌دهد'), overlayText);
  await page.screenshot({ path: `${OUT}/video-4-pick-again.png`, fullPage: true });
  await overlay.locator('input[type=file]').setInputFiles(bigFile);
  await page.waitForSelector('video', { timeout: 10000 });
  const resumed = await videoInfo();
  check('picking it again plays it and resumes where it stopped', resumed?.error === null && resumed.time >= 7 && resumed.time < 12, JSON.stringify(resumed));

  // ── 4. a small file whose copy is not made now can be saved later, without interrupting playback ──
  await page.goto(sectionUrl);
  await rows().first().waitFor({ timeout: 15000 });
  await openAdd();
  await keepSwitch.click();
  check('the switch can be turned off', (await keepSwitch.getAttribute('aria-checked')) === 'false');
  await pick(`${FIX}/tiny.webm`);
  await page.waitForFunction(() => document.querySelectorAll('.media-row').length === 3, null, { timeout: 10000 });
  const keepNotice = page.locator('.video-stage').getByText('فقط تا بستن برنامه');
  await keepNotice.waitFor({ timeout: 10000 });
  await page.evaluate(async () => {
    const v = document.querySelector('video');
    v.muted = true;
    v.currentTime = 4;
    await v.play();
    window.__srcBefore = v.currentSrc;
  });
  await page.locator('.video-stage').getByRole('button', { name: 'ذخیره در برنامه' }).click();
  await page.getByText('نسخه‌ای از ویدئو در برنامه ذخیره شد').first().waitFor({ timeout: 10000 });
  await page.waitForTimeout(400);
  const after = await page.evaluate(() => {
    const v = document.querySelector('video');
    return { same: v.currentSrc === window.__srcBefore, paused: v.paused, time: v.currentTime };
  });
  check('saving later does not interrupt or restart the video that is playing', after.same && !after.paused && after.time >= 4, JSON.stringify(after));
  check('the warning disappears once the copy is saved', (await page.locator('.video-stage').getByText('فقط تا بستن برنامه').count()) === 0);

  // ── 5. files that cannot work: clear message + technical code, nothing is added ──
  const before = await rows().count();
  await openAdd();
  await pick({ name: 'fake.mp4', mimeType: 'video/mp4', buffer: Buffer.from('%PDF-1.7\n1 0 obj\n<<>>\nendobj\n') });
  await dialog.locator('.notice').waitFor({ timeout: 5000 });
  let msg = (await dialog.locator('.notice').innerText()).replace(/\s+/g, ' ');
  check('a PDF renamed .mp4 is refused with a plain message and a code', msg.includes('پشتیبانی نمی‌شود') && msg.includes('UNSUPPORTED_MEDIA'), msg);
  await pick({ name: 'song.webm', mimeType: 'audio/webm', buffer: readFileSync(`${FIX}/audio-only.webm`) });
  await page.waitForFunction(() => /صوتی است/.test(document.querySelector('dialog[open] .notice')?.textContent ?? ''), null, { timeout: 5000 });
  msg = (await dialog.locator('.notice').innerText()).replace(/\s+/g, ' ');
  check('an audio file is sent to the Music section', msg.includes('موسیقی'), msg);
  await pick({ name: 'empty.mp4', mimeType: 'video/mp4', buffer: Buffer.alloc(0) });
  await page.waitForFunction(() => /خالی/.test(document.querySelector('dialog[open] .notice')?.textContent ?? ''), null, { timeout: 5000 });
  check('an empty file is refused', true);
  await page.screenshot({ path: `${OUT}/video-5-refused.png` });
  check('none of those was added to the list', (await rows().count()) === before);

  // a file that looks like a video but cannot be decoded: it is added, and the player explains why
  await dialog.getByRole('switch').click();
  check('the "keep a copy" switch starts on again every time the dialog opens (and could be turned off here)', (await dialog.getByRole('switch').getAttribute('aria-checked')) === 'false');
  await pick({ name: 'broken.mp4', mimeType: 'video/mp4', buffer: Buffer.concat([Buffer.from([0, 0, 0, 0x18]), Buffer.from('ftypisom'), Buffer.alloc(4), Buffer.from('isommp42'), Buffer.alloc(3000, 7)]) });
  await page.waitForFunction((n) => document.querySelectorAll('.media-row').length === n + 1, before, { timeout: 10000 });
  const problem = page.locator('.video-overlay .err-tag');
  await problem.waitFor({ timeout: 15000 });
  const tag = await problem.innerText();
  const problemText = (await page.locator('.video-overlay').innerText()).replace(/\s+/g, ' ');
  check('an undecodable video shows what is wrong, a technical code and a "pick again" button', /^MEDIA_ERR_/.test(tag) && /قالب|خراب|ناقص|پخش نشد/.test(problemText) && (await page.locator('.video-overlay').getByRole('button', { name: 'انتخاب دوباره‌ی فایل' }).count()) === 1, `${tag} | ${problemText.slice(0, 120)}`);
  check('no "keep a copy" offer is made for a video that cannot play', (await page.locator('.video-stage').getByText('فقط تا بستن برنامه').count()) === 0);
  check('the player’s own controls are hidden behind the message', await page.evaluate(() => getComputedStyle(document.querySelector('video')).visibility === 'hidden'));
  await page.screenshot({ path: `${OUT}/video-6-undecodable.png`, fullPage: true });

  // a file with sound but no picture the device can show
  await openAdd();
  await dialog.getByRole('switch').click();
  await pick({ name: 'sound-only.webm', mimeType: 'video/webm', buffer: readFileSync(`${FIX}/audio-only.webm`) });
  await page.waitForFunction((n) => document.querySelectorAll('.media-row').length === n + 2, before, { timeout: 10000 });
  await page.getByText('فقط صدا پخش می‌شود').waitFor({ timeout: 10000 });
  check('a file with no picture says only sound plays and why', true);
  await page.screenshot({ path: `${OUT}/video-7-no-picture.png`, fullPage: true });

  // ── 6. large view: fills the screen; Back and Esc leave it ──
  await rows().first().locator('.row-main').click();
  await page.waitForSelector('video');
  await page.getByRole('button', { name: 'نمای بزرگ' }).click();
  const stage = page.locator('.video-stage.is-theater');
  await stage.waitFor();
  const box = await stage.boundingBox();
  const frame = await page.locator('.video-stage.is-theater .video-frame').boundingBox();
  check('large view covers the whole screen', box && box.x === 0 && box.y === 0 && Math.round(box.width) === 412 && Math.round(box.height) === 860, JSON.stringify(box));
  check('the player fills the large view', frame && Math.round(frame.width) === 412 && frame.height > 700, JSON.stringify(frame));
  check('the page behind does not scroll while it is open', await page.evaluate(() => document.documentElement.classList.contains('has-theater')));
  check('a way out is on screen', await page.getByRole('button', { name: 'بستن نمای بزرگ' }).isVisible());
  await page.screenshot({ path: `${OUT}/video-8-large-view.png` });
  const notCancelled = await page.evaluate(() => window.dispatchEvent(new Event('hamyar:back', { cancelable: true })));
  check('Android’s Back button leaves the large view (the page handles it)', notCancelled === false && (await page.locator('.video-stage.is-theater').count()) === 0);
  await page.getByRole('button', { name: 'نمای بزرگ' }).click();
  await stage.waitFor();
  await page.keyboard.press('Escape');
  await page.waitForFunction(() => !document.querySelector('.video-stage.is-theater'));
  check('Esc leaves the large view too, and the page scrolls again', !(await page.evaluate(() => document.documentElement.classList.contains('has-theater'))));
  const stillPlaying = await videoInfo();
  check('the video is still loaded after leaving the large view', stillPlaying?.error === null && stillPlaying.duration === 20, JSON.stringify(stillPlaying));

  // ── 7. links still work ──
  await openAdd();
  await dialog.getByRole('tab', { name: /لینک/ }).or(dialog.getByRole('radio', { name: /لینک/ })).first().click();
  await dialog.getByPlaceholder('https://').fill('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
  await dialog.getByRole('button', { name: 'افزودن' }).last().click();
  await page.locator('.video-overlay .err-tag', { hasText: 'YOUTUBE_' }).waitFor({ timeout: 20000 });
  const href = await page.locator('.video-overlay a').first().getAttribute('href');
  check('a YouTube link that cannot load shows the reason and an "open on YouTube" link', href === 'https://www.youtube.com/watch?v=dQw4w9WgXcQ');

  // ── 8. removing a video forgets its copy ──
  const beforeRemoval = await storedAssets();
  check('two copies are stored before removing one (the first video and the one saved later)', beforeRemoval.length === 2, JSON.stringify(beforeRemoval));
  const count = await rows().count();
  await rows().first().getByRole('button', { name: 'حذف' }).click();
  await page.getByRole('button', { name: 'حذف', exact: true }).last().click();
  await page.waitForFunction((n) => document.querySelectorAll('.media-row').length === n - 1, count, { timeout: 10000 });
  const assets = await storedAssets();
  check('removing a video removes its stored copy and keeps the others', assets.length === 1 && assets[0].kind === 'video' && assets[0].size === statSync(`${FIX}/tiny.webm`).size, JSON.stringify(assets));

  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  check('no sideways scroll on the phone screen', overflow <= 0, String(overflow));
} catch (e) {
  check('video run completed without exceptions', false, String(e).slice(0, 400));
  await page.screenshot({ path: `${OUT}/zz-video-failure.png`, fullPage: true }).catch(() => undefined);
} finally {
  check('no script errors', errors.length === 0, errors.slice(0, 4).join(' | '));
  await browser.close();
  server.close();
  rmSync(bigFile, { force: true });
  console.log(`\n${results.filter(Boolean).length}/${results.length} checks passed`);
  process.exitCode = results.every(Boolean) ? 0 : 1;
}
