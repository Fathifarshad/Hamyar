/* global document, window -- used inside page.evaluate callbacks, which run in the browser */
// Voice assistant, cars and music-by-voice on a phone-sized screen (npm run build:mobile first):
// the first word chooses the section and that section opens with its form filled in; cars keep
// insurance, oil changes and the odometer; «آهنگ‌های X» plays one artist, «آهنگ X» one song.
// Speech is simulated by a fake recognizer that "hears" the sentence the test sets.
import { chromium } from 'playwright-core';
import http from 'node:http';
import { existsSync, mkdirSync, readFileSync, statSync } from 'node:fs';
import { extname, join, normalize } from 'node:path';
import { chromiumPath } from '../../scripts/chromium.mjs';

const ROOT = 'dist-mobile';
const PORT = Number(process.env.ASSISTANT_PORT || 4198);
const BASE = `http://127.0.0.1:${PORT}/Hamyar/`;
const OUT = 'test-results';
mkdirSync(OUT, { recursive: true });

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2', '.pdf': 'application/pdf', '.bcmap': 'application/octet-stream', '.wasm': 'application/wasm' };
const server = http
  .createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    if (!url.pathname.startsWith('/Hamyar/')) {
      res.writeHead(404);
      return res.end();
    }
    let file = normalize(join(ROOT, decodeURIComponent(url.pathname.slice('/Hamyar/'.length)) || 'index.html'));
    if (!file.startsWith(ROOT)) {
      res.writeHead(403);
      return res.end();
    }
    if (existsSync(file) && statSync(file).isDirectory()) file = join(file, 'index.html');
    if (!existsSync(file)) {
      res.writeHead(404);
      return res.end();
    }
    res.writeHead(200, { 'content-type': TYPES[extname(file)] || 'application/octet-stream' });
    res.end(readFileSync(file));
  })
  .listen(PORT, '127.0.0.1');

const results = [];
const check = (name, ok, detail = '') => {
  results.push(ok);
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`);
};

// ── small MP3 files with ID3 tags (silent frames), like songs downloaded with their artist tag
const latin = (s) => [...s].map((c) => c.charCodeAt(0) & 255);
const safe = (n) => [(n >> 21) & 127, (n >> 14) & 127, (n >> 7) & 127, n & 127];
const be32 = (n) => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
function mp3(title, artist) {
  const frame = (id, text) => {
    const body = [0, ...latin(text)];
    return [...latin(id), ...be32(body.length), 0, 0, ...body];
  };
  const frames = [...frame('TIT2', title), ...frame('TPE1', artist)];
  const tag = [...latin('ID3'), 3, 0, 0, ...safe(frames.length), ...frames];
  const mpegFrame = Buffer.alloc(417);
  mpegFrame.set([0xff, 0xfb, 0x90, 0xc0], 0);
  return Buffer.concat([Buffer.from(tag), ...new Array(80).fill(mpegFrame)]);
}

const browser = await chromium.launch({ executablePath: chromiumPath(), args: ['--autoplay-policy=no-user-gesture-required'] });
const androidUA = 'Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36';
const context = await browser.newContext({ viewport: { width: 412, height: 860 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: androidUA, locale: 'fa-IR', timezoneId: 'America/Santiago' });
// a recognizer that "hears" window.__nextSpeech a moment after it starts
await context.addInitScript(() => {
  class FakeRecognition {
    start() {
      setTimeout(() => {
        const text = window.__nextSpeech || '';
        window.__heard = (window.__heard || 0) + 1;
        const result = [{ transcript: text }];
        result.isFinal = true;
        this.onresult?.({ resultIndex: 0, results: [result] });
        this.onend?.();
      }, 250);
    }
    stop() {}
    abort() {}
  }
  window.SpeechRecognition = FakeRecognition;
  window.webkitSpeechRecognition = FakeRecognition;
});
const page = await context.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
page.on('console', (m) => {
  if (m.type() !== 'error') return;
  if (/youtube|open-meteo|ERR_INTERNET_DISCONNECTED|ERR_TUNNEL|Failed to load resource/.test(`${m.text()} ${m.location()?.url ?? ''}`)) return;
  errors.push(m.text().slice(0, 200));
});

const dialog = page.locator('dialog[open]').last();
const fab = page.locator('.assistant-fab');
/** Types a sentence into the assistant and presses «انجام». */
const say = async (text) => {
  await fab.click();
  await dialog.getByRole('textbox', { name: 'فرمان یا پیام' }).fill(text);
  await dialog.getByRole('button', { name: 'انجام' }).click();
};
const toastText = async () => (await page.locator('.toast').allInnerTexts()).join(' | ').replace(/\s+/g, ' ');

try {
  await page.goto(BASE);
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('radio', { name: /شروع پیشنهادی/ }).click();
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('button', { name: 'ساخت داشبورد من' }).click();
  await page.locator('.dash-grid .mod').first().waitFor({ timeout: 20000 });

  // ── 0. the button is on every screen ──
  check('a microphone button is on the dashboard', await fab.isVisible());
  await page.evaluate(() => (window.__nextSpeech = ''));
  await fab.click();
  // the first use of the microphone explains it once
  const consent = page.getByRole('button', { name: 'متوجه شدم، شروع' });
  await consent.waitFor({ timeout: 5000 });
  check('the microphone starts by itself, after a one-time explanation', true);
  await consent.click();
  await consent.waitFor({ state: 'detached' });
  const sheet = (await page.locator('dialog[open]', { hasText: 'دستیار صوتی' }).innerText()).replace(/\s+/g, ' ');
  check('the assistant explains «section first, then the rest» and shows examples', /اول بگویید برای کدام بخش است/.test(sheet) && /دارو استامینوفن/.test(sheet), sheet.slice(0, 160));
  await page.screenshot({ path: `${OUT}/assistant-1-sheet.png` });
  await dialog.getByRole('button', { name: 'بستن' }).first().click();

  // ── 1. medicine: no section yet → create it → the form opens filled in ──
  await say('دارو استامینوفن ۵۰۰ میلی گرم هر ۸ ساعت بعد از غذا به مدت ۵ روز');
  await dialog.getByText('بخش «داروها» هنوز ساخته نشده').waitFor();
  check('a section that does not exist yet is offered, not guessed', true);
  await dialog.getByRole('button', { name: 'بساز و ادامه بده' }).click();
  await page.getByRole('heading', { name: 'افزودن دارو' }).waitFor({ timeout: 10000 });
  const medDialog = page.locator('dialog[open]').last();
  const medName = await medDialog.getByRole('textbox', { name: 'نام دارو' }).inputValue();
  const medDose = await medDialog.getByRole('textbox', { name: 'مقدار مصرف' }).inputValue();
  const medUnit = await medDialog.locator('input[placeholder="مثلاً میلی‌گرم"]').inputValue();
  const medTimes = await medDialog.locator('input[type=time]').evaluateAll((els) => els.map((e) => e.value));
  const medNotes = await medDialog.getByRole('textbox', { name: 'نکات' }).inputValue();
  check('the medications section opened with name, amount, unit, times and note filled in', medName === 'استامینوفن' && medDose === '۵۰۰' && medUnit === 'میلی‌گرم' && medNotes === 'بعد از غذا' && medTimes.join(',') === '00:00,08:00,16:00', JSON.stringify({ medName, medDose, medUnit, medTimes, medNotes }));
  const medNotice = (await medDialog.innerText()).replace(/\s+/g, ' ');
  check('it asks to compare with the prescription and says the times were placed by the app', /با نسخه مقایسه کنید/.test(medNotice) && /ساعت‌ها را همیار گذاشته است/.test(medNotice));
  await page.screenshot({ path: `${OUT}/assistant-2-medication.png`, fullPage: true });
  await medDialog.getByRole('button', { name: 'ذخیره' }).click();
  await page.getByText('برنامه دارو ذخیره شد').first().waitFor({ timeout: 10000 });
  check('nothing was saved until «ذخیره»; after it the medication is in the list', (await page.locator('.dose-row').count()) > 0 || (await page.getByText('استامینوفن').count()) > 0);

  // ── 2. cars ──
  await say('ماشین');
  await dialog.getByRole('button', { name: 'بساز و ادامه بده' }).click();
  await page.getByRole('heading', { name: 'افزودن خودرو' }).waitFor({ timeout: 10000 });
  check('a new cars section asks for the first car', true, await toastText());
  const carDialog = page.locator('dialog[open]').last();
  await carDialog.getByRole('textbox', { name: 'نام خودرو' }).fill('پژو سفید');
  await carDialog.getByLabel('سازنده').fill('ایران‌خودرو');
  await carDialog.getByLabel('مدل').fill('۲۰۶ تیپ ۲');
  await carDialog.getByLabel('پلاک').fill('۱۲ ب ۳۴۵ ایران ۶۷');
  await carDialog.getByLabel('شماره شاسی (VIN)').fill('nfa12');
  await carDialog.getByLabel('شماره شاسی (VIN)').blur();
  check('a VIN that is not 17 characters gets a gentle warning, and is stored upper-case', /۱۷ نویسه/.test(await carDialog.innerText()) && (await carDialog.getByLabel('شماره شاسی (VIN)').inputValue()) === 'NFA12');
  await carDialog.getByLabel('کیلومتر فعلی', { exact: true }).fill('۸۵۰۰۰');
  await carDialog.getByRole('button', { name: 'ذخیره' }).click();
  await page.locator('.veh-head').waitFor({ timeout: 10000 });
  const head = (await page.locator('.veh-head').innerText()).replace(/\s+/g, ' ');
  check('the car page shows name, plate, VIN and odometer', /پژو سفید/.test(head) && /۱۲ ب ۳۴۵ ایران ۶۷/.test(head) && /NFA12/.test(head) && /۸۵٬۰۰۰/.test(head), head);
  const tiles = (await page.locator('.veh-tiles').innerText()).replace(/\s+/g, ' ');
  check('status tiles for third-party and body insurance, inspection and oil change, all «not recorded»', /بیمه شخص ثالث/.test(tiles) && /بیمه بدنه/.test(tiles) && /معاینه فنی/.test(tiles) && /تعویض روغن/.test(tiles) && (tiles.match(/ثبت نشده/g) ?? []).length === 4, tiles);

  // a policy typed into the section's own box
  await page.getByRole('textbox', { name: 'ثبت سریع برای خودرو' }).fill('بیمه ثالث تا ۲۰ اسفند ۱۴۰۵ حق بیمه ۸ میلیون تومان');
  await page.getByRole('button', { name: 'بررسی و ثبت' }).click();
  await page.getByRole('heading', { name: 'ثبت برای خودرو' }).waitFor();
  const rd = page.locator('dialog[open]').last();
  const kind = await rd.getByRole('combobox', { name: 'نوع' }).inputValue();
  const cost = await rd.getByLabel('هزینه (اختیاری)').inputValue();
  check('the record form opens as third-party insurance with the premium filled in', kind === 'insurance_third' && cost === '8000000', JSON.stringify({ kind, cost }));
  await page.screenshot({ path: `${OUT}/assistant-3-car-record.png`, fullPage: true });
  await rd.getByRole('button', { name: 'ذخیره' }).click();
  await page.getByText(/برای پژو سفید ثبت شد/).first().waitFor({ timeout: 10000 });
  const tiles2 = (await page.locator('.veh-tiles').innerText()).replace(/\s+/g, ' ');
  check('the third-party tile now shows its end date and days left', /تا ۲۰ اسفند ۱۴۰۵/.test(tiles2) && /روز مانده/.test(tiles2), tiles2.slice(0, 200));

  // an oil change by voice, from the dashboard
  await page.goto(BASE);
  await page.locator('.dash-grid .mod').first().waitFor();
  await page.evaluate(() => (window.__nextSpeech = 'ماشین تعویض روغن امروز کیلومتر ۸۶ هزار بعدی ۵ هزار کیلومتر دیگه هزینه ۲ میلیون تومان'));
  await fab.click();
  await page.getByRole('heading', { name: 'ثبت برای خودرو' }).waitFor({ timeout: 10000 });
  check('spoken (not typed): the microphone hears the sentence and the cars section opens with it', (await page.evaluate(() => window.__heard)) >= 1 && /#\/m\//.test(page.url()));
  const od = page.locator('dialog[open]').last();
  const oilKind = await od.getByRole('combobox', { name: 'نوع' }).inputValue();
  const oilKm = await od.getByLabel('کیلومتر', { exact: true }).inputValue();
  const nextKm = await od.getByLabel('در کیلومتر').inputValue();
  check('oil change with the reading, the next one at +5000 and the cost', oilKind === 'oil' && oilKm === '86000' && nextKm === '91000' && (await od.getByLabel('هزینه (اختیاری)').inputValue()) === '2000000', JSON.stringify({ oilKind, oilKm, nextKm }));
  await od.getByRole('button', { name: 'فیلتر روغن' }).click();
  await od.getByRole('button', { name: 'ذخیره' }).click();
  await page.getByText(/برای پژو سفید ثبت شد/).first().waitFor({ timeout: 10000 });
  const head2 = (await page.locator('.veh-head').innerText()).replace(/\s+/g, ' ');
  const tiles3 = (await page.locator('.veh-tiles').innerText()).replace(/\s+/g, ' ');
  check('the odometer moved to 86,000 and the oil tile counts the 5,000 km left', /۸۶٬۰۰۰/.test(head2) && /۵٬۰۰۰ کیلومتر مانده/.test(tiles3), `${head2} || ${tiles3}`);
  const history = (await page.locator('section[aria-label="سابقه"]').innerText()).replace(/\s+/g, ' ');
  check('the history lists both, with cost and the filter that was changed', /تعویض روغن/.test(history) && /فیلتر روغن/.test(history) && /بیمه شخص ثالث/.test(history), history.slice(0, 220));
  await page.screenshot({ path: `${OUT}/assistant-4-car.png`, fullPage: true });

  // only a new reading
  await say('کیلومتر ۸۷ هزار');
  await page.getByRole('heading', { name: /کیلومتر فعلی «پژو سفید»/ }).waitFor({ timeout: 10000 });
  check('«کیلومتر ۸۷ هزار» asks to confirm the new reading', (await page.locator('dialog[open]').last().getByRole('textbox').inputValue()) === '87000');
  await page.locator('dialog[open]').last().getByRole('button', { name: 'ذخیره' }).click();
  await page.waitForFunction(() => /۸۷٬۰۰۰/.test(document.querySelector('.veh-head')?.textContent ?? ''));
  check('and the car page shows it', true);

  // ── 3. music by artist and by song ──
  await page.goto(BASE);
  await page.locator('.dash-grid .mod', { hasText: 'موسیقی' }).getByRole('button', { name: 'افزودن' }).click();
  const md = page.locator('dialog[open]').last();
  await md.locator('input[type=file]').setInputFiles([
    { name: 'track01.mp3', mimeType: 'audio/mpeg', buffer: mp3('Pol', 'Googoosh') },
    { name: 'track02.mp3', mimeType: 'audio/mpeg', buffer: mp3('Talaye Zard', 'Googoosh') },
    { name: 'Ebi - Khalij (320).mp3', mimeType: 'audio/mpeg', buffer: mp3('', '') },
  ]);
  await md.locator('.file-log li.ok').nth(2).waitFor({ timeout: 15000 });
  await md.getByRole('button', { name: 'بستن' }).first().click();
  await say('آهنگ‌های گوگوش');
  await page.locator('.player .player-title').waitFor({ timeout: 10000 });
  await page.waitForFunction(() => /Pol/.test(document.querySelector('.player .player-title')?.textContent ?? ''));
  const now1 = (await page.locator('.player').innerText()).replace(/\s+/g, ' ');
  check('«آهنگ‌های گوگوش» (said in Persian) plays only the 2 songs tagged «Googoosh»', /Pol/.test(now1) && /Googoosh/.test(now1) && /۲ آهنگ/.test(now1), now1.slice(0, 120));
  const rowsText = (await page.locator('.media-row').allInnerTexts()).join(' | ').replace(/\s+/g, ' ');
  check('the artist comes from the file’s tag, or from «Artist - Title» in its name', /Googoosh/.test(rowsText) && /Khalij/.test(rowsText) && /Ebi/.test(rowsText), rowsText);
  check('artist buttons let you play an artist with one tap', (await page.locator('.chip-row button', { hasText: 'Googoosh' }).count()) === 1);
  await page.screenshot({ path: `${OUT}/assistant-5-music.png`, fullPage: true });
  await say('آهنگ خلیج');
  await page.waitForFunction(() => /Khalij/.test(document.querySelector('.player .player-title')?.textContent ?? ''), null, { timeout: 10000 });
  const now2 = (await page.locator('.player').innerText()).replace(/\s+/g, ' ');
  check('«آهنگ خلیج» plays just that one song', /Khalij/.test(now2) && !/آهنگ ·|۲ آهنگ|۳ آهنگ/.test(now2), now2.slice(0, 120));

  // ── 4. tasks, a shopping list, and a sentence with no section word ──
  await say('یادم بنداز فردا ساعت ۹ صبح جلسه تیم');
  await page.getByRole('heading', { name: 'بررسی پیش از ثبت' }).waitFor({ timeout: 10000 });
  const preview = page.locator('dialog[open]').last();
  check('«یادم بنداز …» opens the task preview with the title and 09:00 tomorrow', (await preview.locator('input').first().inputValue()) === 'جلسه تیم' && (await preview.locator('input[type=time]').inputValue()) === '09:00', (await preview.innerText()).replace(/\s+/g, ' ').slice(0, 160));
  await page.locator('dialog[open]').last().getByRole('button', { name: 'انصراف' }).click();

  await say('خرید نان، شیر و تخم مرغ');
  await dialog.getByRole('button', { name: 'بساز و ادامه بده' }).click();
  await page.getByRole('heading', { name: /افزودن ۳ مورد/ }).waitFor({ timeout: 10000 });
  check('«خرید …» becomes three checklist items to confirm', /نان، شیر، تخم مرغ/.test(await page.locator('dialog[open]').last().innerText()));
  await page.locator('dialog[open]').last().getByRole('button', { name: 'افزودن' }).click();
  await page.waitForFunction(() => document.querySelectorAll('.check-row, .rows li').length >= 3);
  check('and they are added one by one', (await page.getByText('تخم مرغ').count()) > 0);

  await say('سلام خوبی');
  await dialog.getByText('معلوم نشد برای کدام بخش است').waitFor();
  const choices = await dialog.locator('.assistant-chip').count();
  check('a sentence without a section word is not guessed: the sections are offered', choices >= 3, String(choices));
  await page.screenshot({ path: `${OUT}/assistant-6-unknown.png` });
  await dialog.getByRole('button', { name: 'بستن' }).first().click();

  // ── 5. layout ──
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  check('no sideways scroll on the phone screen', overflow <= 0, String(overflow));
  const fabBox = await fab.boundingBox();
  const nav = await page.locator('.bottom-nav').boundingBox();
  check('the microphone button sits above the bottom bar', !!fabBox && !!nav && fabBox.y + fabBox.height <= nav.y, JSON.stringify({ fabBox, nav }));
  check('no script errors', errors.length === 0, errors.join(' | '));
} catch (e) {
  check('scenario ran to the end', false, String(e?.message ?? e).slice(0, 400));
  await page.screenshot({ path: `${OUT}/assistant-error.png`, fullPage: true }).catch(() => undefined);
} finally {
  await browser.close();
  server.close();
}

const passed = results.filter(Boolean).length;
console.log(`\n${passed}/${results.length} checks passed`);
process.exit(passed === results.length ? 0 : 1);
