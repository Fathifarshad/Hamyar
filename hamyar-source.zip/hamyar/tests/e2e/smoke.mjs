/* global document, window -- used inside page.evaluate callbacks, which run in the browser */
// End-to-end smoke run against the production build (npm run build first).
// Starts the local server, walks the main paths in headless Chromium, saves screenshots
// to test-results/ and fails on console errors or broken expectations.
import { chromium } from 'playwright-core';
import { spawn } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { chromiumPath } from '../../scripts/chromium.mjs';

const PORT = Number(process.env.SMOKE_PORT || 4199);
const BASE = `http://127.0.0.1:${PORT}/`;
const OUT = 'test-results';
mkdirSync(OUT, { recursive: true });

const server = spawn(process.execPath, ['server/index.mjs'], { env: { ...process.env, PORT: String(PORT), HOST: '127.0.0.1' }, stdio: ['ignore', 'pipe', 'pipe'] });
await new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error('server did not start')), 15000);
  server.stdout.on('data', (d) => {
    if (String(d).includes('running')) {
      clearTimeout(timer);
      resolve();
    }
  });
  server.on('exit', (code) => reject(new Error(`server exited ${code}`)));
});

const results = [];
const check = (name, ok, detail = '') => {
  results.push({ name, ok, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`);
};

const browser = await chromium.launch({
  executablePath: chromiumPath(),
  args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required'],
});
const context = await browser.newContext({ viewport: { width: 1440, height: 960 }, locale: 'fa-IR', timezoneId: 'America/Santiago', colorScheme: 'light' });
await context.grantPermissions(['microphone', 'notifications'], { origin: BASE.slice(0, -1) });
const page = await context.newPage();
const consoleErrors = [];
const failed = [];
// External services (weather, YouTube) are unreachable from the test sandbox; their
// failures are expected and filtered by the URL the message comes from.
const EXTERNAL = /open-meteo|youtube|ytimg/i;
page.on('console', (m) => {
  if (m.type() !== 'error') return;
  const where = m.location()?.url ?? '';
  if (EXTERNAL.test(where) || EXTERNAL.test(m.text())) return;
  if (/ERR_TUNNEL_CONNECTION_FAILED|ERR_NAME_NOT_RESOLVED/.test(m.text()) && !where.startsWith(BASE)) return;
  consoleErrors.push(`${m.text()} @ ${where}`);
});
page.on('pageerror', (e) => consoleErrors.push(String(e)));
page.on('requestfailed', (r) => {
  const u = r.url();
  if (!u.includes('open-meteo') && !u.includes('youtube')) failed.push(`${u} ${r.failure()?.errorText}`);
});

try {
  await page.goto(BASE);
  await page.getByText('زبان و زمان').first().waitFor({ timeout: 15000 });
  await page.screenshot({ path: `${OUT}/01-onboarding-1440.png` });
  check('onboarding opens in Persian RTL', (await page.getAttribute('html', 'dir')) === 'rtl');

  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('radio', { name: /شروع پیشنهادی/ }).click();
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('switch', { name: /داده نمونه/ }).click();
  await page.getByRole('button', { name: 'ساخت داشبورد من' }).click();
  await page.locator('.dash-grid .mod').first().waitFor({ timeout: 20000 });
  await page.waitForTimeout(1500);
  const cards = await page.locator('.dash-grid .mod').count();
  check('dashboard shows sections after onboarding', cards >= 5, `${cards} cards`);
  await page.screenshot({ path: `${OUT}/02-dashboard-1440.png`, fullPage: true });

  // Create a task through the command preview.
  const tasksCard = page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'کارها و قرارها' }) }).first();
  await tasksCard.locator('input.vi-input').fill('فردا ساعت ۹ صبح جلسه تیم');
  await tasksCard.locator('input.vi-input').press('Enter');
  const dialog = page.locator('dialog.modal');
  await dialog.waitFor();
  const preview = await dialog.innerText();
  check('command preview shows parsed time and title', preview.includes('۰۹:۰۰') && (await dialog.locator('input').first().inputValue()) === 'جلسه تیم', preview.replace(/\s+/g, ' ').slice(0, 120));
  await page.screenshot({ path: `${OUT}/03-task-preview.png` });
  await dialog.getByRole('button', { name: /ثبت قرار/ }).click();
  await page.waitForTimeout(600);

  // Ambiguous time must not be guessed.
  await tasksCard.locator('input.vi-input').fill('ساعت ۹ جلسه');
  await tasksCard.locator('input.vi-input').press('Enter');
  await dialog.waitFor();
  const ambiguous = await dialog.innerText();
  check('«ساعت ۹» asks morning or evening', ambiguous.includes('صبح یا شب'));
  const saveDisabled = await dialog.getByRole('button', { name: /ثبت/ }).last().isDisabled();
  check('save is blocked until the ambiguity is resolved', saveDisabled);
  await dialog.getByRole('button', { name: 'انصراف' }).click();

  await page.reload();
  await page.locator('.dash-grid .mod').first().waitFor();
  await page.waitForTimeout(800);
  const html = await page.content();
  check('task persists after reload', html.includes('جلسه تیم'));

  // Medication dose needs explicit confirmation.
  const medCard = page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'داروها' }) }).first();
  if (await medCard.count()) {
    const taken = medCard.getByRole('button', { name: 'مصرف شد' }).first();
    if (await taken.count()) {
      await taken.click();
      await dialog.waitFor();
      check('dose “taken” opens a confirmation with details', (await dialog.innerText()).includes('داروی نمونه'));
      await dialog.getByRole('button', { name: 'تأیید' }).click();
      await page.waitForTimeout(500);
      check('dose recorded as taken', (await medCard.locator('.dose-row.state-taken').count()) >= 1);
    }
  }

  // Active cap: fill to 10, then the 11th must be blocked.
  await page.goto(`${BASE}#/library`);
  await page.getByRole('heading', { name: 'بخش‌ها' }).waitFor();
  for (let i = 0; i < 12; i++) {
    const counter = await page.locator('.counter-text').first().innerText();
    if (counter.startsWith('۱۰ از ۱۰')) break;
    await page.getByRole('button', { name: 'افزودن بخش' }).first().click();
    await page.locator('.type-card', { hasText: 'یادداشت‌ها' }).click();
    await page.getByRole('button', { name: 'ساخت بخش' }).click();
    await page.waitForTimeout(300);
  }
  check('ten sections can be active', (await page.locator('.counter-text').first().innerText()).startsWith('۱۰ از ۱۰'));
  await page.getByRole('button', { name: 'افزودن بخش' }).first().click();
  await page.locator('.type-card', { hasText: 'چک‌لیست' }).click();
  const capNotice = await page.locator('dialog.modal').innerText();
  check('the 11th section offers “create hidden” or “replace”', capNotice.includes('۱۰ بخش فعال دارید') && capNotice.includes('ساخت به‌صورت پنهان'));
  await page.getByRole('button', { name: 'ساخت بخش' }).click();
  await page.waitForTimeout(400);
  check('11th section was created hidden, cap kept', (await page.locator('.counter-text').first().innerText()).startsWith('۱۰ از ۱۰') && (await page.content()).includes('پنهان'));
  await page.screenshot({ path: `${OUT}/04-library-1440.png`, fullPage: true });

  // PDF sample: extraction and viewer.
  await page.goto(BASE);
  const pdfCard = page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'PDF' }) }).first();
  await pdfCard.locator('.row-main').first().click();
  await page.locator('.pdf-canvas').waitFor({ timeout: 15000 });
  await page.waitForTimeout(1500);
  const pdfText = await page.locator('.summary').innerText();
  check('PDF text extracted and coverage shown', /متن ۳ صفحه از ۳ صفحه/.test(pdfText), pdfText.slice(0, 80));
  const drawn = await page.evaluate(() => {
    const c = document.querySelector('.pdf-canvas');
    if (!c || c.hidden || !c.width) return 0;
    const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    let ink = 0;
    for (let i = 0; i < d.length; i += 4 * 37) if (d[i] < 160 && d[i + 3] > 0) ink++;
    return ink;
  });
  check('PDF page is drawn on the canvas', drawn > 50, `${drawn} ink samples`);
  check('Persian section title keeps right-to-left order', (await page.locator('.page-title').first().getAttribute('dir')) === 'rtl');
  check('summary is unavailable (not faked) without a provider', pdfText.includes('راه‌اندازی نشده'));
  await page.locator('.search-box input').last().fill('پومودورو');
  await page.waitForTimeout(300);
  check('search inside PDF finds page 2', (await page.locator('.search-results').innerText()).includes('۲'));
  await page.screenshot({ path: `${OUT}/05-pdf-1440.png`, fullPage: true });

  // Settings: English + dark.
  await page.goto(`${BASE}#/settings`);
  await page.getByRole('radio', { name: 'English' }).first().click();
  await page.getByRole('radio', { name: 'Dark' }).click();
  await page.waitForTimeout(400);
  check('switching to English sets LTR', (await page.getAttribute('html', 'dir')) === 'ltr');
  await page.goto(BASE);
  await page.locator('.dash-grid .mod').first().waitFor();
  await page.waitForTimeout(1200);
  await page.screenshot({ path: `${OUT}/06-dashboard-en-dark-1440.png`, fullPage: true });

  // Back to Persian light for phone/tablet shots.
  await page.goto(`${BASE}#/settings`);
  await page.getByRole('radio', { name: 'فارسی' }).first().click();
  await page.getByRole('radio', { name: /روشن/ }).click();
  for (const [w, h] of [
    [768, 1024],
    [320, 720],
  ]) {
    await page.setViewportSize({ width: w, height: h });
    await page.goto(BASE);
    await page.locator('.dash-grid .mod').first().waitFor();
    await page.waitForTimeout(1000);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    check(`no horizontal page scroll at ${w}px`, overflow <= 0, `overflow ${overflow}px`);
    await page.screenshot({ path: `${OUT}/07-dashboard-${w}.png`, fullPage: true });
  }
  await page.goto(`${BASE}#/settings`);
  await page.waitForTimeout(600);
  await page.screenshot({ path: `${OUT}/08-settings-320.png`, fullPage: true });
} catch (e) {
  check('smoke run completed without exceptions', false, String(e).slice(0, 300));
  await page.screenshot({ path: `${OUT}/zz-failure.png`, fullPage: true }).catch(() => undefined);
} finally {
  const relevant = consoleErrors.filter((e) => !/favicon/i.test(e));
  check('no console errors', relevant.length === 0, relevant.slice(0, 5).join(' | '));
  check('no failed requests', failed.length === 0, failed.slice(0, 5).join(' | '));
  await browser.close();
  server.kill();
  const bad = results.filter((r) => !r.ok);
  console.log(`\n${results.length - bad.length}/${results.length} checks passed`);
  process.exitCode = bad.length ? 1 : 0;
}
