// Second end-to-end run (npm run build first): server API guards, voice input failure
// handling, an in-app reminder firing on time, and export → erase → import.
import { chromium } from 'playwright-core';
import { spawn } from 'node:child_process';
import { mkdirSync, readFileSync } from 'node:fs';
import { chromiumPath } from '../../scripts/chromium.mjs';

const PORT = Number(process.env.FLOWS_PORT || 4195);
const ORIGIN = `http://127.0.0.1:${PORT}`;
const BASE = `${ORIGIN}/`;
const OUT = 'test-results';
mkdirSync(OUT, { recursive: true });

// No AI keys on purpose: the app must report "not set up", never invent results.
const env = { ...process.env, PORT: String(PORT), HOST: '127.0.0.1', TEXT_PROVIDER: 'none', TRANSCRIPTION_PROVIDER: 'none', OPENAI_API_KEY: '', ANTHROPIC_API_KEY: '' };
const server = spawn(process.execPath, ['server/index.mjs'], { env, stdio: ['ignore', 'pipe', 'pipe'] });
await new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error('server did not start')), 15000);
  server.stdout.on('data', (d) => String(d).includes('running') && (clearTimeout(timer), resolve()));
  server.on('exit', (code) => reject(new Error(`server exited ${code}`)));
});

const results = [];
const check = (name, ok, detail = '') => {
  results.push({ name, ok });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`);
};

// ── 1. Server API guards ──────────────────────────────────────────────
{
  const health = await fetch(`${BASE}api/health`).then((r) => r.json());
  check('health reports summary and transcription as not configured', health.summary?.available === false && health.transcription?.available === false);
  const body = JSON.stringify({ pages: [{ n: 1, text: 'متن آزمایشی' }], totalPages: 1, language: 'fa', length: 'short' });
  const sum = await fetch(`${BASE}api/summaries`, { method: 'POST', headers: { 'content-type': 'application/json', origin: ORIGIN }, body });
  const sumJson = await sum.json().catch(() => ({}));
  check('summary request without a provider is refused, not faked', sum.status === 503 && sumJson.error?.code === 'NOT_CONFIGURED', `${sum.status} ${sumJson.error?.code}`);
  const foreign = await fetch(`${BASE}api/summaries`, { method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://evil.example' }, body });
  check('requests from another origin are rejected', foreign.status === 403, String(foreign.status));
  const notAudio = await fetch(`${BASE}api/transcriptions?lang=fa&duration=3`, { method: 'POST', headers: { 'content-type': 'audio/webm', origin: ORIGIN }, body: 'this is not audio' });
  check('transcription endpoint refuses (not configured or not audio)', notAudio.status >= 400 && notAudio.status < 600, String(notAudio.status));
  const page404 = await fetch(`${BASE}api/jobs/does-not-exist`);
  check('unknown job id returns 404', page404.status === 404);
  const headers = (await fetch(BASE)).headers;
  check('security headers are sent', (headers.get('content-security-policy') || '').includes("default-src 'self'") && headers.get('x-content-type-options') === 'nosniff');
}

const browser = await chromium.launch({
  executablePath: chromiumPath(),
  args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required'],
});
const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, locale: 'fa-IR', timezoneId: 'America/Santiago', acceptDownloads: true });
await context.grantPermissions(['microphone', 'notifications'], { origin: ORIGIN });
const page = await context.newPage();
const pageErrors = [];
page.on('pageerror', (e) => pageErrors.push(String(e)));

try {
  await page.clock.install();
  await page.goto(BASE);
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('radio', { name: /شروع پیشنهادی/ }).click();
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('button', { name: 'ساخت داشبورد من' }).click();
  await page.locator('.dash-grid .mod').first().waitFor({ timeout: 20000 });
  const tasksCard = page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'کارها و قرارها' }) }).first();

  // ── 2. Voice input: consent first, then an honest result (headless has no speech service).
  await tasksCard.getByRole('button', { name: /گفتن فرمان|دیکته با صدا/ }).first().click();
  const consent = page.locator('dialog.modal', { hasText: 'پیش از اولین استفاده از میکروفن' });
  await consent.waitFor({ timeout: 5000 });
  check('microphone asks for consent before first use', true);
  await consent.getByRole('button', { name: 'متوجه شدم، شروع' }).click();
  await page.waitForTimeout(2500);
  const listening = await page.locator('.vi.is-listening').count();
  const micMsg = await tasksCard.locator('.field-err, .vi-error, [role="alert"]').allInnerTexts();
  check('voice input either listens or explains why it cannot', listening > 0 || micMsg.join(' ').length > 0, listening ? 'listening' : micMsg.join(' ').slice(0, 90));
  if (listening) await page.getByRole('button', { name: 'لغو' }).first().click().catch(() => undefined);
  await page.screenshot({ path: `${OUT}/09-voice.png` });

  // ── 3. Reminder fires on time while the app is open.
  const due = await page.evaluate(() => {
    const d = new Date(Date.now() + 2 * 60_000);
    const parts = new Intl.DateTimeFormat('en-GB', { timeZone: 'America/Santiago', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(d);
    return parts;
  });
  await tasksCard.locator('input.vi-input').fill(`امروز ساعت ${due} تماس آزمایشی`);
  await tasksCard.locator('input.vi-input').press('Enter');
  const dialog = page.locator('dialog.modal');
  await dialog.waitFor();
  // Before 1 p.m. a typed hour could mean morning or evening and the app asks (it never guesses):
  // answer with the hour that was meant, so the check does not depend on the time of day it runs at.
  await page.waitForTimeout(300);
  const meant = dialog.getByRole('button', { name: new RegExp(`^${due.replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[d])}`) });
  if (await meant.count()) await meant.click();
  await dialog.getByRole('button', { name: /ثبت قرار|ثبت کار/ }).click();
  await page.waitForTimeout(500);
  await page.clock.fastForward(3 * 60_000);
  await page.locator('.toasts', { hasText: 'تماس آزمایشی' }).waitFor({ timeout: 8000 }).catch(() => undefined);
  const toasts = await page.locator('.toasts').innerText().catch(() => '');
  check('due reminder shows an in-app alert', toasts.includes('تماس آزمایشی'), toasts.replace(/\s+/g, ' ').slice(0, 100));
  await page.goto(`${BASE}#/inbox`);
  await page.waitForTimeout(800);
  check('reminder is listed in the inbox', (await page.locator('.inbox-list').innerText().catch(() => '')).includes('تماس آزمایشی'));
  await page.screenshot({ path: `${OUT}/10-inbox.png` });

  // ── 3b. Section look and title survive a reload; other sections are unaffected.
  await page.goto(BASE);
  const notesCard = page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'یادداشت‌ها' }) }).first();
  await notesCard.waitFor();
  const otherAccentBefore = await page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'موسیقی' }) }).first().getAttribute('data-accent');
  await notesCard.getByRole('button', { name: 'گزینه‌های بخش' }).click();
  await page.getByRole('menuitem', { name: 'تنظیمات و ظاهر' }).click();
  const sheet = page.locator('dialog.modal', { hasText: 'تنظیمات و ظاهر' });
  await sheet.waitFor();
  await sheet.locator('input').first().fill('دفتر ایده‌ها');
  await sheet.getByRole('radio', { name: 'سبز', exact: true }).click();
  await sheet.getByRole('radio', { name: 'فشرده' }).click();
  await sheet.getByRole('button', { name: 'ذخیره', exact: true }).click();
  await page.waitForTimeout(500);
  await page.reload();
  const renamed = page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'دفتر ایده‌ها' }) }).first();
  await renamed.waitFor({ timeout: 10000 });
  const accentAfter = await renamed.getAttribute('data-accent');
  const densityAfter = await renamed.getAttribute('data-density');
  const otherAccentAfter = await page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'موسیقی' }) }).first().getAttribute('data-accent');
  check('section title, colour and density persist after reload', accentAfter === 'green' && densityAfter === 'compact', `${accentAfter}/${densityAfter}`);
  check('other sections keep their own look', otherAccentAfter === otherAccentBefore, `${otherAccentBefore} → ${otherAccentAfter}`);

  // ── 3c. A double click on "save" creates the task only once.
  const tasks2 = page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'کارها و قرارها' }) }).first();
  await tasks2.locator('input.vi-input').fill('فردا ساعت ۱۰ صبح بررسی دوبار');
  await tasks2.locator('input.vi-input').press('Enter');
  await page.locator('dialog.modal').waitFor();
  await page.locator('dialog.modal').getByRole('button', { name: /ثبت قرار|ثبت کار/ }).dblclick();
  await page.waitForTimeout(800);
  const dupCount = await tasks2.locator('.row-title', { hasText: 'بررسی دوبار' }).count();
  check('double-clicking save records one task', dupCount === 1, `${dupCount} rows`);

  // ── 4. Export → erase → import.
  await page.goto(`${BASE}#/settings`);
  await page.getByRole('button', { name: 'خروجی JSON' }).waitFor();
  const [download] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'خروجی JSON' }).click()]);
  const file = `${OUT}/export.json`;
  await download.saveAs(file);
  const raw = readFileSync(file, 'utf8');
  const exported = JSON.parse(raw);
  check('export is a JSON file with sections and tasks', Array.isArray(exported.modules ?? exported.data?.modules) || raw.includes('"modules"'));
  check('export contains no keys or secrets', !/api[_-]?key|sk-[A-Za-z0-9]{10,}|ANTHROPIC|OPENAI/i.test(raw));

  await page.getByRole('button', { name: 'پاک کردن همه' }).click();
  const confirm = page.locator('dialog.modal', { hasText: 'پاک کردن همه داده‌های همیار' });
  await confirm.waitFor();
  const eraseBtn = confirm.getByRole('button', { name: 'پاک کردن همه' });
  check('erase stays disabled until the word is typed', await eraseBtn.isDisabled());
  await confirm.locator('input').fill('حذف');
  await eraseBtn.click();
  await page.getByText('زبان و زمان').first().waitFor({ timeout: 15000 });
  check('after erasing, the app starts from onboarding', true);

  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('radio', { name: /داشبورد خالی/ }).click();
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('button', { name: 'ساخت داشبورد من' }).click();
  await page.waitForTimeout(800);
  await page.goto(`${BASE}#/settings`);
  await page.locator('input[type="file"][accept*="json"]').setInputFiles(file);
  const preview = page.locator('dialog.modal', { hasText: 'پیش‌نمایش ورود داده' });
  await preview.waitFor({ timeout: 5000 });
  await preview.getByRole('button', { name: 'ورود داده' }).click();
  await page.waitForTimeout(1200);
  await page.goto(BASE);
  await page.waitForTimeout(1200);
  const html = await page.content();
  check('import restores sections and the task', (await page.locator('.dash-grid .mod').count()) >= 5 && html.includes('تماس آزمایشی'));
  await page.screenshot({ path: `${OUT}/11-after-import.png`, fullPage: true });
} catch (e) {
  check('flows completed without exceptions', false, String(e).slice(0, 400));
  await page.screenshot({ path: `${OUT}/zz-flows-failure.png`, fullPage: true }).catch(() => undefined);
} finally {
  check('no uncaught page errors', pageErrors.length === 0, pageErrors.slice(0, 3).join(' | '));
  await browser.close();
  server.kill();
  const bad = results.filter((r) => !r.ok);
  console.log(`\n${results.length - bad.length}/${results.length} checks passed`);
  process.exitCode = bad.length ? 1 : 0;
}
