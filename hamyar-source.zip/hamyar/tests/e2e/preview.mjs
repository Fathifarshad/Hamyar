/* global document, window -- used inside page.evaluate callbacks, which run in the browser */
// Preview check (npm run build:artifact first): serves dist-artifact/hamyar.html the way the
// claude.ai viewer wraps a page (document skeleton + strict CSP, no window.claude) and checks
// that it boots, seeds labelled examples, draws the sample PDF and logs no errors.
import { chromium } from 'playwright-core';
import { chromiumPath } from '../../scripts/chromium.mjs';
import http from 'node:http';
import { mkdirSync, readFileSync } from 'node:fs';
const dir = 'dist-artifact/';
const OUT = 'test-results';
mkdirSync(OUT, { recursive: true });
const page = readFileSync(dir + 'hamyar.html', 'utf8');
const csp = "default-src 'none'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src data: https://fonts.gstatic.com; img-src 'self' data: blob:; media-src 'self' data: blob:; connect-src 'self' data: blob:; worker-src 'self' blob:";
const html = `<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui;background:#fafafa}img{max-width:100%}[hidden]{display:none!important}</style></head><body>${page}</body></html>`;
const srv = http.createServer((q, r) => {
  if (q.url === '/' || q.url.startsWith('/?')) { r.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'content-security-policy': csp }); return r.end(html); }
  if (q.url === '/samples/hamyar-sample-fa.pdf') { r.writeHead(200, { 'content-type': 'application/pdf' }); return r.end(readFileSync(dir + 'samples/hamyar-sample-fa.pdf')); }
  if (q.url === '/favicon.ico') { r.writeHead(204); return r.end(); }
  r.writeHead(404); r.end();
}).listen(4194);
const browser = await chromium.launch({ executablePath: chromiumPath() });
const results = [];
const check = (n, ok, d = '') => { results.push(ok); console.log(`${ok ? 'PASS' : 'FAIL'}  ${n}${d ? ' — ' + d : ''}`); };
for (const [label, opts] of [['fa light 1280', { viewport: { width: 1280, height: 900 }, locale: 'fa-IR', colorScheme: 'light' }], ['fa dark 390', { viewport: { width: 390, height: 844 }, locale: 'fa-IR', colorScheme: 'dark' }]]) {
  const ctx = await browser.newContext({ ...opts, timezoneId: 'America/Santiago' });
  const pg = await ctx.newPage();
  const errors = [];
  pg.on('console', (m) => m.type() === 'error' && errors.push(m.text().slice(0, 160)));
  pg.on('pageerror', (e) => errors.push(String(e).slice(0, 160)));
  await pg.goto('http://127.0.0.1:4194/');
  await pg.locator('.dash-grid .mod').first().waitFor({ timeout: 30000 });
  await pg.waitForTimeout(2500);
  const cards = await pg.locator('.dash-grid .mod').count();
  check(`[${label}] preview opens on a filled example dashboard`, cards >= 8, `${cards} cards`);
  const overflow = await pg.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  check(`[${label}] no horizontal scroll`, overflow <= 0, `${overflow}px`);
  await pg.screenshot({ path: `${OUT}/12-preview-${label.replace(/ /g, '-')}.png`, fullPage: false });
  if (label.startsWith('fa light')) {
    const pdfCard = pg.locator('.mod', { has: pg.locator('.mod-title', { hasText: 'PDF' }) }).first();
    await pdfCard.locator('.row-main').first().click();
    await pg.locator('.pdf-canvas').waitFor({ timeout: 15000 });
    await pg.waitForTimeout(2500);
    const ink = await pg.evaluate(() => { const c = document.querySelector('.pdf-canvas'); if (!c || c.hidden || !c.width) return 0; const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let n = 0; for (let i = 0; i < d.length; i += 148) if (d[i] < 160 && d[i + 3] > 0) n++; return n; });
    check(`[${label}] sample PDF is drawn inside the preview`, ink > 50, `${ink}`);
    const sum = await pg.locator('.summary').innerText();
    check(`[${label}] summary explains it is unavailable outside claude.ai`, /در دسترس نیست|نمایش/.test(sum), sum.replace(/\s+/g, ' ').slice(0, 120));
    await pg.screenshot({ path: `${OUT}/13-preview-pdf.png` });
  }
  check(`[${label}] no console errors`, errors.length === 0, errors.slice(0, 4).join(' | '));
  await ctx.close();
}
await browser.close(); srv.close();
console.log(`\n${results.filter(Boolean).length}/${results.length} checks passed`);
process.exitCode = results.every(Boolean) ? 0 : 1;
