/* global document, window, caches -- used inside page.evaluate callbacks, which run in the browser */
// Phone web app check (npm run build:mobile first): serves dist-mobile under /hamyar/ the way
// GitHub Pages does, opens it at iPhone size, and checks install hint, offline start after the
// service worker installs, phone-specific AI messages, the calendar file and layout.
import { chromium } from 'playwright-core';
import http from 'node:http';
import { existsSync, mkdirSync, readFileSync, statSync } from 'node:fs';
import { extname, join, normalize } from 'node:path';
import { chromiumPath } from '../../scripts/chromium.mjs';

const ROOT = 'dist-mobile';
const PORT = Number(process.env.MOBILE_PORT || 4188);
const BASE = `http://127.0.0.1:${PORT}/hamyar/`;
const OUT = 'test-results';
mkdirSync(OUT, { recursive: true });

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2', '.pdf': 'application/pdf', '.bcmap': 'application/octet-stream', '.wasm': 'application/wasm' };
const server = http
  .createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    if (!url.pathname.startsWith('/hamyar/')) {
      res.writeHead(404);
      return res.end();
    }
    let file = normalize(join(ROOT, decodeURIComponent(url.pathname.slice('/hamyar/'.length)) || 'index.html'));
    if (!file.startsWith(ROOT)) {
      res.writeHead(403);
      return res.end();
    }
    if (existsSync(file) && statSync(file).isDirectory()) file = join(file, 'index.html');
    if (!existsSync(file)) {
      res.writeHead(404);
      return res.end();
    }
    res.writeHead(200, { 'content-type': TYPES[extname(file)] || 'application/octet-stream' });
    res.end(readFileSync(file));
  })
  .listen(PORT, '127.0.0.1');

const results = [];
const check = (name, ok, detail = '') => {
  results.push(ok);
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`);
};

const browser = await chromium.launch({ executablePath: chromiumPath() });
const iphoneUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1';
const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, userAgent: iphoneUA, locale: 'fa-IR', timezoneId: 'Asia/Tehran', acceptDownloads: true });
const page = await context.newPage();
const errors = [];
page.on('console', (m) => {
  if (m.type() !== 'error') return;
  const where = m.location()?.url ?? '';
  if (/open-meteo/.test(where) || /open-meteo|ERR_INTERNET_DISCONNECTED|ERR_TUNNEL/.test(m.text())) return;
  errors.push(`${m.text()} @ ${where}`);
});
page.on('pageerror', (e) => errors.push(String(e)));

try {
  await page.goto(BASE);
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('radio', { name: /شروع پیشنهادی/ }).click();
  await page.getByRole('button', { name: 'ادامه' }).click();
  await page.getByRole('switch', { name: /داده نمونه/ }).click();
  await page.getByRole('button', { name: 'ساخت داشبورد من' }).click();
  await page.locator('.dash-grid .mod').first().waitFor({ timeout: 20000 });
  await page.waitForTimeout(1500);
  check('dashboard opens under a sub-path (GitHub Pages layout)', (await page.locator('.dash-grid .mod').count()) >= 8);
  check('iPhone browser shows how to add Hamyar to the home screen', await page.locator('.install-hint').isVisible());
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  check('no horizontal scroll at 390px', overflow <= 0, `${overflow}px`);
  await page.screenshot({ path: `${OUT}/14-phone-dashboard.png` });

  const ready = await page.evaluate(async () => {
    const reg = await navigator.serviceWorker.ready;
    const keys = await caches.keys();
    const cache = await caches.open(keys.find((k) => k.startsWith('hamyar-shell-')));
    const cached = (await cache.keys()).map((r) => new URL(r.url).pathname);
    return { scope: reg.scope, keys, count: cached.length, hasWorker: cached.some((p) => p.includes('pdf.worker')) };
  });
  check('service worker installed for the app folder', ready.scope.endsWith('/hamyar/'), ready.scope);
  check('every app file is cached for offline use', ready.count > 40 && ready.hasWorker, `${ready.count} files`);

  // Medication calendar file (the dependable reminder path on iPhone)
  const medHref = await page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'داروها' }) }).first().locator('.mod-title a').getAttribute('href');
  await page.goto(BASE + medHref);
  const calBtn = page.getByRole('button', { name: 'افزودن به تقویم گوشی' });
  await calBtn.waitFor({ timeout: 10000 });
  const [download] = await Promise.all([page.waitForEvent('download'), calBtn.click()]);
  const icsPath = `${OUT}/hamyar-medications.ics`;
  await download.saveAs(icsPath);
  const ics = readFileSync(icsPath, 'utf8');
  check('medication calendar file is valid iCalendar with daily alerts', ics.startsWith('BEGIN:VCALENDAR') && ics.includes('RRULE:FREQ=DAILY') && /DTSTART:\d{8}T080000/.test(ics) && ics.includes('TRIGGER:PT0M'), download.suggestedFilename());

  // Offline start
  await context.setOffline(true);
  await page.goto(BASE);
  await page.locator('.dash-grid .mod').first().waitFor({ timeout: 15000 });
  check('app opens with no internet after the first visit', true);
  const pdfCard = page.locator('.mod', { has: page.locator('.mod-title', { hasText: 'PDF' }) }).first();
  await pdfCard.locator('.row-main').first().click();
  await page.locator('.pdf-canvas').waitFor({ timeout: 15000 });
  await page.waitForTimeout(2000);
  const summary = await page.locator('.summary').innerText();
  check('PDF opens offline and explains that summaries need the computer version', summary.includes('نسخه گوشی'), summary.replace(/\s+/g, ' ').slice(0, 90));
  await page.screenshot({ path: `${OUT}/15-phone-pdf-offline.png` });
  await context.setOffline(false);

  // Dark theme and narrow phones
  await page.goto(`${BASE}#/settings`);
  await page.getByRole('radio', { name: 'تیره' }).click();
  await page.setViewportSize({ width: 360, height: 780 });
  await page.goto(BASE);
  await page.locator('.dash-grid .mod').first().waitFor();
  await page.waitForTimeout(800);
  const overflow360 = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  check('no horizontal scroll at 360px (dark)', overflow360 <= 0, `${overflow360}px`);
  await page.screenshot({ path: `${OUT}/16-phone-dark-360.png` });
  await page.goto(`${BASE}#/settings`);
  await page.waitForTimeout(600);
  const settingsText = await page.locator('.settings-page').innerText();
  check('settings explain the iPhone reminder limit and the calendar option', settingsText.includes('محدودیت آیفون') && settingsText.includes('تقویم'));
  await page.screenshot({ path: `${OUT}/17-phone-settings.png`, fullPage: true });
} catch (e) {
  check('mobile run completed without exceptions', false, String(e).slice(0, 300));
  await page.screenshot({ path: `${OUT}/zz-mobile-failure.png`, fullPage: true }).catch(() => undefined);
} finally {
  check('no console errors', errors.length === 0, errors.slice(0, 4).join(' | '));
  await browser.close();
  server.close();
  console.log(`\n${results.filter(Boolean).length}/${results.length} checks passed`);
  process.exitCode = results.every(Boolean) ? 0 : 1;
}
